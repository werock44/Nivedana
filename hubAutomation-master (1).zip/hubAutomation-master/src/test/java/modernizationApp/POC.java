package modernizationApp;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import utils.BrowserFactory;
import utils.ConfigDataProvider;

@Test
public class POC {
	static WebDriver driver;

	public static void poc_modernizationApp() throws Exception {
		ConfigDataProvider configuration = new ConfigDataProvider();
		String Browser = configuration.getBrowser();
		String url = configuration.getURL("ModernizationAppurl");
		driver = BrowserFactory.openbrowser(Browser, url);

		
		/*System.setProperty("webdriver.edge.driver","C:\\SeleniumWorkspace\\hubAutomation\\Drivers\\MicrosoftWebDriver.exe");
		 driver = new ChromeDriver(options); 
		driver = new EdgeDriver();
		driver.get("https://modernizationportal.stage.cglcloud.in/"); */
		 // Set the driver path
	      /* System.setProperty("webdriver.edge.driver", "C:\\Hub2.OAutomation\\hubAutomation\\Drivers\\MicrosoftWebDriver.exe");
	       // Start Edge Session
	       driver = new EdgeDriver();*/
		
	if(Browser.equalsIgnoreCase("chrome")){
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//driver.get("https://modernizationportal.stage.cglcloud.in/");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("arindam-nath@crgl-thirdparty.com");
		//driver.findElement(By.xpath("//input[@type='email']")).sendKeys("arindam_nath@crgl-thirdparty.com");
		driver.findElement(By.id("idSIButton9")).click();
		Reporter.log("Login Sucessfull");
		driver.findElement(By.xpath("//div[text()='Application Search']")).click();
		Reporter.log("Clicked on Application search.");
	}else if(Browser.equalsIgnoreCase("Edge")){
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[text()='Application Search']")).click();
		Reporter.log("Clicked on Application search.");
	}
		
		
		driver.findElement(By.xpath("(//input[@class='ag-floating-filter-input'])[1]")).sendKeys("ABA Tracker");
		Reporter.log("Entered the Aplication name to be searched.");
		Thread.sleep(4000);
		boolean AppPresent=driver.findElement(By.xpath("//a[contains(text(),'ABA Tracker')]")).isDisplayed();
		if(AppPresent==true){
			Reporter.log("Application search is successfull.");
		}
		driver.findElement(By.xpath("//a[contains(text(),'ABA Tracker')]")).click();
		Reporter.log("Cliked on Application Name.");
		Thread.sleep(3000);
		Select assessmentStatus = new Select(driver.findElement(By.xpath("(//select)[1]")));
		assessmentStatus.selectByValue("Assessment Complete");
		Reporter.log("Selected Assesment status.");
		Select RFactorAssessment = new Select(driver.findElement(By.xpath("(//select)[2]")));
		RFactorAssessment.selectByValue("Workshop Candidate");
		Reporter.log("Selected R factor assessment");
		driver.findElement(By.xpath("//a[text()=' Assessment']")).click();
		Reporter.log("Clicked on Assessment tab.");
		driver.findElement(By.xpath("//a[text()=' Modernization Gaps and Dependencies']")).click();
		Reporter.log("Clicked on 'Modernization Gaps and Dependencies'");
		driver.findElement(By.xpath("//textarea[@placeholder='Gaps and Dependencies']")).clear();
		driver.findElement(By.xpath("//textarea[@placeholder='Gaps and Dependencies']")).sendKeys("Automation");
		Reporter.log("Entered text in the text area field.");
			
		// Save button
		//driver.findElement(By.xpath("//button[text()='Save Application']")).click();
		//Contacts tab
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()=' Contacts']")).click();
		Reporter.log("Clicked on 'Contacts tab.");
		driver.findElement(By.xpath("//label[text()='Application BRM']//parent::div//parent::div/following-sibling::div/input")).clear();
		driver.findElement(By.xpath("//label[text()='Application BRM']//parent::div//parent::div/following-sibling::div/input")).sendKeys("Sekson Tosriplub");
		
		driver.findElement(By.xpath("//label[text()='Assessment SME(s)']//parent::div//parent::div/following-sibling::div/input")).clear();
		driver.findElement(By.xpath("//label[text()='Assessment SME(s)']//parent::div//parent::div/following-sibling::div/input")).sendKeys("Jason Yap");
		driver.findElement(By.xpath("//label[text()='Portfolio Architect(s)']//parent::div//parent::div/following-sibling::div/input")).clear();
		driver.findElement(By.xpath("//label[text()='Portfolio Architect(s)']//parent::div//parent::div/following-sibling::div/input")).sendKeys("POC1");
		
		driver.findElement(By.xpath("//label[text()='Product Owner(s)']//parent::div//parent::div/following-sibling::div/input")).clear();
		driver.findElement(By.xpath("//label[text()='Product Owner(s)']//parent::div//parent::div/following-sibling::div/input")).sendKeys("POC2");
		
		driver.findElement(By.xpath("//label[text()='Application Service Delivery Advisor(s)']//parent::div//parent::div/following-sibling::div/input")).clear();
		driver.findElement(By.xpath("//label[text()='Application Service Delivery Advisor(s)']//parent::div//parent::div/following-sibling::div/input")).sendKeys("POC3");
		
		driver.findElement(By.xpath("//label[text()='Technical SME/Architect(s)']//parent::div//parent::div/following-sibling::div/input")).clear();
		driver.findElement(By.xpath("//label[text()='Technical SME/Architect(s)']//parent::div//parent::div/following-sibling::div/input")).sendKeys("POC4");
		Reporter.log("Entered values in all the fields.");
		
		Select enterPrise=new Select(driver.findElement(By.xpath("(//select)[12]")));
		//enterPrise.selectByValue("Chung Yu (FIBI)");
		List<WebElement> list=enterPrise.getOptions();
		int listsize=list.size();
		
		for(int i=0; i<listsize; i++){
			String value=enterPrise.getOptions().get(i).getText();
			System.out.println(value);
			//if(value.equals("Antonia Van Der Holst (CASC)")){
				enterPrise.deselectByIndex(i);
				enterPrise.selectByIndex(i);
			/*	break;
			}*/			
		}
		Reporter.log("Selected values from Enterprise Architect(s) list one by one.");
		// Save button
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='Save Application']")).click();
		Reporter.log("Saved the application.");
		//All Attribute
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='All Attributes']")).click();
		Reporter.log("Clicked on All Attribute button.");
		String header1=driver.findElement(By.xpath("//div[@role='dialog']/div/div[@class='modal-header']")).getText();
		Reporter.log("Header of the pop up is: " +header1);
		System.out.println(header1);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Close']")).click();
		Reporter.log("Closed All Attribute popup.");
		Thread.sleep(2000);
		
		//More Tab
		
		driver.findElement(By.xpath("//a[text()=' More...']")).click();	
		Reporter.log("Clicked on More tab.");
		driver.findElement(By.xpath("//*[@id='ngb-tab-12-panel']/app-attachments-tab/div/div/div[1]/input")).sendKeys("Description");
		Reporter.log("Type value in description field.");
		String filePathToUpload="C:\\Users\\A196031\\Documents\\POC.docx";
		driver.findElement(By.id("upload")).sendKeys(filePathToUpload);	
		Reporter.log("Selecting the file to be uploaded");
		driver.findElement(By.xpath("//button[text()='Upload ']")).click();
		Thread.sleep(3000);
		Reporter.log("File uploaded sucessfully.");
		
		//Notes Section:
		driver.findElement(By.xpath("//a[text()=' Notes']")).click();
		Reporter.log("Clicked on Notes tab.");
		driver.findElement(By.xpath("//button[text()='New Note']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[starts-with(@class,'editor-title-bar')]/input")).sendKeys("Typing Notes header by automation");
		Reporter.log("Entering text in the text header.");
		driver.switchTo().frame(driver.findElement(By.xpath("//*[@class='tox-edit-area__iframe']")));
		WebElement el1=driver.switchTo().activeElement();
		Actions act=new Actions(driver);
		act.moveToElement(el1).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//html/body/p")).sendKeys("Entering data by automation");
		//For Edge
		/*WebElement editorBody=driver.findElement(By.xpath("//html/body/p"));
		//JavascriptExecutor jse = (JavascriptExecutor)driver;
		(JavascriptExecutor)driver.executeScript("document.evaluate(xpathExpresion, document, null, 9, null).singleNodeValue.innerHTML="+ DesiredText);
		 jse.executeScript("arguments[0].value='Entering data by automation';", editorBody);*/
		
		Reporter.log("Entering text in the text area field.");
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//button[text()='Save Note']")).click();
		Reporter.log("Notes saved sucessfully.");
		Thread.sleep(6000);
		driver.quit();
	}
	
	
	
	}
	


