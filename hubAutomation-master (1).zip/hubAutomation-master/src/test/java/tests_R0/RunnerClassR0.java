package tests_R0;

import org.testng.TestNG;

public class RunnerClassR0 {
	
	static TestNG testNg;

	public static void main(String[] args) {
		
		testNg= new TestNG();
		
		testNg.setTestClasses(new Class[] {TC_815A_FieldLevelValidation1.class});
		testNg.run();
	
		
	}

}
