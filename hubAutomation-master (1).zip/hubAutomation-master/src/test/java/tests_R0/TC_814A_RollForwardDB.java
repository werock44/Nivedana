package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form814ARollForwardDBPage;
import utils.Login;

public class TC_814A_RollForwardDB {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String period;

	@BeforeClass
	public void LaunchApp() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("814A RollForward DB Validation");
		//driver = Login.LaunchHub("Setupurl", Logs);
	}
	
	@BeforeMethod
		public static void Login() throws Exception{
		driver = Login.LaunchHub("Setupurl", Logs);
	}


	
	 //This test case could be executed when previous year last quarter is available.
	
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void statusOfResRollFwPrevYr(String TestType) throws Exception {
		Form814ARollForwardDBPage.statusOfResPrevFY(driver, Logs, TestType, "814ADB");
		
	}
	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void statusOfResRollFwCurreYrQ1ToQ2(String TestType) throws Exception {
		Form814ARollForwardDBPage.statusOfResCurrentFYQ1ToQ2(driver, Logs, TestType, "814ADB");
		
	}
	
	//This test will be executed when Q3 and Q4 is available for current year
	
	@Test(enabled=false)
	@Parameters({ "TestType" })
	public static void statusOfResRollFwCurreYrQ3ToQ4(String TestType) throws Exception {
		Form814ARollForwardDBPage.statusOfResCurrentFYQ3ToQ4(driver, Logs, TestType, "814ADB");
		

	}
	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void verifyExpectedPercBenifit_CR_TC003(String TestType) throws Exception {
		Form814ARollForwardDBPage.verifyExpectedPercBenifit(driver, Logs, TestType, "814ADB");
		
	}
		
	//Change request
		@Test(priority=2)
		@Parameters({ "TestType" })
		public static void verifyVariancefield_CR_TC004(String TestType) throws Exception{
			Form814ARollForwardDBPage.verifyVariancefield(driver, Logs,TestType, "814A");
		}

		@Test(priority=1)
		@Parameters({ "TestType" })
		public static void verifyAbleToSubmitWithVarianceNonZero_CR_TC006(String TestType) throws Exception {
			Form814ARollForwardDBPage.verifyAbleToSubmitWithVarianceNonZero(driver, Logs, TestType, "814ADB");
			
		}
		
	
	@AfterMethod
	public void QuitBrowser(){
		driver.quit();
	}

	
}
