package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form816APage;
import pages.Form816APage_WithoutAllData;
import pages.Form816ARollForwardDBPage;
import pages.HubContributorFormPage;
import utils.Login;
import utils.Util;

public class TC_816_RollForwardDB {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String period;

	@BeforeSuite
	public void LaunchApp() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("816A RollForward DB Validation");
		//driver = Login.LaunchHub("Setupurl", Logs);
	}
	
	@BeforeMethod
		public static void Login() throws Exception{
		driver = Login.LaunchHub("Setupurl", Logs);
	}

	//@BeforeTest
	//This has been accommodated in each test case since period is different for each test
	
	/*@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		schedule = Util.getAllNecessaryData(TestType, "816ADB", "ScheduleName");
		entityName = Util.getAllNecessaryData(TestType, "816ADB", "EntityDetail");
		period = Util.getAllNecessaryData(TestType, "816ADB", "Period");
		HubContributorFormPage.openScheduleRollFwDB(driver, entityName, period, schedule, Logs);
		//Form816APage.fillForm816A(driver);// its included in opensheduleRoll

	}*/

	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void begBalanceRollFw(String TestType) throws Exception {
		Form816ARollForwardDBPage.begBalEndBalRollFwPrevYr(driver, Logs, TestType, "816ADB");
		
	}
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void rollFWofFieldsForSameFY(String TestType) throws Exception {
		Form816ARollForwardDBPage.rollFWofFieldsForSameFY(driver, Logs, TestType, "816ADB");		
	}	
	
	
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void endingBalRollFWPrevYear_Zero(String TestType) throws Exception {
		Form816ARollForwardDBPage.endingBalRollFw_ZeroFromPrvYear(driver, Logs, TestType, "816ADB");	
	}
	
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void endingBalRollFWCurrYr_Zero(String TestType) throws Exception {
		Form816ARollForwardDBPage.endingBalRollFWCurrFY_Zero(driver, Logs, TestType, "816ADB");	
	}
	
	@AfterMethod
	public void QuitBrowser(){
		driver.quit();
	}

	
}
