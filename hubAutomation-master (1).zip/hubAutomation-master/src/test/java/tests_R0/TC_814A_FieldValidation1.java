package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form814APage;
import pages.HubContributorFormPage;
import pages.HubHomePage;
import utils.HubContributor;
import utils.Login;
import utils.Util;
/*author v265130
Vivek Keshav
*/
public class TC_814A_FieldValidation1 {
	static WebDriver driver;
	static DriverScript Logs; 
	public static String schedule;
	public static String entityName;
	public static String period;
	/*@BeforeSuite
	public void LaunchApp() throws Exception {
		
	}*/
	
	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception{
		//LaunchApp
		Logs =new DriverScript();
		Logs.driveTestExecution("814A Field Level Validation");	
		driver  = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "814A", "ScheduleName");	
		period = Util.getAllNecessaryData(TestType, "814A", "Period");
		//String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", period);
		String bugoID="BU135GOAU";
		System.out.println(bugoID);
		//String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				//+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		//String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		String entityCode="7027";
		System.out.println(entityCode);
		//Code to distribute schedule and get entity code
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
			
		HubContributorFormPage.openSchedule(driver, entityCode, period, schedule, Logs);
		Form814APage.fillForm814A(driver);
	}
	@Test(priority=0)	
	@Parameters({ "TestType" })
	public static void statusOfReserve(String TestType) throws Exception{
		Form814APage.statusOfReserveField814(driver, Logs, TestType, "814A");
	}
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void TaxBenifitField(String TestType) throws Exception{
		Form814APage.taxBenifitFiledField(driver, Logs, TestType, "814A");
	}
	/*@Test(priority=2)
	@Parameters({ "TestType" })
	public static void PotentialInterestField(String TestType) throws Exception{
		Form814APage.potentialInterestField(driver, Logs, TestType, "814A");
	}
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void recognition_ThresholdField(String TestType) throws Exception{
		Form814APage.recognitionThresholdField(driver, Logs, TestType, "814A");
	}	
	
	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void accuredInterestPenalitiesField(String TestType) throws Exception{
		Form814APage.accuredInterestPenalities(driver, Logs,TestType, "814A");
	}
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void unrecognized_TaxBenefitField(String TestType) throws Exception{
		Form814APage.unrecognizedTaxBenefitField(driver, Logs,TestType, "814A");
	}
	@Test(priority=6)
	@Parameters({ "TestType" })
	public static void GLAccountReserveFieldValidation(String TestType) throws Exception{
		Form814APage.GLAccountReserveField(driver, Logs,TestType, "814A");
	}
	@Test(priority=7)
	@Parameters({ "TestType" })
	public static void GLAccountRecordedFieldValidation(String TestType) throws Exception{
		Form814APage.GLAccountRecordedField(driver, Logs,TestType, "814A");
	}
	@Test(priority=8)
	@Parameters({ "TestType" })
	public static void expected_PercentageBenefitField(String TestType) throws Exception{
		Form814APage.expectedPercentageBenifitField(driver, Logs,TestType, "814A");
	}
	*/
	
	
	@AfterClass
	public void QuitBrowser(){
		driver.quit();
	}
}


