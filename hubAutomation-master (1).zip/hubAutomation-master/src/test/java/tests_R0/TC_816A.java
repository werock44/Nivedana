package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.HubHomePage;
import utils.Login;
import utils.Util;

public class TC_816A {
	static WebDriver driver;
	static DriverScript Logs; 
	
	
	@BeforeSuite
	public void LaunchApp() throws Exception {
		Logs =new DriverScript();
		Logs.driveTestExecution("Schedule Distribution");
		driver  = Login.LaunchHub("Setupurl", Logs);
	}
	
	
		
	@Test(priority=1)
	@Parameters({ "TestType" })
	public void distribute_Schedule(String TestType) throws Exception{	
	String schedule = Util.getAllNecessaryData(TestType, "816A", "ScheduleName");	
	String entityType = Util.getAllNecessaryData(TestType, "816A", "EntityType");
	HubHomePage.clickAdminLinkAndSwitchPage(driver, Logs);
	HubHomePage.selectScheduleValue(driver, TestType, schedule, entityType, Logs);
	
	
    }
	@AfterSuite
	public void QuitBrowser(){
		driver.quit();
	}
}
