package tests_R0;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubContributorFormObj;
import pages.Form815APage;
import pages.Form816APage;
import pages.HubContributorFormPage;
import utils.HubContributor;
import utils.Login;
import utils.ReadXML;
import utils.Util;

/*
Author - Prasannajit(p674532)
 */
public class TC_815A_FieldLevelValidation1 {

	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String period;
	HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();

	/*@BeforeSuite
	public void LaunchApp() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("815A Field Level Validation");
		driver = Login.LaunchHub("Setupurl", Logs);
	}*/

	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("815A Field Level Validation");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "815A", "ScheduleName");//from excel
		period = Util.getAllNecessaryData(TestType, "815A", "Period");
		String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "604D7F93-7239-482B-9A93-ECC4107FC6FA", period);
		System.out.println(bugoID);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		//String entityCode="7903";
		System.out.println(entityCode);
		//Code to distribute schedule and get entity code
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openSchedule(driver, entityCode, period, schedule, Logs);
		Form815APage.enterTransactionTaxAllData(TestType, driver, Logs);
			
	}

	@Test(priority=0)
	@Parameters({ "TestType" })
	public void Field_Validation(String TestType) throws Exception {

Form815APage.scenarioAnalysisLocalFields(driver, Logs, TestType, "815A");
		Form815APage.scenarioAnalysisInterestAndPenaltiesFields(driver, Logs, TestType, "815A");
		Form815APage.endingBalanceField815(driver, Logs, TestType, "815A");
	}


	@Test(priority = 1)
	@Parameters({ "TestType" })
	public void Field_Validation_BeginningBalance(String TestType) throws Exception {
		Form815APage.begBalance(driver, Logs, TestType, "815A");

	}


	@Test(priority = 2)
	@Parameters({ "TestType" })
	public void Field_Validation_ChargePL(String TestType) throws Exception {
		Form815APage.charge_to_PL_Field(driver, Logs, TestType, "815A");

	}

	@Test(priority = 3)
	@Parameters({ "TestType" })
	public void Field_Validation_UseForIntended(String TestType) throws Exception {

		Form815APage.useForIntended(driver, Logs, TestType, "815A");

	}


	@Test(priority = 4)
	@Parameters({ "TestType" })
	public static void returnToPLField(String TestType) throws Exception {
		Form815APage.return_to_PL_Field(driver, Logs, TestType, "815A");

	}


	@Test(priority = 5)
	@Parameters({ "TestType" })
	public static void translationField(String TestType) throws Exception {
		Form815APage.translation(driver, Logs, TestType, "815A");

	}

	@Test(priority = 6)
	@Parameters({ "TestType" })
	public static void reclass(String TestType) throws Exception {
		Form815APage.reClass(driver, Logs, TestType, "815A");

	}


	// Not yet implemented as confirmed by Manual testing team . Hence  this test is disabled 
	/*@Test(enabled = false)
	@Parameters({ "TestType" })
	public static void verifyUSDExchangeRate(String TestType) throws Exception {
		Form815APage.verifyExchangeRate(driver, Logs, TestType, "815A");
	}*/
	

	@Test(priority = 7)
	@Parameters({ "TestType" })
	public static void statusOFReserveField(String TestType) throws Exception{
		Form815APage.statusOfReserveField815(driver, Logs, TestType,"815A"); 	
	}
	
	// Change Request - 02-Dec-2019
	@Test(priority = 8)
	@Parameters({ "TestType" })
	public static void valueOfStatusfield(String TestType) throws Exception{
		Form815APage.valueOfStatuseField815(driver, Logs, TestType,"815A"); 	
	}
	
	

	@AfterClass
	public void QuitBrowser(){
		//driver.quit();
	}
}
