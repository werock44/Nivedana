package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form814APage;
import pages.HubContributorFormPage;
import utils.HubContributor;
import utils.Login;
import utils.Util;
/*author v265130
Vivek Keshav
*/
public class TC_814A_FieldValidation2Default {
	static WebDriver driver;
	static DriverScript Logs; 
	public static String schedule;
	public static String entityName;
	public static String period;
	/*@BeforeSuite
	public void LaunchApp() throws Exception {
		
	}*/
	
	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception{
		Logs =new DriverScript();
		Logs.driveTestExecution("814A Default Values verification");	
		driver  = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "814A", "ScheduleName");	
		period = Util.getAllNecessaryData(TestType, "814A", "Period");
		String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", period);
		System.out.println(bugoID);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		System.out.println(entityCode);
		//Code to distribute schedule and get entity code
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
					HubContributorFormPage.openSchedule(driver, entityCode, period, schedule, Logs);
	}
	
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void taxBenefitFiledFieldDefault(String TestType) throws Exception{
		Form814APage.taxBenifitFiledField_Default(driver, Logs, TestType, "814A");
	}
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void PotentialInterestFieldDefalut(String TestType) throws Exception{
		Form814APage.PotentialInterestField_Defalut(driver, Logs, TestType, "814A");
	}
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void unrecognizedTaxBenefitFieldDefault(String TestType) throws Exception{
		Form814APage.unrecognizedTaxBenefitField_Default(driver, Logs, TestType, "814A");
	}
	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void accuredInterestPenalitiesDefault(String TestType) throws Exception{
		Form814APage.accuredInterestPenalities_Default(driver, Logs, TestType, "814A");
	}
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void GLAccountRecordedAccuredInterestDefault(String TestType){
		Form814APage.GLAccountRecordedAccuredInterest_Default(driver, Logs, TestType, "814A");
	}
	@AfterClass
	public void QuitBrowser(){
		driver.quit();
	}
}
