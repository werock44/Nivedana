package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form816APage;
import pages.Form816APage_WithoutAllData;
import pages.HubContributorFormPage;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_816_FieldValidation1 {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String period;

	/*@BeforeSuite
	public void LaunchApp() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("816A Field Level Validation");
		driver = Login.LaunchHub("Setupurl", Logs);
	}*/

	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("816A Field Level Validation");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "816A", "ScheduleName");//from excel
		period = Util.getAllNecessaryData(TestType, "816A", "Period");
		//select scheduleID from config.schedule where schedulecode='816A' // to get shedule id for 816
		//String bugoID="BU275GOAR";
		String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "EA8B8BA4-B64E-4023-B952-38BC3880E716", period);
		System.out.println(bugoID);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		System.out.println(entityCode);
		//String entityCode="7913";
		//Code to distribute schedule and get entity code
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		//entityName = Util.getAllNecessaryData(TestType, "816A", "EntityDetail");		
		HubContributorFormPage.openSchedule(driver, entityCode, period, schedule, Logs);
		Form816APage.fillForm816A(driver);

	}

	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void statusOfReserve(String TestType) throws Exception {
		Form816APage.statusOfReserveField816(driver, Logs, TestType, "816A");
	}

	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void begBalance(String TestType) throws Exception {
		Form816APage.begBalance(driver, Logs, TestType, "816A");
		
	}
	
	
	@Test(priority=2)
	@Parameters({ "TestType" })
	public static void chargeToPLField(String TestType) throws Exception {
		Form816APage.charge_to_PL_Field(driver, Logs, TestType, "816A");
	}
	
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void returnToPLField(String TestType) throws Exception {
		Form816APage.return_to_PL_Field(driver, Logs, TestType, "816A");
	}
	
	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void translationTest(String TestType) throws Exception {
		Form816APage.translation(driver, Logs, TestType, "816A");
		
	}
	
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void reClass(String TestType) throws Exception {
		Form816APage.reClass(driver, Logs, TestType, "816A");
		
	}
	
	@Test(priority=6)
	@Parameters({ "TestType" })
	public static void useForIntended(String TestType) throws Exception {
		Form816APage.useForIntended(driver, Logs, TestType, "816A");
		
	}

	
	@Test(priority=7)
	@Parameters({ "TestType" })
	public static void technicalAccountingCOE(String TestType) throws Exception{
		Form816APage.technicalAccountingCOEField(driver, Logs, TestType, "816A");
	}
	
	@Test(priority=8)
	@Parameters({ "TestType" })
	public static void endingBalance_Field(String TestType) throws Exception{
		Form816APage.endingBalanceField(driver, Logs, TestType, "816A");
	}
	
	@Test(priority=9)
	@Parameters({ "TestType" })
	public static void explanationOfReclassificationsField(String TestType) throws Exception{
		Form816APage.explanationOfReclassifications(driver, Logs, TestType, "816A");
	}
	
	
	@AfterClass
	public void QuitBrowser(){
		driver.quit();
	}

	
}
