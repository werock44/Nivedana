package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form1590GPages;
import pages.HubContributorFormPage;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_1590G_SheduleTest_WithSubmit {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityLongDesc;

	/**Difference here is distribution is happening in @BeforeMethod since we need new
	 *record each time*/

	@BeforeClass
	public void initializeLogs() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("814A RollForward DB Validation");
		}
	
	@BeforeMethod
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "1590G", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "1590G", "Period");
		String bugoID=HubContributor.getBugoID_NON_US(driver, Logs, TestType, "854BC4F7-0FFF-4FC2-838B-999B0D4FB445", period);
		//String bugoID="BU522GOPK";
		System.out.println(bugoID);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		System.out.println(entityCode);
		//entityCode="7903";
		/**Distribute schedule and get entity code**/
		String queryToGetLongDesc="select entityLongDesc from masterdata.entity where entityCode="+"'"+bugoID+"'";
		entityLongDesc =DataBaseConnection.getData(driver, Logs, TestType, queryToGetLongDesc, "entityLongDesc");
		HubContributor.distributeScheduleYearly_Fiscal(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		//entityName = Util.getAllNecessaryData(TestType, "1590G", "EntityDetail");		
		//HubContributorFormPage.openSchedule(driver, entityCode, period, schedule, Logs);
		/**Uncomment above distribution lines**/
	}
	
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void verifyMutlipleRowAddOrRemove_TC19_TC20(String TestType) throws Exception {
	Form1590GPages.verifyMutlipleRowAddOrRemove(driver, entityCode, period, schedule, Logs,TestType);
		
	}
	
	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void verifyCrglUSBU_Zero_TC14(String TestType) throws Exception {
	Form1590GPages.verifyCrglUSBU_Zero(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);
		
	}
	
	@Test(priority=2)
	@Parameters({ "TestType" })
	public static void verifySameProductIsSoldInBoth_TC15(String TestType) throws Exception {
	Form1590GPages.verifySameProductIsSoldInBoth(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);
		
	}
	
	
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void verifyThirdParty_Zero_TC28_TC29(String TestType) throws Exception {
	Form1590GPages.verifyThirdParty_Zero(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);
		
	}
	
	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void verifyMutlipleRowNonCargillRevAdd_TC21(String TestType) throws Exception {
	Form1590GPages.verifyMutlipleRowNonCargillRevAdd(driver, entityCode, period, schedule, Logs,TestType);
		
	}
	
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void verifyMutlipleRowUSCargillRevAdd_TC22(String TestType) throws Exception {
	Form1590GPages.verifyMutlipleRowUSCargillRevAdd(driver, entityCode, period, schedule, Logs,TestType);
		
	}
	
	@Test(priority=6)
	@Parameters({ "TestType" })
	public static void verifyCargillAndNonCargillRevAdd_TC23(String TestType) throws Exception {
	Form1590GPages.verifyCargillAndNonCargillRevAdd(driver, entityCode, period, schedule, Logs, TestType);
		
	}
	
	@AfterMethod
	public void QuitBrowser(){
		driver.quit();
	}

	
}
