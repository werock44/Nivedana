package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import Reports.DriverScript;
import pages.Form1798DPage;
import pages.Form814APage;
import pages.HubContributorFormPage;
import pages.HubHomePage;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_1798D_ScheduleTests {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityCode;
	public static String bugoID;
	public static String period;
	
	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		// LaunchApp
		Logs = new DriverScript();
		Logs.driveTestExecution("1798D Suite execution report");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "1798D", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "1798D", "Period");
		
		bugoID=HubContributor.getBugoID(driver, Logs, TestType,
				"F9020350-47FE-42FF-93DB-57FE05151A34", period);
		System.out.println(bugoID); String QueryToGetentityCode=
				"select  top 1 entitycode from masterdata.entity where " +
						"bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		/*entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType,
				QueryToGetentityCode, "entitycode"); */
		
		entityCode="7902";
		System.out.println(entityCode); //Code to distribute schedule and get entity code 
				//HubContributor.distributeSchedule(driver, Logs, TestType,bugoID, schedule, period); 
				driver.quit(); 
							
			}
	
	@BeforeMethod
	public static void lauchBrowser() throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);

	}

	@Test(priority = 0)
	@Parameters({ "TestType" })
	public static void verifyDistributedSchedule_TC01(String TestType) throws Exception {
		Form1798DPage.verifyscheduleDistribution(driver, Logs, TestType, entityCode, schedule, period, "1798D");
		
	}
	
	@Test(priority = 1)
	@Parameters({ "TestType" })
	public static void verifyReportingUnit_TC02_TC03_TC40(String TestType) throws Exception {
		String QueryToGetReportingUnit="select  EntityShortDesc from masterdata.entity where entitycode='"+entityCode+"'";
		String expectedReportingUnit=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetReportingUnit, "EntityShortDesc");
		Form1798DPage.verifyReportingUnit(driver, Logs, TestType, entityCode, schedule, period, "1798D",expectedReportingUnit);
		
	}
	//TC04 and TC05 are descoped.
	
	@Test(priority = 2)
	@Parameters({ "TestType" })
	public static void verifySectionB_TC06_TC07_TC08(String TestType) throws Exception {
		Form1798DPage.verifySectionB(driver, Logs, TestType, entityCode, schedule, period, "1798D");
		
	}
	
	@Test(priority = 3)
	@Parameters({ "TestType" })
	public static void verifySectionCMandatoryfields_TC09_TC10_TC12_TC13(String TestType) throws Exception {
		Form1798DPage.verifySectionC(driver, Logs, TestType, entityCode, schedule, period, "1798D");
		
	}
	
	@Test(priority = 4)
	@Parameters({ "TestType" })
	public static void verifySectionEdit_TC14_TC15_TC16_TC17_TC18_TC19(String TestType) throws Exception {
		Form1798DPage.verifySectionEditSectionC(driver, Logs, TestType, entityCode, schedule, period, "1798D");
			
	}
	
	
	@Test(priority = 5)
	@Parameters({ "TestType" })
	public static void verifySubmitAndRecall_TC20_TC21_TC22_TC23(String TestType) throws Exception {
		Form1798DPage.verifySubmitAndRecall(driver, Logs, TestType, entityCode, schedule, period, "1798D");
			
	}
	
	
	@Test(priority = 6)
	@Parameters({ "TestType" })
	public static void verifyEditAfterSubmit_TC34(String TestType) throws Exception {
		Form1798DPage.verifyEditAfterSubmit(driver, Logs, TestType, entityCode, schedule, period, "1798D");
			
	}
	
	
	@Test(priority = 7)
	@Parameters({ "TestType" })
	public static void verifyEditAfterSubmitpriorduedate_TC35(String TestType) throws Exception {
		Form1798DPage.verifyEditAfterSubmitBeforeduedate(driver, Logs, TestType, entityCode, schedule, period, "1798D");
			
	}
	
	@Test(priority = 8)
	@Parameters({ "TestType" })
	public static void verifyRedirect_TC33(String TestType) throws Exception {
		Form1798DPage.verifyRedirect(driver, schedule ,Logs, TestType, entityCode, schedule, period, "1798D");
			
	}
	
	@Test(priority = 9)
	@Parameters({ "TestType" })
	public static void verifyInstructions_TC38(String TestType) throws Exception {
		Form1798DPage.verifyInstructions(driver, Logs, TestType, entityCode, schedule, period, "1798D");
			
	}
	
	@AfterMethod
	public void afterMethod() {
      driver.quit();
	}

	
}