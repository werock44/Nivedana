package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form1930DPages;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_1930D_SheduleTest {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityShortDesc;
	public static String accountCode;

	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("1930D All field validations");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "1930D", "Period");
		accountCode = Util.getAllNecessaryData(TestType, "1930D", "AccountCode");
		
		
		 String QueryToGetentityCode="select  top 1 entitycode from masterdata.FCFeed where AccountCode = '"+accountCode+"' and PeriodID in ('"+period+"')";
		 entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType,QueryToGetentityCode, "entitycode"); System.out.println(entityCode);
		 System.out.println(entityCode);
		//entityCode = "6981";// Prasanna
		//entityCode="2612";//Arindam

		/*
		 * String
		 * QueryTobugoID="Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' and EntityStatus='A' and "
		 * +
		 * "entityID not IN (select entityId from scheduleinstance where scheduleID='B0C61D4A-78C6-4AFA-9B76-1DE1502CFDC6' "
		 * + "and periodid IN ('"+period+"'))";
		 */
		/**
		 * To get buGo id we need to consider account code(Bs Line) from 1930D
		 * schedule then we will get Fair value numbers This query is only for
		 * 1930D
		 **/
		String QueryTobugoID = "select Bustructure from masterdata.Entity where EntityCode = '" + entityCode + "'";

		String bugoID = HubContributor.getBugoID_WithQuery(driver, Logs, TestType, QueryTobugoID, "BUStructure");
		// String bugoID="BU522GOIE";
		System.out.println(bugoID);

		// Code to distribute schedule and get entity code
		String queryToGetLongDesc = "select entityShortDesc from masterdata.entity where entityCode=" + "'" + entityCode
				+ "'";
		entityShortDesc = DataBaseConnection.getData(driver, Logs, TestType, queryToGetLongDesc, "entityShortDesc");
		HubContributor.distributeScheduleYearly_Fiscal(driver, Logs,
		TestType, bugoID, schedule, period);
		driver.quit();

	}

	@BeforeMethod
	public static void lauchBrowser() throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);

	}

	@Test(priority = 1)
	@Parameters({ "TestType" })
	public static void verifyScheduleDistribute1930D_TC01_TC02(String TestType) throws Exception {
		Form1930DPages.verifyScheduleDistributed(driver, entityCode, period, schedule, entityShortDesc, Logs);
	}
	
	@Test(priority = 2)
	@Parameters({ "TestType" })
	public static void verify_FairValue_TC03(String TestType) throws Exception {
		Form1930DPages.verifyFairValueHeader(driver, entityCode, period, schedule, Logs, TestType);
	}

	@Test(priority = 3)
	@Parameters({ "TestType" })
	public static void verify_MethodUsedToCalculateFairValue_Field_TC04(String TestType) throws Exception {
		Form1930DPages.verify_MethodUsedToCalculateFairValue_Field(driver, TestType, entityCode, period, schedule,
				Logs);
	}
	
	// TC_05 and 06
	@Test(priority = 4)
	@Parameters({ "TestType" })
	public static void verify_longtermdebtHeader_TC05_TC06(String TestType) throws Exception {
		Form1930DPages.verifyLongTermDebtHeader(driver, entityCode, period, schedule, Logs, TestType);
	}

	@Test(priority = 5)
	@Parameters({ "TestType" })
	public static void verify_incomeStatementHeader_TC07_TC08(String TestType) throws Exception {
		Form1930DPages.verifyIncomeStatementHeader(driver, entityCode, period, schedule, Logs, TestType);
	}

	@Test(priority = 6)
	@Parameters({ "TestType" })
	public static void verify_FairValue_fieldValidation_TC12(String TestType) throws Exception {
		Form1930DPages.verify_FairValue_fieldValidation(driver, TestType, entityCode, period, schedule, Logs);
	}

	@Test(priority = 7)
	@Parameters({ "TestType" })
	public static void verify_FairValue_fieldValidation_TC13(String TestType) throws Exception {
		Form1930DPages.verify_MethodUsedToCalcFairValue_fieldValidation(driver, TestType, entityCode, period, schedule,
				Logs);
	}


	@Test(priority = 8)
	@Parameters({ "TestType" })
	public static void verify_detailsQuestion4_TC09_10_11(String TestType) throws Exception {
		Form1930DPages.verify_detailsQuestion_TC09_10_11(driver, entityCode, period, schedule, Logs, TestType);
	}
	
	
	@Test(priority=9)
	@Parameters({ "TestType" })
	public static void verify_AmountOfSecuredDebt_fieldValidation_TC16(String TestType) throws Exception {
	Form1930DPages.verify_AmountOfSecuredDebt_fieldValidation(driver,TestType,entityCode, period, schedule,Logs);
	}

	@Test(priority=10)
	@Parameters({ "TestType" })
	public static void verify_ListALLitemsThatAreSecurinTheDebt_fieldValidation_TC17(String TestType) throws Exception {
	Form1930DPages.verify_ListALLitemsThatAreSecurinTheDebt_fieldValidation(driver,TestType,entityCode, period, schedule,Logs);
	}

	@Test(priority=11)
	@Parameters({ "TestType" })
	public static void verify_AmountOFForExch_ReasonForNotReporting_fieldValidation_TC18(String TestType) throws Exception {
	Form1930DPages.verify_AmountOFForExch_ReasonForNotReporting_fieldValidation(driver,TestType,entityCode, period, schedule,Logs);
	}
	
	@Test(priority =12)// This test case should be run at the end of the suite
	@Parameters({ "TestType" })
	public static void verify_Yes_No_Question2_3_TC15(String TestType) throws Exception {
		Form1930DPages.verify_Yes_No_Question2_3(driver, TestType, Logs);
	}
	
	@AfterMethod
	public void QuitBrowser() {
		driver.quit();
	}

}
