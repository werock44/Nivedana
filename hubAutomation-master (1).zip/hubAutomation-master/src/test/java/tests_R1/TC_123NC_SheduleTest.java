package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form123NCPage;
import pages.Form2000APages;
import pages.Form816APage;
import pages.Form816APage_WithoutAllData;
import pages.HubContributorFormPage;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_123NC_SheduleTest {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityLongDesc;

	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("123NC validations");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "123NC", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "123NC", "Period");
		String username = System.getProperty("user.name");
		System.out.println(username);
		String querytoGetBugoId = "select distinct top 1 entityCode, concat (Bumgmtcode,GoMgmtCode) as BUGOID from masterdata.entity where entitytype='NE' "
				+ "and entitystatus='A' and RgnCon is NOT NULL and entityID not IN (select entityId from scheduleinstance "
				+ "where scheduleID='A3C5284E-C794-436E-89D0-7DBEBCF15DF1' and periodid IN ('" + period + "'))";
		entityName = Util.getAllNecessaryData(TestType, "123NC", "EntityDetail");
		String buGoID = HubContributor.getBugoID_WithQuery(driver, Logs, TestType, querytoGetBugoId, "BUGOID");
		//String buGoID="BU522GOLU";
		System.out.println(buGoID);
		entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType,
		querytoGetBugoId, "entityCode");
		//entityCode = entityName;
		String queryToGetLongDesc = "select entityLongDesc from masterdata.entity where entityCode=" + "'" + entityCode
				+ "'";
		entityLongDesc = DataBaseConnection.getData(driver, Logs, TestType, queryToGetLongDesc, "entityLongDesc");

		HubContributor.distributeSchedule(driver, Logs, TestType, buGoID,
		schedule, period);
		/**
		 * Note: We are taking entity code from data sheet as per the discussion
		 * with manual testing team. We will have to do trial and error method
		 * to get the entity code which has suitable data
		 **/
		driver.quit();

	}

	/*@Test(priority = 1)
	@Parameters({ "TestType" })
	public static void verifyScheduleDistribute_TC01_TC02(String TestType) throws Exception {
		
		Form123NCPage.verifyScheduleDistributed(driver, entityCode, period, schedule, entityLongDesc, Logs);

	} */


	/*@Test(priority = 2)
	@Parameters({ "TestType" })
	public static void verifySceduleSpecificHeader_TC03(String TestType) throws Exception {
		Form123NCPage.verifySceduleSpecificHeader(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);

	}

	

	@Test(priority = 3)
	@Parameters({ "TestType" })
	public static void verifyAssetDetails_TC04(String TestType) throws Exception {
		Form123NCPage.verifyAssetTabDetails(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);

	}
	*/

	@Test(priority = 4)
	@Parameters({ "TestType" })
	public static void verifyLiabilitiesAndEquity_TC05(String TestType) throws Exception {
		Form123NCPage.verifyLiabilitiesAndEquity(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);
	}

	/*@Test(priority = 5)
	@Parameters({ "TestType" })
	public static void verifyIncomeStatementDetails_TC06(String TestType) throws Exception {
		Form123NCPage.verifyIncomeStatementTabDetails(driver, entityCode, period, schedule, entityLongDesc, Logs,
				TestType);

	}
	
	@Test(priority = 6)
		@Parameters({ "TestType" })
		public static void verify123NCReconcilation_TC07(String TestType) throws Exception {
			Form123NCPage.verifyReconcilation_TC07(driver, entityCode, period, schedule, entityLongDesc, Logs, TestType);

		}*/



	/*@Test(priority = 7)
	@Parameters({ "TestType" })
	public static void verify123NCSubmitFunctionality_TC08(String TestType) throws Exception {
		Form123NCPage.verify123NCSubmitFunctionality(driver, entityCode, period, schedule, entityLongDesc, Logs,
				TestType);

	}
*/
	
//Tc_09 and TC_10 is out of scope
	


	/*@Test(priority = 8)
	@Parameters({ "TestType" })
	public static void verifyTotalRetainedEarningsFunctionality_TC11_TC12(String TestType) throws Exception {
		Form123NCPage.verifyTotalRetainedEarningsFunctionality(driver, entityCode, period, schedule, entityLongDesc,
				Logs, TestType);

	}
	

	@Test(priority = 9) // Greater than 10000 or less than -10000 scenario
	@Parameters({ "TestType" })
	public static void verifySubmitFunctionWhenDiffIsGreaterThanRange_TC13(String TestType) throws Exception {
		Form123NCPage.verifySubmitFunctionWhenDiffIsGreaterThanRange(driver, entityCode, period, schedule,
				entityLongDesc, Logs, TestType);

	}
	
	@Test(priority = 10) // Less than 10000 and greater than -10000 scenario
	@Parameters({ "TestType" })
	public static void verifySubmitFunctionWhenDiffIsWithinTheRange_TC14(String TestType) throws Exception {
		Form123NCPage.verifySubmitFunctionWhenDiffIsWithinTheRange(driver, entityCode, period, schedule, entityLongDesc,
				Logs, TestType);

	}*/

	@AfterClass
	public void QuitBrowser() {
		//driver.quit();
	}

}
