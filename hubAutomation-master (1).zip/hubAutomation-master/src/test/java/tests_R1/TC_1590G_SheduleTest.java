package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form1590GPages;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_1590G_SheduleTest {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityLongDesc;


	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("1590G All field validations");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "1590G", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "1590G", "Period");
		String bugoID=HubContributor.getBugoID_NON_US(driver, Logs, TestType, "854BC4F7-0FFF-4FC2-838B-999B0D4FB445", period);
		//String bugoID="BU522GOIE";
		System.out.println(bugoID);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");

	   //entityCode="5483";

		//Code to distribute schedule and get entity code
		String queryToGetLongDesc="select entityLongDesc from masterdata.entity where entityCode="+"'"+bugoID+"'";
		entityLongDesc =DataBaseConnection.getData(driver, Logs, TestType, queryToGetLongDesc, "entityLongDesc");
		HubContributor.distributeScheduleYearly_Fiscal(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
	
	}

	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void verifyScheduleDistribute1590G_TC01_TC02(String TestType) throws Exception {
	Form1590GPages.verifyScheduleDistributed(driver, entityCode, period, schedule, entityLongDesc, Logs);
	}
	
	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void verifyAddAndCancel_TC31_TC32(String TestType) throws Exception {
	Form1590GPages.verifyAddAndCancelFunctionality(driver, entityCode, period, schedule, entityLongDesc, Logs);
		
	}
	
	@Test(priority=2)
	@Parameters({ "TestType" })
	public static void verifyMandatoryErrorMsg_TC18(String TestType) throws Exception {
	Form1590GPages.verifyMandatoryFieldMsg(driver, entityCode, period, schedule, entityLongDesc, Logs);
	
	
	}
	
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void verifyThirdPartyRevenueField_TC12(String TestType) throws Exception {
	Form1590GPages.verifyThirdPartyRevenueField(driver, entityCode, period, schedule, entityLongDesc, Logs,TestType,"1590G");
		
	}
	
	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void verifyNAPCSFieldDataSearch_TC03_TC33_TC34_TC35(String TestType) throws Exception {
	Form1590GPages.verifyNAPCSFieldDataSearch(driver, entityCode, period, schedule, entityLongDesc, Logs,TestType,"1590G");
		
	}
	
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void verifyNAPCSDescription_TC04(String TestType) throws Exception {
	Form1590GPages.verifyNAPCSDescription(driver, entityCode, period, schedule, entityLongDesc, Logs,TestType,"1590G");
		
	}
	
	@Test(priority=6)
	@Parameters({ "TestType" })
	public static void verifyRUFieldDescription_TC05(String TestType) throws Exception {
	Form1590GPages.verify_RUFieldDescription(driver, entityCode, period, schedule, entityLongDesc, Logs,TestType,"1590G");
		
	}
	
	@Test(priority=7)
	@Parameters({ "TestType" })
	public static void verifyRUFieldSearch_TC06_TC08_TC09_TC36_TC37(String TestType) throws Exception {
	Form1590GPages.verify_RU_FieldDataSearch(driver, entityCode, period, schedule, entityLongDesc, Logs,TestType,"1590G");
		
	}
	
	@Test(priority=8)
	@Parameters({ "TestType" })
	public static void verifyRUFieldSearch_TC10_TC11_TC13_TC16(String TestType) throws Exception {
	Form1590GPages.verifyMandatFieldMsg_CrglUSBU(driver, entityCode, period, schedule, entityLongDesc, Logs);
		
	}
	
	@Test(priority=9)
	@Parameters({ "TestType" })
	public static void verifyRUCodeMandate_TC17(String TestType) throws Exception {
	Form1590GPages.verifyMandatFieldMsg_RUCode(driver, entityCode, period, schedule, entityLongDesc, Logs);
		
	}
	
	@Test(priority=10)
	@Parameters({ "TestType" })

	public static void verifySaveWithOutMandate_TC24(String TestType) throws Exception {
	Form1590GPages.verifySaveWithOutMandate(driver, entityCode, period, schedule, entityLongDesc, Logs);
	}

	
	@Test(priority=11)
	@Parameters({ "TestType" })
	public static void verifyAbleToDeleteAllRows_TC25(String TestType) throws Exception {
	Form1590GPages.verifyAbleToDeleteAllRows(driver, entityCode, period, schedule, Logs, TestType);
	}

	@Test(priority=12)
	@Parameters({ "TestType" })
	public static void verify_invalidDataThirdParty_TC26(String TestType) throws Exception {
	Form1590GPages.verifyMandatFieldMsgThirdParty(driver, entityCode, period, schedule, entityLongDesc, Logs);
	}
	
	@Test(priority=13)
	@Parameters({ "TestType" })
	public static void verify_schedule_is_not_distributed_to_US_RU_TC30(String TestType) throws Exception {
	Form1590GPages.verify_schedule_is_not_distributed_to_US_RUs(driver, entityCode, period, schedule, Logs, TestType);	
	}


	
	
	@AfterClass
	public void QuitBrowser(){
		driver.quit();
	}

	
}
