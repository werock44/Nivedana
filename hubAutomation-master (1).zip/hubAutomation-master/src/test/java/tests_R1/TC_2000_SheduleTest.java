package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form2000APages;
import pages.Form816APage;
import pages.Form816APage_WithoutAllData;
import pages.HubContributorFormPage;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_2000_SheduleTest {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityLongDesc;

	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("2000A All field validations");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "2000A", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "2000A", "Period");
		String username = System.getProperty("user.name");
		System.out.println(username);
		entityName = Util.getAllNecessaryData(TestType, "2000A", "EntityDetail");
		String buID=HubContributor.getBUID(driver, Logs, TestType, "7810A6D6-99F1-4AEF-A97C-E91D16BC2E3C", period);
		//String buID="BU005"; 
		System.out.println(buID);
		entityCode=buID; /**BUID and Entity code is same for 2000 and 2001**/
		//entityCode="BU005";
		String queryToGetLongDesc="select entityLongDesc from masterdata.entity where entityCode="+"'"+buID+"'";
		entityLongDesc =DataBaseConnection.getData(driver, Logs, TestType, queryToGetLongDesc, "entityLongDesc");
		HubContributor.distributeScheduleMonthly(driver, Logs, TestType, buID, schedule, period);
		driver.quit();
		

	}

	
	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void verifyScheduleDistribute(String TestType) throws Exception {
		Form2000APages.verifyScheduleDistributed(driver, entityCode, period, schedule,entityLongDesc, Logs);
		
	}
	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void verifyMonthlyCommentory(String TestType) throws Exception {
		Form2000APages.verifyEnteringDataInCommentarySection(driver, entityCode, period, schedule,entityLongDesc, Logs, TestType, "2000A");
		
	}

	@Test(priority=2)
	@Parameters({ "TestType" })
	public static void verifyDriversSection(String TestType) throws Exception {
		Form2000APages.verifyEnteringDataInDriversSection(driver, entityCode, period, schedule,entityLongDesc, Logs, TestType, "2000A");
		
	}	
		
	
	
	@AfterClass
	public void QuitBrowser(){
		driver.quit();
	}

	
}
