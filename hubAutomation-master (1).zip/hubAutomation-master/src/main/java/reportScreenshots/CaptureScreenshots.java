/**
 * 
 */
package reportScreenshots;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/**
 * @author s627207
 *
 */
public class CaptureScreenshots {
	
	public static String TakeScreenshot(WebDriver driver,String ScreenshotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		//File outputFolder = new File(); 
		FileUtils.copyFile(source, new File("C:\\Users\\v320817\\Documents\\SFDC_Selenium\\SFDC_Selenium\\src\\main\\java\\reportScreenshots\\Screenshots\\"+ScreenshotName+".png"));
		return ScreenshotName+".png";
	}

}
