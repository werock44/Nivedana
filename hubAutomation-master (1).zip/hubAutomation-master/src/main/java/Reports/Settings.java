package Reports;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Settings {
	private static Properties properties = loadFromPropertiesFile();
	
	private Settings() {
		// To prevent external instantiation of this class
	}

	/**
	 * Function to return the singleton instance of the {@link Properties}
	 * object
	 * 
	 * @return Instance of the {@link Properties} object
	 */
	public static Properties getInstance() {
		return properties;
	}

	
	private static Properties loadFromPropertiesFile() {
	

	
		

		Properties properties = new Properties();

		try {
			final  String path = System.getProperty("user.dir");
			final String doubleslashpath = path.replaceAll("\\\\", "\\\\\\\\");
			properties.load(new FileInputStream(
					doubleslashpath+"\\src\\main\\java\\Reports\\GlobalSettings.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println(
					"FileNotFoundException while loading the Global Settings file");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(
					"IOException while loading the Global Settings file");
		}

		return properties;
	}

	

	@Override
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
}