package Reports;

import java.io.File;
import java.util.Properties;


public class TimeStamp {
	private static volatile String reportPathWithTimeStamp;
	
	private TimeStamp() {
		// To prevent external instantiation of this class
	}
	
	/**
	 * Function to return the timestamped result folder path
	 * @return The timestamped result folder path
	 */
	public static String getInstance() {
		if(reportPathWithTimeStamp == null) {
			synchronized (TimeStamp.class) {
				
					
					Properties properties = Settings.getInstance();
					String timeStamp =
							"Run_" +
							Util.getCurrentFormattedTime(properties.getProperty("DateFormatString"))
							.replace(" ", "_").replace(":", "-");
					final String path = System.getProperty("user.dir");
					final String doubleslashpath = path.replaceAll("\\\\", "\\\\\\\\");
					
					reportPathWithTimeStamp =
							doubleslashpath +
							Util.getFileSeparator() + "Results" +
							Util.getFileSeparator() + "Test" + 
							Util.getFileSeparator() + timeStamp;
		            
		            new File(reportPathWithTimeStamp).mkdirs();
				}
			}
		
		
		return reportPathWithTimeStamp;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
}