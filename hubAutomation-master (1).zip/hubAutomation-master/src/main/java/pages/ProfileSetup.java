/**
 * 
 */
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import objectRepository.ProfileSetUpObj;
import utils.Base_class;

/**
 * @author s627207
 *
 */
public class ProfileSetup {
	
	WebDriver driver;
	
	public void viewusers(WebDriver driver) throws InterruptedException {
		//WebDriverWait wait = new WebDriverWait(driver,30);
		//wait.until(ExpectedConditions.elementToBeSelected(ViewUsersBtn));
		Thread.sleep(5000);
		driver.findElement(ProfileSetUpObj.ViewUsersBtn).click();
	}
	
	public void select_users(WebDriver driver,String UserName) throws InterruptedException {
		String NewUSerName=null;
		Thread.sleep(5000);
		String[] substr = UserName.split("\\s+");
		for(int i=substr.length-1;i>=0;i--)
		{
			if(i==substr.length-1)
				NewUSerName = substr[i]+",";
			else 
				NewUSerName = NewUSerName+" "+substr[i];
		}
		
		WebElement element = driver.findElement(By.xpath("//a[text()='"+NewUSerName+"']"));
		element.click();
	}
	
	public void selectusers(WebDriver driver) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(ProfileSetUpObj.CansalesuserLnk).click();
	}
	
	public void loginuser(WebDriver driver) throws InterruptedException {
		//Thread.sleep(8000);
		WebElement Loginbtn = Base_class.waitForElementToVisible(driver, ProfileSetUpObj.cansalesloginuserBtn, 200);
		Loginbtn.click();
		Thread.sleep(15000);
		driver.navigate().refresh();
		Thread.sleep(10000);
	}
	
	public void selectDatausers(WebDriver driver) throws InterruptedException {
		Thread.sleep(5000);
		driver.findElement(ProfileSetUpObj.CanDatauserLnk).click();
	}
}
