package pages;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import objectRepository.*;
import Reports.DriverScript;
import Reports.Status;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class FoundationCasesPage {

	public static String valOfFrequency = null; 
	public static void AdminScreensFC(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{

		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hubCRPbutton, Logs, "Hub CRP Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.myDashBoardButton, Logs,
				"My Dashboard Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.statusDashBoard, Logs,
				"Status Dashboard Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.switchWindow(driver);
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminDashboardButton, Logs,
				"Admin-Dashboard Button");
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminScreenButton, Logs,
				"Admin-Screen Button");
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDistributionButton, Logs,
				"Schedule Distribution Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminScreenButton, Logs, "Admin-Screen Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.scheduleAttributeMaintenance, Logs,
				"Schedule Attribute Maintenance");
		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.btn_Edit, Logs, "Edit Button");
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
		List<WebElement> rowsOfTable = driver.findElements(HubAdminScreen.scheduleAttributeTable);
		boolean checkIfMorethanZero = rowsOfTable.size() > 0;
		Assert.assertTrue(checkIfMorethanZero);
		if (rowsOfTable.size() > 0) {
			Logs.update("The table contains the schedule", "Expected condtion is pass", Status.PASS, driver);
		} else {
			Logs.update("The table contains no schedule", "Expected condtion is pass", Status.PASS, driver);
		}
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate)).doubleClick().build().perform();
		Thread.sleep(2000);
		String dueDate = Util.getAllNecessaryData(TestType, TestCaseName, "DueDate");
		driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).clear();
		driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).sendKeys(dueDate);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
		Thread.sleep(3000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
		Thread.sleep(4000);
		String valAfterSave = driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate).getText();
		Assert.assertEquals(dueDate, valAfterSave);
		if (dueDate.equalsIgnoreCase(valAfterSave)) {
			Logs.update("TC01_AdminScreens",
					"The user is able  to refresh the list that are being displayed on the Schedule Attributes Maintenance Page and the value is saved.",
					Status.PASS, driver);
		} else {
			Logs.update("TC01_AdminScreens",
					"The user is not able  to refresh the list that are being displayed on the Schedule Attributes Maintenance Page and the value is not saved.",
					Status.FAIL, driver);
		}
		action.moveToElement(driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate)).doubleClick().build()
		.perform();
		String dueDate1 = Util.getAllNecessaryData(TestType, TestCaseName, "DueDate2");
		driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).clear();
		driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).sendKeys(dueDate1);
		Thread.sleep(2000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
		Thread.sleep(4000);
		String valAfterSave1 = driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate).getText();
		Assert.assertNotEquals(dueDate1, valAfterSave1);
		if (dueDate.equalsIgnoreCase(valAfterSave1)) {
			Logs.update("TC02_AdminScreens",
					"The user is able  to refresh the list that are being displayed on the Schedule Attributes Maintenance Page and the value is not saved as Save button was not clicked",
					Status.PASS, driver);
		} else {
			Logs.update("TC02_AdminScreens",
					"The user is able  to refresh the list that are being displayed on the Schedule Attributes Maintenance Page and the value is saved although Save button was not clicked",
					Status.FAIL, driver);
		}
		action.moveToElement(driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate)).doubleClick().build().perform();
		driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).clear();
		driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).sendKeys(dueDate1);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
//		Thread.sleep(4000);
		Base_class.waitForElementTobeClickable(driver, HubAdminScreen.btn_RefreshView, 10);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
		Thread.sleep(4000);
		String valOfScheduleName = driver.findElement(HubAdminScreen.scheduleAttributeRowOneScheduleName).getText();
		System.out.println("------------------------------------------------------------"+valOfScheduleName);
		valOfFrequency = driver.findElement(HubAdminScreen.scheduleAttributeRowOneFrequency).getText();
		System.out.println("------------------------------------------------------------"+valOfFrequency);
		driver.switchTo().defaultContent();
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(5000);
		
		driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
		
		//driver.findElement(HubDistributionScreen.drp_scheduleDistributionFrequency).click();
		Thread.sleep(1000);
		WebElement ele = HubDistributionScreen.dynamicXpathFrequency(driver, valOfFrequency);
		ele.click();
		Thread.sleep(3000);
		driver.findElement(HubDistributionScreen.drp_schedulePeriod).click();
		Thread.sleep(300);
		driver.findElement(HubDistributionScreen.secondPeriodValue).click();
		Thread.sleep(2000);
		driver.findElement(HubDistributionScreen.drp_ScheduleName).click();
		WebElement ele2 = HubDistributionScreen.dynamicXpathSchedule(driver, valOfScheduleName);
		ele2.click();
		Thread.sleep(3000);
		driver.findElement(HubDistributionScreen.btnOkDistributionProcess).click();
		Thread.sleep(1000);
		String appVDueDateVal = driver.findElement(HubDistributionScreen.edt_ScheduleDueDate).getAttribute("value");
		Assert.assertEquals(dueDate1, appVDueDateVal);
		if(dueDate1.equalsIgnoreCase(appVDueDateVal)){
			Logs.update("TC03_AdminScreens", "The schedule is available and due date field on the distribution screen is same as selected on the Schedule Attributes", Status.PASS, driver);
		}
		else{
			Logs.update("TC03_AdminScreens", "The schedule is available and due date field on the distribution screen is not the same as selected on the Schedule Attributes", Status.FAIL, driver);
		}		
	}
	public static void AdminScreen_TC04(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hubCRPbutton, Logs, "Hub CRP Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.myDashBoardButton, Logs, "My Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.statusDashBoard, Logs, "Status Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.switchWindow(driver);
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminDashboardButton, Logs, "Admin-Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminScreenButton, Logs, "Admin-Screen Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminScreenButton, Logs, "Admin-Screen Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.scheduleAttributeMaintenance, Logs, "Schedule Attribute Maintenance");
	driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.btn_Edit, Logs, "Edit Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
	List<WebElement> rowsOfTable = driver.findElements(HubAdminScreen.scheduleAttributeTable);
	boolean checkIfMorethanZero = rowsOfTable.size()>0;
	Assert.assertTrue(checkIfMorethanZero);
	if(rowsOfTable.size()>0){
		Logs.update("The table contains the schedule", "Expected condtion is pass", Status.PASS, driver);
	}
	else{
		Logs.update("The table contains no schedule", "Expected condtion is pass", Status.PASS, driver);
	}
	Thread.sleep(2000);
	Actions action = new Actions(driver);
	action.moveToElement(driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate)).doubleClick().build().perform();
	Thread.sleep(2000);
	String dueDate = Util.getAllNecessaryData(TestType, TestCaseName, "DueDate");
	driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).clear();
	driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).sendKeys(dueDate);
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
	Thread.sleep(3000);
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
	Thread.sleep(4000);
	action.moveToElement(driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDate)).doubleClick().build().perform();
	Thread.sleep(2000);
	String dueDate1 = Util.getAllNecessaryData(TestType, TestCaseName, "DueDate2");
	driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).clear();
	driver.findElement(HubAdminScreen.scheduleAttributeRowOneDueDateInput).sendKeys(dueDate1);
	Thread.sleep(2000);
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
	String valOfScheduleName = driver.findElement(HubAdminScreen.scheduleAttributeRowOneScheduleName).getText();
	System.out.println("------------------------------------------------------------"+valOfScheduleName);
	valOfFrequency = driver.findElement(HubAdminScreen.scheduleAttributeRowOneFrequency).getText();
	System.out.println("------------------------------------------------------------"+valOfFrequency);
	driver.switchTo().defaultContent();
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
	driver.switchTo().frame(Frame);
	Thread.sleep(5000);
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	Thread.sleep(1000);
	WebElement ele = HubDistributionScreen.dynamicXpathFrequency(driver, valOfFrequency);
	ele.click();
	Thread.sleep(3000);
	driver.findElement(HubDistributionScreen.drp_schedulePeriod).click();
	Thread.sleep(300);
	driver.findElement(HubDistributionScreen.secondPeriodValue).click();
	Thread.sleep(2000);
	driver.findElement(HubDistributionScreen.drp_ScheduleName).click();
	WebElement ele2 = HubDistributionScreen.dynamicXpathSchedule(driver, valOfScheduleName);
	ele2.click();
	Thread.sleep(3000);
	driver.findElement(HubDistributionScreen.btnOkDistributionProcess).click();
	Thread.sleep(1000);
	String appVDueDateVal = driver.findElement(HubDistributionScreen.edt_ScheduleDueDate).getAttribute("value");
	boolean equalCheck = appVDueDateVal.equalsIgnoreCase(dueDate1);
	Assert.assertEquals(false, equalCheck);
	if(!dueDate1.equalsIgnoreCase(appVDueDateVal)){
		Logs.update("TC04_AdminScreens", "The schedule is available and due date field on the distribution screen is not same as selected on the Schedule Attributes beacuse it was not saved", Status.PASS, driver);
	}
	else{
		Logs.update("TC04_AdminScreens", "The schedule is available and due date field on the distribution screen is same as selected on the Schedule Attributes although it was not saved", Status.FAIL, driver);
	}
//	Assert.assertEquals(dueDate, valAfterSave);
//	if(dueDate.equalsIgnoreCase(valAfterSave)){
//		Logs.update("TC01_AdminScreens", "The user is able  to refresh the list that are being displayed on the Schedule Attributes Maintenance Page and the value is saved.", Status.PASS, driver);
//	}
//	else{
//		Logs.update("TC01_AdminScreens", "The user is not able  to refresh the list that are being displayed on the Schedule Attributes Maintenance Page and the value is not saved.", Status.FAIL, driver);
//	}
	}



public static void distributionFC_01_02(WebDriver driver, DriverScript Logs, String TestType, String TestCaseNAme) throws Exception{

	HubContributor.validateIfElementIsPresent(driver,HubHomePageObj.hubCRPbutton, Logs, "HUB CRP Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hub2Button, Logs, "HUB 2.0 Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.myDashBoardButton, Logs, "My Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.statusDashBoard, Logs, "Status Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.switchWindow(driver);
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminDashboardButton, Logs, "Admin-Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminScreenButton, Logs, "Admin-Screen Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
	Thread.sleep(1000);
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
	WebElement sdFrame = driver.findElement(By.xpath("//*[@class='content-control-iframe']"));
	driver.switchTo().frame(sdFrame);
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDistFrequencyLbl, Logs, "Schedule Distribution Frequency");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.PeriodLbl, Logs, "Period");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleLbl, Logs, "Schedule");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.entitiesLbl, Logs, "Entities");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDueDateLbl, Logs, "Schedule Due date");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.distributeBtn, Logs, "Distribute Button");
	List<WebElement> sDFreqList = driver.findElements(HubAdminScreen.scheduleDistFrequencyList);
	HubContributor.checkTheDropDownValues(driver, TestType, TestCaseNAme, sDFreqList, Logs, "Verify Schedule distribution frequency list values", "ScheduleDistributionFreqValues");	
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	Thread.sleep(1000);
	driver.findElement(HubAdminScreen.scheduleDistFrequency_Monthly).click();
	Thread.sleep(1000);
	List<WebElement> list_Monthly=driver.findElements(HubAdminScreen.periodList);
	HubContributor.checkTheDropDownValues(driver, TestType, TestCaseNAme, list_Monthly, Logs, "Verify Period list when monthly is selected", "Period_Monthly");
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	driver.findElement(HubAdminScreen.scheduleDistFrequency_Yearly_Fiscal).click();
	Thread.sleep(1000);
	List<WebElement> list_Yearly=driver.findElements(HubAdminScreen.periodList);
	HubContributor.checkTheDropDownValues(driver, TestType, TestCaseNAme, list_Yearly, Logs, "Verify Period list when Yearly is selected", "Period_Yearly");
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	driver.findElement(HubAdminScreen.scheduleDistFrequency_Quaterly).click();
	Thread.sleep(2000);
	List<WebElement> list_Quaterly=driver.findElements(HubAdminScreen.periodList);
	HubContributor.checkTheDropDownValues(driver, TestType, TestCaseNAme, list_Quaterly, Logs, "Verify Period list when Quaterly is selected", "Period_Quaterly");
    driver.findElement(HubAdminScreen.periodField).click();
    Thread.sleep(1000);
    driver.findElement(HubAdminScreen.period_QuaterlyCurrent).click();
    Thread.sleep(1000);
    List<WebElement> schedle=driver.findElements(HubAdminScreen.scheduleList);
	//HubContributor.checkTheDropDownValues(driver, TestType, TestCaseNAme, schedle, Logs, "Verify schedule list values", "ScheduleListVal");
    driver.findElement(HubAdminScreen.scheduleField).click();
    driver.findElement(HubAdminScreen.schedule_GenReserve).click();
    driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
    Thread.sleep(1000);
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.availableEntitiesHeader, Logs, "Available Entities header");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.selectedEntitiesHeader, Logs, "Selected Entities header");
    HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.addAllicon, Logs, "Add All entities using icon '>>'");
    HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.removeAllIcon, Logs, "Remove all entities using icon '>>'");
    driver.findElement(HubAdminScreen.entities_2ndOption).click();
    HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.selectedAddicon, Logs, "Add selected entities using '>'");
    HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.selectedRemoveIcon, Logs, "Remove selected entities using '<'");
    driver.findElement(HubAdminScreen.selectedAddicon).click();
    //To check if the due date field is read only.
    String dueDateAttr=driver.findElement(HubAdminScreen.scheduleDueDateField).getAttribute("class");
    		if(dueDateAttr.contains("readonly"))
    		{
    			Logs.update("Schedule Due Date field", "Field is read only", Status.PASS, driver);
    		}else{
    			Logs.update("Schedule Due Date field", "Field is not read only and editable", Status.FAIL, driver);
    		}
    //-----
    HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.distributeBtn, Logs, "Distribute Button");
    Thread.sleep(5000);
    Actions action = new Actions(driver);
    action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build().perform();
   //HubContributor.verifyPopUpHeader(driver, HubAdminScreen.distributionPopUp, Logs, "Distribution Process Started");
   //driver.findElement(HubAdminScreen.distributionPopUp).sendKeys(Keys.ENTER);
   //driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp);
    Thread.sleep(2000);
    HubContributor.switchWindow_3(driver);
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.schDistributionProgDashboard, Logs, "Schedule Distribution Progress Dashboard");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.totalNumOfScheduleToBeDistributed, Logs, "Total Number of schedule to be distributed");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.totalNumOfScheduleDistributed, Logs, "Total number of schedule distrubuted succesfully");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.DistributionProgress, Logs, "Distribution Progress");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.pageRefreshInfo, Logs, "Page will refresh in");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.pageRefreshValue, Logs, "Page refresh in seconds dynamic value. After completion -NA- is displayed");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.entityDetail_Distrib, Logs, "Entity Details");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.periodID_Distrib, Logs, "Period Id");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.stateName_Distrib, Logs, "State Name");
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.HcadGroup_Distrib, Logs, "Hcad Group");
    boolean hcadGrpAvl=driver.findElement(HubAdminScreen.HcadGroup_Distrib).isDisplayed();
		if (hcadGrpAvl == true) {
			Logs.update("TC_01 DistributionFC", "User is in Schedule Distribution page and all fields are available",
					Status.PASS, driver);
		} else {
			Logs.update("TC_01 DistributionFC",
					"User is in Schedule Distribution page and all fields are NOT available", Status.FAIL, driver);
		}
	String progBarVal=driver.findElement(HubAdminScreen.distributionProgressBar).getAttribute("title");
	if(!progBarVal.contains("100%")){
		Logs.update("TC_02 Verifying Progress bar value when distribution is unsuccessful", "Progress bar is NOT showing 100% as expected", Status.PASS, driver);
	}else{
		Logs.update("TC_02 Verifying Progress bar value when distribution is unsuccessful", "Progress bar is showing 100% even when distribution is not successful", Status.FAIL, driver);
	}
		
}

public static void distributionFC_03_04(WebDriver driver, DriverScript Logs, String TestType, String TestCaseNAme) throws ClassNotFoundException, SQLException, Exception{
	HubContributorFormPage.openAdminLink(driver, Logs);
	driver.findElement(HubAdminScreen.scheduleDistributionButton).click();
	WebElement sdFrame = driver.findElement(By.xpath("//*[@class='content-control-iframe']"));
	driver.switchTo().frame(sdFrame);
	Thread.sleep(4000);
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	driver.findElement(HubAdminScreen.scheduleDistFrequency_Quaterly).click();
	Thread.sleep(1000);
	driver.findElement(HubAdminScreen.periodField).click();
	driver.findElement(HubAdminScreen.period_QuaterlyCurrent).click();
	driver.findElement(HubAdminScreen.scheduleField).click();
	driver.findElement(HubAdminScreen.schedule_GenReserve).click();
	driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
	Thread.sleep(5000);
	Logs.update("Clicking on Distribute", "Clicking on Distribute button without selecting a entity", Status.DONE, driver);
	driver.findElement(HubAdminScreen.distributeBtn).click();
	HubContributor.verifyPopUpMessage(driver, HubAdminScreen.scheduleDistWarningPopup, Logs, "Please select an Entity to Distribute!");
	Actions action = new Actions(driver);
    action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build().perform();
	//driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp);
	driver.findElement(HubAdminScreen.entities_2ndOption).click();
	driver.findElement(HubAdminScreen.selectedAddicon).click();
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	driver.findElement(HubAdminScreen.scheduleDistFrequency_Unselect).click();
	Thread.sleep(2000);
	Logs.update("Clicking on Distribute", "Clicking on Distribute button without selecting frequency, Period and schedule", Status.DONE, driver);
	driver.findElement(HubAdminScreen.distributeBtn).click();
	HubContributor.verifyPopUpMessage(driver, HubAdminScreen.scheduleDistWarningPopup, Logs, "Required field warning\nPlease fill all the required fields highlighted in red.");
	action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build().perform();
	
}


public static void distributionFC_05(WebDriver driver, DriverScript Logs, String TestType, String TestCaseNAme) throws Exception{
	
	HubContributorFormPage.openAdminLink(driver, Logs);
	driver.findElement(HubAdminScreen.adminScreenButton).click();
	driver.findElement(HubAdminScreen.scheduleAttributeMaintenance).click();
	driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
	Actions action=new Actions(driver);
	action.moveToElement(driver.findElement(HubAdminScreen.scheduleAttributeDueDate_3rdRow)).doubleClick().build().perform();
	Thread.sleep(1000);
	String pastDueDate=Util.getAllNecessaryData(TestType, TestCaseNAme, "PastDueDate");
	driver.findElement(HubAdminScreen.scheduleAttributeDueDateInput_3rdRow).clear();
	driver.findElement(HubAdminScreen.scheduleAttributeDueDateInput_3rdRow).sendKeys(pastDueDate);
	//driver.findElement(HubAdminScreen.btn_Save).click();
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
	Base_class.waitForElementTobeClickable(driver, HubAdminScreen.btn_RefreshView, 10);
	//driver.findElement(HubAdminScreen.btn_RefreshView);
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
	Thread.sleep(4000);
	String Schfreq=driver.findElement(HubAdminScreen.scheduleAttributeFrequency_3rdRow).getText();
	String scheduleName=driver.findElement(HubAdminScreen.scheduleAttributeScheduleName_3rdRow).getText();
	driver.switchTo().defaultContent();
	driver.findElement(HubAdminScreen.scheduleDistributionButton).click();
//	Thread.sleep(1000);
//	driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
	
	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
	driver.switchTo().frame(Frame);
	Thread.sleep(5000);
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	Thread.sleep(3000);
	HubDistributionScreen.dynamicXpathFrequency(driver, Schfreq).click();
	Thread.sleep(3500);
	driver.findElement(HubAdminScreen.periodField).click();
	Thread.sleep(1000);
	driver.findElement(HubAdminScreen.period_QuaterlyCurrent).click();
	Thread.sleep(2000);
	driver.findElement(HubAdminScreen.scheduleField).click();
	Logs.update("Select a schedule for which due date is crossed", "Schedule for which due date is crossed has been selected", Status.PASS, driver);
	HubDistributionScreen.dynamicXpathSchedule(driver, scheduleName).click();
	Thread.sleep(3000);
	driver.findElement(HubDistributionScreen.btnOkDistributionProcess).click();
	Thread.sleep(2000);
	String PastDueexpWarning=Util.getAllNecessaryData(TestType, TestCaseNAme, "PastDueDateWarning");
	String actHeader=driver.findElement(HubAdminScreen.scheduleDistWarningPopup).getText();
	Assert.assertEquals(actHeader, PastDueexpWarning);
	if (actHeader.equalsIgnoreCase(PastDueexpWarning)){
		Logs.update("TC_05 Distribution", "Validation pop up message is displayed: "+actHeader, Status.PASS, driver);
	}else{
		Logs.update("TC_05 Distribution", "Wrong validation pop up message is displayed: "+actHeader, Status.FAIL, driver);
	}
	driver.findElement(HubDistributionScreen.btnOkDistributionProcess).click();	
	//Return back to Schedule maintenance page and set valid due date value for next test case to work.
	
	driver.switchTo().defaultContent();
	String FutureDueDate=Util.getAllNecessaryData(TestType, TestCaseNAme, "FuruteDueDate");
	HubContributor.setValidDueDateVal(driver, scheduleName,HubAdminScreen.scheduleAttributeDueDateInput_3rdRow, Logs, FutureDueDate, TestCaseNAme, TestType);
	
}


public static void dashboardFC(WebDriver driver, DriverScript Logs, String TestType, String TestCaseNAme)
		throws Exception {

	Actions actions = new Actions(driver);
	String schedule = Util.getAllNecessaryData(TestType, "FoundationCase815", "ScheduleName");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
	Thread.sleep(5000);
	driver.findElement(HubHomePageObj.statusDashBoard).click();
	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
	driver.switchTo().frame(Frame);
	Thread.sleep(5000);
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("window.scrollBy(0,250)");
	WebElement ele = driver.findElement(HubHomePageObj.table_scheduleName);
	actions.moveToElement(ele).doubleClick().build().perform();
	HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_scheduleName, Logs,
			"Table_Schedule_Name", "TC01_StatusDB_schedulename");
	HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_entityDetail, Logs,
			"Table_Entity_Detail", "TC01_StatusDB_Entity_detail");
	HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_entityPeriod, Logs,
			"Table_Entity_period", "TC01_StatusDB_entity_period");
	HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_scheduleDueDate, Logs,
			"Table_Schedule_Due_date", "TC01_StatusDB_scheduleDueDate");
	HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_status, Logs, "Table_Status",
			"TC01_StatusDB_Status");
	HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_lastActionBy, Logs,
			"Table_Last_Action_By", "TC01_StatusDB_LastActionBy");
	// Date validation of schedule date
	String actualdateformat = driver.findElement(HubHomePageObj.table_scheduleDueDate).getText();
	HubContributor.validateDateFormat(driver, Logs, actualdateformat, "MM/dd/yyyy hh:mm a");
	// Date validation of period
	actualdateformat = driver.findElement(HubHomePageObj.table_entityPeriod).getText();
	HubContributor.validateDateFormat(driver, Logs, actualdateformat, "yyyy.MM");
	// Verify View and Recall buttons
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.table_view, Logs, "Table - view button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.table_recall, Logs, "Table - recall button");
	//driver.findElement(HubHomePageObj.recall_cancel_button).click();
	/* Filters */
	/* Entity detail */
	String entitydetails = Util.getAllNecessaryData(TestType, "FoundationCase815", "EntityDetail");
	String[] arrSplit = entitydetails.split(" ");
	String entityDigits = arrSplit[0];
	Thread.sleep(2000);
	HubContributor.verifyTextBoxIsEditable(driver, HubHomePageObj.edt_EntityDeatils, Logs, "Entity Detail", entityDigits);
	System.out.println(entityDigits);
	/* Search Schedule */
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.searchButtonDashboard, Logs, "Search button");
	Thread.sleep(2000);
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.scheduleButton, Logs, "SelectSchedule");
	Thread.sleep(1000);
	System.out.println(schedule);
	HubHomePageObj.findScheduleName(driver, schedule).click();
	/* Select Status */
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.statusDropdown, Logs, "Status dropdown");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.statusSubmit, Logs, "Status Submit");
	String period = Util.getAllNecessaryData(TestType, "FoundationCase815", "Period");
	HubContributor.verifyTextBoxIsEditable(driver, HubHomePageObj.periodTextBoxStatusDB, Logs, "Satus Dashboard Period", period);
	String dsid = Util.getAllNecessaryData(TestType, "FoundationCase815", "DSID");
	HubContributor.verifyTextBoxIsEditable(driver, HubHomePageObj.actionerDSIDtextbox, Logs, "Satus Dashboard Actioner DSID",
			dsid);

	/* Verify Sort */
	// String sortcolumn = Util.getAllNecessaryData(TestType,
	// "FoundationCase", "SortColumn");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.sortColumn, Logs, "Sort column");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.sortValue, Logs, "Sort Value");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.ascendingRadioButton, Logs,
			"Radio Button Ascending");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.descendingRadioButton, Logs,
			"Radio Button Descending");
	/* Verify Refresh View */
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.refreshView, Logs, "Refresh View");
	/* Verify clear filters */
	//HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.clearAllFilters, Logs, "Clear Filters");
	String periodtext = driver.findElement(HubHomePageObj.periodTextBoxStatusDB).getText();
	System.out.println(periodtext);
	if (periodtext.equalsIgnoreCase(" ")) {
		Logs.update("Period Text box verification ", " Cleared after filter is applied", Status.FAIL, driver);

	} else {
		Logs.update("Period Text box verification ", " Not Cleared after filter is applied expected", Status.PASS,
				driver);
	}

}


/* Prasannajit 
 * Admin Dashboard verification 
 */

public static void dashboardAdminFC(WebDriver driver, DriverScript Logs, String TestType, String TestCaseNAme)
		throws Exception {
	Actions actions = new Actions(driver);	
	String schedule = Util.getAllNecessaryData(TestType, "FoundationCase815", "ScheduleName");
	HubContributor.validateIfElementIsPresent(driver,HubHomePageObj.hubCRPbutton, Logs, "HUB CRP Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hub2Button, Logs, "HUB 2.0 Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.myDashBoardButton, Logs, "My Dashboard Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.statusDashBoard, Logs, "Status Dashboard Button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.switchWindow(driver);
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminDashboardButton, Logs, "Admin-Dashboard Button");
		HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminScreenButton, Logs, "Admin-Screen Button");
        /* Admin Dashboard */
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminDashboardButton, Logs, "Admin Dashboard");
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250)");
		WebElement ele = driver.findElement(HubHomePageObj.table_scheduleName);
		actions.moveToElement(ele).doubleClick().build().perform();
		HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_scheduleName, Logs,
				"Table_Schedule_Name", "TC02_StatusDB_schedulename");
		HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_entityDetail, Logs,
				"Table_Entity_Detail", "TC02_StatusDB_Entity_detail");
		HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_entityPeriod, Logs,
				"Table_Entity_period", "TC02_StatusDB_entity_period");
		HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_scheduleDueDate, Logs,
				"Table_Schedule_Due_date", "TC02_StatusDB_scheduleDueDate");
		HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_status, Logs, "Table_Status",
				"TC02_StatusDB_Status");
		HubContributor.checkifElementisNotEditable(driver, HubHomePageObj.table_lastActionBy, Logs,
				"Table_Last_Action_By", "TC02_StatusDB_LastActionBy");
		ele = driver.findElement(HubHomePageObj.table_lastActionBy);
		jse.executeScript("window.scrollBy(0,250)");
		//actions.moveToElement(ele).doubleClick().build().perform();
		Thread.sleep(3000);
		//HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.admintable_view, Logs, "AdminTable View button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.admintable_redirect, Logs, "AdminTable Redirect button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.admintable_reject, Logs, "AdminTable Reject button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.admintable_NA, Logs, "AdminTable NA button");
		HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.admintable_edit, Logs, "AdminTable Edit button");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.admintable_view, Logs, "Admin Table View Button");

		/* Filters */
		/* Entity detail */
		String entitydetails = Util.getAllNecessaryData(TestType, "FoundationCase815", "EntityDetail");
		String[] arrSplit = entitydetails.split(" ");
		String entityDigits = arrSplit[0];
		HubContributor.verifyTextBoxIsEditable(driver, HubHomePageObj.edt_EntityDeatils, Logs, "Entity Detail", entityDigits);
		/* Search Schedule */
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.searchButtonDashboard, Logs, "Search button");

		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminscheduleButton, Logs, "SelectSchedule");
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		/* Select Status */
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminstatusDropdown, Logs, "Status dropdown");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminstatusValue, Logs, "Status Current");
		String period = Util.getAllNecessaryData(TestType, "FoundationCase815", "Period");
		HubContributor.verifyTextBoxIsEditable(driver, HubHomePageObj.periodTextBoxStatusDB, Logs, "Satus Dashboard Period", period);
		String dsid = Util.getAllNecessaryData(TestType, "FoundationCase815", "DSID");
		HubContributor.verifyTextBoxIsEditable(driver, HubHomePageObj.actionerDSIDtextbox, Logs, "Satus Dashboard Actioner DSID",
				dsid);

		/* Verify Sort */
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminsortColumn, Logs, "Sort column");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.sortValue, Logs, "Sort Value");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.ascendingRadioButton, Logs,
				"Radio Button Ascending");
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.descendingRadioButton, Logs,
				"Radio Button Descending");
		/* Verify Refresh View */
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.refreshView, Logs, "Refresh View");
		/* Verify clear filters */
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.clearAllFilters, Logs, "Clear Filters");
		String periodtext = driver.findElement(HubHomePageObj.periodTextBoxStatusDB).getText();
		System.out.println(periodtext);
		if (periodtext.equalsIgnoreCase(" ")) {
			Logs.update("Period Text box verification ", " Cleared after filter is applied", Status.FAIL, driver);

		} else {
			Logs.update("Period Text box verification ", " Not Cleared after filter is applied expected", Status.PASS,
					driver);
		}
		
}
	public static void myDashboardF_TC01(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.myDashBoardButton, 10);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.myDashBoardButton).click();
		Thread.sleep(4000);
		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		
		boolean check = driver.findElement(HubDistributionScreen.allRowsOfMyDashboardTable).isDisplayed();
		Assert.assertEquals(true, check);
		if(check){
			Logs.update("Schedules are getting displayed", "As Expected", Status.PASS, driver);
		}
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.edt_ActionerID, Logs, "Actioner ID text Box");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.edt_EntityDetails, Logs, "Entity Details textBox");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.scheduleDropDown, Logs, "Schedule Dropdown");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.statusDropDown, Logs, "status dropdown");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.edt_Period, Logs, "Period textBox");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.sortDropDown, Logs, "Sort DropDown");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.checkBox_Ascending, Logs, "Ascending Checkbox");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.checkBox_Descending, Logs, "Descending Checkbox");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.refreshWorkList, Logs, "Refresh WorkList Button");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.clearALL, Logs, "Clear ALL Button");
		HubContributor.checkifElementisNotEditable(driver, HubDistributionScreen.scheduleNameRow, Logs, "Schedule Name", "Check if Element is Editable or not");
		HubContributor.checkifElementisNotEditable(driver, HubDistributionScreen.entityDetailRow, Logs, "Entity Detail", "Check if Element is Editable or not");
		HubContributor.checkifElementisNotEditable(driver, HubDistributionScreen.periodRow, Logs, "Peiod", "Check if Element is Editable or not");
		HubContributor.checkifElementisNotEditable(driver, HubDistributionScreen.LockedByRow, Logs, "Locked By", "Check if Element is Editable or not");
		HubContributor.checkifElementisNotEditable(driver, HubDistributionScreen.scheduleDueDateRow, Logs, "Schedule Due Date", "Check if Element is Editable or not");
		HubContributor.checkifElementisNotEditable(driver, HubDistributionScreen.statusRow, Logs, "Status", "Check if Element is Editable or not");
		String DSID = Util.getAllNecessaryData(TestType, TestCaseName, "ActionerID");
		driver.findElement(HubDistributionScreen.edt_ActionerID).sendKeys(DSID);
		Thread.sleep(2000);
		driver.findElement(HubDistributionScreen.btn_search).click();
		Thread.sleep(4000);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(HubDistributionScreen.firstRow)).doubleClick().build().perform();
		Thread.sleep(4000);
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.btn_OpenSchedule, Logs, "Open Schedule Button");
		HubContributor.validateIfElementIsPresent(driver, HubDistributionScreen.btn_Release, Logs, "Relase Schedule Button");
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		//Entity validation
		String entity = Util.getAllNecessaryData(TestType, TestCaseName, "EntityDetail");
		String [] arr = entity.split("-");		
		String valToFill = arr[0];
		driver.findElement(HubDistributionScreen.edt_EntityDetails).sendKeys(valToFill.trim());
		driver.findElement(HubDistributionScreen.btn_search).click();
		Thread.sleep(3000);
		HubContributor.checkEntityTableValueMyDashboard(driver, Logs, 2, entity);
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		//Schedule Name Validation
		driver.findElement(HubDistributionScreen.scheduleDropDown).click();
		String scheduleName = Util.getAllNecessaryData(TestType, TestCaseName, "ScheduleName");
		HubHomePageObj.findScheduleName(driver, scheduleName).click();
		driver.findElement(HubDistributionScreen.btn_search).click();
		Thread.sleep(3000);
		HubContributor.checkEntityTableValueMyDashboard(driver, Logs, 1, scheduleName);
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		//Status Of Schedule Validation
		String statusOfSchedule = Util.getAllNecessaryData(TestType, TestCaseName, "StatusOfSchedule");
		driver.findElement(HubDistributionScreen.statusDropDown).click();
		Thread.sleep(1000);
		HubHomePageObj.frameStatusOfScheduleLocator(driver, statusOfSchedule).click();
		driver.findElement(HubDistributionScreen.btn_search).click();
		Thread.sleep(3000);
		HubContributor.checkEntityTableValueMyDashboard(driver, Logs, 5, statusOfSchedule);
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		//Period Validation
		String period = Util.getAllNecessaryData(TestType, TestCaseName, "Period");
		driver.findElement(HubDistributionScreen.edt_Period).sendKeys(period);
		driver.findElement(HubDistributionScreen.btn_search).click();
		Thread.sleep(3000);
		HubContributor.checkEntityTableValueMyDashboard(driver, Logs, 3, period);
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		//Actioner DS ID
		String actionerId = Util.getAllNecessaryData(TestType, TestCaseName, "ActionerID");
		driver.findElement(HubDistributionScreen.edt_ActionerID).sendKeys(actionerId);
		driver.findElement(HubDistributionScreen.btn_search).click();
		Thread.sleep(3000);
		HubContributor.checkEntityTableValueMyDashboard(driver, Logs, 6, actionerId);
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		//Checking Clear ALL button
		driver.findElement(HubDistributionScreen.edt_Period).sendKeys(period);
		driver.findElement(HubDistributionScreen.edt_Period).sendKeys(actionerId);
		driver.findElement(HubDistributionScreen.edt_EntityDetails).sendKeys(valToFill.trim());
		driver.findElement(HubDistributionScreen.clearALL).click();
		Thread.sleep(5000);
		String val1 = driver.findElement(HubDistributionScreen.edt_Period).getAttribute("value");
		String val2 = driver.findElement(HubDistributionScreen.edt_ActionerID).getAttribute("value");
		String val3 = driver.findElement(HubDistributionScreen.edt_EntityDetails).getAttribute("value");
		if(val1.equalsIgnoreCase("Type a value") && val2.equalsIgnoreCase("Type a value") &&val3.equalsIgnoreCase("Type a value")){
			Logs.update("TC01_Workspace_My Dashboard", "The clear ALL and other functionalities are working fine", Status.PASS, driver);
		}
		else{
			Logs.update("TC01_Workspace_My Dashboard", "The clear ALL and other functionalities are not working fine", Status.FAIL, driver);
		}
	}
	public static void myDashboardF_TC02(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		String schedule = Util.getAllNecessaryData(TestType, TestCaseName, "ScheduleName");	
		String entityName = Util.getAllNecessaryData(TestType, TestCaseName, "EntityDetail");
		String period = Util.getAllNecessaryData(TestType, TestCaseName, "Period");
		
		String entity = Util.getAllNecessaryData(TestType, TestCaseName, "EntityDetail");
		String [] arr = entity.split(" ");		
		String valToFill = arr[0];
		
		Thread.sleep(3000);
		HubContributorFormPage.openSchedule(driver, valToFill, period, schedule, Logs);
		Form814APage.fillForm814A(driver);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		Thread.sleep(7000);
		driver.findElement(HubContributorFormObj.submitOK).click();
		Thread.sleep(5000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(1000);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		driver.quit();
		Thread.sleep(3000);
		driver = Login.launchAppURL("Setupurl", Logs);
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		Thread.sleep(3000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.switchWindow(driver);
		Thread.sleep(7000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminDashboardButton, Logs,
				"Admin-Dashboard Button");
		entity = Util.getAllNecessaryData(TestType, TestCaseName, "EntityDetail");
		String [] arr1 = entity.split("-");		
		String valToFill1 = arr1[0];
		Thread.sleep(6000);
		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		driver.findElement(HubAdminScreen.entityDetail).sendKeys(valToFill1.trim());
		Thread.sleep(4000);
		String period2 = Util.getAllNecessaryData(TestType, TestCaseName, "Period");
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).clear();
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).sendKeys(period2);
		Thread.sleep(5000);
		driver.findElement(HubAdminScreen.searchButtom).click();
		Thread.sleep(4000);
//		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		List<WebElement> totalNumOfResults =  driver.findElements(HubAdminScreen.allRowsOfScheduleTable);
		int numberOfSearchResults = totalNumOfResults.size();
		System.out.println("------------------------------------------------------------------------------"+numberOfSearchResults);
		Assert.assertEquals(numberOfSearchResults, 1);
		if(numberOfSearchResults==1){
			String valInColumn = driver.findElement(HubAdminScreen.statusColumnRowOne).getAttribute("title");
			Assert.assertEquals(valInColumn, "Submitted");
			if(valInColumn.equalsIgnoreCase("Submitted")){
			Logs.update("TC02_Workspace", "The schedule is present in the Admin Dashboard with Status as 'Submitted'", Status.PASS, driver);
			}
			else{
				Logs.update("TC02_Workspace", "The schedule is present in the Admin Dashboard but the Status is not det to 'Submitted'", Status.FAIL, driver);
			}
		}
		else{
			Logs.update("TC02_Workspace", "The schedule is not present in the Admin Dashboard with Status as 'Submitted'", Status.FAIL, driver);
		}
		
	}




public static void dashboardDomainVerificationFC(WebDriver driver, DriverScript Logs, String TestType,
		String TestCaseNAme) throws Exception {
	WebDriverWait wait = new WebDriverWait(driver, 20);
	Actions actions = new Actions(driver);
	String schedule = Util.getAllNecessaryData(TestType, "FoundationCase815", "ScheduleName");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hubCRPbutton, Logs, "HUB CRP Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hub2Button, Logs, "HUB 2.0 Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.myDashBoardButton, Logs,
			"My Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.statusDashBoard, Logs,
			"Status Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.switchWindow(driver);
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminDashboardButton, Logs,
			"Admin-Dashboard Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminDashboardButton, Logs, "Admin Dashboard");
	/* Verify Valid Domains */
	String validvaluesForField = Util.getAllNecessaryData(TestType, "FoundationCase815", "ValidDomains");
	String periodValue = Util.getAllNecessaryData(TestType, "FoundationCase815", "Period");
	String[] splittedValsForField = validvaluesForField.split(",");
   	int expectedRunCount = splittedValsForField.length;
	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
	driver.switchTo().frame(Frame);
	Thread.sleep(20000);
	driver.findElement(HubHomePageObj.periodTextBoxStatusDB).clear();
	driver.findElement(HubHomePageObj.periodTextBoxStatusDB).sendKeys(periodValue);
	JavascriptExecutor jse = (JavascriptExecutor) driver;
	jse.executeScript("window.scrollBy(0,250)");
	for (int i = 0; i < expectedRunCount; i++) {
		Thread.sleep(10000);
		driver.findElement(HubHomePageObj.adminscheduleButton).click();
		Thread.sleep(5000);
		System.out.println(splittedValsForField[i]);
		HubHomePageObj.findScheduleName(driver, splittedValsForField[i]).click();
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.searchButtonDashboard, Logs,
				"Search button");
		for (int j = 0; j <= 2; j++) {
			try {
				driver.findElement(HubHomePageObj.table_entityDetail).click();
				actions.moveToElement(driver.findElement(HubHomePageObj.table_entityDetail)).doubleClick().build().perform();
				Logs.update("Verify that the Admin is able to view the schedule Only as per their domain.", splittedValsForField[i]+" schedules are visible", Status.PASS, driver);
				break;
			} catch (StaleElementReferenceException e) {
				System.out.println(e.getMessage());
				
			}
			catch (ElementNotVisibleException e)
			{
				Logs.update("Verify that the Admin is able to view the schedule Only as per their domain.", splittedValsForField[i]+" schedules are Not visible", Status.FAIL, driver);
			}
		}

	}

}

}




