package pages;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.formula.functions.T;
import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import objectRepository.R11798Dobj;
import objectRepository.R12001BGobj;
import utils.Base_class;
import utils.HubContributor;
import utils.Login;
import utils.ReadXML;
import utils.Util;

public class Form2001BG {

	public static void verifyscheduleDistribution(WebDriver driver, DriverScript Logs, String TestType,
			String entityCode, String schedule, String period, String TestCaseName) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		System.out.println(entityXpath);
		try {
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Logs.update("TC01- Verify Distribution", "Distribution is successfull and verified  ", Status.PASS, driver);

		}

		catch (Exception e) {
			Logs.update("TC01-Verify Distribution", "Distrbuted schedule not found", Status.FAIL, driver);
		}

		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		String actualScheduleName = driver.findElement(R12001BGobj.scheduleName).getAttribute("title");
		String actualPeriodName = driver.findElement(R12001BGobj.periodValue).getAttribute("title");
		String actualBGName = driver.findElement(R12001BGobj.businessGroup).getAttribute("title");

		System.out.println(actualScheduleName);
		System.out.println(actualPeriodName);
		System.out.println(actualBGName);

		if (actualScheduleName.equals(schedule)) {
			Logs.update("TC02- Verify the header", "Schedule name is as expected ", Status.PASS, driver);
		}

		else {
			Logs.update("TC02- Verify the header", "Schedule name is NOT as expected ", Status.FAIL, driver);
		}

		if (actualPeriodName.equals(period)) {
			Logs.update("TC02- Verify the header", "Period is as expected ", Status.PASS, driver);
		}

		else {
			Logs.update("TC02- Verify the header", "Period is NOT as expected ", Status.FAIL, driver);
		}

		if (actualBGName.equals("BU345-CASC SA")) {
			Logs.update("TC02- Verify the header", "Business Group name is as expected ", Status.PASS, driver);
		}

		else {
			Logs.update("TC02- Verify the header", "Business Group name is NOT as expected ", Status.FAIL, driver);
		}

		// TC -03

		driver.findElement(R12001BGobj.currentQuarterActualAOE_target).sendKeys("4");
		driver.findElement(R12001BGobj.currentQuarterActualAOE_priorYear).sendKeys("5");

		driver.findElement(R12001BGobj.currentQuarterAdjustedAOE_target).sendKeys("2");
		driver.findElement(R12001BGobj.currentQuarterAdjustedAOE_priorYear).sendKeys("4");

		String targetVariance = driver.findElement(R12001BGobj.varianceTarget$).getAttribute("value");
		String priorYearVariance = driver.findElement(R12001BGobj.variancePriorYear$).getAttribute("value");

		String percenttargetVariance = driver.findElement(R12001BGobj.varianceTargetpercent).getAttribute("value");
		String percentpriorYearVariance = driver.findElement(R12001BGobj.variancePriorYearpercent)
				.getAttribute("value");

		System.out.println(targetVariance + " " + priorYearVariance + " " + percenttargetVariance + " "
				+ percentpriorYearVariance);
		String changeinAOETextArea = Util.getAllNecessaryData(TestType, "2001", "SOR_500plus_Chars");

		driver.findElement(R12001BGobj.changeinAOETextArea).sendKeys(changeinAOETextArea);
		int actualLength = driver.findElement(R12001BGobj.changeinAOETextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1500);
		if (actualLength == 1500) {
			Logs.update("TC05- Verify the length of text area changeinAOETextArea",
					"Length is as expected - not more than 1500 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC05- Verify the length of text area changeinAOETextArea",
					"Length is NOT as expected -  It is more than 1500 characters  ", Status.FAIL, driver);
		}

		// Revenue
		String textArea1000chars = Util.getAllNecessaryData(TestType, "2001", "Characters_1000");
		driver.findElement(R12001BGobj.revenueTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.revenueTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC06- Verify the length of text area Revenue",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC06- Verify the length of text area Revenue",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// costOfInventoryTextArea
		driver.findElement(R12001BGobj.costOfInventoryTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.revenueTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC07- Verify the length of text area costOfInventoryTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC07- Verify the length of text area costOfInventoryTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// manufacturingCostsTextArea
		driver.findElement(R12001BGobj.manufacturingCostsTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.manufacturingCostsTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC08- Verify the length of text area manufacturingCostsTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC08- Verify the length of text area manufacturingCostsTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// marketTomarketImpactTextArea
		driver.findElement(R12001BGobj.marketTomarketImpactTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.marketTomarketImpactTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC09- Verify the length of text area marketTomarketImpactTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC09- Verify the length of text area marketTomarketImpactTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// tradingMarginsTextArea
		driver.findElement(R12001BGobj.tradingMarginsTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.tradingMarginsTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC09- Verify the length of text area tradingMarginsTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC09- Verify the length of text area tradingMarginsTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// tradingMarginsTextArea
		driver.findElement(R12001BGobj.tradingMarginsTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.tradingMarginsTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC09- Verify the length of text area tradingMarginsTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC09- Verify the length of text area tradingMarginsTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// SGATextArea
		driver.findElement(R12001BGobj.SGATextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.SGATextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC09- Verify the length of text area SGATextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC09- Verify the length of text area SGATextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// otherTextArea
		driver.findElement(R12001BGobj.otherTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.otherTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC09- Verify the length of text area otherTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC09- Verify the length of text area otherTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// externalEnvironmentTextArea
		driver.findElement(R12001BGobj.externalEnvironmentTextArea).sendKeys(textArea1000chars);
		actualLength = driver.findElement(R12001BGobj.externalEnvironmentTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 1000);
		if (actualLength == 1000) {
			Logs.update("TC10- Verify the length of text area externalEnvironmentTextArea",
					"Length is as expected - not more than 1000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC10- Verify the length of text area externalEnvironmentTextArea",
					"Length is NOT as expected -  It is more than 1000 characters  ", Status.FAIL, driver);
		}

		// mostRecentlyPublishedTextArea
		String textArea2000chars = Util.getAllNecessaryData(TestType, "2001", "Characters_2000");
		driver.findElement(R12001BGobj.mostRecentlyPublishedTextArea).sendKeys(textArea2000chars);
		actualLength = driver.findElement(R12001BGobj.mostRecentlyPublishedTextArea).getAttribute("value").length();
		System.out.println(actualLength);
		Assert.assertEquals(actualLength, 2000);
		if (actualLength == 2000) {
			Logs.update("TC10- Verify the length of text area mostRecentlyPublishedTextArea",
					"Length is as expected - not more than 2000 characters  ", Status.PASS, driver);
		}

		else {
			Logs.update("TC10- Verify the length of text area externalEnvironmentTextArea",
					"Length is NOT as expected -  It is more than 2000 characters  ", Status.FAIL, driver);
		}

		// addButton
		Thread.sleep(3000);
		driver.findElement(R12001BGobj.addbutton).click();
		Thread.sleep(3000);
		driver.findElement(R12001BGobj.itemTextBox).sendKeys("item1");
		Thread.sleep(3000);
		driver.findElement(R12001BGobj.countryTextBox).sendKeys("country1");
		Thread.sleep(3000);
		driver.findElement(R12001BGobj.explainationTextBox).sendKeys("Explain");
		Thread.sleep(3000);
		driver.findElement(R11798Dobj.submitButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform(); // Click confirm submit
		Thread.sleep(3000);
		actions.sendKeys(Keys.ENTER).build().perform(); // Click on warning ok
														// button
		Thread.sleep(4000);
		actions.sendKeys(Keys.ENTER).build().perform(); // Click on warning ok
														// button
		Thread.sleep(3000);
		driver.switchTo().alert().accept();

		// Recall
		driver.switchTo().window(currentHandle);
		Thread.sleep(2000);
		driver.findElement(By.name("StatusDashBoardButton")).click();

		Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(5000);
		// Base_class.waitForElementTobeClickable(driver,
		// HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(5000);
		// Base_class.waitForElementToVisible(driver,
		// HubHomePageObj.selectSchedule, 10);
		driver.findElement(HubHomePageObj.selectScheduleNew).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		// Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
		driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
		driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
		Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(4000);
		driver.findElement(By.name("btnRecallEdit")).click();

		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

	}
}
