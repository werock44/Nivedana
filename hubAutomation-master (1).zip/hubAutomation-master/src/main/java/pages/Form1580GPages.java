package pages;

import java.sql.SQLException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.Form_1580G_Obj;
import objectRepository.Form_1590G_Obj;
import objectRepository.Form_1930D_Obj;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class Form1580GPages {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	static Actions actions;
	static WebElement entityXpath;
	static WebElement list;
	static WebDriverWait wait;
	static WebElement dueDateValue;
    static WebElement dueDateField;
	static int i;

	// Test case TC_01 and TC_02

	public static void verifyScheduleDistributed(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		boolean scheduleDistributed = entityXpath.isDisplayed();
		Assert.assertTrue(scheduleDistributed, "Schedule is not distributed correctly");
		if (scheduleDistributed == true) {
			Thread.sleep(4000);
			Logs.update(
					"R2.1_1580G_TC01_Verify whether the Schedule owner is able to distribute Schedule",
					"Sales/Purchases of Selected Svcs/Intangible Assets schedule is distributed successfully", Status.PASS, driver);
		} else {
			Logs.update(
					"R2.1_1580G_TC01_Verify whether the Schedule owner is able to distribute Schedule",
					"Sales/Purchases of Selected Svcs/Intangible Assets schedule is NOT distributed successfully", Status.FAIL, driver);
		}
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String ScheduleNameAct = driver.findElement(HubContributorFormObj.ScheduleNameValue).getText();
		Assert.assertEquals(ScheduleNameAct, schedule);
		if (ScheduleNameAct.equalsIgnoreCase(schedule)) {
			Logs.update("R2.1_1580G_TC02.1_Verify the shchedule Name",
					"Schedule Name is displayed as expected: " + ScheduleNameAct, Status.PASS, driver);
		} else {
			Logs.update("R2.1_1580G_TC02.1_Verify the shchedule Name", "Schedule Name is not displayed as expected",
					Status.FAIL, driver);
		}
		String periodAct = driver.findElement(HubContributorFormObj.PeriodValue).getText();
		Assert.assertEquals(periodAct, period);
		if (periodAct.equalsIgnoreCase(period)) {
			Logs.update(
					"R2.1_1580G_TC02.2_Verify that period is appropriate",
					"Period is displayed as expected to which period the schedule is distributed to_"+periodAct, Status.PASS, driver);
		} else {
			Logs.update(
					"R2.1_1580G_TC02.2_Verify that period is appropriate",
					"Period is not displayed as expected", Status.FAIL, driver);
		}

		String reportingUnit_HeaderAct = driver.findElement(Form_1580G_Obj.reportingUnit_Header).getText();
		Assert.assertEquals(reportingUnit_HeaderAct, "Reporting Unit :");
		if (reportingUnit_HeaderAct.equalsIgnoreCase("Reporting Unit :")) {
			Logs.update("R2.1_1580G_TC02.3 verify the reporting Unit header",
					"Reporting Unit header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R2.1_1580G_TC02.3 verify the reporting Unit header",
					"Reporting Unit header is not displayed as expected", Status.FAIL, driver);
		}

		String RuGroupExp = entityName + "-" + scheduleLongDesc;
		String RuGroupAct = driver.findElement(HubContributorFormObj.ReportingUnitValue).getText();
		Assert.assertEquals(RuGroupAct, RuGroupExp);
		if (RuGroupAct.equalsIgnoreCase(RuGroupExp)) {
			Logs.update("R2.1_1580G_TC02.4_Verify that Reporting unit is displayed in the Schedule header",
					"Reporting unit is displayed as expected: " + RuGroupAct, Status.PASS, driver);
		} else {
			Logs.update("R2.1_1580G_TC02.4_Verify that Reporting unit is displayed in the Schedule header",
					"Reporting unit is NOT displayed as expected: " + RuGroupAct, Status.FAIL, driver);

		}

		driver.findElement(HubContributorFormObj.btn_Instructions).click();
		HubContributor.switchWindow_3(driver);
		String pageURLAct = driver.getCurrentUrl();
		String UrlExp = "https://sites.cargill.com/sites/Finance/CFR/Pages/Quick-Learning.aspx";
		System.out.println(pageURLAct);
		if (pageURLAct.equalsIgnoreCase(UrlExp)) {
			Logs.update("R2.1_1580G_TC02.5 verify the user is navigated to QuickLearning page",
					"Clicking on Instructions button user is navigated to page: " + pageURLAct, Status.PASS, driver);
		} else {
			Logs.update("R2.1_1580G_TC02.5 verify the user is navigated to QuickLearning page",
					"Clicking on Instructions button user is NOT navigated to page: " + UrlExp + "But navigated to: "
							+ pageURLAct,
					Status.FAIL, driver);
		}
		//driver.quit();
	}


	//Test case TC06
	public static void verify_Foreign_Affiliates_Schedule_A_Field(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String chooseTxnCode="1.1-Rights";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_A).click();
		
		WebElement FOREIGN_AFFILIATES_Sch_A_Ele= driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_A);

		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1580G", "MaxLengthOfField",
				FOREIGN_AFFILIATES_Sch_A_Ele, Logs, "R2_1_1580G_TC06_1", 19);
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "DecimalVal",
				FOREIGN_AFFILIATES_Sch_A_Ele, Logs, "R2_1_1580G_TC06_2", "FOREIGN AFFILIATES field");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "InvalidVal",
				FOREIGN_AFFILIATES_Sch_A_Ele, Logs, "R2_1_1580G_TC06_3", "FOREIGN AFFILIATES field");
		/*HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1580G", "NegVal", FOREIGN_AFFILIATES_Sch_A_Ele, Logs,
				"R2_1_1580G_TC06_4", 20, "FOREIGN AFFILIATES field");*/
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, FOREIGN_AFFILIATES_Sch_A_Ele, "1580G", "PosNegValue", Logs, "R2_1_1580G_TC06_4");
		driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_A).sendKeys("1234");
		driver.findElement(HubContributorFormObj.btn_Save).click();

		String actHeader = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		
		Assert.assertEquals(actHeader, "Your changes have been saved successfully!!");
		if (actHeader.equalsIgnoreCase("Your changes have been saved successfully!!")) {
			Logs.update("R2_1_1580G_TC06_5 verify the able to save the form",
					"Able to save the form successfully with message "+actHeader, Status.PASS, driver);
		} else {
			Logs.update("R2_1_1580G_TC06_5 verify the able to save the form",
					"Not Able to save the form.Message displayed is:  "+actHeader, Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_A).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);
	
		//driver.quit();
	}
	

	//Test case TC07
	public static void verify_UNAFFILIATED_FOREIGN_ENTITIES_Schedule_A_Field(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String chooseTxnCode="1.1-Rights";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_A).click();
		
		WebElement UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Ele= driver.findElement(Form_1580G_Obj.UnAffiliatesForeignEntities_Schedule_A);

		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1580G", "MaxLengthOfField",
				UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Ele, Logs, "R2_1_1580G_TC07_1", 19);
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "DecimalVal",
				UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Ele, Logs, "R2_1_1580G_TC07_2", "UNAFFILIATED FOREIGN ENTITIES field");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "InvalidVal",
				UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Ele, Logs, "R2_1_1580G_TC07_3", "FOREIGN AFFILIATES field");
		/*HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1580G", "NegVal", FOREIGN_AFFILIATES_Sch_A_Ele, Logs,
				"R2_1_1580G_TC06_4", 20, "FOREIGN AFFILIATES field");*/
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Ele, "1580G", "PosNegValue", Logs, "R2_1_1580G_TC07_4");
		driver.findElement(Form_1580G_Obj.UnAffiliatesForeignEntities_Schedule_A).sendKeys("1234");
		driver.findElement(HubContributorFormObj.btn_Save).click();

		String actHeader = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		
		Assert.assertEquals(actHeader, "Your changes have been saved successfully!!");
		if (actHeader.equalsIgnoreCase("Your changes have been saved successfully!!")) {
			Logs.update("R2_1_1580G_TC07_5 verify the able to save the form",
					"Able to save the form successfully with message "+actHeader, Status.PASS, driver);
		} else {
			Logs.update("R2_1_1580G_TC07_5 verify the able to save the form",
					"Not Able to save the form.Message displayed is:  "+actHeader, Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_A).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);

	
		//driver.quit();

	}

	//Test case TC11
	public static void verify_Foreign_Affiliates_Schedule_B_Field(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String chooseTxnCode="1.1-rights related to the use of a patent";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_B).click();
		
		WebElement FOREIGN_AFFILIATES_Sch_B_Ele= driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_B);

		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1580G", "MaxLengthOfField",
				FOREIGN_AFFILIATES_Sch_B_Ele, Logs, "R2_1_1580G_TC11_1", 19);
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "DecimalVal",
				FOREIGN_AFFILIATES_Sch_B_Ele, Logs, "R2_1_1580G_TC11_2", "FOREIGN AFFILIATES field");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "InvalidVal",
				FOREIGN_AFFILIATES_Sch_B_Ele, Logs, "R2_1_1580G_TC11_3", "FOREIGN AFFILIATES field");
		/*HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1580G", "NegVal", FOREIGN_AFFILIATES_Sch_A_Ele, Logs,
				"R2_1_1580G_TC06_4", 20, "FOREIGN AFFILIATES field");*/
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, FOREIGN_AFFILIATES_Sch_B_Ele, "1580G", "PosNegValue", Logs, "R2_1_1580G_TC11_4");
		driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_B).sendKeys("1234");
		driver.findElement(HubContributorFormObj.btn_Save).click();

		String actHeader = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		
		Assert.assertEquals(actHeader, "Your changes have been saved successfully!!");
		if (actHeader.equalsIgnoreCase("Your changes have been saved successfully!!")) {
			Logs.update("R2_1_1580G_TC11_5 verify the able to save the form",
					"Able to save the form successfully with message "+actHeader, Status.PASS, driver);
		} else {
			Logs.update("R2_1_1580G_TC11_5 verify the able to save the form",
					"Not Able to save the form.Message displayed is:  "+actHeader, Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_B).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);

	
		//driver.quit();

	}	
	
	//Test case TC12
	public static void verify_UNAFFILIATED_FOREIGN_ENTITIES_Schedule_B_Field(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String chooseTxnCode="1.1-rights related to the use of a patent";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_B).click();
		
		WebElement UnAffiliates_Foreign_Sch_B_Ele= driver.findElement(Form_1580G_Obj.UnAffiliatesForeignEntities_Schedule_B);

		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1580G", "MaxLengthOfField",
				UnAffiliates_Foreign_Sch_B_Ele, Logs, "R2_1_1580G_TC_12_1", 19);
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "DecimalVal",
				UnAffiliates_Foreign_Sch_B_Ele, Logs, "R2_1_1580G_TC12_2", "UNAFFILIATED FOREIGN ENTITIES field");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1580G", "InvalidVal",
				UnAffiliates_Foreign_Sch_B_Ele, Logs, "R2_1_1580G_TC12_3", "UNAFFILIATED FOREIGN ENTITIES field");
		/*HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1580G", "NegVal", FOREIGN_AFFILIATES_Sch_A_Ele, Logs,
				"R2_1_1580G_TC06_4", 20, "FOREIGN AFFILIATES field");*/
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, UnAffiliates_Foreign_Sch_B_Ele, "1580G", "PosNegValue", Logs, "R2_1_1580G_TC12_4");
		driver.findElement(Form_1580G_Obj.UnAffiliatesForeignEntities_Schedule_B).sendKeys("1234");
		driver.findElement(HubContributorFormObj.btn_Save).click();

		String actHeader = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		
		Assert.assertEquals(actHeader, "Your changes have been saved successfully!!");
		if (actHeader.equalsIgnoreCase("Your changes have been saved successfully!!")) {
			Logs.update("R2_1_1580G_TC12_5 verify the able to save the form",
					"Able to save the form successfully with message "+actHeader, Status.PASS, driver);
		} else {
			Logs.update("R2_1_1580G_TC12_5 verify the able to save the form",
					"Not Able to save the form.Message displayed is:  "+actHeader, Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_B).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);

	
		//driver.quit();
		
	}
	
	//Test case TC04
		public static void verify_transactionCodeSmartText(WebDriver driver, String entityName, String period, String schedule,
				String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
			//String parentWindow = driver.getWindowHandle();
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(7000);
			//TC-04-Negative Scenario- Verify Invalid value is not accepted  for Transaction code
			String chooseInvalidTxnCode="HubAutomation";
			driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseInvalidTxnCode);
			Thread.sleep(2000);
			actions.sendKeys(Keys.TAB).build().perform();
			Thread.sleep(2000);
			String actualText=driver.findElement(Form_1580G_Obj.transactionCodeText).getText();
			
			Assert.assertEquals(actualText, "Type a value");
			
			if (actualText.equalsIgnoreCase("Type a value"))
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule",
						"Invalid Text is not accepted ", Status.PASS, driver);
			}
			
			else 
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule",
						"Invalid Text is accepted ", Status.FAIL, driver);
			}
			
			
			//TC-04-Positive scenario- Verify valid value is accepted  for Transaction code
			String choosevalidTxnCode="1.1";
			driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(choosevalidTxnCode);
			Thread.sleep(2000);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(2000);
			actualText=driver.findElement(Form_1580G_Obj.transactionCodeText).getText();
			Assert.assertNotSame(actualText, "Type a value");
			
			if (actualText.equalsIgnoreCase("Type a value"))
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule",
						"valid Text is not accepted ", Status.FAIL, driver);
			}
			
			else 
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule",
						"Valid Text is accepted ", Status.PASS, driver);
			}
			
			//Verify Static text
			String textMockup="Schedule A - U.S. Reporter's Sales of elected Services and Intangible Assets to Foreign Entities";
			String actualstatictext=driver.findElement(Form_1580G_Obj.scheduleAStaticText).getText();
			Assert.assertEquals(textMockup, actualstatictext);
			
			if (textMockup.equalsIgnoreCase(actualstatictext))
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Validate the static text of  Schedule A   section",
						"Schedule A text is as expected", Status.PASS, driver);
			}
			
			else 
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Validate the static text of  Schedule A   section",
						"Schedule A text is NOT as expected", Status.FAIL, driver);
			}
			
			textMockup="Choose a Transaction Code To Enter Data : ";
			actualstatictext=driver.findElement(Form_1580G_Obj.transactionCodeStatictext).getText();
			Assert.assertEquals(textMockup, actualstatictext);
			
			if (textMockup.equalsIgnoreCase(actualstatictext))
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Validate the static text of Choose a Transaction Code To Enter Data ",
						"Transaction code static text is as expected", Status.PASS, driver);
			}
			
			else 
			{
				Logs.update("HUB2.0_R2.1_1580G_TC04 Validate the static text of Choose a Transaction Code To Enter Data",
						"Transaction code static text is NOT as expected", Status.FAIL, driver);
			}
			
			
}
		
		//Test case TC05
				public static void verify_CountryCodeSmartText(WebDriver driver, String entityName, String period, String schedule,
						String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
					actions = new Actions(driver);
					HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
					entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
					actions.moveToElement(entityXpath).doubleClick().build().perform();
					Thread.sleep(4000);
					Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
					//String parentWindow = driver.getWindowHandle();
					driver.findElement(HubHomePageObj.Btn_Open).click();
					Thread.sleep(3000);
					HubContributor.switchWindow(driver);
					driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
					Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
					Thread.sleep(7000);
					driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys("1.1");
					Thread.sleep(2000);
					actions.sendKeys(Keys.TAB).build().perform();
					driver.findElement(Form_1580G_Obj.btn_Add_Schedule_A).click();
					Thread.sleep(2000);
					//TC-05-Negative Scenario- Verify Invalid CountryCode is not accepted  
					String chooseInvalidCountryCode="United States";
					driver.findElement(Form_1580G_Obj.countryName_Schedule_A_AutoSuggest).sendKeys(chooseInvalidCountryCode);
					Thread.sleep(2000);
					actions.sendKeys(Keys.TAB).build().perform();
					Thread.sleep(2000);
					
					
					String actualText=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
					boolean actualTextPresent=actualText.contains("Country does not Exists!");
					Assert.assertTrue(actualTextPresent);
					if (actualText.contains("Country does not Exists!"))
					{
						Logs.update("HUB2.0_R2.1_1580G_TC05 Validate whether the Hub Contributor is able to select any Country from the dropdown by using the smart text for the field  Sales to  for Schedule A.",
								"Country code United States is not accepted ", Status.PASS, driver);
					}
					
					else 
					{
						Logs.update("HUB2.0_R2.1_1580G_TC05 Validate whether the Hub Contributor is able to select any Country from the dropdown by using the smart text for the field  Sales to  for Schedule A.",
								"Country code United States is accepted ", Status.FAIL, driver);
					}
					Thread.sleep(3000);
					driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
					
					 
					//TC-05-Positive scenario- Verify valid value is accepted  for Country code
					String chooseValidCountryCode="India";
					driver.findElement(Form_1580G_Obj.countryName_Schedule_A_AutoSuggest).sendKeys(chooseValidCountryCode);
					Thread.sleep(2000);
					actions.sendKeys(Keys.TAB).build().perform();
					Thread.sleep(2000);
					actualText=driver.findElement(Form_1580G_Obj.countryCodeText).getText();
					Assert.assertNotSame(actualText, "Type a value");
					
					if (actualText.equalsIgnoreCase("Type a value"))
					{
						Logs.update("HUB2.0_R2.1_1580G_TC05 Validate whether the Hub Contributor is able to select any Country from the dropdown by using the smart text for the field  Sales to  for Schedule A.",
								"Country code is not accepted ", Status.FAIL, driver);
					}
					
					else 
					{
						Logs.update("HUB2.0_R2.1_1580G_TC05 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule",
								"Country code is accepted ", Status.PASS, driver);
					}
		}
		

	// Test case TC09
	public static void verify_CountryDropDown_Sch_B(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		// String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys("1.1");
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_B).click();
		Thread.sleep(2000);
		// TC-09-Negative Scenario- Verify Invalid CountryCode is not accepted
		String chooseInvalidCountryCode = "United States";
		driver.findElement(Form_1580G_Obj.countryName_Schedule_B_AutoSuggest).sendKeys(chooseInvalidCountryCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(2000);

		String actualText = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		boolean actualTextPresent = actualText.contains("Country does not Exists!");
		Assert.assertTrue(actualTextPresent);

		if (actualText.contains("Country does not Exists!")) {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC09 Validate whether the Hub Contributor is able to select any Country",
					"Invalid Country code United States is not accepted in country smart text dropdown in schedule B ", Status.PASS, driver);
		}

		else {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC09 Validate whether the Hub Contributor is able to select any Country",
					"Invalid Country code United States is accepted in country smart text for schedule B", Status.FAIL, driver);
		}
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

		//
		// TC-09-Positive scenario- Verify valid value is accepted for Country
		// code
		String chooseValidCountryCode = "India";
		driver.findElement(Form_1580G_Obj.countryName_Schedule_B_AutoSuggest).sendKeys(chooseValidCountryCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(2000);
		String actualText1 = driver.findElement(Form_1580G_Obj.countryCodeText_sch_B).getText();
		System.out.println("Text:" +actualText1);
		String actualText2 = driver.findElement(Form_1580G_Obj.countryCodeText_sch_B).getAttribute("value");
		System.out.println("Value:" +actualText2);
		Assert.assertNotSame(actualText, "Type a value");

		if (!actualText.equalsIgnoreCase("Type a value")) {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC09 Validate whether the Hub Contributor is able to select valid Country ",
					"Able to select a valid country from smart text country drop down for Schedule B ", Status.PASS, driver);
		}

		else {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC09 Verify whether the Hub Contributor is able to select valid Country ",
					"Not able to select a valid country from smart text drop down for Schedule B ", Status.PASS, driver);
		}
	}
		
	//Test case TC_15
	public static void verify_Submit_WithCountryBlank_Schedule_A_Field(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String chooseTxnCode="12.1-computer software";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_A).click();
		driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_A).sendKeys("1234");
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		String SubmitErrorMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		System.out.println(SubmitErrorMsg);
		boolean errorMsgContain=SubmitErrorMsg.contains("Please fill the Country Name for the following Transaction Code");
		Assert.assertTrue(errorMsgContain);
		
		if (SubmitErrorMsg.contains("Please fill the Country Name for the following Transaction Code")){
			Logs.update("HUB2.0_R2.1_1580G_TC15 verify if user is able to submit without country selected", "User is not able to submit the schedule without selecting contry for schedule A. Popup Msg: "+SubmitErrorMsg, Status.PASS, driver);
		} else{
			Logs.update("HUB2.0_R2.1_1580G_TC15 verify if user is able to submit without country selected", "User is able to submit the schedule without selecting contry for schedule A. Message displayed: "+SubmitErrorMsg, Status.FAIL, driver);
		}
		
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		WebElement recordToBeDeleted=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A);
	boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_A).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);
		//HubContributor.deleteTxnCodeRecord(driver, recordToBeDeleted, driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_A));
		//driver.quit();
			
}
		

	//Test case TC_16
	public static void verify_Submit_WithCountryBlank_Schedule_B_Field(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String chooseTxnCode="12.1-computer software";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_B).click();
		driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_B).sendKeys("1234");
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		String SubmitErrorMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		System.out.println(SubmitErrorMsg);
		boolean errorMsgContain=SubmitErrorMsg.contains("Please fill the Country Name for the following Transaction Code");
		Assert.assertTrue(errorMsgContain);
		
		if (SubmitErrorMsg.contains("Please fill the Country Name for the following Transaction Code")){
			Logs.update("HUB2.0_R2.1_1580G_TC16 verify if user is able to submit without country selected", "User is not able to submit the schedule without selecting contry for schedule A. Popup Msg: "+SubmitErrorMsg, Status.PASS, driver);
		} else{
			Logs.update("HUB2.0_R2.1_1580G_TC16 verify if user is able to submit without country selected", "User is able to submit the schedule without selecting contry for schedule A. Message displayed: "+SubmitErrorMsg, Status.FAIL, driver);
		}
		
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_B).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);
		//WebElement recordToBeDeleted=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B);
		//HubContributor.deleteTxnCodeRecord(driver, recordToBeDeleted, driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_B));

		//driver.quit();			
}
	
	public static void verify_SummaryReport_Schedule_A(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String[] chooseTxnCode={"1.1","12.1"};
		String[] countryselect={"Algeria","Brazil"};
		String valToEnterInForeignAff="111";
		String valToEnterInUnAffiliatesForeign="123";
		for(int i=0; i<=1; i++)
		{
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode[i]);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_A).click();
		driver.findElement(Form_1580G_Obj.countryName_Schedule_A_AutoSuggest).sendKeys(countryselect[i]);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_A).sendKeys(valToEnterInForeignAff);
		driver.findElement(Form_1580G_Obj.UnAffiliatesForeignEntities_Schedule_A).sendKeys(valToEnterInUnAffiliatesForeign);
		driver.findElement(HubContributorFormObj.btn_Save).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
		
		driver.findElement(Form_1580G_Obj.SummaryExpandIcon_Sch_A).click();
		Thread.sleep(2000);
		String TxnCodeValAct=driver.findElement(Form_1580G_Obj.Summary_TransactionCode_Sch_A_Row_1).getText();
		System.out.println("Actual "+ TxnCodeValAct+"expected "+chooseTxnCode[0]);
		boolean txnCodeStatus=TxnCodeValAct.contains(chooseTxnCode[0]);
		Assert.assertTrue(txnCodeStatus);
		if (TxnCodeValAct.contains(chooseTxnCode[0])){
			Logs.update("HUB2.0_R2.1_1580G_TC08_1 Verify transaction code is displayed", "Transaction code selected by user is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC08_1 Verify transaction code is displayed", "Transaction code selected by user is Not displayed", Status.FAIL, driver);
		}
		
		String countryAct=driver.findElement(Form_1580G_Obj.Summary_CountryName_Sch_A_Row_1).getText();
		Assert.assertEquals(countryAct, countryselect[0]);
		System.out.println(countryAct+""+countryselect[0]);
		if(countryAct.equalsIgnoreCase(countryselect[0])){
			Logs.update("HUB2.0_R2.1_1580G_TC08_2 Verify that Country name is displayed in summary" , "Country Name is displayed in summary report as expected" , Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC08_2 Verify that Country name is displayed in summary" , "Country Name is Not displayed in summary report" , Status.FAIL, driver);
		}
		
		String foreignAff_Act=driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_Sch_A_Row_1).getText();
		Assert.assertEquals(foreignAff_Act, valToEnterInForeignAff);
		if(foreignAff_Act.equals(valToEnterInForeignAff)){
			Logs.update("HUB2.0_R2.1_1580G_TC08_3 verify foreign affiliates is displayed in summary", "Foreign affiliates entered by used is displayed in summary report as expected", Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC08_3 verify foreign affiliates is displayed in summary", "Foreign affiliates entered by used is not displayed in summary report", Status.FAIL, driver);
		}
		
		String unaffiliatedForeign_Act=driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_Sch_A_Row_1).getText();
		Assert.assertEquals(unaffiliatedForeign_Act, valToEnterInUnAffiliatesForeign);
		if(unaffiliatedForeign_Act.equalsIgnoreCase(valToEnterInUnAffiliatesForeign)){
			Logs.update("HUB2.0_R2.1_1580G_TC08_4 verify Unaffiliated foreign entites is displayed in summary", "Unaffiliated foreign entites entered by used is displayed in summary report as expected", Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC08_4 verify Unaffiliated foreign entites is displayed in summary", "Unaffiliated foreign entites entered by used is NOT displayed in summary report as expected", Status.FAIL, driver);
		}
	
		int total_ForAff_OfRow1=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_Total_Sch_A_Row_1).getText());
		Logs.update("HUB2.0_R2.1_1580G_TC08_5 verify that the total amount is displayed", "The total amount displayed against the column Foreign Affiliates as expected "+total_ForAff_OfRow1, Status.PASS, driver);
		int total_ForAff_OfRow2=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_Total_Sch_A_Row_2).getText());
		//Grand Total is sum of total amount
		String grandTotal_ForAff=Integer.toString(total_ForAff_OfRow1+total_ForAff_OfRow2);
		
		String grandTotal_ForAff_Act=driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_GrandTotal_Sch_A).getText();
		Assert.assertEquals(grandTotal_ForAff_Act, grandTotal_ForAff);
		if(grandTotal_ForAff_Act.equals(grandTotal_ForAff)){
			Logs.update("HUB2.0_R2.1_1580G_TC08_6 Verify that grand total is displayed against Foreign Affiliates", "Grand Total is displayed with sum of all amounts entered against each transaction as expected: "+total_ForAff_OfRow1+"+"+total_ForAff_OfRow2+"="+grandTotal_ForAff_Act, Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC08_6 Verify that grand total is displayed against Foreign Affiliates", "Grand Total is not displayed with sum of all amounts entered against each transaction", Status.FAIL, driver);
		}
		
		int total_UnAffiliated_OfRow1=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_Total_Sch_A_Row_1).getText());
		Logs.update("HUB2.0_R2.1_1580G_TC08_7 verify that the total amount is displayed", "The total amount displayed against the column Unaffiliated Foreign Entites as expected "+total_UnAffiliated_OfRow1, Status.PASS, driver);
		int total_UnAffiliated_OfRow2=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_Total_Sch_A_Row_2).getText());
		//Grand Total is sum of total amount
		String grandTotal_UnAffiliated=Integer.toString(total_UnAffiliated_OfRow1+total_UnAffiliated_OfRow2);
		//Get the actual grand total
		String grandTotal_UnAffiliated_Act=driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_GrandTotal_Sch_A).getText();
		Assert.assertEquals(grandTotal_UnAffiliated_Act, grandTotal_UnAffiliated);
		if(grandTotal_UnAffiliated_Act.equals(grandTotal_UnAffiliated)){
			Logs.update("HUB2.0_R2.1_1580G_TC08_8 Verify that grand total is displayed against Unaffiliated Foreign Entites", "Grand Total is displayed with sum of all amounts entered against each transaction as expected: "+total_UnAffiliated_OfRow1+"+"+total_UnAffiliated_OfRow2+"="+grandTotal_UnAffiliated, Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC08_8 Verify that grand total is displayed against Unaffiliated Foreign Entites", "Grand Total is not displayed with sum of all amounts entered against each transaction", Status.FAIL, driver);
		}
		
		for(i=0; i<=1; i++){
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).clear();
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_A_AutoSuggest).sendKeys(chooseTxnCode[i]);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_A).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_A).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
		

	
		}
		while(ifFirstRecPresent==true);
}
}

	public static void verify_SummaryReport_Schedule_B(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String[] chooseTxnCode={"1.1","12.1"};
		String[] countryselect={"Algeria","Brazil"};
		String valToEnterInForeignAff="111";
		String valToEnterInUnAffiliatesForeign="123";
		for(int i=0; i<=1; i++)
		{
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode[i]);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		driver.findElement(Form_1580G_Obj.btn_Add_Schedule_B).click();
		driver.findElement(Form_1580G_Obj.countryName_Schedule_B_AutoSuggest).sendKeys(countryselect[i]);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		driver.findElement(Form_1580G_Obj.ForeignAffiliates_Schedule_B).sendKeys(valToEnterInForeignAff);
		driver.findElement(Form_1580G_Obj.UnAffiliatesForeignEntities_Schedule_B).sendKeys(valToEnterInUnAffiliatesForeign);
		driver.findElement(HubContributorFormObj.btn_Save).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
		
		driver.findElement(Form_1580G_Obj.SummaryExpandIcon_Sch_B).click();
		Thread.sleep(2000);
		String TxnCodeValAct=driver.findElement(Form_1580G_Obj.Summary_TransactionCode_Sch_B_Row_1).getText();
		System.out.println("Actual "+ TxnCodeValAct+"expected "+chooseTxnCode[0]);
		boolean txnCodeStatus=TxnCodeValAct.contains(chooseTxnCode[0]);
		Assert.assertTrue(txnCodeStatus);
		if (TxnCodeValAct.contains(chooseTxnCode[0])){
			Logs.update("HUB2.0_R2.1_1580G_TC13_1 Verify transaction code is displayed", "Transaction code selected by user is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC13_1 Verify transaction code is displayed", "Transaction code selected by user is Not displayed", Status.FAIL, driver);
		}
		
		String countryAct=driver.findElement(Form_1580G_Obj.Summary_CountryName_Sch_B_Row_1).getText();
		Assert.assertEquals(countryAct, countryselect[0]);
		System.out.println(countryAct+""+countryselect[0]);
		if(countryAct.equalsIgnoreCase(countryselect[0])){
			Logs.update("HUB2.0_R2.1_1580G_TC13_2 Verify that Country name is displayed in summary" , "Country Name is displayed in summary report as expected" , Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC13_2 Verify that Country name is displayed in summary" , "Country Name is Not displayed in summary report" , Status.FAIL, driver);
		}
		
		String foreignAff_Act=driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_Sch_B_Row_1).getText();
		Assert.assertEquals(foreignAff_Act, valToEnterInForeignAff);
		if(foreignAff_Act.equals(valToEnterInForeignAff)){
			Logs.update("HUB2.0_R2.1_1580G_TC13_3 verify foreign affiliates is displayed in summary", "Foreign affiliates entered by used is displayed in summary report as expected", Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC13_3 verify foreign affiliates is displayed in summary", "Foreign affiliates entered by used is not displayed in summary report", Status.FAIL, driver);
		}
		
		String unaffiliatedForeign_Act=driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_Sch_B_Row_1).getText();
		Assert.assertEquals(unaffiliatedForeign_Act, valToEnterInUnAffiliatesForeign);
		if(unaffiliatedForeign_Act.equalsIgnoreCase(valToEnterInUnAffiliatesForeign)){
			Logs.update("HUB2.0_R2.1_1580G_TC13_4 verify Unaffiliated foreign entites is displayed in summary", "Unaffiliated foreign entites entered by used is displayed in summary report as expected", Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC13_4 verify Unaffiliated foreign entites is displayed in summary", "Unaffiliated foreign entites entered by used is NOT displayed in summary report as expected", Status.FAIL, driver);
		}
	
		int total_ForAff_OfRow1=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_Total_Sch_B_Row_1).getText());
		Logs.update("HUB2.0_R2.1_1580G_TC13_5 verify that the total amount is displayed", "The total amount displayed against the column Foreign Affiliates as expected "+total_ForAff_OfRow1, Status.PASS, driver);
		int total_ForAff_OfRow2=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_Total_Sch_B_Row_2).getText());
		//Grand Total is sum of total amount
		String grandTotal_ForAff=Integer.toString(total_ForAff_OfRow1+total_ForAff_OfRow2);
		
		String grandTotal_ForAff_Act=driver.findElement(Form_1580G_Obj.Summary_ForeignAffiliates_GrandTotal_Sch_B).getText();
		Assert.assertEquals(grandTotal_ForAff_Act, grandTotal_ForAff);
		if(grandTotal_ForAff_Act.equals(grandTotal_ForAff)){
			Logs.update("HUB2.0_R2.1_1580G_TC13_6 Verify that grand total is displayed against Foreign Affiliates", "Grand Total is displayed with sum of all amounts entered against each transaction as expected: "+total_ForAff_OfRow1+"+"+total_ForAff_OfRow2+"="+grandTotal_ForAff_Act, Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC13_6 Verify that grand total is displayed against Foreign Affiliates", "Grand Total is not displayed with sum of all amounts entered against each transaction", Status.FAIL, driver);
		}
		
		int total_UnAffiliated_OfRow1=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_Total_Sch_B_Row_1).getText());
		Logs.update("HUB2.0_R2.1_1580G_TC13_7 verify that the total amount is displayed", "The total amount displayed against the column Unaffiliated Foreign Entites as expected "+total_UnAffiliated_OfRow1, Status.PASS, driver);
		int total_UnAffiliated_OfRow2=Integer.parseInt(driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_Total_Sch_B_Row_2).getText());
		//Grand Total is sum of total amount
		String grandTotal_UnAffiliated=Integer.toString(total_UnAffiliated_OfRow1+total_UnAffiliated_OfRow2);
		//Get the actual grand total
		String grandTotal_UnAffiliated_Act=driver.findElement(Form_1580G_Obj.Summary_UnaffiliatedForeign_GrandTotal_Sch_B).getText();
		Assert.assertEquals(grandTotal_UnAffiliated_Act, grandTotal_UnAffiliated);
		if(grandTotal_UnAffiliated_Act.equals(grandTotal_UnAffiliated)){
			Logs.update("HUB2.0_R2.1_1580G_TC13_8 Verify that grand total is displayed against Unaffiliated Foreign Entites", "Grand Total is displayed with sum of all amounts entered against each transaction as expected: "+total_UnAffiliated_OfRow1+"+"+total_UnAffiliated_OfRow2+"="+grandTotal_UnAffiliated, Status.PASS, driver);
		}else{
			Logs.update("HUB2.0_R2.1_1580G_TC13_8 Verify that grand total is displayed against Unaffiliated Foreign Entites", "Grand Total is not displayed with sum of all amounts entered against each transaction", Status.FAIL, driver);
		}
		
		for(i=0; i<=1; i++){
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).clear();
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseTxnCode[i]);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			driver.findElement(Form_1580G_Obj.AddedFisrtRow_Schedule_B).click();
			Thread.sleep(2000);
			driver.findElement(Form_1580G_Obj.btn_Delete_Schedule_B).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
		

	
		}
		while(ifFirstRecPresent==true);
}
	}
				//Tc-10

	public static void verify_scheduleBtransactionCodeSmartText(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		// String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		// TC-10-Negative Scenario- Verify Invalid value is not accepted for
		// Transaction code schedule B
		String chooseInvalidTxnCode = "HubAutomation";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(chooseInvalidTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(2000);
		String actualText = driver.findElement(Form_1580G_Obj.transactionCodeTextScheduleB).getText();

		Assert.assertEquals(actualText, "Type a value");

		if (actualText.equalsIgnoreCase("Type a value")) {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC010 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule B",
					"Invalid Text is not accepted ", Status.PASS, driver);
		}

		else {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC10 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule B",
					"Invalid Text is accepted ", Status.FAIL, driver);
		}

		// TC-10-Positive scenario- Verify valid value is accepted for
		// Transaction code in schedule B
		String choosevalidTxnCode = "1.1";
		driver.findElement(Form_1580G_Obj.chooseTransactionCode_Schedule_B_AutoSuggest).sendKeys(choosevalidTxnCode);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(2000);
		actualText = driver.findElement(Form_1580G_Obj.transactionCodeTextScheduleB).getText();
		Assert.assertNotSame(actualText, "Type a value");

		if (actualText.equalsIgnoreCase("Type a value")) {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC10 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule B",
					"valid Text is not accepted ", Status.FAIL, driver);
		}

		else {
			Logs.update(
					"HUB2.0_R2.1_1580G_TC10 Verify whether the Hub Contributor is able to choose  a transaction code from the dropdown through a  smart text entry  for Schedule B",
					"Valid Text is accepted ", Status.PASS, driver);
		}

		// Verify Static text schedule B
		String textMockup = "Schedule B - U.S. Reporter's Purchases of elected Services and Intangible Assets to Foreign Entities";
		String actualstatictext = driver.findElement(Form_1580G_Obj.scheduleBStaticText).getText();
		Assert.assertEquals(textMockup, actualstatictext);

		if (textMockup.equalsIgnoreCase(actualstatictext)) {
			Logs.update("HUB2.0_R2.1_1580G_TC10 Validate the static text of  Schedule B   section",
					"Schedule B text is as expected", Status.PASS, driver);
		}

		else {
			Logs.update("HUB2.0_R2.1_1580G_TC10 Validate the static text of  Schedule B  section",
					"Schedule B text is NOT as expected", Status.FAIL, driver);
		}

	}
	
	//TC-14
	
	public static void verify_commentsInCommentaryField(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {
	
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		// String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		//To verify the comments box accepts 500 chars 
		
		WebElement ele=driver.findElement(Form_1580G_Obj.commentsTextbox);
		ele.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, "1580G", "commentary_LessThan1500_Chars", ele, Logs, "HUB2.0_R2.1_1580G_TC14", 500);
		ele.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1580G", "commentary_1500plus_Chars", ele, Logs, "HUB2.0_R2.1_1580G_TC14", 500);
		
		driver.findElement(HubContributorFormObj.btn_Save).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		
	
	}
	
	

	//Test case TC17
	public static void verifyIfScheduleOwnerIsAbleToEditAfterDueDate(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		//String parentWindow;
		driver=Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		//Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		String expMessage=Util.getAllNecessaryData(TestType, "1580G", "SubmitPopUpHeaderMessage");
		HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.submitPopUpHeader, Logs, expMessage );
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click on OK in submit pop up
		//driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click OK on confirmation pop up
		driver.quit();
		/**
		 * Login again and verify the status of the schedule in status dash board
		 * */
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openScheduleFromStatusDashBoard(driver, entityName, period, schedule, Logs);
		String statusValAct=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
		Assert.assertEquals(statusValAct, "Submitted", "Status should be submitted but it is not" );
		if(statusValAct.equalsIgnoreCase("Submitted")){
			Logs.update("1580G_TC17.1_Verify the status should be submitted in Status Dashboard", "Status is submitted as expected", Status.PASS, driver);
		}else{
			Logs.update("1580G_TC17.1_Verify the status should be submitted in Status Dashboard", "Status is Not submitted", Status.FAIL, driver);
		}
		String usernameExp = System.getProperty("user.name");
		String lastActionByAct=driver.findElement(HubHomePageObj.LockedByVal_Row1).getText();
		Assert.assertEquals(lastActionByAct, usernameExp, "Hub Contributor's id is not displayed correctly");
		if(lastActionByAct.equalsIgnoreCase(usernameExp)){
			Logs.update("1580G_TC17.2_Verify that hub Contributor id should be displayed", "Hub Contributor's id is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("1580G_TC17.2_Verify that hub Contributor id should be displayed", "Hub Contributor's id is not displayed", Status.FAIL, driver);
		}
		driver.quit();
		/**
		 * Login again and verify that Edit button is disabled when due date is not crossed for schedule owner
		 * */
		driver = Login.LaunchHub("Setupurl", Logs);
		Thread.sleep(3000);	
		HubContributorFormPage.openScheduleAttributeManitenancePage(driver, Logs);
		Thread.sleep(5000);
		dueDateField=HubHomePageObj.findDueDateXpath(driver, "A&F 1580 Sales/Purchases of Selected Svcs/Intangible Assets");
		//dueDateField=driver.findElement(HubAdminScreen.scheduleAttributeDueDate_2000A);
		Thread.sleep(3000);
		dueDateValue=HubHomePageObj.findDueDate_Value_Xpath(driver, "A&F 1580 Sales/Purchases of Selected Svcs/Intangible Assets");
		//dueDateValue=driver.findElement(HubAdminScreen.scheduleAttributeDueDate_2000AValue);
		String actDueDateVal=HubContributorFormPage.getDueDateValue(driver, dueDateValue, Logs);
		Logs.update("Due date value should be future date", "Due date value is future date "+actDueDateVal , Status.PASS, driver);
		driver.switchTo().defaultContent();
		Thread.sleep(2000);
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		actions = new Actions(driver);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(2000);
		String statusOfEditBtn=driver.findElement(HubHomePageObj.admintable_edit).getAttribute("aria-disabled");
		Assert.assertEquals(statusOfEditBtn, "true");
		if(statusOfEditBtn.equalsIgnoreCase("true")){
			Logs.update("1580G_TC17.3 Edit button should be disabled if due date is not crossed", "Edit button is disabled as expected when due date is not crossed", Status.PASS, driver);
		}else{
			Logs.update("1580G_TC17.3 Edit button should be disabled if due date is not crossed", "Edit button is Not disabled when due date is not crossed", Status.FAIL, driver);
		}
		driver.quit();
		/**
		 * To verify that edit button becomes enabled for schedule owner after due date is crossed.
		 */
		driver = Login.LaunchHub("Setupurl", Logs);
		//Change the due date to past date.	
		//HubContributorFormPage.openScheduleAttributeManitenancePage(driver, Logs);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(5000);
		
		String pastDueDate=Util.getAllNecessaryData(TestType, "1580G", "PastDueDate");
		Thread.sleep(2000);
		HubContributor.setValidDueDateVal(driver, "A&F 1580 Sales/Purchases of Selected Svcs/Intangible Assets", HubAdminScreen.scheduleAttributeDueDateInput_3rdRow, Logs, pastDueDate, "2000A", TestType);
		driver.switchTo().defaultContent();
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		Thread.sleep(2000);
		actions = new Actions(driver);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(3000);
		Logs.update("1580G_TC17.4 Verify that the edit button is enabled for schedule owner when due date is crossed", "Edit button is enabled", Status.PASS, driver);
		driver.findElement(HubHomePageObj.admintable_edit).click();
		HubContributor.switchWindow_3(driver);
		Thread.sleep(5000);
		boolean scheduleField=driver.findElement(HubContributorFormObj.ScheduleNameValue).isDisplayed();
		Assert.assertTrue(scheduleField);
		if(scheduleField==true){
			Logs.update("1580G TC17.5 Verify schedule owner is able to click in edit button after due date is crossed", "schedule owner is able to click in edit button", Status.PASS, driver);
		}
		else{
			Logs.update("1580G TC17.5 Verify schedule owner is able to click in edit button after due date is crossed", "schedule owner is not able to click in edit button", Status.FAIL, driver);
		}
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(4000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click on OK in submit pop up
		Thread.sleep(2000);
		//driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click OK on confirmation pop up
		driver.quit();
		/**
		 * Verify that status of schedule is 'Schedule owner closed' after schedule owner edit and submits.
		 */
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openScheduleFromStatusDashBoard(driver, entityName, period, schedule, Logs);
		statusValAct=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
		Assert.assertEquals(statusValAct, "Schedule Owner Closed", "Status should be 'Schedule Owner Closed' but it is not" );
		if(statusValAct.equalsIgnoreCase("Schedule Owner Closed")){
			Logs.update("1580G_TC17.6_Verify the status should be Schedule Owner Closed in Status Dashboard", "Status is 'Schedule Owner Closed' as expected", Status.PASS, driver);
		}else{
			Logs.update("1580G_TC17.6_Verify the status should be Schedule Owner Closed in Status Dashboard", "Status is Not 'Schedule Owner Closed'", Status.FAIL, driver);
		}
		driver.quit();
		//Again set the due date as future due date for next iteration
		driver = Login.LaunchHub("Setupurl", Logs);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(5000);
		String futureDueDate=Util.getAllNecessaryData(TestType, "1580G", "FuruteDueDate");
		Thread.sleep(2000);
		HubContributor.setValidDueDateVal(driver, "A&F 1580 Sales/Purchases of Selected Svcs/Intangible Assets", HubAdminScreen.scheduleAttributeDueDateInput_3rdRow, Logs, futureDueDate, "1580G", TestType);
		driver.quit();
	}

}