package pages;

import utils.Base_class;
import utils.SpreadSheetOperation;
import utils.SpreadSheetOperation;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Parameters;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubDistributionScreen;
import objectRepository.HubHomePageObj;

public class HubHomePage {
	
	static Base_class base = new Base_class();
	static WebDriver driver;
	static DriverScript Logs; 
	static String currentHandle;
	public static void clickAdminLinkAndSwitchPage(WebDriver driver, DriverScript Logs) throws InterruptedException{
		
		Thread.sleep(2000);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(4000);
		
		Logs.update("Admin Link should be clicked", "Admin Link has been clicked ", Status.PASS,driver);
		currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));
		Thread.sleep(3000);
		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
		    if (!handle.equals(currentHandle)){
		    	driver.switchTo().window(handle);
		    	driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		    	Logs.update("Switch to newly opened window", "Success", Status.PASS,driver);
		    }
		}
		
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	}	
	
	
	
	public static void selectScheduleValue(WebDriver driver, String TestType, String ScheduleType, String EntityType, DriverScript Logs) throws Exception{		
		base.waitForElementTobeClickable(driver, HubDistributionScreen.btn_ScheduleDistribution, 15);
		driver.findElement(HubDistributionScreen.btn_ScheduleDistribution).click();
		Thread.sleep(4000);
		//WebElement Frame = driver.findElement(By.xpath("//*[@id='9ebc6e70-40e2-6ac2-56a3-e5a8291ed6ce_ad6a4db5-133f-7cad-77ac-60caa1f9b725']/div[1]/div/iframe"));
		WebElement Frame = driver.findElement(By.xpath("(//iframe)[2]"));
		driver.switchTo().frame(Frame);
		System.out.println("Switched the frame---------------------------------");
		base.waitForElementTobeClickable(driver, HubDistributionScreen.drp_scheduleDistributionFrequency, 10);
		driver.findElement(HubDistributionScreen.drp_scheduleDistributionFrequency).click();
		Thread.sleep(1000);
		driver.findElement(HubDistributionScreen.ScheduleDistribution_Quarterly	).click();
		Thread.sleep(1000);
		driver.findElement(HubDistributionScreen.drp_schedulePeriod).click();
		Thread.sleep(1000);
		driver.findElement(HubDistributionScreen.quarter2020_03).click();
		Thread.sleep(2000);
		switch(ScheduleType)
		{
			case "General Reserves":
				driver.findElement(HubDistributionScreen.drp_ScheduleName).click();
				Thread.sleep(900);
				driver.findElement(HubDistributionScreen.selectGeneral_ScheduleName).click();
				break;
			case "Transaction Tax Contingencies and Reserves":
				driver.findElement(HubDistributionScreen.drp_ScheduleName).click();
				Thread.sleep(900);
				driver.findElement(HubDistributionScreen.selectTransactionContingency).click();
				break;
			case "Income Tax Contingency and Reserve":
				driver.findElement(HubDistributionScreen.drp_ScheduleName).click();
				Thread.sleep(900);
				driver.findElement(HubDistributionScreen.selectITContingency).click();
				break;
			default:
				Assert.fail("Please pass the Distribution Type");
				System.out.println("No distribution type is passed");
		}
		Thread.sleep(2000);
		Logs.update("The values have been selected", "Success", Status.PASS,driver);
//		Alert alert = driver.switchTo().alert();
//		alert.accept();
		base.waitForElementTobeClickable(driver, HubDistributionScreen.OKButton_WarningMsg, 15);
		driver.findElement(HubDistributionScreen.OKButton_WarningMsg).click();
		Thread.sleep(5000);
		List<WebElement> myList = driver.findElements(HubDistributionScreen.availableEntities);
		for(int i=0;i<myList.size();i++){
			if((myList.get(i).getText()).equalsIgnoreCase(EntityType)){
				myList.get(i).click();
				Logs.update("Entity has been selected", "Success", Status.PASS,driver);
				break;
			}
		}
		
		Thread.sleep(2000);
		driver.findElement(HubDistributionScreen.btnAddSelection).click();
		Thread.sleep(2000);
		driver.findElement(HubDistributionScreen.btnDistribute).click();
		Thread.sleep(3000);
		driver.findElement(HubDistributionScreen.OKButton_WarningMsg);
		Thread.sleep(2000);
		WebElement element = driver.findElement(HubDistributionScreen.OKButton_WarningMsg);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);

	}
	
	public static void validateDashBoard(WebDriver driver, String period, String schedule) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.switchTo().window(currentHandle);
		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.myDashBoardButton).click();
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(900);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		

	}

	
	
}
