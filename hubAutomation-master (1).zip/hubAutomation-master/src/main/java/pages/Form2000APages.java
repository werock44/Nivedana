package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class Form2000APages {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
    static Actions actions;
    static String parentWindow;
    static WebElement dueDateValue;
    static WebElement dueDateField;
	public static void verifyScheduleDistributed(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		boolean scheduleDistributed=entityXpath.isDisplayed();
		Assert.assertTrue(scheduleDistributed);
		if(scheduleDistributed==true){
			Thread.sleep(4000);
			Logs.update("R1_2000A_TC01_Validate whether the Schedule owner is able to distribute the BG Monthly Schedule", "BG Monthly schedule is distributed successfully", Status.PASS, driver);
		}
		else{
			Logs.update("R1_2000_TC01_Validate whether the Schedule owner is able to distribute the BG Monthly Schedule", "BG Monthly schedule is NOT distributed successfully", Status.FAIL, driver);		
		}
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(5000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String ScheduleNameAct=driver.findElement(HubContributorFormObj.ScheduleNameValue).getText();
		Assert.assertEquals(ScheduleNameAct, schedule);
		if (ScheduleNameAct.equalsIgnoreCase(schedule)){

			//Logs.update(testReportName, stepDescription, stepStatus, driver);

			Logs.update("R1_2000_TC_02.1_Verify the shchedule Name", "Schedule Name is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_2000_TC_02.1_Verify the shchedule Name", "Schedule Name is not displayed as expected", Status.FAIL, driver);
		}
		String periodAct=driver.findElement(HubContributorFormObj.PeriodValue).getText();
		Assert.assertEquals(periodAct, period);
		if (periodAct.equalsIgnoreCase(period)){
			Logs.update("R1_2000_TC_02.2_Verify that period is appropriate as to whichever period the schedule is distributed to", "Period is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_2000_TC_02.2_Verify that period is appropriate as to whichever period the schedule is distributed to", "Period is not displayed as expected", Status.FAIL, driver);
		}
		String BuGroupExp=entityName+"-"+scheduleLongDesc;
		String BuGroupAct=driver.findElement(HubContributorFormObj.BusinessGroupValue).getText();
		Assert.assertEquals(BuGroupAct, BuGroupExp);
		if (BuGroupAct.equalsIgnoreCase(BuGroupExp)){
			Logs.update("R1_2000_TC_02.3_Verify that Business Group is displayed in the Schedule header", "Business group is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_2000_TC_02.3_Verify that Business Group is displayed in the Schedule header", "Business group is NOT displayed as expected", Status.FAIL, driver);

		}
		/*driver.close();
		driver.switchTo().window(parentWindow);*/
		driver.quit();
		
	}
	
	public static void verifyEnteringDataInCommentarySection(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		//driver.switchTo().defaultContent();
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		//Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String bgMonthlyCommLbl=driver.findElement(HubContributorFormObj.BGMonthlyCommHeaderLbl).getText();
		Assert.assertEquals(bgMonthlyCommLbl, "BG Monthly Commentary", "BG Monthly Commentory header is not as expected");//Verifying the header
		WebElement ele=driver.findElement(HubContributorFormObj.BGMonthlyCommBriefSummTextArea);
		ele.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele, Logs, "2000_TC03.1", 1500);
		ele.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele, Logs, "2000_TC03.2", 1500);
		driver.findElement(HubContributorFormObj.btn_SaveAndRelease).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		String expectedPopUpMsg=Util.getAllNecessaryData(TestType, "2000A", "SaveAndReleasePopUpMsg");
		HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.saveAndReleasePopUpMsg, Logs, expectedPopUpMsg);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(3000);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		parentWindow=driver.getWindowHandle();
		System.out.println(parentWindow);
		String StatusValAct=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
		Assert.assertEquals(StatusValAct, "Current");
		if(StatusValAct.equalsIgnoreCase("Current")){
			Logs.update("2000_TC03.3", "Status is displayed as Current as expected", Status.PASS, driver);
		}else{
			Logs.update("2000_TC03.3", "Status is displayed as"+ StatusValAct, Status.FAIL, driver);
		}
		String LockedByValAct=driver.findElement(HubHomePageObj.LockedByVal_Row1).getText();
		Assert.assertEquals(LockedByValAct, "");
		if(LockedByValAct.equals("")){
			Logs.update("2000_TC03.4", "Locked By is displayed as Blank as expected", Status.PASS, driver);
		}else{
			Logs.update("2000_TC03.4", "Locked By is not displayed as Blank", Status.FAIL, driver);
		}
		driver.quit();
		
		
}
	public static void verifyEnteringDataInDriversSection(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		//Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String driversHeaderLbl=driver.findElement(HubContributorFormObj.DriversHeaderLbl).getText();
		boolean verifyHeader=driversHeaderLbl.contains("Drivers");
		Assert.assertTrue(verifyHeader, "Drivers header is not displayed as expected");
		//Assert.assertEquals(driversHeaderLbl, "Drivers", "Drivers header is not as expected");//Verifying the header
		//Revenue section
		WebElement ele1=driver.findElement(HubContributorFormObj.RevenueTextArea);
		ele1.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele1, Logs, "2000_TC04.1", 1000);
		ele1.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele1, Logs, "2000_TC04.1", 1000);
		//Cost if inventory section
		WebElement ele2=driver.findElement(HubContributorFormObj.CostOfInventoryTextArea);
		ele2.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele2, Logs, "2000_TC04.2", 1000);
		ele2.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele2, Logs, "2000_TC04.2", 1000);
		//Manufacturing cost section
		WebElement ele3=driver.findElement(HubContributorFormObj.ManufactoringCostTextArea);
		ele3.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele3, Logs, "2000_TC04.3", 1000);
		ele3.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele3, Logs, "2000_TC04.3", 1000);
		//Mark to Mark section
		WebElement ele4=driver.findElement(HubContributorFormObj.MarkToMarketTextArea);
		ele4.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele4, Logs, "2000_TC04.4", 1000);
		ele4.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele4, Logs, "2000_TC04.4", 1000);
		//Trading Margins section
		WebElement ele5=driver.findElement(HubContributorFormObj.TradingMarginTextArea);
		ele5.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele5, Logs, "2000_TC04.5", 1000);
		ele5.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele5, Logs, "2000_TC04.5", 1000);
		//SG&A section
		WebElement ele6=driver.findElement(HubContributorFormObj.SG_ATextArea);
		ele6.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele6, Logs, "2000_TC04.6", 1000);
		ele6.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele6, Logs, "2000_TC04.6", 1000);
		//Other section
		WebElement ele7=driver.findElement(HubContributorFormObj.OtherFxTextArea);
		ele7.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele7, Logs, "2000_TC04.6", 1000);
		ele7.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele7, Logs, "2000_TC04.6", 1000);
		//External environment 
		WebElement ele8=driver.findElement(HubContributorFormObj.ExternalEnvTextArea);
		ele8.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele8, Logs, "2000_TC04.6", 1000);
		ele8.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele8, Logs, "2000_TC04.6", 1000);
	driver.quit();
	
	}
	
	
	/**TC_05 and TC_07*/
	
	public static void verifyEnteringDataInImpactedAOEField(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		driver=Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		//Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		WebElement ele=driver.findElement(HubContributorFormObj.BGMonthlyCommBriefSummTextArea);
		ele.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele, Logs, "2000_TC03.1", 1500);
		String driversHeaderLbl=driver.findElement(HubContributorFormObj.DriversHeaderLbl).getText();
		boolean verifyHeader=driversHeaderLbl.contains("Drivers");
		Assert.assertTrue(verifyHeader, "Drivers header is not displayed as expected");
		//Revenue section
		WebElement ele1=driver.findElement(HubContributorFormObj.AOETextArea);
		ele1.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele1, Logs, "2000_TC05.1", 2000);
		ele1.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "commentary_1500plus_Chars", ele1, Logs, "2000_TC05.2", 2000);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		String expMessage=Util.getAllNecessaryData(TestType, "2000A", "SubmitPopUpHeaderMessage");
		HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.submitPopUpHeader, Logs, expMessage );
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click on OK in submit pop up
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click OK on confirmation pop up
		driver.quit();
		/**
		 * Login again and verify the status of the schedule in status dash board
		 * */
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openScheduleFromStatusDashBoard(driver, entityName, period, schedule, Logs);
		String statusValAct=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
		Assert.assertEquals(statusValAct, "Submitted", "Status should be submitted but it is not" );
		if(statusValAct.equalsIgnoreCase("Submitted")){
			Logs.update("2000_TC05.3_Verify the status should be submitted in Status Dashboard", "Status is submitted as expected", Status.PASS, driver);
		}else{
			Logs.update("2000_TC05.3_Verify the status should be submitted in Status Dashboard", "Status is Not submitted", Status.FAIL, driver);
		}
		String usernameExp = System.getProperty("user.name");
		String lastActionByAct=driver.findElement(HubHomePageObj.LockedByVal_Row1).getText();
		Assert.assertEquals(lastActionByAct, usernameExp, "Hub Contributor's id is not displayed correctly");
		if(lastActionByAct.equalsIgnoreCase(usernameExp)){
			Logs.update("2000_TC05.4_Verify that hub Contributor id should be displayed", "Hub Contributor's id is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("2000_TC05.4_Verify that hub Contributor id should be displayed", "Hub Contributor's id is not displayed", Status.FAIL, driver);
		}
		driver.quit();
		/**
		 * Login again and verify that Edit button is disabled when due date is not crossed for schedule owner
		 * */
		driver = Login.LaunchHub("Setupurl", Logs);
		Thread.sleep(3000);	
		HubContributorFormPage.openScheduleAttributeManitenancePage(driver, Logs);
		Thread.sleep(5000);
		dueDateField=driver.findElement(HubAdminScreen.scheduleAttributeDueDate_2000A);
		Thread.sleep(3000);
		dueDateValue=driver.findElement(HubAdminScreen.scheduleAttributeDueDate_2000AValue);
		String actDueDateVal=HubContributorFormPage.getDueDateValue(driver, dueDateValue, Logs);
		Logs.update("Due date value should be future date", "Due date value is future date "+actDueDateVal , Status.PASS, driver);
		driver.switchTo().defaultContent();
		Thread.sleep(2000);
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		actions = new Actions(driver);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(2000);
		String statusOfEditBtn=driver.findElement(HubHomePageObj.admintable_edit).getAttribute("aria-disabled");
		Assert.assertEquals(statusOfEditBtn, "true");
		if(statusOfEditBtn.equalsIgnoreCase("true")){
			Logs.update("2000_TC07.1 Edit button should be disabled if due date is not crossed", "Edit button is disabled as expected when due date is not crossed", Status.PASS, driver);
		}else{
			Logs.update("2000_TC07.1 Edit button should be disabled if due date is not crossed", "Edit button is Not disabled when due date is not crossed", Status.FAIL, driver);
		}
		driver.quit();
		/**
		 * To verify that edit button becomes enabled for schedule owner after due date is crossed.
		 */
		driver = Login.LaunchHub("Setupurl", Logs);
		//Change the due date to past date.	
		//HubContributorFormPage.openScheduleAttributeManitenancePage(driver, Logs);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(5000);
		
		String pastDueDate=Util.getAllNecessaryData(TestType, "2000A", "PastDueDate");
		Thread.sleep(2000);
		HubContributor.setValidDueDateVal(driver, "FP&A 2000 Monthly Commentary", HubAdminScreen.scheduleAttributeDueDateInput_3rdRow, Logs, pastDueDate, "2000A", TestType);
		driver.switchTo().defaultContent();
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		Thread.sleep(2000);
		actions = new Actions(driver);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(3000);
		Logs.update("Verify that the edit button is enabled for schedule owner when due date is crossed", "Edit button is enabled", Status.PASS, driver);
		driver.findElement(HubHomePageObj.admintable_edit).click();
		HubContributor.switchWindow_3(driver);
		Thread.sleep(5000);
		boolean scheduleField=driver.findElement(HubContributorFormObj.ScheduleNameValue).isDisplayed();
		Assert.assertTrue(scheduleField);
		if(scheduleField==true){
			Logs.update("2000 TC07.2 Verify schedule owner is able to click in edit button after due date is crossed", "schedule owner is able to click in edit button", Status.PASS, driver);
		}
		else{
			Logs.update("2000 TC07.2 Verify schedule owner is able to click in edit button after due date is crossed", "schedule owner is not able to click in edit button", Status.FAIL, driver);
		}
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click on OK in submit pop up
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click OK on confirmation pop up
		driver.quit();
		/**
		 * Verify that status of schedule is 'Schedule owner closed' after schedule owner edit and submits.
		 */
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openScheduleFromStatusDashBoard(driver, entityName, period, schedule, Logs);
		statusValAct=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
		Assert.assertEquals(statusValAct, "Schedule Owner Closed", "Status should be 'Schedule Owner Closed' but it is not" );
		if(statusValAct.equalsIgnoreCase("Schedule Owner Closed")){
			Logs.update("2000_TC07.3_Verify the status should be Schedule Owner Closed in Status Dashboard", "Status is 'Schedule Owner Closed' as expected", Status.PASS, driver);
		}else{
			Logs.update("2000_TC07.3_Verify the status should be Schedule Owner Closed in Status Dashboard", "Status is Not 'Schedule Owner Closed'", Status.FAIL, driver);
		}
		driver.quit();
		//Again set the due date as future due date for next iteration
		driver = Login.LaunchHub("Setupurl", Logs);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(5000);
		String futureDueDate=Util.getAllNecessaryData(TestType, "2000A", "FuruteDueDate");
		Thread.sleep(2000);
		HubContributor.setValidDueDateVal(driver, "FP&A 2000 Monthly Commentary", HubAdminScreen.scheduleAttributeDueDateInput_3rdRow, Logs, futureDueDate, "2000A", TestType);
		driver.quit();
	}
	
	//TC_06
		public static void verifyRejectScheduleFunctionality(WebDriver driver, String entityName, String period, String schedule,
		DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		//Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		WebElement ele=driver.findElement(HubContributorFormObj.BGMonthlyCommBriefSummTextArea);
		ele.clear();
		HubContributor.checkIfUserIsAbletoEnterLessThanExpData(driver, TestType, TestCaseName, "commentary_LessThan1500_Chars", ele, Logs, "2000_TC03.1", 1500);
	    Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		String expMessage=Util.getAllNecessaryData(TestType, "2000A", "SubmitPopUpHeaderMessage");
		HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.submitPopUpHeader, Logs, expMessage );
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click on OK in submit pop up
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();//Click OK on confirmation pop up
		driver.quit();
		/**
		 * Verify schedule owner is able to reject the schedule
		 */
		driver = Login.LaunchHub("Setupurl", Logs);
		Thread.sleep(3000);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(4000);
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		actions = new Actions(driver);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(2000);
		driver.findElement(HubHomePageObj.admintable_reject).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(5000);
		String rejectionComent="Rejection comment for automation";
		WebElement frame=driver.findElement(By.xpath("//iframe[@class='runtime-popup']"));
		driver.switchTo().frame(frame);
		Thread.sleep(1000);
		/*driver.findElement(HubHomePageObj.enterRejectionCommentTxtBox).click();
		driver.findElement(HubHomePageObj.enterRejectionCommentTxtBox).sendKeys(rejectionComent);*/
		JavascriptExecutor JS = (JavascriptExecutor)driver;
		JS.executeScript("document.getElementById('00000000-0000-0000-0000-000000000000_0a731a22-d5e7-421e-bc93-d38d8f46cf11_TextArea').value='Rejection comments'");
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(5000);
		Actions act=new Actions(driver);
		act.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew)).click().build().perform();
		//driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.quit();
		/**
		 * Navigate to My Dashboard and check the rejection comments.
		 */
		driver = Login.LaunchHub("Setupurl", Logs);
		Thread.sleep(3000);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Thread.sleep(3000);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		boolean rejn=driver.findElement(HubContributorFormObj.RejectionCommentsLbl).isDisplayed();
		Assert.assertTrue(rejn, "Rejection comment section is not available");
		if(rejn==true){
			Logs.update("2000_TC06 verify the rejection comment section should be available", "Rejection comment section is available", Status.PASS, driver);
		}
		else{
			Logs.update("2000_TC06 verify the rejection comment section should be available", "Rejection comment section is not available", Status.FAIL, driver);
		}
		String rejComm=driver.findElement(HubContributorFormObj.RejectionCommentsValue).getText();
		System.out.println(rejComm);
		driver.quit();
		}
		
		
		
		// TC-08
		public static void verifyRedirect(WebDriver driver, String entityName, String period, String schedule,
				DriverScript Logs, String TestType, String TestCaseName) throws Exception {
				actions = new Actions(driver);
		driver = Login.LaunchHub("Setupurl", Logs);
		Thread.sleep(3000);
		actions = new Actions(driver);
		String currentWindow=driver.getWindowHandle();
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		//base.waitForElementToVisible(driver, HubHomePageObj.Btn_Open, 10);
		Thread.sleep(3000);
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();// This schedule will be locked by current user.
		HubContributor.switchWindow(driver);
		Thread.sleep(3000);
		driver.switchTo().window(currentWindow);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		String LockedByValAct=driver.findElement(HubHomePageObj.LockedByVal_Row1).getText();
		Assert.assertNotEquals(LockedByValAct, "", "Locked By is displayed as null");
		if(!LockedByValAct.equals("")){
			Logs.update("Verify that the schedule is locked by Hub contributor", "Locked By is displayed with DSID of hub contributor as expected", Status.PASS, driver);
		}else{
			Logs.update("Verify that the schedule is locked by Hub contributor", "Locked By is displayed as null", Status.FAIL, driver);
		}
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);	
		String CurrWindow2=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(4000);
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		actions = new Actions(driver);
		WebElement	entityXpath1 = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath1).doubleClick().build().perform();
		Thread.sleep(2000);
		try {
			driver.findElement(HubHomePageObj.admintable_redirect).click();
			Logs.update("2000_TC08 verify the Redirect", "Redirect is working as expected", Status.PASS, driver);
		}
		catch(Exception e)
		{
			Logs.update("2000_TC08 verify the Redirect", "Redirect is Not working as expected", Status.FAIL, driver);
		}
		
		Thread.sleep(3000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		actions.sendKeys(Keys.ENTER).build().perform();
		//driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.switchTo().window(CurrWindow2);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		String LockedByValActAfterRed=driver.findElement(HubHomePageObj.LockedByVal_Row1).getText();
		Assert.assertEquals(LockedByValActAfterRed, "", "Locked By is NOT displayed as null even after redirect");
		if(LockedByValActAfterRed.equals("")){
			Logs.update("Verify that the schedule is not locked by any Hub contributor", "Locked By is displayed as null as expected", Status.PASS, driver);
		}else{
			Logs.update("Verify that the schedule is not locked by any Hub contributor", "Locked By is NOT displayed as null even after redirect", Status.FAIL, driver);
		}
		
		
			}
		
}
