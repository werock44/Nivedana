package pages;


import org.openqa.grid.web.Hub;
import java.util.List;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubContributorFormObj;
import utils.Base_class;
import utils.HubContributor;
import utils.ReadXML;
import utils.Util;

public class Form816APage {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();

	public static void fillForm816A(WebDriver driver) throws InterruptedException {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.lbl_Reserve_Id, 10);

		// hubContributorFormObj.currentTaxRate(driver).sendKeys(ReadXML.readData("TC_816A",
		// "currTaxRate"));
		driver.findElement(HubContributorFormObj.currentTaxRate_reserve).clear();
		driver.findElement(HubContributorFormObj.currentTaxRate_reserve)
				.sendKeys(ReadXML.readData("TC_816A", "currTaxRate"));
		// driver.findElement(HubContributorFormObj.dateFirstRecorded).click();
		driver.findElement(HubContributorFormObj.dateFirstRecorded)
				.sendKeys(ReadXML.readData("TC_816A", "dateFirstRecorded"));
		driver.findElement(HubContributorFormObj.typeOfReserve).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.typeOfReserveConractDefault).click();
		driver.findElement(HubContributorFormObj.descriptionOfReserve)
				.sendKeys(ReadXML.readData("TC_816A", "descriptionOfReserve"));
		driver.findElement(HubContributorFormObj.technicalAccountingCOE).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.technicalAccountingCOEValMollie).click();
		driver.findElement(HubContributorFormObj.backgroundOfContingency)
				.sendKeys(ReadXML.readData("TC_816A", "backgroundOfContingency"));
		driver.findElement(HubContributorFormObj.statusOfReserve_816)
				.sendKeys(ReadXML.readData("TC_816A", "statusOfReserve"));
		driver.findElement(HubContributorFormObj.explanationofReclassifications_816)
				.sendKeys(ReadXML.readData("TC_816A", "explainationOfReclassification"));
		driver.findElement(HubContributorFormObj.begBalance).sendKeys(ReadXML.readData("TC_816A", "begBal"));
		driver.findElement(HubContributorFormObj.chargeToPL).sendKeys(ReadXML.readData("TC_816A", "chargeToPL"));
		driver.findElement(HubContributorFormObj.returnedToPL).sendKeys(ReadXML.readData("TC_816A", "returnedToPL"));
		driver.findElement(HubContributorFormObj.useForIntended_816)
				.sendKeys(ReadXML.readData("TC_816A", "userForIntended"));
		driver.findElement(HubContributorFormObj.translation_816).sendKeys(ReadXML.readData("TC_816A", "translation"));
		driver.findElement(HubContributorFormObj.reClass_816).sendKeys(ReadXML.readData("TC_816A", "reClass"));

	}
	
	// Test Id# TC45,TC48,TC49,TC50
	public static void begBalance(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		base.waitForElementTobeClickable(driver, HubContributorFormObj.edt_BegBalance, 10);
		WebElement edt_BegBal = driver.findElement(HubContributorFormObj.edt_BegBalance);
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, edt_BegBal, TestCaseName, "TaxBenifit_+ve", Logs, "TC_45_BegBalance");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_BegBal, Logs, "TC_49 BegBalance");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValues_815_816", edt_BegBal, Logs,
				"TC_48 BegBalance");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_BegBal, Logs, "TC_50 Beg Balance");
		edt_BegBal.sendKeys(ReadXML.readData("TC_816A", "begBal"));

	}
	
	//Test Id# TC101,TC102,TC103
	public static void statusOfReserveField816(WebDriver driver, DriverScript Logs, String TestType,
			String TestCaseName) throws Exception {
		WebElement ele = driver.findElement(HubContributorFormObj.edt_StatusOfReserve816);
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "SOR_500plus_Chars",ele , Logs, "TC101 816A Verify Status of Reserve", 500);
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve816).clear();
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve816).sendKeys(ReadXML.readData("TC_816A", "statusOfReserve"));
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve816).clear();
		Thread.sleep(1000);
		

		HubContributor.saveWithFieldAsBlank(driver, TestType, ele, Logs, "TC_102 Status of Reserve");
		String chargeToPL=driver.findElement(HubContributorFormObj.chargeToPL).getAttribute("value");
		int chargeToPL_int=Integer.parseInt(chargeToPL);
		String returnToPL=driver.findElement(HubContributorFormObj.returnedToPL).getAttribute("value");
		char rPL=returnToPL.charAt(1);
		int returnToPL_int=Integer.parseInt(String.valueOf(rPL));
		String usedForIntended=driver.findElement(HubContributorFormObj.useForIntended_816).getAttribute("value");
		char uForIn=usedForIntended.charAt(1);		
		int useForIntended_int=Integer.parseInt(String.valueOf(uForIn));
		if(!(chargeToPL_int==0) || !(returnToPL_int==0) || !(useForIntended_int==0)){
			Logs.update("Charge to PL,Return to PL, Use for Intended", "Fields contains a values other than 0", Status.DONE, driver);
			HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMsg_StatusOfReserve", ele, Logs, "TC_103 Status of Reserve");
			
		}else{
			Logs.update("Charge to PL,Return to PL, Use for Intended", "Fields not contains a values other than 0", Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve816).sendKeys(ReadXML.readData("TC_816A", "statusOfReserve"));

	}

	// Test Id# TC52,TC55,TC56,TC57,TC58
	public static void charge_to_PL_Field(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.edt_ChargeToPLField, 10);
		WebElement edt_ChargeToPL = driver.findElement(HubContributorFormObj.edt_ChargeToPLField);
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, edt_ChargeToPL, TestCaseName, "TaxBenifit_+ve", Logs, "TC_52 Charge to PL");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_ChargeToPL, Logs, "TC_56 Charge to P&L");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValues_815_816", edt_ChargeToPL, Logs, "TC_55 Charge to P&L");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_ChargeToPL, Logs, "TC_57 Charge to P&L");
		edt_ChargeToPL.sendKeys(ReadXML.readData("TC_816A", "chargeToPL"));
		//<---Test case 58
		WebElement statusOfReserve=driver.findElement(HubContributorFormObj.statusOfReserve_816);
		String chargeToPL=edt_ChargeToPL.getAttribute("value");
		int chargePL_int=Integer.parseInt(chargeToPL);
		if(!(chargePL_int==0)){
			Logs.update("ChargeToPL", "Field contains value other than 0", Status.DONE, driver);
			HubContributor.verifyEnteringDataInField(driver, TestType, "Status Of Reserve", statusOfReserve, Logs, "TC_58 Charge to P&L");
			
		}else{
			Logs.update("ChargeToPL", "Field not contains value other than 0", Status.FAIL, driver);
		}
		
		
	}

	// Test Id# TC60,TC63,TC64,TC65,TC66
	public static void return_to_PL_Field(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.returnedToPL, 10);
		WebElement edt_ReturnToPL = driver.findElement(HubContributorFormObj.returnedToPL);
		HubContributor.verifyFieldIsTakingOnlyNegativeValues(driver, TestType, "TC_60:Return to PL", edt_ReturnToPL, "816A", "TaxBenifit_+ve", Logs);
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_ReturnToPL, Logs, "TC_64 Return to PL");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValReturnPL_Use4Intented", edt_ReturnToPL, Logs, "TC_63 Return to PL");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_ReturnToPL, Logs, "TC_65 Return to PL");
		edt_ReturnToPL.sendKeys(ReadXML.readData("TC_816A", "returnedToPL"));
		//<--Test case TC66
		WebElement statusOfReserve=driver.findElement(HubContributorFormObj.statusOfReserve_816);
		String returnToPL=edt_ReturnToPL.getAttribute("value");
		char retPL=returnToPL.charAt(1);
		int returnPL_int=Integer.parseInt(String.valueOf(retPL));
		if(!(returnPL_int==0)){
			Logs.update("ReturnToPL", "Field contains value other than 0", Status.DONE, driver);
			HubContributor.verifyEnteringDataInField(driver, TestType, "Status Of Reserve", statusOfReserve, Logs, "TC_66 Return to P&L");
			
		}else{
			Logs.update("ReturnToPL", "Field not contains value other than 0", Status.FAIL, driver);
		}
		
	}

	//Test Id# TC76,TC79,TC80,TC81
	public static void translation(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.translation_816, 10);
		WebElement edt_translation = driver.findElement(HubContributorFormObj.translation_816);
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, edt_translation, Logs, "TC_76 Translation", "TaxBenifit_+ve");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_translation, Logs, "TC_79 Translation");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValuesReclass_Trnsl", edt_translation, Logs, "TC_81 Translation");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl", edt_translation, Logs, "TC_81 Translation");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_translation, Logs, "TC_80 Translation");
		edt_translation.sendKeys(ReadXML.readData("TC_816A", "translation"));
	}

	//Test Id# TC85,TC86,TC87,TC88,TC89
	public static void reClass(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.reClass_816, 10);
		WebElement edt_reClass=driver.findElement(HubContributorFormObj.reClass_816);
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, edt_reClass, Logs, "TC_85 Reclass","TaxBenifit_+ve");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_reClass, Logs, "TC_86 Reclass");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_reClass, Logs, "TC_87 Reclass");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValuesReclass_Trnsl", edt_reClass, Logs, "TC_88 Reclass");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl", edt_reClass, Logs, "TC_88 Reclass");
		edt_reClass.sendKeys(ReadXML.readData("TC_816A", "reClass"));
		//Test Id# TC89
		WebElement expOfReclass=driver.findElement(HubContributorFormObj.explanationofReclassifications_816);
		String reClass=edt_reClass.getAttribute("value");
		int reClass_int=Integer.parseInt(reClass);
		if(!(reClass_int==0)){
			Logs.update("Reclass", "Field contains value other than 0", Status.DONE, driver);
			HubContributor.verifyEnteringDataInField(driver, TestType, "Explaination of Reclassification", expOfReclass, Logs, "TC_89 Reclass");
		}else{
			Logs.update("Reclass", "Field not contains value other than 0", Status.FAIL, driver);
		}
				
	
	}
	
	//Test Id # TC68,TC71,TC72,TC73,TC74.
	public static void useForIntended(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.useForIntended_816, 10);
		WebElement edt_useForIntended=driver.findElement(HubContributorFormObj.useForIntended_816);
		HubContributor.verifyFieldIsTakingOnlyNegativeValues(driver, TestType, "TC_68 Use for Intended", edt_useForIntended, "816A", "TaxBenifit_+ve", Logs);
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_useForIntended, Logs, "TC_72 Use for Intended");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValReturnPL_Use4Intented", edt_useForIntended, Logs, "TC_71 Use for Intended");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_useForIntended, Logs, "TC_73 Use for Intended");
		edt_useForIntended.sendKeys(ReadXML.readData("TC_816A", "userForIntended"));
		//Test Id # TC74
		WebElement statusOfReserve=driver.findElement(HubContributorFormObj.statusOfReserve_816);
		String useForIntended=edt_useForIntended.getAttribute("value");
		char useForInt=useForIntended.charAt(1);
		int useForIntended_int=Integer.parseInt(String.valueOf(useForInt));
		if(!(useForIntended_int==0)){
			Logs.update("Use for intended", "Field contails value other than 0", Status.DONE, driver);
			HubContributor.verifyEnteringDataInField(driver, TestType, "Status Of Reserve", statusOfReserve, Logs, "TC_77 Use for Intended");
			
		}else{
			Logs.update("Use for intended", "Field not contains value other than 0", Status.FAIL, driver);
		}
		
		
	}
	public static void explanationOfReclassifications(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement ele = driver.findElement(HubContributorFormObj.explanationofReclassifications_816);
		HubContributor.saveWithFieldAsBlank(driver, TestType, ele, Logs, "TC105 816A Verify Explanation of Reclassifications");
		ele.sendKeys(ReadXML.readData("TC_816A", "explainationOfReclassification"));
		
		//Test Id # TC106----> A value should be entered greater than 0.
		String positiveVal = Util.getAllNecessaryData(TestType, TestCaseName, "PosVal");
		driver.findElement(HubContributorFormObj.reClass_816).clear();
		driver.findElement(HubContributorFormObj.reClass_816).sendKeys(positiveVal);
		String valInReclass = driver.findElement(HubContributorFormObj.reClass_816).getAttribute("value");
		Integer intReclass = Integer.parseInt(valInReclass);
		if(intReclass>0){
			Logs.update("Reclass field", "Reclass field contains a value greater than 0", Status.DONE, driver);
		HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMessage_Reclassification", ele, Logs, "TC106 816A Verify Explanation of Reclassifications");
		}
		else{
			Logs.update("Reclass field", "Reclass field does not contain a value greater than 0", Status.FAIL, driver);
		}
		// <---------
		
		//Test Id # TC107----> A value should be entered is 0.
		driver.findElement(HubContributorFormObj.reClass_816).clear();
		driver.findElement(HubContributorFormObj.reClass_816).sendKeys("0");
		Thread.sleep(2000);
		String val = driver.findElement(HubContributorFormObj.reClass_816).getAttribute("value");
		Integer intInReclass = Integer.parseInt(val);
		driver.findElement(HubContributorFormObj.explanationofReclassifications_816).clear();
		if(intInReclass==0){
			Logs.update("Reclass field", "Reclass field contains 0", Status.DONE, driver);
		HubContributor.verifyIfUserIsAbleToSubmitWithBlank(driver, TestType, Logs, "TC107 816A Verify Explanation of Reclassifications");
		}
		else{
			Logs.update("Reclass field", "Reclass field does not contain 0", Status.FAIL, driver);
		}
		// <-----------------------------------
		driver.findElement(HubContributorFormObj.explanationofReclassifications_816).sendKeys(ReadXML.readData("TC_816A", "explainationOfReclassification"));
	}
	public static void technicalAccountingCOEField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		List<WebElement> EleList = driver.findElements(HubContributorFormObj.technicalAccountingCOEDropDownList);
		HubContributor.checkTheDropDownValues(driver, TestType, TestCaseName, EleList, Logs, "TC98 816A Verify Technical Accounting CoE", "TechnicalAccountingCOEValues");
		Thread.sleep(4000);
		driver.findElement(HubContributorFormObj.technicalAccountingCOE).click();
		Thread.sleep(900);
		driver.findElement(HubContributorFormObj.technicalAccountingCOE_Unselected).click();
		WebElement ele = driver.findElement(HubContributorFormObj.technicalAccountingCOE);
		//Setting Beginning Balance not equal to 0 for TC_099and TC100 as Pre-requisites
		driver.findElement(HubContributorFormObj.edt_BegBalance).clear();
		driver.findElement(HubContributorFormObj.edt_BegBalance).sendKeys(ReadXML.readData("TC_816A", "begBal"));
		HubContributor.saveWithFieldAsBlank(driver, TestType, ele, Logs, "TC99 816A Verify Technical Accounting CoE");
		HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMessageTechnicalCOE", ele, Logs, "TC100 816A Verify Technical Accounting CoE");
		//=============================================================
		driver.findElement(HubContributorFormObj.technicalAccountingCOE).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.technicalAccountingCOEValMollie).click();
		
	}
	public static void endingBalanceField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		int intValInBegBalance = Integer.parseInt(driver.findElement(HubContributorFormObj.edt_BegBalance).getAttribute("value"));
		Thread.sleep(2000);
		int intvalInChargePLField = Integer.parseInt(driver.findElement(HubContributorFormObj.chargeToPL).getAttribute("value"));
		driver.findElement(HubContributorFormObj.returnedToPL).click();
		Thread.sleep(400);
		int intvalInReturnedToPL = Integer.parseInt(driver.findElement(HubContributorFormObj.returnedToPL).getAttribute("value"));
		driver.findElement(HubContributorFormObj.useForIntended_816).click();
		Thread.sleep(400);
		int intvalInIntended = Integer.parseInt(driver.findElement(HubContributorFormObj.useForIntended_816).getAttribute("value"));
		int intvalInTranslation = Integer.parseInt(driver.findElement(HubContributorFormObj.translation_816).getAttribute("value"));
		int intvalInReclass = Integer.parseInt(driver.findElement(HubContributorFormObj.reClass_816).getAttribute("value"));
		int intvalInEndingBalance = Integer.parseInt(driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value"));
		int sum = intValInBegBalance+intvalInChargePLField+intvalInReturnedToPL+intvalInIntended+intvalInTranslation+intvalInReclass;
		if(sum == intvalInEndingBalance){
			Logs.update("TC90 816A Ending Balance", "Sum of Beginning Balance, Charge to P & L, Return to P & L, Used for Intend Purpose, Translation, Reclass is equal to Ending Balance", Status.PASS, driver);
		}
		else{
			Logs.update("TC90 816A Ending Balance", "Sum of Beginning Balance, Charge to P & L, Return to P & L, Used for Intend Purpose, Translation, Reclass is not equal to Ending Balance", Status.FAIL, driver);
		}
		String numericData = Util.getAllNecessaryData(TestType, TestCaseName, "CurrencyVal");
		numericData= "-"+numericData;
		driver.findElement(HubContributorFormObj.returnedToPL).clear();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.returnedToPL).sendKeys(numericData);
		driver.findElement(HubContributorFormObj.returnedToPL).sendKeys(Keys.TAB);
		String valInEndingBal = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
		if(valInEndingBal.contains("(") || valInEndingBal.contains(")")){
			WebElement endingBal = driver.findElement(HubContributorFormObj.endingBalance);
			HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMessageEndingBalance", endingBal, Logs, "TC91 816A Ending Balance");
		}
		else{
			Logs.update("TC91 816A Ending Balance", "Value of Ending balance is not negative so can't proceed with validation", Status.FAIL, driver);
		}
		//Setting to default val
		driver.findElement(HubContributorFormObj.returnedToPL).clear();
		driver.findElement(HubContributorFormObj.returnedToPL).sendKeys(ReadXML.readData("TC_816A", "returnedToPL"));
		
		
	}
	
}
	
