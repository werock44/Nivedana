package pages;

import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.HubContributor;
import utils.ReadXML;
import utils.Util;

public class Form815APage {

	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	static Base_class base = new Base_class();
	public static void enterTransactionTaxAllData(String TestType, WebDriver driver, DriverScript Logs)
			throws Exception {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		HubContributorFormObj obj = new HubContributorFormObj();
		obj.fromTaxYearName(driver).sendKeys(ReadXML.readData("TC_815A", "fromTaxYear"));
		obj.toTaxYearName(driver).sendKeys(ReadXML.readData("TC_815A", "toTaxYear"));
		Thread.sleep(4000);
		obj.taxDeduct(driver).click();
		Thread.sleep(4000);
		obj.currentTaxRate(driver).sendKeys(ReadXML.readData("TC_815A", "currTaxRate"));

		driver.findElement(HubContributorFormObj.descriptionOfTaxContigency)
				.sendKeys(ReadXML.readData("TC_815A", "descriptionOfTaxContigency"));
		driver.findElement(HubContributorFormObj.effectDropdown).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.effectValue).click();
		driver.findElement(HubContributorFormObj.outcomeDropdown).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.outcomeValue).click();
		driver.findElement(HubContributorFormObj.bestCase).sendKeys(ReadXML.readData("TC_815A", "bestCase"));
		driver.findElement(HubContributorFormObj.worstCase).sendKeys(ReadXML.readData("TC_815A", "worstCase"));
		driver.findElement(HubContributorFormObj.mostLikely).sendKeys(ReadXML.readData("TC_815A", "mostLikely"));

		// penalties
		driver.findElement(HubContributorFormObj.interestAndPenaltiesBestCase)
				.sendKeys(ReadXML.readData("TC_815A", "interestAndPenaltiesBestCase"));
		driver.findElement(HubContributorFormObj.interestAndPenaltiesworstCase)
				.sendKeys(ReadXML.readData("TC_815A", "interestAndPenaltiesworstCase"));

		driver.findElement(HubContributorFormObj.totalReserved).sendKeys(ReadXML.readData("TC_815A", "totalReserved"));
		driver.findElement(HubContributorFormObj.totalAccruedInterest)
				.sendKeys(ReadXML.readData("TC_815A", "totalAccruedInterest"));

		driver.findElement(HubContributorFormObj.backgroundOfTaxContigency)
				.sendKeys(ReadXML.readData("TC_815A", "backgroundOfTaxContigency"));

		driver.findElement(HubContributorFormObj.statusOfreserve)
				.sendKeys(ReadXML.readData("TC_815A", "statusOfreserve"));
		driver.findElement(HubContributorFormObj.explanationofReclassifications)
				.sendKeys(ReadXML.readData("TC_815A", "explanationofReclassifications"));
		// YTD

		driver.findElement(HubContributorFormObj.begBalance).sendKeys(ReadXML.readData("TC_815A", "begBalance"));
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(ReadXML.readData("TC_815A", "chargePL"));
		driver.findElement(HubContributorFormObj.returnPL).sendKeys(ReadXML.readData("TC_815A", "returnPL"));
		driver.findElement(HubContributorFormObj.useForIntended)
				.sendKeys(ReadXML.readData("TC_815A", "useForIntended"));
		driver.findElement(HubContributorFormObj.translation).sendKeys(ReadXML.readData("TC_815A", "translation"));
		driver.findElement(HubContributorFormObj.reClass).sendKeys(ReadXML.readData("TC_815A", "reClass"));
		//driver.findElement(HubContributorFormObj.endingBalance).sendKeys(ReadXML.readData("TC_815A", "begBalance"));
		// Account Impacted
		driver.findElement(HubContributorFormObj.accountImpacted).click();
		driver.findElement(HubContributorFormObj.accountImpactedValue).click();
	}
	
	/* Enter values such that ending balance is zero */
	
	public static void enterTransactionTaxAllData_endingBal_zero(String TestType, WebDriver driver, DriverScript Logs)
			throws Exception {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		HubContributorFormObj obj = new HubContributorFormObj();
		obj.fromTaxYearName(driver).sendKeys(ReadXML.readData("TC_815A", "fromTaxYear"));
		obj.toTaxYearName(driver).sendKeys(ReadXML.readData("TC_815A", "toTaxYear"));
		Thread.sleep(4000);
		obj.taxDeduct(driver).click();
		Thread.sleep(4000);
		obj.currentTaxRate(driver).sendKeys(ReadXML.readData("TC_815A", "currTaxRate"));

		driver.findElement(HubContributorFormObj.descriptionOfTaxContigency)
				.sendKeys(ReadXML.readData("TC_815A", "descriptionOfTaxContigency"));
		driver.findElement(HubContributorFormObj.effectDropdown).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.effectValue).click();
		driver.findElement(HubContributorFormObj.outcomeDropdown).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.outcomeValue).click();
		driver.findElement(HubContributorFormObj.bestCase).sendKeys(ReadXML.readData("TC_815A", "bestCase"));
		driver.findElement(HubContributorFormObj.worstCase).sendKeys(ReadXML.readData("TC_815A", "worstCase"));
		driver.findElement(HubContributorFormObj.mostLikely).sendKeys(ReadXML.readData("TC_815A", "mostLikely"));

		// penalties
		driver.findElement(HubContributorFormObj.interestAndPenaltiesBestCase)
				.sendKeys(ReadXML.readData("TC_815A", "interestAndPenaltiesBestCase"));
		driver.findElement(HubContributorFormObj.interestAndPenaltiesworstCase)
				.sendKeys(ReadXML.readData("TC_815A", "interestAndPenaltiesworstCase"));

		driver.findElement(HubContributorFormObj.totalReserved).sendKeys(ReadXML.readData("TC_815A", "totalReserved"));
		driver.findElement(HubContributorFormObj.totalAccruedInterest)
				.sendKeys(ReadXML.readData("TC_815A", "totalAccruedInterest"));

		driver.findElement(HubContributorFormObj.backgroundOfTaxContigency)
				.sendKeys(ReadXML.readData("TC_815A", "backgroundOfTaxContigency"));

		driver.findElement(HubContributorFormObj.statusOfreserve)
				.sendKeys(ReadXML.readData("TC_815A", "statusOfreserve"));
		driver.findElement(HubContributorFormObj.explanationofReclassifications)
				.sendKeys(ReadXML.readData("TC_815A", "explanationofReclassifications"));
		// YTD

		driver.findElement(HubContributorFormObj.begBalance).sendKeys(ReadXML.readData("TC_815A", "begBalance0"));
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(ReadXML.readData("TC_815A", "chargePL0"));
		driver.findElement(HubContributorFormObj.returnPL).sendKeys(ReadXML.readData("TC_815A", "returnPL0"));
		driver.findElement(HubContributorFormObj.useForIntended)
				.sendKeys(ReadXML.readData("TC_815A", "useForIntended0"));
		driver.findElement(HubContributorFormObj.translation).sendKeys(ReadXML.readData("TC_815A", "translation0"));
		driver.findElement(HubContributorFormObj.reClass).sendKeys(ReadXML.readData("TC_815A", "reClass0"));
		//driver.findElement(HubContributorFormObj.endingBalance).sendKeys(ReadXML.readData("TC_815A", "begBalance"));
		// Account Impacted
		driver.findElement(HubContributorFormObj.accountImpacted).click();
		driver.findElement(HubContributorFormObj.accountImpactedValue).click();
	}

	/* Scenario Analysis Reserves(Local) Field Validation */

	public static void scenarioAnalysisLocalFields(WebDriver driver, DriverScript Logs, String TestType,
			String TestCaseName) throws Exception {
		WebElement bestcase = driver.findElement(HubContributorFormObj.bestCase);
		WebElement mostlikely = driver.findElement(HubContributorFormObj.mostLikely);
		WebElement worstcase = driver.findElement(HubContributorFormObj.worstCase);

		/* Verify the Positive / Negative values */
		bestcase.clear();
		worstcase.clear();
		mostlikely.clear();
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, bestcase, Logs, "TC39",
				"TaxBenifit_+ve");
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, mostlikely, Logs, "TC41",
				"TaxBenifit_+ve");
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, worstcase, Logs, "TC43",
				"TaxBenifit_+ve");

		/* Verify Invalid data */
		bestcase.clear();
		worstcase.clear();
		mostlikely.clear();
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "Invalid_UseForIntended",
				bestcase, Logs, "TC40");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "Invalid_UseForIntended",
				mostlikely, Logs, "TC42");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "Invalid_UseForIntended",
				worstcase, Logs, "TC44");

		/* Verify decimal values */
		bestcase.clear();
		worstcase.clear();
		mostlikely.clear();
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				bestcase, Logs, "TC40_decimal");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				mostlikely, Logs, "TC42_decimal");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				worstcase, Logs, "TC44_decimal");

		/*
		 * Enter all data and verify the Save when only particular field is left
		 * blank
		 */

		HubContributor.saveWithFieldAsBlank(driver, TestType, bestcase, Logs, "TC45_Bestcase");
		HubContributor.saveWithFieldAsBlank(driver, TestType, worstcase, Logs, "TC45_worstcase");
		HubContributor.saveWithFieldAsBlank(driver, TestType, mostlikely, Logs, "TC45_mostlikely");
		/*
		 * Enter all data and verify the Submit when only particular field is
		 * left blank
		 */
		HubContributor.submitWithFieldAsBlank(driver, TestType, bestcase, Logs, "TC46_BestCase");
		HubContributor.submitWithFieldAsBlank(driver, TestType, worstcase, Logs, "TC46_worstcase");
		HubContributor.submitWithFieldAsBlank(driver, TestType, mostlikely, Logs, "TC46_mostlikely");

	}

	public static void scenarioAnalysisInterestAndPenaltiesFields(WebDriver driver, DriverScript Logs, String TestType,
			String TestCaseName) throws Exception {
		/* Verify default values */
		WebElement bestcaseIP = driver.findElement(HubContributorFormObj.interestAndPenaltiesBestCase);
		WebElement mostlikelyIP = driver.findElement(HubContributorFormObj.interestAndPenaltiesmostLikely);
		WebElement worstcaseIP = driver.findElement(HubContributorFormObj.interestAndPenaltiesworstCase);
		/* Verify the Positive / Negative values */
		bestcaseIP.clear();
		worstcaseIP.clear();
		mostlikelyIP.clear();
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, bestcaseIP, Logs, "TC54",
				"TaxBenifit_+ve");
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, mostlikelyIP, Logs, "TC56",
				"TaxBenifit_+ve");
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, worstcaseIP, Logs, "TC58",
				"TaxBenifit_+ve");

		/* Verify Invalid data */
		bestcaseIP.clear();
		worstcaseIP.clear();
		mostlikelyIP.clear();
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "Invalid_UseForIntended",
				bestcaseIP, Logs, "TC50");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "Invalid_UseForIntended",
				mostlikelyIP, Logs, "TC51");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "Invalid_UseForIntended",
				worstcaseIP, Logs, "TC53");

		/* Verify decimal values */
		bestcaseIP.clear();
		worstcaseIP.clear();
		mostlikelyIP.clear();
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				bestcaseIP, Logs, "TC50_decimal");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				mostlikelyIP, Logs, "TC51_decimal");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				worstcaseIP, Logs, "TC53_decimal");

		/*
		 * Enter all data and verify the Save when only particular field is left
		 * blank
		 */
		HubContributor.saveWithFieldAsBlank(driver, TestType, bestcaseIP, Logs, "TC56");
		HubContributor.saveWithFieldAsBlank(driver, TestType, worstcaseIP, Logs, "TC58");
		HubContributor.saveWithFieldAsBlank(driver, TestType, mostlikelyIP, Logs, "TC60");

		/*
		 * Enter all data and verify the Submit when only particular field is
		 * left blank
		 */
		HubContributor.submitWithFieldAsBlank(driver, TestType, bestcaseIP, Logs, "TC56");
		HubContributor.submitWithFieldAsBlank(driver, TestType, worstcaseIP, Logs, "TC58");
		HubContributor.submitWithFieldAsBlank(driver, TestType, mostlikelyIP, Logs, "TC60");

	}

	/* Validation of Beginning balance field */

	public static void begBalance(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.begBalance, 10);
		WebElement edt_begbalance = driver.findElement(HubContributorFormObj.begBalance);

		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, edt_begbalance, TestCaseName,
				"TaxBenifit_+ve", Logs, "TC64");

		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_begbalance, Logs, "TC66");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_begbalance, Logs, "TC67");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidVal", edt_begbalance,
				Logs, "TC68");

	}

	/* Verification of Charge to PL field */

	public static void charge_to_PL_Field(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		String excelValNegative = Util.getAllNecessaryData(TestType, TestCaseName, "TaxBenifit_+ve");
		String[] splittedVals = excelValNegative.split(",");
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.chargePL, 10);

		WebElement edt_chargetoPL = driver.findElement(HubContributorFormObj.chargePL);
		HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, edt_chargetoPL, TestCaseName,
				"TaxBenifit_+ve", Logs, "TC84");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_chargetoPL, Logs, "TC86");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_chargetoPL, Logs, "TC87");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidVal", edt_chargetoPL,
				Logs, "TC88");

		/*
		 * Verify Charge to P&L field for entered value > 0. The system should
		 * display Account Impacted � B/S on the schedule for user data entry.
		 */
		edt_chargetoPL.clear();
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(splittedVals[0]);
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(Keys.TAB);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.accountImpacted, 10);
		try {

			driver.findElement(HubContributorFormObj.accountImpacted).click();

			Logs.update("TC79 and 80 815A Verify Charge to P&L",
					"Account Impacted is enable when charge P&L is positive ", Status.PASS, driver);
		} catch (Exception e) {
			Logs.update("TC79 and 80 815A Verify Charge to P&L",
					"Account Impacted is NOT enabled when charge P&L is positive ", Status.FAIL, driver);
		}

		// beg balance = 0 , Charge to P&L = 0
		driver.findElement(HubContributorFormObj.begBalance).clear();
		edt_chargetoPL.clear();
		driver.findElement(HubContributorFormObj.begBalance).sendKeys("0");
		edt_chargetoPL.sendKeys("0");
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(Keys.TAB);

		try {

			driver.findElement(HubContributorFormObj.accountImpacted).click();

			Logs.update("TC81 815A Verify Charge to P&L",
					"Account Impacted is enable when beg balance = 0 , Charge to P&L = 0 ", Status.FAIL, driver);
		} catch (Exception e) {
			Logs.update("TC81 815A Verify Charge to P&L",
					"Account Impacted is not enabled when beg balance = 0 , Charge to P&L = 0 ", Status.PASS, driver);
		}

		// beg balance > 0 , Charge to P&L = 0

		driver.findElement(HubContributorFormObj.begBalance).clear();
		edt_chargetoPL.clear();
		driver.findElement(HubContributorFormObj.begBalance).sendKeys(splittedVals[0]);
		edt_chargetoPL.sendKeys("0");
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(Keys.TAB);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.accountImpacted, 10);

		try {

			driver.findElement(HubContributorFormObj.accountImpacted).click();

			Logs.update("TC82 815A Verify Charge to P&L",
					"Account Impacted is enable when beg balance = 0 , Charge to P&L = 0 ", Status.PASS, driver);
		} catch (Exception e) {
			Logs.update("TC82 815A Verify Charge to P&L",
					"Account Impacted is not enabled when beg balance = 0 , Charge to P&L = 0 ", Status.FAIL, driver);
		}

		// beg balance = 0 , Charge to P&L > 0
		driver.findElement(HubContributorFormObj.begBalance).clear();
		edt_chargetoPL.clear();
		driver.findElement(HubContributorFormObj.begBalance).sendKeys("0");
		edt_chargetoPL.sendKeys(splittedVals[0]);
		driver.findElement(HubContributorFormObj.chargePL).sendKeys(Keys.TAB);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.accountImpacted, 10);

		try {

			driver.findElement(HubContributorFormObj.accountImpacted).click();

			Logs.update("TC83 815A Verify Charge to P&L",
					"Account Impacted is enable when beg balance = 0 , Charge to P&L > 0 ", Status.PASS, driver);
		} catch (Exception e) {
			Logs.update("TC83 815A Verify Charge to P&L",
					"Account Impacted is not enabled when beg balance = 0 , Charge to P&L > 0 ", Status.FAIL, driver);
		}

		// status of reserve and charge to P & L
		driver.findElement(HubContributorFormObj.begBalance).clear();
		driver.findElement(HubContributorFormObj.chargePL).clear();
		driver.findElement(HubContributorFormObj.statusOfreserve).clear();
		try {
			driver.findElement(HubContributorFormObj.statusOfreserve).sendKeys("test");

			Logs.update("TC84 815A Verify Charge to P&L", "Status of reserve comments can be added  ", Status.PASS,
					driver);
		} catch (Exception e) {
			Logs.update("TC84 815A Verify Charge to P&L", "Status of reserve comments cannot be added ", Status.FAIL,
					driver);
		}

	}

	public static void verifyStatusOfReserve(WebDriver driver, DriverScript Logs, String TestType, WebElement element,
			String TestCaseName) throws Exception {
		element.clear();
		driver.findElement(HubContributorFormObj.statusOfreserve).clear();
		try {
			driver.findElement(HubContributorFormObj.statusOfreserve).sendKeys("test");

			Logs.update("TC99 815A Verify Status of reserve", "Status of reserve comments can be added  ", Status.PASS,
					driver);
		} catch (Exception e) {
			Logs.update("TC99 815A Verify Status  of reserve", "Status of reserve comments cannot be added ",
					Status.FAIL, driver);
		}

	}

	/* Verification of Return to PL field */

	public static void return_to_PL_Field(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.returnPL, 10);
		WebElement edt_ReturnToPL = driver.findElement(HubContributorFormObj.returnPL);
		// HubContributor.verifyDefaultValueIsZero(driver, TestType, "Return to
		// PL", edt_begbalance, Logs);
		HubContributor.verifyFieldIsTakingOnlyNegativeValues(driver, TestType, "TC_87:Return to PL", edt_ReturnToPL,
				"815A", "TaxBenifit_+ve", Logs);
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_ReturnToPL, Logs, "TC_89 Return to PL");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValReturnPL",
				edt_ReturnToPL, Logs, "TC_88 Return to PL");

		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_ReturnToPL, Logs, "TC_65 Return to PL");
	}

	/* Verification of Translation field */

	public static void translation(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.translation, 10);
		WebElement edt_Translation = driver.findElement(HubContributorFormObj.translation);
		// HubContributor.verifyDefaultValueIsZero(driver, TestType,
		// "Translation", edt_Translation, Logs);
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, edt_Translation, Logs, "TC101",
				"TaxBenifit_+ve");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_Translation, Logs, "TC_79 Translation");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_Translation, Logs, "TC_80 Translation");

	}

	/* Verification of Reclass field */

	public static void reClass(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.reClass, 10);
		WebElement edt_reClass = driver.findElement(HubContributorFormObj.reClass);
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, edt_reClass, Logs, "TC110",
				"TaxBenifit_+ve");
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_reClass, Logs, "TC111");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_reClass, Logs, "TC112");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValuesReclass_Trnsl",
				edt_reClass, Logs, "TC113");
		HubContributor.verifySaveAndSubmitWithDecimal(driver, TestType, TestCaseName, "DecimalValuesReclass_Trnsl",
				edt_reClass, Logs, "TC114");

	}

	/* Verification of Use for Intended field */
	public static void useForIntended(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.useForIntended, 10);
		WebElement edt_useForIntended = driver.findElement(HubContributorFormObj.useForIntended);
		HubContributor.verifyFieldIsTakingOnlyNegativeValues(driver, TestType, "TC_87:Return to PL", edt_useForIntended,
				"815A", "TaxBenifit_+ve", Logs);
		HubContributor.saveWithFieldAsBlank(driver, TestType, edt_useForIntended, Logs, "TC111");
		HubContributor.submitWithFieldAsBlank(driver, TestType, edt_useForIntended, Logs, "TC112");
		HubContributor.verifySaveAndSubmitWithInvalidData(driver, TestType, TestCaseName, "InvalidValuesReclass_Trnsl",
				edt_useForIntended, Logs, "TC113");
		HubContributor.verifySaveAndSubmitWithDecimalforpositivefields(driver, TestType, TestCaseName,
				"DecimalValuesReclass_Trnsl", edt_useForIntended, Logs, "TC114");

		Form815APage.verifyStatusOfReserve(driver, Logs, TestType, edt_useForIntended, "815A");
	}

	public static void defaultValues815(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) {
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_38_Scenario Analysis Reserves(Local)-BestCase",
				driver.findElement(HubContributorFormObj.bestCase), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_38_Scenario Analysis Reserves(Local)-MostLikely",
				driver.findElement(HubContributorFormObj.mostLikely), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_38_Scenario Analysis Reserves(Local)-Worstcase",
				driver.findElement(HubContributorFormObj.worstCase), Logs);
		//USD
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_47_Scenario Analysis Reserves(Local)-BestCase",
				driver.findElement(HubContributorFormObj.bestCaseUSD), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_47_Scenario Analysis Reserves(Local)-MostLikely",
				driver.findElement(HubContributorFormObj.mostLikelyUSD), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_47_Scenario Analysis Reserves(Local)-Worstcase",
				driver.findElement(HubContributorFormObj.worstCaseUSD), Logs);
		
    //IP
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC-49_Interest and penalties-BestCase",
				driver.findElement(HubContributorFormObj.interestAndPenaltiesBestCase), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC-49_Interest and penalties-MostLikely",
				driver.findElement(HubContributorFormObj.interestAndPenaltiesmostLikely), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC-49_Interest and penalties-Worstcase",
				driver.findElement(HubContributorFormObj.interestAndPenaltiesworstCase), Logs);

		
		// IP -USD 
		
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC-58_Interest and penalties-BestCase",
				driver.findElement(HubContributorFormObj.interestAndPenaltiesBestCase), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC-58_Interest and penalties-MostLikely",
				driver.findElement(HubContributorFormObj.interestAndPenaltiesmostLikely), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC-58_Interest and penalties-Worstcase",
				driver.findElement(HubContributorFormObj.interestAndPenaltiesworstCase), Logs);
		
		
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Beginning_Balance",driver.findElement(HubContributorFormObj.begBalance), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Charge to PL",
				driver.findElement(HubContributorFormObj.chargePL), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Return to PL",
				driver.findElement(HubContributorFormObj.returnPL), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Use for Intended ",
				driver.findElement(HubContributorFormObj.useForIntended), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Translation",
				driver.findElement(HubContributorFormObj.translation), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Reclass",
				driver.findElement(HubContributorFormObj.reClass), Logs);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "Ending Balance",
				driver.findElement(HubContributorFormObj.endingBalance), Logs);

	}
	public static void statusOfReserveField815(WebDriver driver, DriverScript Logs, String TestType,
			String TestCaseName) throws Exception {
		WebElement ele = driver.findElement(HubContributorFormObj.statusOfReserve815);
		driver.findElement(HubContributorFormObj.edt_BegBalance).clear();
		driver.findElement(HubContributorFormObj.edt_BegBalance).sendKeys(ReadXML.readData("TC_815A", "begBalance"));
		Thread.sleep(1000);
		String valInBegBalField = driver.findElement(HubContributorFormObj.edt_BegBalance).getAttribute("value");
		if(!valInBegBalField.equalsIgnoreCase("0") && !valInBegBalField.equalsIgnoreCase("")){
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "SOR_500plus_Chars",ele , Logs, "TC121_815A_Verify Comments-Status of Reserve", 500);
		}
		else{
			Logs.update("TC121_815A_Verify Comments-Status of Reserve", "Make sure Beg Balance field is greater than 0", Status.PASS, driver);
		}
		driver.findElement(HubContributorFormObj.statusOfReserve815).clear();
		driver.findElement(HubContributorFormObj.statusOfReserve815).sendKeys(ReadXML.readData("TC_814A", "statusOfReserve"));
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.statusOfReserve815).clear();
		Thread.sleep(1000);
		HubContributor.saveWithFieldAsBlank(driver, TestType, ele, Logs, "TC123_815A_Verify Comments-Status of Reserve");
		//HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMsg_StatusOfReserve", ele, Logs, "TC124_815A_Verify Comments-Status of Reserve");
		WebElement eleM = driver.findElement(HubContributorFormObj.statusOfReserve815);
		driver.findElement(HubContributorFormObj.statusOfReserve815).clear();
		driver.findElement(HubContributorFormObj.statusOfReserve815).sendKeys(ReadXML.readData("TC_815A", "statusOfReserve"));
		String reclassValue = driver.findElement(HubContributorFormObj.reClass).getAttribute("value");
		
		//Pre-requisite for Test Cases TC125, TC126 and TC127
		if(reclassValue.equalsIgnoreCase("0") && reclassValue.equalsIgnoreCase("")){
			driver.findElement(HubContributorFormObj.reClass).sendKeys(ReadXML.readData("TC_815A", "reClass"));
		}
		//=====================
		HubContributor.checkIfUserIsAbleToEnter(driver, TestType, "815A", eleM, Logs, "TC125_815A_Verify Explanation of Reclassifications", "InvalidValReturnPL");
		HubContributor.saveWithFieldAsBlank(driver, TestType, ele, Logs, "TC126_815A_Verify Comments-Status of Reserve");
		HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMsg_StatusOfReserve", ele, Logs, "TC127_815A_Verify Comments-Status of Reserve");
		driver.findElement(HubContributorFormObj.statusOfReserve815).clear();
		driver.findElement(HubContributorFormObj.statusOfReserve815).sendKeys(ReadXML.readData("TC_815A", "statusOfReserve"));
//		
//		
//		//<---Test case TC 103: There should be non 0 value in charge to PL, Return to PL and Use for intended.
//		String chargeToPL=driver.findElement(HubContributorFormObj.chargeToPL).getAttribute("value");
//		int chargeToPL_int=Integer.parseInt(chargeToPL);
//		String returnToPL=driver.findElement(HubContributorFormObj.returnedToPL).getAttribute("value");
//		char rPL=returnToPL.charAt(1);
//		int returnToPL_int=Integer.parseInt(String.valueOf(rPL));
//		String usedForIntended=driver.findElement(HubContributorFormObj.useForIntended_816).getAttribute("value");
//		char uForIn=usedForIntended.charAt(1);		
//		int useForIntended_int=Integer.parseInt(String.valueOf(uForIn));
//		if(!(chargeToPL_int==0) || !(returnToPL_int==0) || !(useForIntended_int==0)){
//			Logs.update("Charge to PL,Return to PL, Use for Intended", "Fields contains a values other than 0", Status.DONE, driver);
//			HubContributor.validatePopUpErrorMsgOnSubmit(driver, TestType, TestCaseName, "ErrorMsg_StatusOfReserve", ele, Logs, "TC_103 Status of Reserve");
//			
//		}else{
//			Logs.update("Charge to PL,Return to PL, Use for Intended", "Fields not contains a values other than 0", Status.FAIL, driver);
//		}
//
//		HubContributor.saveWithFieldAsBlank(driver, TestType, ele, Logs, "TC_102 Status of Reserve");
//		//HubContributor.submitWithStatusOfReserveAsBlank(driver, TestType, edt_statusOfReserve, Logs,"TC_103 Status of Reserve");


	}

	public static void endingBalanceField815(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		driver.findElement(HubContributorFormObj.btn_Add).click();
		Form815APage.enterTransactionTaxAllData(TestType, driver, Logs);
		int intValInBegBalance = Integer
				.parseInt(driver.findElement(HubContributorFormObj.begBalance).getAttribute("value"));
		int intvalInChargePLField = Integer
				.parseInt(driver.findElement(HubContributorFormObj.chargePL).getAttribute("value"));
		driver.findElement(HubContributorFormObj.returnPL).click();
		Thread.sleep(400);
		int intvalInReturnedToPL = Integer
				.parseInt(driver.findElement(HubContributorFormObj.returnPL).getAttribute("value"));
		driver.findElement(HubContributorFormObj.useForIntended).click();
		Thread.sleep(400);
		int intvalInIntended = Integer
				.parseInt(driver.findElement(HubContributorFormObj.useForIntended).getAttribute("value"));
		int intvalInTranslation = Integer
				.parseInt(driver.findElement(HubContributorFormObj.translation).getAttribute("value"));
		int intvalInReclass = Integer.parseInt(driver.findElement(HubContributorFormObj.reClass).getAttribute("value"));
		int intvalInEndingBalance = Integer
				.parseInt(driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value"));
		int sum = intValInBegBalance + intvalInChargePLField + intvalInReturnedToPL + intvalInIntended
				+ intvalInTranslation + intvalInReclass;
		if (sum == intvalInEndingBalance) {
			Logs.update("TC115 815A Ending Balance",
					"Sum of Beginning Balance, Charge to P & L, Return to P & L, Used for Intend Purpose, Translation, Reclass is equal to Ending Balance",
					Status.PASS, driver);
		} else {
			Logs.update("TC115 815A Ending Balance",
					"Sum of Beginning Balance, Charge to P & L, Return to P & L, Used for Intend Purpose, Translation, Reclass is not equal to Ending Balance",
					Status.FAIL, driver);
		}

		/*
		 * When Ending balance is Negative
		 */
		driver.findElement(HubContributorFormObj.useForIntended).clear();
		driver.findElement(HubContributorFormObj.useForIntended).sendKeys(ReadXML.readData("TC_815A", "negativevalue"));
		driver.findElement(HubContributorFormObj.useForIntended).sendKeys(Keys.TAB);
		String valInEndingBal = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
		if (valInEndingBal.contains("(") || valInEndingBal.contains(")")) {
			WebElement endingBal = driver.findElement(HubContributorFormObj.endingBalance);
			driver.findElement(HubContributorFormObj.btn_Submit).click();// Click
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.btn_OkSuccessPopUp, 10);
			String NotSubmitted = driver.findElement(HubContributorFormObj.submitUnsuccessMessage).getText();
			if (NotSubmitted.contains("Submit Unsuccessful")) {
				Logs.update("To verify sumit not succesful", "Not submitted as expected.", Status.PASS, driver);
			}

			else {
				Logs.update("To verify sumit not succesful", "Submitted.", Status.FAIL, driver);
			}

			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();

		}
		
	}
	
	public static void verifyExchangeRate(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		String bestcasevalue = ReadXML.readData(TestCaseName, "bestCase");
		String worstcasevalue = ReadXML.readData(TestCaseName, "worstCase");
		String mostlikelyvalue = ReadXML.readData(TestCaseName, "mostLikelyCase");
		String exchangeRate = ReadXML.readData(TestCaseName, "exchangeRate");
		driver.findElement(HubContributorFormObj.bestCase).clear();
		driver.findElement(HubContributorFormObj.worstCase).clear();
		driver.findElement(HubContributorFormObj.mostLikely).clear();
		driver.findElement(HubContributorFormObj.bestCase).sendKeys(bestcasevalue);
		driver.findElement(HubContributorFormObj.worstCase).sendKeys(worstcasevalue);
		driver.findElement(HubContributorFormObj.mostLikely).sendKeys(mostlikelyvalue);
		float floatbestcaseValue = Float.parseFloat(bestcasevalue);
		float floatworstcaseValue = Float.parseFloat(worstcasevalue);
		float floatmostlikelyValue = Float.parseFloat(mostlikelyvalue);
		float floatexchangerateValue = Float.parseFloat(exchangeRate);
		
		String bestcaseUSD=driver.findElement(HubContributorFormObj.bestCaseUSD).getAttribute("value");
		String worstcaseUSD=driver.findElement(HubContributorFormObj.bestCaseUSD).getAttribute("value");
		String mostlikleyUSD=driver.findElement(HubContributorFormObj.bestCaseUSD).getAttribute("value");
		float floatbestcaseUSDValue = Float.parseFloat(bestcaseUSD);
		float floatworstcaseUSDValue = Float.parseFloat(worstcaseUSD);
		float floatmostlikelyUSDValue = Float.parseFloat(mostlikleyUSD);
		
		
		if ( floatbestcaseUSDValue == (floatbestcaseValue / floatexchangerateValue))
		{
			Logs.update("TC-48 best case-Exchange Rate verification reserves Local best case", "Value is as per exchange Rate", Status.PASS, driver);
		}
		
		else 
		{
			Logs.update("TC-48-best case -Exchange Rate verification reserves Local", "Value is NOT as per exchange Rate", Status.FAIL, driver);
		}
		
		
		if ( floatworstcaseUSDValue == (floatworstcaseValue / floatexchangerateValue))
		{
			Logs.update("TC-48 worst case-Exchange Rate verification reserves Local best case", "Value is as per exchange Rate", Status.PASS, driver);
		}
		
		else 
		{
			Logs.update("TC-48-worst case -Exchange Rate verification reserves Local", "Value is NOT as per exchange Rate", Status.FAIL, driver);
		}
		
		if ( floatmostlikelyUSDValue == (floatmostlikelyValue / floatexchangerateValue))
		{
			Logs.update("TC-48 mostlikely case-Exchange Rate verification reserves Local best case", "Value is as per exchange Rate", Status.PASS, driver);
		}
		
		else 
		{
			Logs.update("TC-48-mostlikely case -Exchange Rate verification reserves Local", "Value is NOT as per exchange Rate", Status.FAIL, driver);
		}

	}
	
	//TC-122 Status of reserve for existing reserve
	public static void existingReserveStatusOfReserveField815(WebDriver driver, DriverScript Logs, String TestType,
			String TestCaseName) throws Exception {
		WebElement ele = driver.findElement(HubContributorFormObj.statusOfReserve815);
		//driver.findElement(HubContributorFormObj.edt_BegBalance).clear();
		driver.findElement(HubContributorFormObj.edt_BegBalance).sendKeys(ReadXML.readData("TC_815A", "begBalance"));
		Thread.sleep(1000);
		String valInBegBalField = driver.findElement(HubContributorFormObj.edt_BegBalance).getAttribute("value");
		if(!valInBegBalField.equalsIgnoreCase("0") && !valInBegBalField.equalsIgnoreCase("")){
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "SOR_500plus_Chars",ele , Logs, "TC121_815A_Verify Comments-Status of Reserve", 500);
		}
		else{
			Logs.update("TC122_815A_Verify Comments-Status of Reserve", "Make sure Beg Balance field is greater than 0", Status.PASS, driver);
		}
		
	}
	// Change Request - 02-Dec-2019-Prasannajit
	public static void valueOfStatuseField815(WebDriver driver, DriverScript Logs, String TestType,
			String TestCaseName) throws Exception {
		
		String statusDefaultValue = driver.findElement(By.xpath("//*[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_4d969148-f031-9fe1-fdaa-e9ac27f13a12']/div/div[1]/div[2]/div[2]/div/a/span")).getText();
		System.out.println(statusDefaultValue);
		driver.findElement(By.xpath("//*[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_4d969148-f031-9fe1-fdaa-e9ac27f13a12']/div/div[2]/a/span/span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Audit']")).click();
		
		hubContributorFormObj.saveButton(driver).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(2000);
		// Verify default value of new record after saving 
		driver.findElement(HubContributorFormObj.btn_Add).click();
		Thread.sleep(5000);
		String statusDefaultValue1 = driver.findElement(By.xpath("//*[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_4d969148-f031-9fe1-fdaa-e9ac27f13a12']/div/div[1]/div[2]/div[2]/div/a/span")).getText();
		System.out.println(statusDefaultValue1);
		
		if (statusDefaultValue1=="New/Undiscovered")
		{
			Logs.update("TC-CR- Verify Status default value"," Default Value is  New/Undiscovered as expected", Status.PASS, driver);
		}
		else
		{
			Logs.update("TC-CR- Verify Status default value"," Default Value is  NOT New/Undiscovered", Status.FAIL, driver);
		}
	}
}



