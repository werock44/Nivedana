package pages;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import objectRepository.*;
import Reports.DriverScript;
import Reports.Status;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class FoundationCasesPage_DistFC_TC06 {
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String buGOId;

	public static void distributionFC_06(WebDriver driver, DriverScript Logs, String TestType, String TestCaseNAme) throws Exception{
	schedule = Util.getAllNecessaryData(TestType, "816ADB", "ScheduleName");	
	entityName = Util.getAllNecessaryData(TestType, "816ADB", "EntityDetail");
	
	String queryToGetBuGoId="Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' and EntityStatus='A' and entityID"
			+ " not IN (select entityId from scheduleinstance where scheduleID='EA8B8BA4-B64E-4023-B952-38BC3880E716' "
			+ "and periodid='2019.12')"; //Change the period if if other period data is required.
	buGOId=	DataBaseConnection.getData(driver, Logs, TestType, queryToGetBuGoId, "BUStructure");
	//buGOId="BU522GOIE";
	Logs.update("BuGOID", buGOId, Status.DONE, driver);
	String querytoGetEntityCode="select  top 1 entityCode from masterdata.entity where bustructure=+'"+buGOId+"'and entitystatus='A' and EntityType='R'";
	entityCode=DataBaseConnection.getData(driver, Logs, TestType, querytoGetEntityCode, "entityCode");
	//entityCode="5483";
	Logs.update("Entity ID", entityCode, Status.DONE, driver);
	period = Util.getAllNecessaryData(TestType, "816ADB", "Period");
	
	/*HubContributor.validateIfElementIsPresent(driver,HubHomePageObj.hubCRPbutton, Logs, "HUB CRP Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.hub2Button, Logs, "HUB 2.0 Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");*/
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.myDashBoardButton, Logs, "My Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.statusDashBoard, Logs, "Status Dashboard Button");
	HubContributor.validateIfElementIsPresent(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
	HubContributor.switchWindow(driver);
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminDashboardButton, Logs, "Admin-Dashboard Button");
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.adminScreenButton, Logs, "Admin-Screen Button");
	HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
	Thread.sleep(1000);
	HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.scheduleDistributionButton, Logs, "Schedule Distribution Button");
	WebElement sdFrame = driver.findElement(By.xpath("//*[@class='content-control-iframe']"));
	driver.switchTo().frame(sdFrame);
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDistFrequencyLbl, Logs, "Schedule Distribution Frequency");
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.PeriodLbl, Logs, "Period");
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleLbl, Logs, "Schedule");
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.entitiesLbl, Logs, "Entities");
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.scheduleDueDateLbl, Logs, "Schedule Due date");
	//HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.distributeBtn, Logs, "Distribute Button");
	//List<WebElement> sDFreqList = driver.findElements(HubAdminScreen.scheduleDistFrequencyList);
	//HubContributor.checkTheDropDownValues(driver, TestType, TestCaseNAme, sDFreqList, Logs, "Verify Schedule distribution frequency list values", "ScheduleDistributionFreqValues");	
	Thread.sleep(3000);
	driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
	Thread.sleep(1000);
	driver.findElement(HubAdminScreen.scheduleDistFrequency_Quaterly).click();
	Thread.sleep(2000);
	
    driver.findElement(HubAdminScreen.periodField).click();
    Thread.sleep(1000);
    driver.findElement(HubAdminScreen.period_QuaterlyPrevious).click();
    Thread.sleep(1000);
    driver.findElement(HubAdminScreen.scheduleField).click();
    Thread.sleep(1000);
    //driver.findElement(HubAdminScreen.schedule_GenReserve).click();
    HubHomePageObj.findScheduleName(driver, schedule).click();
    driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
    Thread.sleep(3000);
    driver.findElement(By.xpath("(//div[contains(text()," + "'"+buGOId +"')])[1]")).click();
    HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.selectedAddicon, Logs, "Add selected entities using '>'");
    
    //driver.findElement(HubAdminScreen.selectedAddicon).click();
     HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.distributeBtn, Logs, "Distribute Button");
    Thread.sleep(5000);
    Actions action = new Actions(driver);
    action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build().perform();
    Thread.sleep(2000);
    HubContributor.switchWindow_3(driver);
    HubContributor.validateIfElementIsPresent(driver, HubAdminScreen.schDistributionProgDashboard, Logs, "Schedule Distribution Progress Dashboard");
	String progBarVal=driver.findElement(HubAdminScreen.distributionProgressBar).getAttribute("title");
	if(progBarVal.contains("100%")){
		Logs.update("Verifying Progress bar value when distribution is successful", "Progress bar is showing 100% as expected", Status.PASS, driver);
	}else{
		Logs.update("Verifying Progress bar value when distribution is successful", "Progress bar is not showing 100% ", Status.FAIL, driver);
	}
	driver.quit();	
	Thread.sleep(2000);
	driver=Login.LaunchHub("Setupurl", Logs);
	HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
	WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
	boolean recordPresent=entityXpath.isDisplayed();
	Assert.assertTrue(recordPresent);
	if(recordPresent==true){
		Logs.update("Verify the presence of distributed schedule in My DashBoard page", "Distributed schedule is present in my dashboard", Status.PASS, driver);
	}else{
		Logs.update("Verify the presence of distributed schedule in My DashBoard page", "Distributed schedule is not present in my dashboard", Status.FAIL, driver);
	}
	driver.switchTo().defaultContent();
	//Click on status dashboard and verify the schedule
	driver.findElement(HubHomePageObj.statusDashBoard).click();
	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
	driver.switchTo().frame(Frame);
	Thread.sleep(5000);
	//JavascriptExecutor jse = (JavascriptExecutor) driver;
	//jse.executeScript("window.scrollBy(0,250)");
	Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
	driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);//entity code is retrieved from DB
	Thread.sleep(4000);
	driver.findElement(HubHomePageObj.scheduleButton).click();
	Thread.sleep(2000);
	HubHomePageObj.findScheduleName(driver, schedule).click();
	Thread.sleep(1000);
	driver.findElement(HubHomePageObj.periodTextBoxStatusDB).clear();
	driver.findElement(HubHomePageObj.periodTextBoxStatusDB).sendKeys(period);
	Thread.sleep(1000);
	driver.findElement(HubHomePageObj.searchButtonDashboard).click();// only search
	Thread.sleep(3000);
	WebElement entityXpathSD = HubHomePageObj.findEntityCode(driver, entityCode);
	boolean SchedulePresentInSD=entityXpathSD.isDisplayed();
	if(SchedulePresentInSD==true){
		Logs.update("Verify the distributed schedule present in status dashboard", "Distributed schedule is present in status dashboard", Status.PASS, driver);
	}else{
		Logs.update("Verify the distributed schedule present in status dashboard", "Distributed schedule is not present in status dashboard", Status.FAIL, driver);
	}
	//Navigate to Admin Dashboard
	driver.switchTo().defaultContent();
	driver.findElement(HubHomePageObj.adminLink).click();
	Thread.sleep(2000);
	HubContributor.switchWindow(driver);
	Thread.sleep(5000);
	//driver.findElement(HubAdminScreen.adminDashboardButton).click();
	
	driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
	Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
	driver.findElement(HubAdminScreen.entityDetail).sendKeys(entityCode);
	Thread.sleep(4000);
	driver.findElement(HubAdminScreen.scheduleDrpDwn).click();
	Thread.sleep(8000);
	HubHomePageObj.findScheduleName(driver, schedule).click();
	Thread.sleep(1000);
	driver.findElement(HubAdminScreen.edt_Period).clear();
	Thread.sleep(2000);
	driver.findElement(HubAdminScreen.edt_Period).sendKeys(period);
	Thread.sleep(1000);
	driver.findElement(HubAdminScreen.searchButtom).click();
	Thread.sleep(3000);
	WebElement entityXpathAD = HubHomePageObj.findEntityCode(driver, entityCode);
	boolean SchedulePresentInAD=entityXpathAD.isDisplayed();
	if(SchedulePresentInAD==true){
		Logs.update("Verify the distributed schedule present in Admin dashboard", "Distributed schedule is present in Admin dashboard", Status.PASS, driver);
	}else{
		Logs.update("Verify the distributed schedule present in Admin dashboard", "Distributed schedule is not present in Admin dashboard", Status.FAIL, driver);
	}
	Actions act=new Actions(driver);
	act.moveToElement(entityXpathAD).doubleClick().build().perform();
	Thread.sleep(2000);
	boolean statusOfRedirect=driver.findElement(HubAdminScreen.redirect_btn).isEnabled();
	if(statusOfRedirect==true){
		Logs.update("Verify redirect button gets enabled for admin", "Redirect button is enabled", Status.PASS, driver);
	}else{
		Logs.update("Verify redirect button gets enabled for admin", "Redirect button is NOT enabled", Status.PASS, driver);
	}
	
	
	
}

	

}




