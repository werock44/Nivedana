package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import utils.Base_class;
import utils.HubContributor;
import utils.ReadXML;
import utils.Util;
/*author v265130
Vivek Keshav
*/
public class Form814APage {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	
	public static void fillForm814A(WebDriver driver) throws InterruptedException{
		base.waitForElementTobeClickable(driver, HubContributorFormObj.lbl_IdNo, 10);
		hubContributorFormObj.fromTaxYearName(driver).clear();
		hubContributorFormObj.fromTaxYearName(driver).sendKeys(ReadXML.readData("TC_814A", "fromTaxYear"));
		hubContributorFormObj.toTaxYearName(driver).clear();
		hubContributorFormObj.toTaxYearName(driver).sendKeys(ReadXML.readData("TC_814A", "toTaxYear"));
		hubContributorFormObj.currentTaxRate(driver).clear();
		hubContributorFormObj.currentTaxRate(driver).sendKeys(ReadXML.readData("TC_814A", "currTaxRate"));
		driver.findElement(HubContributorFormObj.drpDown_Status).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.statusValue_Undiscovered).click();
		driver.findElement(HubContributorFormObj.edt_ShortDescription).clear();
		driver.findElement(HubContributorFormObj.edt_ShortDescription).sendKeys(ReadXML.readData("TC_814A", "shortDescription"));
		driver.findElement(HubContributorFormObj.edt_LongDescription).clear();
		driver.findElement(HubContributorFormObj.edt_LongDescription).sendKeys(ReadXML.readData("TC_814A", "longDescription"));
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).clear();
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).sendKeys(ReadXML.readData("TC_814A", "statusOfReserve"));
		driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).clear();
		driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).sendKeys(ReadXML.readData("TC_814A", "TaxBenifitFiled"));
		driver.findElement(HubContributorFormObj.potentialInterestLocal).clear();
		driver.findElement(HubContributorFormObj.potentialInterestLocal).sendKeys(ReadXML.readData("TC_814A", "PotentialInterestAndPenalities"));
		driver.findElement(HubContributorFormObj.potentialInterestLocal).sendKeys(Keys.TAB);
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_MoreThan50).click();;
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).clear();
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).sendKeys(ReadXML.readData("TC_814A", "ExpectedBenifit"));
		driver.findElement(HubContributorFormObj.drpDown_GLAccountReserve).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.GLAccountReserve_147350).click();
		driver.findElement(HubContributorFormObj.drpDown_GLAccountInterestPenalities).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.val_GLAccountInterestPenalities268200).click();
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).clear();
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).sendKeys(ReadXML.readData("TC_814A", "AccuredInterest"));		
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).sendKeys(Keys.TAB);
	}
	
	
	/*---------------------------------------------------------------------------------------------------------------------------------------
    ----First Time Login Fields(Validation after entering the default values- CALLING --->> Form814APage.fillForm814A(driver);-----------
    -----------------------------Following Test Cases are called from TC_814A_FieldValidation1 test case-------------------
	*/
	
	public static void statusOfReserveField814(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
//		String valOfStatusOfReserve = Util.getAllNecessaryData(TestType, TestCaseName, "SOR_500plus_Chars"); 
//		int lengthOfInput = valOfStatusOfReserve.length();
//		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).sendKeys(valOfStatusOfReserve);
//		Thread.sleep(3000);
//		int enteredValueLength = (driver.findElement(HubContributorFormObj.edt_StatusOfReserve).getAttribute("value")).length();
//		if(enteredValueLength==500){
//			Logs.update("TC024 814A Status of Reserve", "The status of reserve field does not accept more than 500 alphanumeric characters", Status.PASS, driver);
//			Assert.assertEquals(enteredValueLength, 500);
//		}
//		else{
//			Logs.update("TC024 814A Status of Reserve", "The status of reserve field accepts more than 500 alphanumeric characters", Status.FAIL, driver);
//			Assert.assertEquals(enteredValueLength, 500);
//		}
		WebElement ele = driver.findElement(HubContributorFormObj.edt_StatusOfReserve);
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName, "SOR_500plus_Chars",ele , Logs, "TC024 814A Status of Reserve", 500);
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).clear();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).sendKeys(ReadXML.readData("TC_814A", "statusOfReserve"));
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.potentialInterestLocal).clear();
		driver.findElement(HubContributorFormObj.potentialInterestLocal).sendKeys(ReadXML.readData("TC_814A", "PotentialInterestAndPenalities"));
		//Add the other status of Reserve test case here if possible
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		//base.waitForElementTobeClickable(driver, HubContributorFormObj.btn_OkSuccessPopUpNew, 10);
		
		if((driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew)).isDisplayed()){
			Logs.update("TC025 814A Status of Reserve", "User is NOT able to submit the schedule when status of reserve is left blank", Status.PASS, driver);
			
		}
		else{
			Logs.update("TC025 814A Status of Reserve", "User is able to submit the schedule when status of reserve is left blank", Status.FAIL, driver);
		}
		Thread.sleep(5000);
		/*Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(HubContributorFormObj.btn_Cancel));*/
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.findElement(HubContributorFormObj.btn_Cancel).click();
		Thread.sleep(2000);
		//Setting the value to default in order to check other fields
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).sendKeys(ReadXML.readData("TC_814A", "statusOfReserve"));
		Thread.sleep(5000);
		//Actions action = new Actions(driver);
		/*action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew)).sendKeys(Keys.ENTER).build()
		.perform();*/
	
	}


	public static void recognitionThresholdField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		int fCount = 0;
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_LessThan50).click();
		Thread.sleep(1000);
		Logs.update("Screenshot","",Status.PASS,driver);
		String valInDropDown = driver.findElement(HubContributorFormObj.selectedVal_drpDown_ReognitionThreshold).getAttribute("title");
		if(valInDropDown.equalsIgnoreCase("<50%")){
			fCount = fCount+1;	
		}
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_MoreThan50).click();
		Thread.sleep(1000);
		String valInDropDown2 = driver.findElement(HubContributorFormObj.selectedVal_drpDown_ReognitionThreshold).getAttribute("title");
		if(valInDropDown2.equalsIgnoreCase(">50%")){
			fCount = fCount+1;	
		}
		if(fCount==2){
			Logs.update("TC035 814A Recognition Threshold","User is able to select  >50% and <50%. from the dropdown",Status.PASS,driver);
		}
		else{
			Logs.update("TC035 814A Recognition Threshold","User is not able to select  >50% and <50%. from the dropdown",Status.FAIL,driver);
		}
	}
	public static void expectedPercentageBenifitField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_LessThan50).click();
		Thread.sleep(1000);
		WebElement ele1 = driver.findElement(HubContributorFormObj.edt_ExpectedBenifit);
		Thread.sleep(1000);
		String classVal1 = HubContributor.getClassValue(driver, Logs, ele1 );
		if(classVal1.contains("readonly")){
			Logs.update("TC036 814A Expected Percentage benefit to be sustained on settlement or disposition", "user is not allowed to enter any data in Expected Percentage benefit field and is greyed out", Status.PASS, driver);
		}
		else{
			Logs.update("TC036 814A Expected Percentage benefit to be sustained on settlement or disposition", "user is allowed to enter any data in Expected Percentage benefit field and is greyed out", Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_MoreThan50).click();
		Thread.sleep(1000);
		WebElement ele = driver.findElement(HubContributorFormObj.edt_ExpectedBenifit);
		HubContributor.checkIfUserIsAbleToEnter(driver, TestType, TestCaseName, ele, Logs, "TC_037", "PosVal");
		HubContributor.checkIfUserIsAbleToEnter(driver, TestType, TestCaseName, ele, Logs, "TC040 814A Expected Percentage benefit to be sustained", "PosVal");
		HubContributor.onSubmitWithInvalidDataLocal(driver, TestType, TestCaseName, ele, Logs, "TC_038", "InvalidVal");		
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).sendKeys(ReadXML.readData("TC_814A", "ExpectedBenifit"));
	}
	public static void accuredInterestPenalities(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		String testData = Util.getAllNecessaryData(TestType, TestCaseName, "TaxBenifit_+ve");
		WebElement ele_AccuredInterestLocal = driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities);
		WebElement ele_AccuredInterestUSD = driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalitiesUSD);
		HubContributor.checkIfUserIsAbleToEnter(driver, TestType, TestCaseName, ele_AccuredInterestLocal, Logs, "TC_054", "PosVal");
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, ele_AccuredInterestLocal, Logs, "TC_050", "TaxBenifit_+ve");
		HubContributor.calculateAmountInUSD(driver, TestType, TestCaseName, ele_AccuredInterestLocal, ele_AccuredInterestUSD, Logs, "TC_052");
		HubContributor.onSubmitWithInvalidDataLocal(driver, TestType, TestCaseName, ele_AccuredInterestLocal, Logs, "TC_051","InvalidVal");
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).sendKeys(ReadXML.readData("TC_814A", "AccuredInterest"));
	}
	
	public static void unrecognizedTaxBenefitField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement ele_UnrecognizedBenifitLocal = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifit);
		WebElement ele_UnrecognizedBenifitUSD = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifitUSD);
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_LessThan50).click();
		Thread.sleep(1000);
		String valTaxBenifit = driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).getAttribute("value");
		String valUnrecogTaxBenifit = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifit).getAttribute("value");
		Assert.assertEquals(valTaxBenifit, valUnrecogTaxBenifit);
		if(valTaxBenifit.equalsIgnoreCase(valUnrecogTaxBenifit)){
			Logs.update("TC044 814A Unrecognized Tax Benefit or Reserve", "The Unrecognized Tax Benefit field displays the 100% of amount entered in Tax Benefit Filed when Recognition Threshold is < 50%", Status.PASS, driver);
		}
		else{
			Logs.update("TC044 814A Unrecognized Tax Benefit or Reserve", "The Unrecognized Tax Benefit field does not display the 100% of amount entered in Tax Benefit Filed when Recognition Threshold is < 50%", Status.FAIL, driver);
		}	
		
		String numericVal= Util.getAllNecessaryData(TestType, TestCaseName, "PosVal");
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_MoreThan50).click();
		Thread.sleep(1000);
		String vaInTaxBenifit = driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).getAttribute("value");
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).sendKeys(numericVal);
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).sendKeys(Keys.TAB);
		String valInExpectedBenifitField = driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).getAttribute("value");
		String valInUnrecognizedTaxBenifitField = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifit).getAttribute("value");
		int IntInExpectedBenifitField = Integer.parseInt(valInExpectedBenifitField);
		int valInTaxBenifitField = Integer.parseInt(vaInTaxBenifit);
		int intUnrecognizedTaxBenifitField = Integer.parseInt(valInUnrecognizedTaxBenifitField);
		Assert.assertEquals(valInTaxBenifitField-(valInTaxBenifitField*IntInExpectedBenifitField/100), intUnrecognizedTaxBenifitField);
		int res = valInTaxBenifitField-(valInTaxBenifitField*IntInExpectedBenifitField/100);
		if(res==intUnrecognizedTaxBenifitField){
			Logs.update("TC045 814A Unrecognized Tax Benefit or Reserve", "The text box displays the amount (100% of ax Benefit Filed or to be Filed - Expected % of benefit sustained) X Tax Benefit Filed or to be Filed", Status.PASS, driver);
		}
		else{
			Logs.update("TC045 814A Unrecognized Tax Benefit or Reserve", "The text box does not display the amount (100% of ax Benefit Filed or to be Filed - Expected % of benefit sustained) X Tax Benefit Filed or to be Filed", Status.FAIL, driver);
		}
		HubContributor.checkIfUserIsAbleToEnter(driver, TestType, TestCaseName, ele_UnrecognizedBenifitLocal, Logs, "TC_047", "PosVal");
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, ele_UnrecognizedBenifitLocal, Logs, "TC_042", "TaxBenifit_+ve");
		HubContributor.onSubmitWithInvalidDataLocal(driver, TestType, TestCaseName, ele_UnrecognizedBenifitLocal, Logs, "TC_043", "InvalidVal");
		HubContributor.calculateAmountInUSD(driver, TestType, TestCaseName, ele_UnrecognizedBenifitLocal, ele_UnrecognizedBenifitUSD, Logs, "TC_046");
		//fill some default value to continue with other test cases(The value will be calculated again when expected benifit field is populated
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).clear();
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).sendKeys(ReadXML.readData("TC_814A", "ExpectedBenifit"));
	}
	
	
	public static void taxBenifitFiledField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement ele = driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled);
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, ele, Logs, "TC_026", "TaxBenifit_+ve");
		HubContributor.onSubmitWithInvalidDataLocal(driver, TestType, TestCaseName, ele, Logs, "TC_029", "InvalidVal");
		//Setting the value to default in order to check other fields
		WebElement taxBenifitUSD = driver.findElement(HubContributorFormObj.edt_TaxBenifitFiledUSD); 
		HubContributor.calculateAmountInUSD(driver, TestType, TestCaseName, ele, taxBenifitUSD, Logs, "TC_028");
		driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).clear();
		driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).sendKeys(ReadXML.readData("TC_814A", "TaxBenifitFiled"));
	}	
	public static void potentialInterestField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement ele = driver.findElement(HubContributorFormObj.potentialInterestLocal);
		WebElement potentialInterestUSD = driver.findElement(HubContributorFormObj.potentialInterestUSD);
		HubContributor.onPositiveAndNegativeValues(driver, TestType, TestCaseName, ele, Logs, "TC_030", "TaxBenifit_+ve");
		HubContributor.onSubmitWithInvalidDataLocal(driver, TestType, TestCaseName, ele, Logs, "TC_034", "InvalidVal");
		//Setting the value to default in order to check other fields
		HubContributor.calculateAmountInUSD(driver, TestType, TestCaseName, ele, potentialInterestUSD, Logs, "TC032 814A Potential Interest & Penalties");
		driver.findElement(HubContributorFormObj.potentialInterestLocal).sendKeys(ReadXML.readData("TC_814A", "PotentialInterestAndPenalities"));
	}
	
	public static void GLAccountReserveField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		List<WebElement> EleList = driver.findElements(HubContributorFormObj.drpDown_GLAcountReserveList);
		HubContributor.checkTheDropDownValues(driver, TestType, TestCaseName, EleList, Logs, "TC_049", "GLAccountReserveValues");
		
	}
	public static void GLAccountRecordedField(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		List<WebElement> EleList = driver.findElements(HubContributorFormObj.drpDwn_GeneralAccountRecorded);
		HubContributor.checkTheDropDownValues(driver, TestType, TestCaseName, EleList, Logs, "TC_056", "GLAccountRecordedValues");
	}
	
	/*---------------------------------------------------------------------------------------------------------------------------------------
     ----First Time Login Fields(Validation with entering the default values- NOT CALLING --->> Form814APage.fillForm814A(driver);-----------
     -----------------------------------------Following Test Cases are called from TC_814A_FieldValidation2Default test case-------------------
	*/
	public static void taxBenifitFiledField_Default(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement FieldLocal = driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled);
		WebElement FieldUSD = driver.findElement(HubContributorFormObj.edt_TaxBenifitFiledUSD);
		HubContributor.checkUSDFieldWithInvalidData(driver, TestType, TestCaseName, FieldLocal, FieldUSD, Logs, "TC027", "InvalidVal");
	}
	public static void PotentialInterestField_Defalut(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement FieldLocal = driver.findElement(HubContributorFormObj.potentialInterestLocal);
		WebElement FieldUSD = driver.findElement(HubContributorFormObj.potentialInterestUSD);
		HubContributor.checkIfUserIsAbleToEnterUSD(driver, TestType, TestCaseName, FieldLocal, FieldUSD, Logs, "TC033 814A Potential Interest & Penalties", "PosVal");
		HubContributor.checkUSDFieldWithInvalidData(driver, TestType, TestCaseName, FieldLocal, FieldUSD, Logs, "TC031 814A Potential Interest & Penalties", "InvalidVal");
	}
	public static void unrecognizedTaxBenefitField_Default(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_MoreThan50).click();;
		Thread.sleep(1000);
		WebElement FieldLocal = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifit);
		WebElement FieldUSD = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifitUSD);
		HubContributor.checkUSDFieldWithInvalidData(driver, TestType, TestCaseName, FieldLocal, FieldUSD, Logs, "TC048 814A Unrecognized Tax Benefit or Reserve", "InvalidVal");
	}
	public static void accuredInterestPenalities_Default(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName) throws Exception{
		WebElement FieldLocal = driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities);
		WebElement FieldUSD = driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalitiesUSD);
		HubContributor.checkIfUserIsAbleToEnterUSD(driver, TestType, TestCaseName, FieldLocal, FieldUSD, Logs, "TC053 814A Accrued Interest & Penalties", "PosVal");
		HubContributor.checkUSDFieldWithInvalidData(driver, TestType, TestCaseName, FieldLocal, FieldUSD, Logs, "TC054 814A Accrued Interest & Penalties", "InvalidVal");
	}
	public static void GLAccountRecordedAccuredInterest_Default(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName){
		String valInGLAccountRecordedAccuredInterest_Default = driver.findElement(HubContributorFormObj.drpDwn_GLAccountRecordedAccuredInterestDefault).getAttribute("title");
		if(valInGLAccountRecordedAccuredInterest_Default.equalsIgnoreCase("Select an item")){
			Logs.update("TC055 814A G L Account Recorded - Accrued Interest & Penalties", "By default nothing is selected in the GL Account Recorded Accured Interest field", Status.PASS, driver);
		}
		else{
			Logs.update("TC055 814A G L Account Recorded - Accrued Interest & Penalties", "By default a value is selected in the GL Account Recorded Accured Interest field", Status.FAIL, driver);
		}
	}
	
	
	
	

}