package pages;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.Form_1590G_Obj;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;

public class Form1590GPages {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	static Actions actions;
	static WebElement entityXpath;
	static WebElement list;
	static WebDriverWait wait;
	static int i;

	// Test case TC_01 and TC_02

	public static void verifyScheduleDistributed(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		boolean scheduleDistributed = entityXpath.isDisplayed();
		Assert.assertEquals(scheduleDistributed, true,"As Expected the schedule is distributed");
		if (scheduleDistributed == true) {
			Thread.sleep(4000);
			Logs.update(
					"R1_1590G_TC01_Validate whether the Schedule owner is able to distribute the BG Monthly Schedule",
					"BG Monthly schedule is distributed successfully", Status.PASS, driver);
		} else {
			Logs.update(
					"R1_1590G_TC01_Validate whether the Schedule owner is able to distribute the BG Monthly Schedule",
					"BG Monthly schedule is NOT distributed successfully", Status.FAIL, driver);
		}
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String ScheduleNameAct = driver.findElement(HubContributorFormObj.ScheduleNameValue).getText();
		Assert.assertEquals(ScheduleNameAct, schedule);
		if (ScheduleNameAct.equalsIgnoreCase(schedule)) {
			Logs.update("Verify the shchedule Name", "Schedule Name is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("Verify the shchedule Name", "Schedule Name is not displayed as expected", Status.FAIL, driver);
		}
		String periodAct = driver.findElement(HubContributorFormObj.PeriodValue).getText();
		Assert.assertEquals(periodAct, period);
		if (periodAct.equalsIgnoreCase(period)) {
			Logs.update("Verify that period is appropriate as to whichever period the schedule is distributed to",
					"Period is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("Verify that period is appropriate as to whichever period the schedule is distributed to",
					"Period is not displayed as expected", Status.FAIL, driver);
		}
		String scheduleGenInfo_HeaderAct = driver.findElement(Form_1590G_Obj.scheduleGeneralInfo_Header).getText();
		if (scheduleGenInfo_HeaderAct.equalsIgnoreCase("Schedule General Information")) {
			Logs.update("R1_1590G_TC02.1 verify the general info header",
					"Schedule General Information header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC02.1 verify the general info header",
					"Schedule General Information header is not displayed as expected", Status.FAIL, driver);
		}
		String salesOfNonUsa_HeaderAct = driver.findElement(Form_1590G_Obj.salesOfNotUsa_Header).getText();
		if (salesOfNonUsa_HeaderAct.equalsIgnoreCase("Sales of non-USA Manufactured products sold in USA")) {
			Logs.update("R1_1590G_TC02.2 verify the sales of Non USA header",
					"Sales of non-USA header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC02.2 verify the sales of Non USA header",
					"Sales of non-USA header is not displayed as expected", Status.FAIL, driver);
		}
		String napcsCode_HeaderAct = driver.findElement(Form_1590G_Obj.napcs_Header).getText();
		if (napcsCode_HeaderAct.equalsIgnoreCase("NAPCS Code & Product Description")) {
			Logs.update("R1_1590G_TC02.3 verify the NAPCS Code & Product header",
					"NAPCS Code & Product Description header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC02.3 verify the NAPCS Code & Product header",
					"NAPCS Code & Product Description header is not displayed as expected", Status.FAIL, driver);
		}
		String thirdParty_HeaderAct = driver.findElement(Form_1590G_Obj.thirdPartyCust_Header).getText();
		if (thirdParty_HeaderAct.equalsIgnoreCase("Third-party customer, Not Affiliated with Cargill")) {
			Logs.update("R1_1590G_TC02.4 verify the Third-party customer header",
					"Third-party customer header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC02.4 verify the Third-party customer header",
					"Third-party customer header is not displayed as expected", Status.FAIL, driver);
		}
		String cargillsBU_HeaderAct = driver.findElement(Form_1590G_Obj.cargillUsBus_Header).getText();
		if (cargillsBU_HeaderAct.equalsIgnoreCase("Cargill�s U.S. BU's & Sub's.")) {
			Logs.update("R1_1590G_TC02.5 verify the Cargill�s U.S. BU's & Sub's. header",
					"Cargill�s U.S. BU's & Sub's. header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC02.5 verify the Cargill�s U.S. BU's & Sub's. header",
					"Cargill�s U.S. BU's & Sub's. header is not displayed as expected", Status.FAIL, driver);
		}
		String reportingUnit_HeaderAct = driver.findElement(Form_1590G_Obj.reportingUnit_Header).getText();
		if (reportingUnit_HeaderAct.equalsIgnoreCase(
				"Reporting unit (RU) code & Name of U.S. Cargill entity that purchased product manufactured outside of the United States")) {
			Logs.update("R1_1590G_TC02.6 verify the reporting Unit header",
					"Reporting Unit header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC02.6 verify the reporting Unit header",
					"Reporting Unit header is not displayed as expected", Status.FAIL, driver);
		}
		driver.close();
		driver.switchTo().window(parentWindow);
		

	}

	// TC_31, TC_32
	public static void verifyAddAndCancelFunctionality(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		boolean statusOfNewRow = driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).isEnabled();
		Thread.sleep(2000);
		System.out.println(statusOfNewRow);
		if (statusOfNewRow) {
			Logs.update("R1_1590G_TC03 verify that new row is created after clicking on Add icon",
					"New row is created as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC03 verify that new row is created after clicking on Add icon",
					"New row is not created", Status.FAIL, driver);
		}
		driver.findElement(Form_1590G_Obj.btn_Cancel).click();
		Thread.sleep(4000);
		boolean statusOfNewRow_AfterCancel = driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1)
				.isDisplayed();
		System.out.println(statusOfNewRow_AfterCancel);
		Assert.assertFalse(statusOfNewRow_AfterCancel, "New row is removed");
		if (statusOfNewRow_AfterCancel == false) {
			
			Logs.update("R1_1590G_TC04 verify that new row is removed after clicking on cancel icon",
					"New row is removed as expected", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC03 verify that new row is removed after clicking on cancel icon",
					"New row is not removed", Status.FAIL, driver);
		}
		
		driver.close();
		driver.switchTo().window(parentWindow);
	
	}

	// Test id: TC_18
	public static void verifyMandatoryFieldMsg(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Logs.update("Error should be higlighted in red", "Error is highlighted in red", Status.PASS, driver);
		Thread.sleep(2000);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1_invalid)).build().perform();
		Thread.sleep(2000);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1)).build().perform();
		Thread.sleep(2000);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(2000);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1_invalid)).build().perform();
		Thread.sleep(2000);
		String actErrMsgField1 = driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_tooltip).getText();
		System.out.println(actErrMsgField1);
		Thread.sleep(2000);
		Assert.assertEquals(actErrMsgField1, "a value is required");
		if (actErrMsgField1.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC18_1 Verify that error message should be displayed for RU field",
					"Error message is displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC18_1 Verify that error message should be displayed for RU field",
					"Error message is Not displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.FAIL, driver);
		}
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(2000);
		String actErrMsgField2 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip).getText();
		System.out.println(actErrMsgField2);
		Thread.sleep(2000);
		Assert.assertEquals(actErrMsgField2, "a value is required");
		if (actErrMsgField2.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC18_2 Verify that error message should be displayed for Cargill BU field",
					"Error message is displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC18_2 Verify that error message should be displayed for Cargill BU field",
					"Error message is Not displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.FAIL, driver);
		}
		actions.moveToElement(driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1)).build().perform();
		Thread.sleep(2000);
		String actErrMsgField3 = driver.findElement(Form_1590G_Obj.thirdPartyCustomer_tooltip).getText();
		System.out.println(actErrMsgField3);
		Thread.sleep(2000);
		Assert.assertEquals(actErrMsgField3, "a value is required");
		if (actErrMsgField3.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC18_3 Verify that error message should be displayed for thirdParty field",
					"Error message is displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC18_3 Verify that error message should be displayed for thirdParty BU field",
					"Error message is Not displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.FAIL, driver);
		}
		actions.moveToElement(driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1_invalid)).build().perform();
		Thread.sleep(2000);
		String actErrMsgField4 = driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_tooltip).getText();
		System.out.println(actErrMsgField4);
		Thread.sleep(2000);
		Assert.assertEquals(actErrMsgField4, "a value is required");
		if (actErrMsgField4.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC18_4 Verify that error message should be displayed for NAPCS field",
					"Error message is displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC18_4 Verify that error message should be displayed for NAPCS BU field",
					"Error message is Not displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.FAIL, driver);
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}

	// Test ID: TC_12, TC_27
	public static void verifyThirdPartyRevenueField(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		WebElement ele1 = driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1);
		ele1.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName,
				"Revenue_MoreThan20Numbers", ele1, Logs, "1590G_TC12 US cargill field validation", 15);
		WebElement ele2 = driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1);
		ele2.clear();
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, TestCaseName,
				"Revenue_MoreThan20Numbers", ele2, Logs, "1590G_TC27 ThirdParty Customer field validation", 15);
		driver.close();
		driver.switchTo().window(parentWindow);
	}
	

	// Test id: TC19, TC20
	public static void verifyMutlipleRowAddOrRemove(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(3000);

		// Add multiple rows
		int count = 0;
		for (int i = 1; i <= 3; i++) {

			driver.findElement(Form_1590G_Obj.btn_Add).click();
			Thread.sleep(2000);
			// driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).click();
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys("2000025000");
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ARROW_DOWN);
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ENTER);
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys("123");
			count++;
		}
		(hubContributorFormObj.saveButton(driver)).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		String queryToGetNumOfRow = "select count(entityCode) as EC from  dbo.schedule1590G where EntityCode=" + "'"
				+ entityName + "'";
		String actCount = DataBaseConnection.getData(driver, Logs, TestType, queryToGetNumOfRow, "EC");
		int actCountInt = Integer.parseInt(actCount);
		if (count == actCountInt) {
			Logs.update("R1_1590G_TC19 verify multiple row could be added", "Multiple rows are added as expected",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC19 verify multiple row could be added", "Multiple rows are not added as expected",
					Status.FAIL, driver);
		}
		// Delete all the rows one by one
		for (int j = 1; j <= 3; j++) {
			driver.findElement(Form_1590G_Obj.row_1_AfterAdd).click();
			Thread.sleep(2000);
			driver.findElement(Form_1590G_Obj.btn_Delete).isDisplayed();
			driver.findElement(Form_1590G_Obj.btn_Delete).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
		}
		Logs.update("Verify all the rows are deleted", "Row are deleted as expected", Status.PASS, driver);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.switchTo().window(currentHandle);
		Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
		// Verify if the rows are deleted from DB
		String actCountAftDelete = DataBaseConnection.getData(driver, Logs, TestType, queryToGetNumOfRow, "EC");
		int actCountIntDel = Integer.parseInt(actCountAftDelete);
	    Assert.assertEquals(actCountIntDel, 0);
		if (actCountIntDel == 0) {
			Logs.update("R1_1590G_TC20 verify multiple row could be deleted",
					"Multiple rows are deleted as expected row count in DB is " + actCountAftDelete, Status.PASS,
					driver);
		} else {
			Logs.update("R1_1590G_TC20 verify multiple row could be deleted",
					"Multiple rows are not deleted as expected " + actCountAftDelete, Status.FAIL, driver);
		}
	}
	//Test id:TC21
	public static void verifyMutlipleRowNonCargillRevAdd(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(3000);

		String napcsCode="2000025000";
		String thirdPartyRevenueAct="123";
		for (int i = 1; i <= 3; i++) {
			Thread.sleep(1000);
			driver.findElement(Form_1590G_Obj.btn_Add).click();
			Thread.sleep(2000);
			// driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).click();
			
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsCode);
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ARROW_DOWN);
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ENTER);
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys(thirdPartyRevenueAct);
		}
		Logs.update("Verify multiple rows are added", "Rows are added as expected", Status.PASS, driver);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.switchTo().window(currentHandle);
		String queryToGetTrdPrRevenue = "select thirdPartyRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
				+ entityName + "'";
		Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
		String thirdPartyRevStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetTrdPrRevenue, "thirdPartyRevenueAmount");
		if (thirdPartyRevStr.equals(thirdPartyRevenueAct)) {
			Logs.update("R1_1590G_TC21 verify data is matching with data in DB",
					"Data is matching with the data in DB as expected " + "Data entered by user is: "
							+ thirdPartyRevenueAct + " " + "Data saved in DB is: " + thirdPartyRevStr,
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC21 verify data is matching with data in DB",
					"Data is not matching with the data in DB as expected " + "Data entered by user is: "
							+ thirdPartyRevenueAct + " " + "Data savedsss in DB is: " + thirdPartyRevStr,
					Status.FAIL, driver);
		}
	}

	//Test id:TC22
		public static void verifyMutlipleRowUSCargillRevAdd(WebDriver driver, String entityName, String period, String schedule,
				DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			String currentHandle = driver.getWindowHandle();
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(5000);
			
			String napcsCode="2000025000";
			String CargillUSRevenueAct="576";
			String RUCode_Number = "243";
			
			for (int i = 1; i <= 3; i++) {

				driver.findElement(Form_1590G_Obj.btn_Add).click();
				Thread.sleep(4000);
				// driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).click();
				
				driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsCode);
				driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ARROW_DOWN);
				driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ENTER);
				driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
				driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(Keys.ARROW_DOWN);
				driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(Keys.ENTER);
				driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(CargillUSRevenueAct);
			}
			Logs.update("Verify multiple rows are added", "Rows are added as expected", Status.PASS, driver);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			driver.switchTo().window(currentHandle);
			String queryToGetCRGLRevenue = "select cargillRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
					+ entityName + "'";
			Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
			String CargillRevStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetCRGLRevenue, "cargillRevenueAmount");
			Assert.assertEquals(CargillRevStr, CargillUSRevenueAct,"Data is matching with the data in DB as expected");
			if (CargillRevStr.equals(CargillUSRevenueAct)) {
				Logs.update("R1_1590G_TC22 verify data is matching with data in DB",
						"Data is matching with the data in DB as expected " + "Data entered by user is: "
								+ CargillUSRevenueAct + " " + "Data saved in DB is: " + CargillRevStr,
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC22 verify data is matching with data in DB",
						"Data is not matching with the data in DB as expected " + "Data entered by user is: "
								+ CargillUSRevenueAct + " " + "Data savedsss in DB is: " + CargillRevStr,
						Status.FAIL, driver);
			}
		}	
		
		//Test id:TC23
		public static void verifyCargillAndNonCargillRevAdd(WebDriver driver, String entityName, String period, String schedule,
				DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			Thread.sleep(2000);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			String currentHandle = driver.getWindowHandle();
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(3000);

			String napcsCode="2000025000";
			String thirdPartyRevenueAct="123";
			String CargillUSRevenueAct="576";
			String RUCode_Number = "243";
			for (int i = 1; i <= 3; i++) {
				Thread.sleep(1000);
				driver.findElement(Form_1590G_Obj.btn_Add).click();
				Thread.sleep(3000);
				// driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).click();
				
				driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsCode);
				driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ARROW_DOWN);
				Thread.sleep(2000);
				driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ENTER);
				driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys(thirdPartyRevenueAct);
				driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
				driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(Keys.ARROW_DOWN);
				Thread.sleep(2000);
				driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(Keys.ENTER);
				driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(CargillUSRevenueAct);
			}
			Logs.update("Verify multiple rows are added", "Rows are added as expected", Status.PASS, driver);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			driver.switchTo().window(currentHandle);
			String queryToGetTrdPr_Revenue = "select thirdPartyRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
					+ entityName + "'";
			String queryToGetCRGL_Revenue = "select cargillRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
					+ entityName + "'";
			Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
			
			String thirdPartyRevStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetTrdPr_Revenue, "thirdPartyRevenueAmount");
			String cargillRevStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetCRGL_Revenue, "CargillRevenueAmount");
			
			if (thirdPartyRevStr.equals(thirdPartyRevenueAct) && cargillRevStr.equals(CargillUSRevenueAct)) {
				Logs.update("R1_1590G_TC23 verify data is matching with data in DB",
						"Data is matching with the data in DB as expected " + "Data entered by user for thirdparty Revenue and Cargill revenues are: "
								+ thirdPartyRevenueAct + " and "+ CargillUSRevenueAct +" "+ "Data saved in DB: " + thirdPartyRevStr+" and "+cargillRevStr,
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC23 verify data is matching with data in DB",
						"Data is not matching with the data in DB" + "Data entered by user for thirdparty Revenue and Cargill revenues are: "
								+ thirdPartyRevenueAct + " and "+ CargillUSRevenueAct +" "+ "Data saved in DB: " + thirdPartyRevStr+" and "+cargillRevStr,
						Status.FAIL, driver);
			}
		}
	
	// Test id:TC03,TC33,TC34,TC35
	public static void verifyNAPCSFieldDataSearch(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);

		String napcsInput_speclChar = "#$%^^&";// Type in a few special
												// characters
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_speclChar);
		List<WebElement> list3 = driver.findElements(Form_1590G_Obj.napcsCodeList);
		for (i = 0; i < list3.size(); i++) {
			boolean compareTheActAndExpSpcChar = list3.get(i).getText().contains(napcsInput_speclChar);
			Assert.assertFalse(compareTheActAndExpSpcChar,
					"Dropdown autosuggest list showing result even when special chars are entered");
					
			if (compareTheActAndExpSpcChar == false) {

				Logs.update("R1_1590G_TC34 Verify that no result is displayed for special chars",
						"No search result is getting displayed when special chars are entered as expected", Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC34 Verify that no result is displayed for special chars",
						"Search result is getting displayed even when special chars are entered", Status.FAIL, driver);
			}
		}

		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).clear();
		String napcsInput_Number = "20097";
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));

		List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
		for (i = 0; i < list.size(); i++) {
			boolean compareTheActAndExpNum = list.get(i).getText().contains(napcsInput_Number);
			Assert.assertTrue(compareTheActAndExpNum, "Dropdown autosuggest list not matching the user input");
			if (compareTheActAndExpNum) {
				Logs.update("R1_1590G_TC03 verify the dropdown list of autosuggest with " + napcsInput_Number,
						"The dropdown list of suggestions that matches the user's search query is displayed as expected: "
								+ list.get(i).getText(),
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC03 verify the dropdown list of autosuggest",
						"The dropdown list of suggestions that matches the user's search query is not displayed",
						Status.FAIL, driver);
			}
		}
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).clear();
		String napcsInput_Desc = "Manufacturing of dry";// Type in a few
														// characters of a valid
														// product description
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Desc);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));

		List<WebElement> list2 = driver.findElements(Form_1590G_Obj.napcsCodeList);
		for (i = 0; i < list2.size(); i++) {
			boolean compareTheActAndExpDesc = list2.get(i).getText().contains(napcsInput_Desc);
			Assert.assertTrue(compareTheActAndExpDesc, "Dropdown autosuggest list not matching the user input");
			if (compareTheActAndExpDesc) {
				Logs.update("R1_1590G_TC33 verify the dropdown list of autosuggest with " + napcsInput_Desc,
						"The dropdown list of suggestions that matches the user's search query is displayed as expected: "
								+ list2.get(i).getText(),
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC33 verify the dropdown list of autosuggest",
						"The dropdown list of suggestions that matches the user's search query is not displayed",
						Status.FAIL, driver);
			}
		}

		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).clear();
		String napcsInput_invalidNapcs = "33333333333333333";// Type in invalid
		// NAPCS
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_invalidNapcs);
		List<WebElement> list4 = driver.findElements(Form_1590G_Obj.napcsCodeList);
		list4.size();
		for (i = 0; i < list4.size(); i++) {
			Thread.sleep(2000);
			boolean compareTheActAndExpSpcinvNo = list4.get(i).getText().contains(napcsInput_invalidNapcs);
			Assert.assertFalse(compareTheActAndExpSpcinvNo,
					"Dropdown autosuggest list showing result even when invalid NAPCS are entered");
			if (compareTheActAndExpSpcinvNo == false) {

				Logs.update("R1_1590G_TC35 Verify that no result is displayed for invalid NAPCS",
						"No search result is getting displayed when invalid NAPCS are entered as expected", Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC35 Verify that no result is displayed for invalid NAPCS",
						"Search result is getting displayed even when invalid NAPCS are entered", Status.FAIL, driver);
			}
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}
	
	
	//Test id:TC24:
	
	public static void verifySaveWithOutMandate(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		hubContributorFormObj.saveButton(driver).click();
		
		String actHeader = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
		Assert.assertEquals(actHeader, "Your changes have been saved successfully!!");
		
		if(actHeader.equalsIgnoreCase("Your changes have been saved successfully!!")){
			Logs.update("R1_1590G_TC24 verify that able to save without mandate", "Able to save without entering mandatory field", Status.PASS, driver);
		}else{
			Logs.update("R1_1590G_TC24 verify that able to save without mandate", "Able to save without entering mandatory field", Status.FAIL, driver);
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}
	//Test id:TC25
	public static void verifyAbleToDeleteAllRows(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String currentHandle = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);

		String napcsCode="2000025000";
		String thirdPartyRevenueAct="123";
		String CargillUSRevenueAct="576";
		String RUCode_Number = "243";
		for (int i = 1; i <= 3; i++) {

			driver.findElement(Form_1590G_Obj.btn_Add).click();
			Thread.sleep(4000);
			// driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).click();
			
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsCode);
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(2000);
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(Keys.ENTER);
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys(thirdPartyRevenueAct);
			driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
			driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(2000);
			driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(Keys.ENTER);
			driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(CargillUSRevenueAct);
		}
		
		boolean rowPresent=driver.findElement(Form_1590G_Obj.row_1_AfterAdd).isDisplayed();
		if(rowPresent==true){
		Logs.update("Verify multiple rows are added", "Rows are added as expected", Status.PASS, driver);	
		}
		for (int j = 1; j <= 3; j++) {
			driver.findElement(Form_1590G_Obj.row_1_AfterAdd).click();
			Thread.sleep(2000);
			driver.findElement(Form_1590G_Obj.btn_Delete).isDisplayed();
			driver.findElement(Form_1590G_Obj.btn_Delete).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
		}
		Logs.update("Verify all the rows are deleted", "Row are deleted as expected", Status.PASS, driver);
		driver.close();//Close the child window
		Thread.sleep(2000);
		driver.switchTo().window(currentHandle);//Switch to parent window and opne the schedule again.
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		
		Thread.sleep(4000);
		Logs.update("Verify that window is closed and navigate to parent window", "Window is closed as expected", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();//Open the schedule.
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(3000);
		String rowsafterDelete=driver.findElement(Form_1590G_Obj.row_AfterDelete).getAttribute("class");
		if(rowsafterDelete.contains("empty-grid")){
			Logs.update("HUB2.0_R1_1590G_TC25 verify that the data added previously is not displayed", "Data added previously is not displayed after closeing and reopening the page as expected", Status.PASS, driver);
		}
		else{
			Logs.update("HUB2.0_R1_1590G_TC25 verify that the data added previously is not displayed", "Data added previously is displayed after closeing and reopening the page", Status.FAIL, driver);
		}
		driver.close();//Close the child window
		Thread.sleep(2000);
		driver.switchTo().window(currentHandle);
		}

	// Test id:TC04
	public static void verifyNAPCSDescription(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);

		String napcsInput_valid = "2002000006";// Type in valid NAPCS code.
		String queryToGetNAPCSDesc = "select NAPCSDescription from MasterData.NACS where NAPCSCode=" + "'"
				+ napcsInput_valid + "'";
		String NAPCSDescFromDB = DataBaseConnection.getData(driver, Logs, TestType, queryToGetNAPCSDesc,
				"NAPCSDescription");
		Logs.update("NAPCSCode " + napcsInput_valid, "Description from DB: " + NAPCSDescFromDB, Status.DONE, driver);
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_valid);
		List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
		for (i = 0; i < list.size(); i++) {
			boolean compareTheActAndExpDesc = list.get(i).getText().contains(NAPCSDescFromDB);
			Assert.assertTrue(compareTheActAndExpDesc,
					"Dropdown autosuggest list showing result even when special chars are entered");
			if (compareTheActAndExpDesc == true) {

				Logs.update("R1_1590G_TC04 Verify that NAPCS corresponding product description",
						"NAPCS corresponding description is displayed as expected" + "NAPCS: " + napcsInput_valid + " "
								+ "Descripton: " + NAPCSDescFromDB,
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC04 Verify thatt NAPCS corresponding product description is displayed",
						"NAPCS corresponding description is not displayed as expected" + "NAPCS: " + napcsInput_valid
								+ " " + "Descripton: " + NAPCSDescFromDB,
						Status.FAIL, driver);
			}
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}

	// Test id: TC05
	public static void verify_RUFieldDescription(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(3000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		String queryToGetRUName = " Select  Distinct Top 1 [EntityCode] as RU_NAME "
				+ "FROM [MasterData].[Entity] Where [EntityType] = 'R' "
				+ "and [EntityStatus] = 'A' and BUStructure like '%GOUS%'";
		String RUCode_FromDB = DataBaseConnection.getData(driver, Logs, TestType, queryToGetRUName, "RU_NAME");
		String QueryToGetLongDesc = "Select  Distinct Top 1 "
				+ "[EntityLongDesc] as RU_LONGDESC FROM [MasterData].[Entity] "
				+ "Where [EntityType] = 'R' and [EntityStatus] = 'A' and BUStructure like '%GOUS%' " + "and EntityCode="
				+ "'" + RUCode_FromDB + "'";
		String RULongDesc = DataBaseConnection.getData(driver, Logs, TestType, QueryToGetLongDesc, "RU_LONGDESC");
		Logs.update("Verify the RU name for corresponding RU code from DB",
				"For RU Code_ " + RUCode_FromDB + " RU name is " + RULongDesc, Status.DONE, driver);
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_FromDB);
		List<WebElement> list = driver.findElements(Form_1590G_Obj.ruCodeList);
		for (i = 0; i < list.size(); i++) {
			boolean compareTheActAndExpDesc = list.get(i).getText().contains(RULongDesc);
			Assert.assertTrue(compareTheActAndExpDesc, "Dropdown autosuggest list showing wrong RU name");
			if (compareTheActAndExpDesc == true) {
				Logs.update("R1_1590G_TC05 Verify that corresponding RU name is getting displayed",
						"Correct RU name is getting displayed upon entering valid RU code as expected", Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC05 Verify that corresponding RU name is getting displayed",
						"Correct RU name is not getting displayed upon entering valid RU code", Status.FAIL, driver);
			}
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}

	// Test id:TC06,TC08,TC09,TC36,TC37
	public static void verify_RU_FieldDataSearch(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType, String TestCaseName) throws Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		String RUCode_Number = "243";
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.ruCodeList));

		List<WebElement> list = driver.findElements(Form_1590G_Obj.ruCodeList);
		for (i = 0; i < list.size(); i++) {
			boolean compareTheActAndExpNum = list.get(i).getText().contains(RUCode_Number);
			Assert.assertTrue(compareTheActAndExpNum, "Dropdown autosuggest list not matching the user input");
			if (compareTheActAndExpNum) {
				Logs.update("R1_1590G_TC08 verify the dropdown list of autosuggest with " + RUCode_Number,
						"The dropdown list of suggestions that matches the user's search query is displayed as expected: "
								+ list.get(i).getText(),
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC08 verify the dropdown list of autosuggest",
						"The dropdown list of suggestions that matches the user's search query is not displayed",
						Status.FAIL, driver);
			}
		}
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).clear();
		String RUName_Desc = "Meat Solutions";
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUName_Desc);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.ruCodeList));

		List<WebElement> list1 = driver.findElements(Form_1590G_Obj.ruCodeList);
		for (i = 0; i < list1.size(); i++) {
			boolean compareTheActAndExpDesc = list1.get(i).getText().contains(RUName_Desc);
			Assert.assertTrue(compareTheActAndExpDesc, "Dropdown autosuggest list not matching the user input");
			if (compareTheActAndExpDesc) {
				Logs.update("R1_1590G_TC06 verify the dropdown list of autosuggest with " + RUName_Desc,
						"The dropdown list of suggestions that matches the user's search query is displayed as expected: "
								+ list1.get(i).getText(),
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC06 verify the dropdown list of autosuggest",
						"The dropdown list of suggestions that matches the user's search query is not displayed",
						Status.FAIL, driver);
			}
		}
	
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).clear();
		String RUCode_invaliRu = "4444444444444444444444";// Type in invalid
		// RU code
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_invaliRu);
		List<WebElement> list2 = driver.findElements(Form_1590G_Obj.ruCodeList);
		for (i = 0; i < 1; i++) {
			Thread.sleep(2000);
			boolean compareTheActAndExpSpcinvNo = list2.get(i).getText().contains(RUCode_invaliRu);
			Assert.assertFalse(compareTheActAndExpSpcinvNo,
					"Dropdown autosuggest list showing result even when invalid RU codes are entered");
			if (compareTheActAndExpSpcinvNo == false) {

				Logs.update("R1_1590G_TC37 Verify that no result is displayed for invalid RU code",
						"No search result is getting displayed when invalid RU code is entered as expected", Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC37 Verify that no result is displayed for invalid RU code",
						"Search result is getting displayed even when invalid RU code is entered", Status.FAIL, driver);
			}

		}
		
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).clear();
		String RUCode_specialChar = "^^^%$$%%%%";// Type in invalid
		// RU code
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_specialChar);
		List<WebElement> list3 = driver.findElements(Form_1590G_Obj.ruCodeList);
		for (i = 0; i < 1; i++) {
			Thread.sleep(2000);
			boolean compareTheActAndExpSpChar = list3.get(i).getText().contains(RUCode_specialChar);
			Assert.assertFalse(compareTheActAndExpSpChar,
					"Dropdown autosuggest list showing result even when special chars are entered");
			if (compareTheActAndExpSpChar == false) {

				Logs.update("R1_1590G_TC36 Verify that no result is displayed for special char",
						"No search result is getting displayed when special char is entered as expected", Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC36 Verify that no result is displayed for invalid RU code",
						"Search result is getting displayed even when special character is entered", Status.FAIL, driver);
			}

		}	
		
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).clear();
		String queryToGetNonUSRU="Select top 1 EntityCode FROM [MasterData].[Entity] where [EntityType] = 'R' "
				+ "and [EntityStatus] = 'A' "
				+ "And Country NOT in('US')";
		String RUCode_NonUSRU =DataBaseConnection.getData(driver, Logs, TestType, queryToGetNonUSRU, "EntityCode");
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_NonUSRU);
		List<WebElement> list4 = driver.findElements(Form_1590G_Obj.ruCodeList);
		for (i = 0; i < 1; i++) {
			Thread.sleep(2000);
			boolean compareTheActAndExpSpChar = list4.get(i).getText().contains(RUCode_NonUSRU);
			Assert.assertFalse(compareTheActAndExpSpChar,
					"Dropdown autosuggest list showing result even when non US RU codes are entered");
			if (compareTheActAndExpSpChar == false) {

				Logs.update("R1_1590G_TC09 Verify that no result is displayed for non US RUs",
						"No search result is getting displayed when non US RU's are entered as expected", Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC09 Verify that no result is displayed for non US RUs",
						"Search result is getting displayed even non US RU is entered", Status.FAIL, driver);
			}

		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}
		
	//Test id:TC10,TC11,TC13,TC16
	public static void verifyMandatFieldMsg_CrglUSBU(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		String napcsInput_Number = "20097";
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));
		List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
		list.get(0).click();//Click on first option
		Thread.sleep(3000);
		String RUCode_Number = "224";
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
		
		List<WebElement> list2 = driver.findElements(Form_1590G_Obj.ruCodeList);
		
		list2.get(0).click();//click on the first element listed in autosuggest

		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Logs.update("Error should be higlighted in red", "Error is highlighted in red", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(2000);
		String actErrMsgField1 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
		System.out.println(actErrMsgField1);
		Thread.sleep(2000);
		
		Assert.assertEquals(actErrMsgField1, "a value is required","Error message is displayed as expected when user is trying to submit the form without entering mandatory fields");
		
		if (actErrMsgField1.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC10 Verify that error message should be displayed for Cargill US BU field",
					"Error message is displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC10 Verify that error message should be displayed for Cargill US BU field",
					"Error message is Not displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.FAIL, driver);
		}
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("alphabetsABC");
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(Keys.TAB);
		Logs.update("Error should be higlighted in red", "Error is highlighted in red when alphabets are entered", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(2000);
		String actErrMsgFieldAlp = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
		System.out.println(actErrMsgFieldAlp);
		Thread.sleep(2000);
		Assert.assertEquals(actErrMsgFieldAlp, "The value is invalid or in an incorrect format","Error message is displayed as expected when user is trying enter Alphabets in US revenue field");
		
		if (actErrMsgFieldAlp.equalsIgnoreCase("The value is invalid or in an incorrect format")) {
			Logs.update("R1_1590G_TC11.1 Verify that error message should be displayed for Cargill US BU field",
					"Error message is displayed as expected when user is trying enter Alphabets in US revenue field",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC11.1 Verify that error message should be displayed for Cargill US BU field",
					"Error message is NOT displayed as expected when user is trying enter Alphabets in US revenue field",
					Status.FAIL, driver);
		}
		
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).clear();//clear the field
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("-45");
		//driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(Keys.TAB);
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).click();
		Logs.update("Error should be higlighted in red", "Error is highlighted in red when negative value is entered", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(2000);
		String actErrMsgFieldNeg2 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
		Thread.sleep(2000);
		if (actErrMsgFieldNeg2.equalsIgnoreCase("Invalid Whole Number provided.")) {
			Logs.update("R1_1590G_TC11.2 Verify that error message should be displayed for Cargill US BU field",
					"Error message is displayed as expected when user is trying enter negative number in US revenue field",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC11.2 Verify that error message should be displayed for Cargill US BU field",
					"Error message is NOT displayed as expected when user is trying enter negative number in US revenue field",
					Status.FAIL, driver);
		}
		
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).clear();//clear the field
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("(45)");
		//driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(Keys.TAB);
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).click();
		Thread.sleep(5000);
		Logs.update("Error should be higlighted in red", "Error is highlighted in red when negative value is entered", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(5000);
		String actErrMsgFieldNeg1 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
		Thread.sleep(2000);
		if (actErrMsgFieldNeg1.equalsIgnoreCase("The value is invalid or in an incorrect format")) {
			Logs.update("R1_1590G_TC11.3 Verify that error message should be displayed for Cargill US BU field",
					"Error message is displayed as expected when user is trying enter negative number in US revenue field",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC11.3 Verify that error message should be displayed for Cargill US BU field",
					"Error message is NOT displayed as expected when user is trying enter negative number in US revenue field",
					Status.FAIL, driver);
		}
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).clear();//clear the field
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("45.66");
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).click();
		Thread.sleep(3000);
		Logs.update("Error should be higlighted in red", "Error is highlighted in red when decimal value is entered", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).click();
		Thread.sleep(3000);
		String actErrMsgFieldDec = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
		Thread.sleep(2000);
		if (actErrMsgFieldDec.equalsIgnoreCase("Invalid Whole Number provided.")) {
			Logs.update("R1_1590G_TC13 Verify that error message should be displayed for Cargill US BU field",
					"Error message is displayed as expected when user is trying enter decimal number in US revenue field",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC13 Verify that error message should be displayed for Cargill US BU field",
					"Error message is NOT displayed as expected when user is trying enter decimal number in US revenue field",
					Status.FAIL, driver);
		}
		
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).clear();//clear the field
		//TC_16:Enter valid number to non cargill RU revenue field instead of cargill RU revenue field.
		driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys("45");
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Logs.update("Error should be higlighted in red", "Error is highlighted in red", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1)).build().perform();
		Thread.sleep(2000);
		String actErrMsgField2 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
		System.out.println(actErrMsgField2);
		Thread.sleep(2000);
		if (actErrMsgField2.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC16 Verify that error message should be displayed for Cargill US BU field",
					"Error message is displayed as expected when user is trying to submit the form by entering the value in non Cargill revenue field instead of cargill revenue field",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC16 Verify that error message should be displayed for Cargill US BU field",
					"Error message is NOT displayed as expected when user is trying to submit the form by entering the value in non Cargill revenue field instead of cargill revenue field",
					Status.FAIL, driver);
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}
	//Test id: TC14
	public static void verifyCrglUSBU_Zero(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		
		String napcsInput_Number = "20097";
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));
		List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
		list.get(0).click();//Click on first option
		Thread.sleep(3000);
		String RUCode_Number = "224";
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
		
		List<WebElement> list2 = driver.findElements(Form_1590G_Obj.ruCodeList);
		
		list2.get(0).click();//click on the first element listed in autosuggest
		//Enter 0 in the cargill US revenue field
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("0");
		Logs.update("Verify '0' is entered in Cargill US BU field", "0 is entered in cargill US BU field", Status.PASS, driver);

		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.switchTo().window(currentHandle);
		Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
		String queryToGetCrglRev = "select CargillRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
				+ entityName + "'";
		String actRevenueStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetCrglRev, "CargillRevenueAmount");
		int actRevenue = Integer.parseInt(actRevenueStr);
		Assert.assertEquals(actRevenue, 0);
		
		if (actRevenue == 0) {
			Logs.update("R1_1590G_TC14 verify that data should match with DB",
					"Data is matching with what user has entered and with DB " + actRevenue, Status.PASS,
					driver);
		} else {
			Logs.update("R1_1590G_TC14 verify that data should match with DB",
					"Data is Not matching with what user has entered and with DB " + actRevenue, Status.FAIL, driver);
		}
	
}
	//Test ID: TC15
	public static void verifySameProductIsSoldInBoth(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		
		String napcsInput_Number = "20097";
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));
		List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
		list.get(0).click();//Click on first option
		Thread.sleep(3000);
		String RUCode_Number = "224";
		driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1).sendKeys(RUCode_Number);
		
		List<WebElement> list2 = driver.findElements(Form_1590G_Obj.ruCodeList);
		
		list2.get(0).click();//click on the first element listed in autosuggest
		//Enter 0 in the cargill US revenue field
		driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys("45");
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("55");
		Logs.update("Verify valid numbers are entered in both thirdparty revenue and Cargill revenue field", "Able to enter valid numbers in both the field as expected", Status.PASS, driver);
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(1000);
		if(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).isDisplayed()){
			Logs.update("Verify that the submit is sucessfull", "Submit is successfull", Status.PASS, driver);	
		}else
		{
			Logs.update("Verify that the submit is sucessfull", "Submit is not successfull", Status.FAIL, driver);	
		}
		
		
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.switchTo().window(currentHandle);
		Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
		String queryToGetThirdPartyRevAmt = "select ThirdPartyRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
				+ entityName + "'";
		String queryToGetCargillRevAmt = "select CargillRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
				+ entityName + "'";
		String act_TrdRevenueStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetThirdPartyRevAmt,
				"ThirdPartyRevenueAmount");
		String act_CrglRevenueStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetCargillRevAmt,
				"CargillRevenueAmount");
		int actTrdRevenue = Integer.parseInt(act_TrdRevenueStr);
		int actCrglRevenue= Integer.parseInt(act_CrglRevenueStr);
		if (actTrdRevenue >0 && actCrglRevenue>0 ) {
			Logs.update("R1_1590G_TC15 verify that it is possible to sell same product for thirdparty and Cargill",
					"It is possible to sell  the same  product to  'Third-party customer, Not Affiliated with Cargill'  and 'Cargill�s U.S. BU's & Sub's", Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC15 verify that it is possible to sell same product for thirdparty and Cargill",
					"It is possible to sell  the same  product to  'Third-party customer, Not Affiliated with Cargill'  and 'Cargill�s U.S. BU's & Sub's", Status.FAIL, driver);
		}

	}

	//Test id: TC17
	public static void verifyMandatFieldMsg_RUCode(WebDriver driver, String entityName, String period,
			String schedule, String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(5000);
		driver.findElement(Form_1590G_Obj.btn_Add).click();
		Thread.sleep(3000);
		String napcsInput_Number = "20097";
		driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));
		List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
		list.get(0).click();//Click on first option
		Thread.sleep(3000);
		driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys("45");
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Logs.update("Error should be higlighted in red", "Field is highlighted in red", Status.PASS, driver);
		actions.moveToElement(driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_FieldRow1_invald_Single)).build()
				.perform();
		Thread.sleep(2000);
		String actErrMsgField1 = driver.findElement(Form_1590G_Obj.ReportingUnitCodeName_tooltip).getText();
		System.out.println(actErrMsgField1);
		Thread.sleep(2000);
		Assert.assertEquals(actErrMsgField1, "a value is required");
		if (actErrMsgField1.equalsIgnoreCase("a value is required")) {
			Logs.update("R1_1590G_TC17 Verify that error message should be displayed for RU code field",
					"Error message is displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.PASS, driver);
		} else {
			Logs.update("R1_1590G_TC17 Verify that error message should be displayed for RU code field",
					"Error message is Not displayed as expected when user is trying to submit the form without entering mandatory fields",
					Status.FAIL, driver);
		}
		driver.close();
		driver.switchTo().window(parentWindow);
	}
	
	//Test id: TC28,TC29
		public static void verifyThirdParty_Zero(WebDriver driver, String entityName, String period,
				String schedule, String scheduleLongDesc, DriverScript Logs, String TestType) throws ClassNotFoundException, SQLException, Exception {
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(2000);
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			String currentHandle = driver.getWindowHandle();
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(5000);
			driver.findElement(Form_1590G_Obj.btn_Add).click();
			Thread.sleep(3000);
			String napcsInput_Number = "20097";
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
			wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(Form_1590G_Obj.napcsCodeList));
			List<WebElement> list = driver.findElements(Form_1590G_Obj.napcsCodeList);
			list.get(0).click();//Click on first option
			Thread.sleep(3000);
			
			//Enter decimal value in the thirdparty field
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys("45.66");
			driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).click();
			Thread.sleep(3000);
			Logs.update("Error should be higlighted in red", "Error is highlighted in red when decimal value is entered", Status.PASS, driver);
			actions.moveToElement(driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1)).build().perform();
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).click();
			Thread.sleep(3000);
			String actErrMsgFieldDec = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
			Thread.sleep(2000);
			
			Assert.assertEquals(actErrMsgFieldDec, "Invalid Whole Number provided.");
			if (actErrMsgFieldDec.equalsIgnoreCase("Invalid Whole Number provided.")) {
				Logs.update("R1_1590G_TC28 Verify that error message should be displayed for thirdparty revenue field",
						"Error message is displayed as expected when user is trying enter decimal number in thirdparty revenue field",
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC28 Verify that error message should be displayed for thirdparty revenue field",
						"Error message is NOT displayed as expected when user is trying enter decimal number in thirdparty revenue field",
						Status.FAIL, driver);
			}
			
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).clear();//clear the field to enter 0 next
			Thread.sleep(2000);
			driver.findElement(Form_1590G_Obj.thirdPartyCustomer_FieldRow1).sendKeys("0");
			Logs.update("Verify 0 is entered in Non Cargill(Thirdparty) revenue field", "0 is entered in non cargill revenue field", Status.PASS, driver);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(1000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			driver.switchTo().window(currentHandle);
			Logs.update("Form should be submitted sucessfully", "Form is submitted sucessfully", Status.PASS, driver);
			String queryToGetNonCrgRev = "select ThirdPartyRevenueAmount from  dbo.schedule1590G where EntityCode=" + "'"
					+ entityName + "'";
			String actRevenueStr = DataBaseConnection.getData(driver, Logs, TestType, queryToGetNonCrgRev, "ThirdPartyRevenueAmount");
			int actRevenue = Integer.parseInt(actRevenueStr);
Assert.assertEquals(actRevenue, 0,"Data is matching with the same what user has entered and with DB");
			if (actRevenue == 0) {
				Logs.update("R1_1590G_TC29 verify that data should match with DB",
						"Data is matching with the same what user has entered and with DB " + actRevenue, Status.PASS,
						driver);
			} else {
				Logs.update("R1_1590G_TC29 verify that data should match with DB",
						"Data is Not matching with the user entered data with DB " + actRevenue, Status.FAIL, driver);
			}
		
	}
		
		// TC- 30
		
		public static void verify_schedule_is_not_distributed_to_US_RUs(WebDriver driver, String entityName, String period,
				String schedule, DriverScript Logs, String TestType)
						throws ClassNotFoundException, SQLException, Exception {
			//driver = Login.LaunchHub("Setupurl", Logs);
			Thread.sleep(5000);
			String parentWindow=driver.getWindowHandle();
			driver.findElement(HubHomePageObj.adminLink).click();
			Thread.sleep(2500);
			HubContributor.switchWindow(driver);// to switch to newly open window
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubAdminScreen.adminDashboardButton, 10);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//a[text()='Schedule Distribution']")).click();
			WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
			driver.switchTo().frame(Frame);
			Thread.sleep(5000);
			driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
			driver.findElement(HubAdminScreen.scheduleDistFrequency_Yearly_Fiscal).click();
			Thread.sleep(3000);

			driver.findElement(HubAdminScreen.periodField).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//span[text()='" + period + "']")).click();
			driver.findElement(HubAdminScreen.scheduleField).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//li[@title='" + schedule + "']")).click();
			Thread.sleep(5000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Thread.sleep(10000);
			List<WebElement> we = driver.findElements(By.xpath("//div[@class='hoverdiv option']"));
			for (i = 0; i < we.size(); i++) {
				if (we.get(i).getText().contains("US")) {
					break;
				} else
					continue;

			} // end of for
			System.out.println(i);
			System.out.println(we.size());

			if (i == we.size()) {

				Logs.update("TC-30-Verify distribution list does not contain US",
						"Distribution List of "+we.size()+" Bugo ids does not contain US as expected ", Status.PASS, driver);

			}

			else {
				Logs.update("TC-30-Verify distribution list does not contain US", "Distribution List contains US ", Status.FAIL,
						driver);

			}
			driver.close();
			driver.switchTo().window(parentWindow);

		}
		
		// TC- 26
		
		public static void verifyMandatFieldMsgThirdParty(WebDriver driver, String entityName, String period,
				String schedule, String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			String parentWindow=driver.getWindowHandle();
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			base.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(5000);
			driver.findElement(Form_1590G_Obj.btn_Add).click();
			Thread.sleep(3000);
			String napcsInput_Number = "20097";
			driver.findElement(Form_1590G_Obj.napcsCodeProductDesc_FieldRow1).sendKeys(napcsInput_Number);
	//
			
			driver.findElement(Form_1590G_Obj.cargill_thirdparty).sendKeys("alphabetsABC");
			driver.findElement(Form_1590G_Obj.cargill_thirdparty).sendKeys(Keys.TAB);
			Logs.update("Error should be higlighted in red", "Error is highlighted in red when alphabets are entered", Status.PASS, driver);
			actions.moveToElement(driver.findElement(Form_1590G_Obj.cargill_thirdparty)).build().perform();
			Thread.sleep(2000);
			String actErrMsgFieldAlp = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
			System.out.println(actErrMsgFieldAlp);
			Thread.sleep(2000);
			Assert.assertEquals(actErrMsgFieldAlp, "The value is invalid or in an incorrect format","Error message is displayed as expected when user is trying enter Alphabets in US revenue field");
			
			if (actErrMsgFieldAlp.equalsIgnoreCase("The value is invalid or in an incorrect format")) {
				Logs.update("R1_1590G_TC26 Verify that error message should be displayed for Cargill US BU field",
						"Error message is displayed as expected when user is trying enter Alphabets in US revenue field",
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC26 Verify that error message should be displayed for Cargill US BU field",
						"Error message is NOT displayed as expected when user is trying enter Alphabets in US revenue field",
						Status.FAIL, driver);
			}
			
			driver.findElement(Form_1590G_Obj.cargill_thirdparty).clear();//clear the field
			driver.findElement(Form_1590G_Obj.cargill_thirdparty).sendKeys("-45");
			Thread.sleep(5000);
			//driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(Keys.TAB);
			driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).click();
			Logs.update("Error should be higlighted in red", "Error is highlighted in red when negative value is entered", Status.PASS, driver);
			actions.moveToElement(driver.findElement(Form_1590G_Obj.cargill_thirdparty)).build().perform();
			Thread.sleep(2000);
			String actErrMsgFieldNeg2 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
			Thread.sleep(2000);
			Assert.assertEquals(actErrMsgFieldNeg2, "Invalid Whole Number provided.","Error message is displayed as expected when user is trying enter negative number in US revenue field");
						if (actErrMsgFieldNeg2.equalsIgnoreCase("Invalid Whole Number provided.")) {
				Logs.update("R1_1590G_TC26 Verify that error message should be displayed for Cargill US BU field",
						"Error message is displayed as expected when user is trying enter negative number in US revenue field",
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC26 Verify that error message should be displayed for Cargill US BU field",
						"Error message is NOT displayed as expected when user is trying enter negative number in US revenue field",
						Status.FAIL, driver);
			}
			
			driver.findElement(Form_1590G_Obj.cargill_thirdparty).clear();//clear the field
			driver.findElement(Form_1590G_Obj.cargill_thirdparty).sendKeys("(45)");
			Thread.sleep(5000);
			//driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).sendKeys(Keys.TAB);
			driver.findElement(Form_1590G_Obj.cargillUSBu_FieldRow1).click();
			Thread.sleep(5000);
			Logs.update("Error should be higlighted in red", "Error is highlighted in red when negative value is entered", Status.PASS, driver);
			actions.moveToElement(driver.findElement(Form_1590G_Obj.cargill_thirdparty)).build().perform();
			Thread.sleep(5000);
			String actErrMsgFieldNeg1 = driver.findElement(Form_1590G_Obj.cargillUSBu_tooltip_single).getText();
			Thread.sleep(2000);
			if (actErrMsgFieldNeg1.equalsIgnoreCase("The value is invalid or in an incorrect format")) {
				Logs.update("R1_1590G_TC26 Verify that error message should be displayed for Cargill US BU field",
						"Error message is displayed as expected when user is trying enter negative number in US revenue field",
						Status.PASS, driver);
			} else {
				Logs.update("R1_1590G_TC26 Verify that error message should be displayed for Cargill US BU field",
						"Error message is NOT displayed as expected when user is trying enter negative number in US revenue field",
						Status.FAIL, driver);
			}	
			driver.close();
			driver.switchTo().window(parentWindow);				
}
		
		
}
