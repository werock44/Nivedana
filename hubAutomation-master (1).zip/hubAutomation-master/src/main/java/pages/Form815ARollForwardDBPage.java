package pages;

import org.openqa.grid.web.Hub;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.HubContributor;
import utils.Login;
import utils.ReadXML;
import utils.Util;

public class Form815ARollForwardDBPage {
	public static String schedule;
	public static String entityName;
	public static String period;
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();

	public static void fillForm815A(WebDriver driver) throws InterruptedException {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.lbl_IdNo, 10);

		// hubContributorFormObj.currentTaxRate(driver).sendKeys(ReadXML.readData("TC_815A",
		// "currTaxRate"));
		driver.findElement(HubContributorFormObj.currentTaxRate_reserve).clear();
		driver.findElement(HubContributorFormObj.currentTaxRate_reserve)
				.sendKeys(ReadXML.readData("TC_815A", "currTaxRate"));
		// driver.findElement(HubContributorFormObj.dateFirstRecorded).click();
		driver.findElement(HubContributorFormObj.dateFirstRecorded)
				.sendKeys(ReadXML.readData("TC_815A", "dateFirstRecorded"));
		driver.findElement(HubContributorFormObj.typeOfReserve).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.typeOfReserveConractDefault).click();
		driver.findElement(HubContributorFormObj.descriptionOfReserve)
				.sendKeys(ReadXML.readData("TC_815A", "descriptionOfReserve"));
		driver.findElement(HubContributorFormObj.technicalAccountingCOE).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.technicalAccountingCOEValMollie).click();
		driver.findElement(HubContributorFormObj.backgroundOfContingency)
				.sendKeys(ReadXML.readData("TC_815A", "backgroundOfContingency"));
		driver.findElement(HubContributorFormObj.statusOfReserve_816)
				.sendKeys(ReadXML.readData("TC_815A", "statusOfReserve"));
		driver.findElement(HubContributorFormObj.explanationofReclassifications_816)
				.sendKeys(ReadXML.readData("TC_815A", "explainationOfReclassification"));
		driver.findElement(HubContributorFormObj.begBalance).sendKeys(ReadXML.readData("TC_815A", "begBal"));
		driver.findElement(HubContributorFormObj.chargeToPL).sendKeys(ReadXML.readData("TC_815A", "chargeToPL"));
		driver.findElement(HubContributorFormObj.returnedToPL).sendKeys(ReadXML.readData("TC_815A", "returnedToPL"));
		driver.findElement(HubContributorFormObj.useForIntended_816)
				.sendKeys(ReadXML.readData("TC_815A", "userForIntended"));
		driver.findElement(HubContributorFormObj.translation_816).sendKeys(ReadXML.readData("TC_815A", "translation"));
		driver.findElement(HubContributorFormObj.reClass_816).sendKeys(ReadXML.readData("TC_815A", "reClass"));

	}

	// Test Id# TC71
	public static void begBalEndBalRollFwPrevYr(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		// Before test open schedule is not required for this since period is
		// different for each test cases.
		// Before test open schedule is not required for this since period is
				// different for each test cases.
				schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
				//entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
				String periodPrevQ4 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodPrevFYQ4");
				String PeriodCurFYQ1=Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ1");
				//Get Bugo id from DB
				String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "604D7F93-7239-482B-9A93-ECC4107FC6FA", periodPrevQ4);
				//String bugoID="BU053GOUS";
				String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
						+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
				//Get entity code for above bugo id
				String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
				//String entityCode="1083";
			     //Distribute the schedule for Q4 previous year
				HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, periodPrevQ4);
				driver.quit();
				driver = Login.LaunchHub("Setupurl", Logs);
				//Distribute the schedule for current year quarter
				HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ1);
				driver.quit();
				driver = Login.LaunchHub("Setupurl", Logs);
				HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, periodPrevQ4, schedule, Logs);
				HubContributorFormPage.OpenscheduleAddReserveIfNotPresent815(driver, "New/Undiscovered", Logs);
				base.waitForElementTobeClickable(driver, HubContributorFormObj.edt_BegBalance, 10);
				String endBalInPreYear = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
				Logs.update("Ending balance of Previous year", endBalInPreYear, Status.DONE, driver);
				HubContributor.switchWindow(driver);
				//period = Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ2");
				HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ1, schedule, Logs);
				Thread.sleep(2000);
				WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
				boolean schedulePresent = entityXpath.isDisplayed();
				HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
				WebElement existingGenReserveRec = HubHomePageObj.findDynamicXpathTypeOfReserve(driver, "New/Undiscovered");
				existingGenReserveRec.click();
				Thread.sleep(4000);
				String statusOfBegBal = driver.findElement(HubContributorFormObj.begBalance).getAttribute("class");
				if (statusOfBegBal.contains("readonly")) {
					Logs.update("TC_47.1 verify beg Balance field should be read only",
							"Beg bal field is read only and greyed out", Status.PASS, driver);
				} else {
					Logs.update("TC_47.1 verify beg Balance field should be read only",
							"Beg bal field is not read only and not greyed out", Status.FAIL, driver);
				}
				String BegBalValInNextYear = driver.findElement(HubContributorFormObj.begBalance).getAttribute("value");
				Logs.update("Beg Bal of next FY year quarter", BegBalValInNextYear, Status.DONE, driver);
				Assert.assertEquals(endBalInPreYear, BegBalValInNextYear);
				if (endBalInPreYear.equals(BegBalValInNextYear)) {
					Logs.update("TC_47.2 verify that ending bal of previous year is displayed as beg bal of current year",
							"Beg bal of current year is same as previous year ending bal as expected", Status.PASS, driver);
				} else {
					Logs.update("TC_47.2 verify that ending bal of previous year is displayed as beg bal of current year",
							"Beg bal of current year is NOT same as previous year ending bal", Status.FAIL, driver);
				}

				
				String endBalValInNextYearQ1 = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
				Logs.update("Ending balance of next FY year quarter", endBalValInNextYearQ1, Status.DONE, driver);
				int endBalPrYr=Integer.parseInt(endBalInPreYear);
				if(endBalPrYr!=0){
					Logs.update("Verify that ending balance of previous year reserve is not equal to 0", "Ending balance is not equal to 0", Status.PASS, driver);
				Assert.assertEquals(endBalInPreYear, endBalValInNextYearQ1);
				if (endBalInPreYear.equals(endBalValInNextYearQ1)) {
					Logs.update("TC_97 verify that ending bal of previous year(if not equal to zero) is roll forwarded to current year Q1",
							"Previous year ending balance is rolled forwared to current year Q1 as expected", Status.PASS, driver);
				} else {
					Logs.update("TC_97 verify that ending bal of previous year(if not equal to zero) is roll forwarded to current year Q1",
							"Previous year ending balance is Not rolled forwared to current year Q1", Status.FAIL, driver);
				}
			}else{
					
				Logs.update("Verify that ending balance of previous year reserve is not equal to 0", "Ending balance is equal to 0", Status.FAIL, driver);
			}


	}

	// Test Id# TC46,TC53,TC54,TC61,TC62,TC69,TC70,TC77,TC78,TC83, TC84,TC95,TC96
	public static void rollFWofFieldsForSameFY(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		// Before test open schedule is not required for this since period is
		// different for each test cases.
		schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
		String PeriodCurFYQ1 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ1");// Current year Q1
		String PeriodCurFYQ2 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ2");
		// entityName = Util.getAllNecessaryData(TestType, "815ADB","EntityDetail");

		// Get Bugo id from DB
		String bugoID = HubContributor.getBugoID(driver, Logs, TestType, "604D7F93-7239-482B-9A93-ECC4107FC6FA",
				PeriodCurFYQ1);
		//String bugoID="BU397GOBR";
		// =====
		// Get entity code for above bugo id
		String QueryToGetentityCode = "select  top 1 entitycode from masterdata.entity where " + "bustructure='"
				+ bugoID + "' and entitystatus='A' and entitytype='R'";
		String entityCode = utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode,
				"entitycode");
		// =====
		//String entityCode="5536";
		// Distribute the schedule for current year Q1
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ1);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		// Distribute the schedule for current year quarter 2
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ2);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, PeriodCurFYQ1, schedule, Logs);
		HubContributorFormPage.OpenscheduleAddReserveIfNotPresent815(driver, "New/Undiscovered", Logs);
		base.waitForElementTobeClickable(driver, HubContributorFormObj.edt_BegBalance, 10);
		//Beg bal
		String begBalInQ1 = driver.findElement(HubContributorFormObj.begBalance).getAttribute("value");
		Logs.update("Beg balance of current year Q1=", begBalInQ1, Status.DONE, driver);
		//Charge to PL
		String chargeToPLInQ1 = driver.findElement(HubContributorFormObj.chargePL).getAttribute("value");
		Logs.update("Charge to PL of current year Q1=", chargeToPLInQ1, Status.DONE, driver);
		//Return to PL
		String returnToPLInQ1 = driver.findElement(HubContributorFormObj.returnPL).getAttribute("value");
		Logs.update("Return to PL of current year Q1=", returnToPLInQ1, Status.DONE, driver);
		//Use for Intended
		String useForIntendedInQ1 = driver.findElement(HubContributorFormObj.useForIntended).getAttribute("value");
		Logs.update("Use for intended of current year Q1=", useForIntendedInQ1, Status.DONE, driver);
		//Translation
		String translationInQ1 = driver.findElement(HubContributorFormObj.translation).getAttribute("value");
		Logs.update("Translation of current year Q1=", translationInQ1, Status.DONE, driver);
		//ReClass
		String reClassInQ1 = driver.findElement(HubContributorFormObj.reClass).getAttribute("value");
		Logs.update("Reclass of current year Q1=", reClassInQ1, Status.DONE, driver);
		//ending Bal
		String endingBalInQ1 = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
		Logs.update("Ending of current year Q1=", endingBalInQ1, Status.DONE, driver);
		
		HubContributor.switchWindow(driver);
		schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
		entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
		// period = Util.getAllNecessaryData(TestType, "815ADB",
		// "PeriodCurFYQ2");
		HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ2, schedule, Logs);
		Thread.sleep(2000);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		boolean schedulePresent = entityXpath.isDisplayed();
		HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
		WebElement existingGenReserveRec = HubHomePageObj.findDynamicXpathTypeOfReserve(driver, "New/Undiscovered");
		existingGenReserveRec.click();
		Thread.sleep(4000);
		//Beg Bal 
		String BegBalOFCurrYearQ2 = driver.findElement(HubContributorFormObj.begBalance).getAttribute("value");
		Logs.update("Beg Bal of curreny FY Q2=", BegBalOFCurrYearQ2, Status.DONE, driver);
		Assert.assertEquals(begBalInQ1, BegBalOFCurrYearQ2);
		if (begBalInQ1.equals(BegBalOFCurrYearQ2)) {
			Logs.update("TC_46 verify that beg bal is same in Q1 and Q2 of current FY",
					"Beg bal is same for Q1 and Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_46 verify that beg bal is same in Q1 and Q2 of current FY",
					"Beg bal is NOT same for Q1 and Q2 of current FY", Status.FAIL, driver);
		}
		//Charge to PL
		String ChargeToPLOFCurrYearQ2 = driver.findElement(HubContributorFormObj.chargePL).getAttribute("value");
		Logs.update("Charge to PL of curreny FY Q2=", ChargeToPLOFCurrYearQ2, Status.DONE, driver);
		Assert.assertEquals(chargeToPLInQ1, ChargeToPLOFCurrYearQ2);
		if (chargeToPLInQ1.equals(ChargeToPLOFCurrYearQ2)) {
			Logs.update("TC_53 verify that charge to PL is rolled forwarded from Q1 to Q2 of current FY",
					"Charge to PL is rolled forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_53 verify that charge to PL is rolled forwarded from Q1 to Q2 of current FY",
					"Charge to PL is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
		}
		HubContributor.checkIfElementIsEditable(driver, HubContributorFormObj.chargePL, Logs, "Charge to PL",
				"TC_54 Charge to PL field should be editable");
		//Return to PL
		String returnToPLOFCurrYearQ2 = driver.findElement(HubContributorFormObj.returnPL).getAttribute("value");
		Logs.update("Return to PL of curreny FY Q2=", returnToPLOFCurrYearQ2, Status.DONE, driver);
		Assert.assertEquals(returnToPLInQ1, returnToPLOFCurrYearQ2);
		if (returnToPLInQ1.equals(returnToPLOFCurrYearQ2)) {
			Logs.update("TC_61 verify that Return to PL is rolled forwarded from Q1 to Q2 of current FY",
					"Return to PL is rolled forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_61 verify that Return to PL is rolled forwarded from Q1 to Q2 of current FY",
					"Return to PL is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
		}
		HubContributor.checkIfElementIsEditable(driver, HubContributorFormObj.returnPL, Logs, "Return to PL",
				"TC_62 Return to PL field should be editable");
		//Use for intended
		String useForIntendedOFCurrYearQ2 = driver.findElement(HubContributorFormObj.useForIntended).getAttribute("value");
		Logs.update("Use for intended of curreny FY Q2=", useForIntendedOFCurrYearQ2, Status.DONE, driver);
		Assert.assertEquals(useForIntendedInQ1, useForIntendedOFCurrYearQ2);
		if (useForIntendedInQ1.equals(useForIntendedOFCurrYearQ2)) {
			Logs.update("TC_69 verify that Use for intended is rolled forwarded from Q1 to Q2 of current FY",
					"Use for intended is rolled forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_69 verify that Use for intended is rolled forwarded from Q1 to Q2 of current FY",
					"Use for intended is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
		}
		HubContributor.checkIfElementIsEditable(driver, HubContributorFormObj.useForIntended, Logs, "Use for intended",
				"TC_70 Use for intended field should be editable");
		//Translation
		String translationOFCurrYearQ2 = driver.findElement(HubContributorFormObj.translation).getAttribute("value");
		Logs.update("Translation of curreny FY Q2=", translationOFCurrYearQ2, Status.DONE, driver);
		Assert.assertEquals(translationInQ1, translationOFCurrYearQ2);
		if (translationInQ1.equals(translationOFCurrYearQ2)) {
			Logs.update("TC_77 verify that Translation is rolled forwarded from Q1 to Q2 of current FY",
					"Translation is rolled forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_77 verify that Translation is rolled forwarded from Q1 to Q2 of current FY",
					"Translation is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
		}
		HubContributor.checkIfElementIsEditable(driver, HubContributorFormObj.translation, Logs, "Translation field",
				"TC_78 translation field should be editable");
		//Reclass
		String reClassOFCurrYearQ2 = driver.findElement(HubContributorFormObj.reClass).getAttribute("value");
		Logs.update("Reclass of curreny FY Q2=", reClassOFCurrYearQ2, Status.DONE, driver);
		Assert.assertEquals(reClassInQ1, reClassOFCurrYearQ2);
		if (reClassInQ1.equals(reClassOFCurrYearQ2)) {
			Logs.update("TC_83 verify that Reclass is rolled forwarded from Q1 to Q2 of current FY",
					"Reclass is rolled forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_83 verify that Reclass is rolled forwarded from Q1 to Q2 of current FY",
					"Reclass is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
		}
		HubContributor.checkIfElementIsEditable(driver, HubContributorFormObj.reClass, Logs, "Reclass field",
				"TC_84 reclass field should be editable");
		//ending balance
		String endingBalOfCurrYearQ2 = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
		Logs.update("Ending Balance of curreny FY Q2=", endingBalOfCurrYearQ2, Status.DONE, driver);
		int endBalQ1=Integer.parseInt(endingBalInQ1);
		//Test id 95: when ending balance in not equal to 0 in previous quarter
		if(endBalQ1!=0){
			Logs.update("Verify if ending balance is not equal to zero", "Ending Balance is not equal to zero", Status.PASS, driver);
		Assert.assertEquals(endingBalInQ1, endingBalOfCurrYearQ2);
		if (endingBalInQ1.equals(endingBalOfCurrYearQ2)) {
			Logs.update("TC_95 verify that Ending Balance is rolled forwarded from Q1 to Q2 of current FY when it is not equal to 0 in Q1",
					"Ending Balance is roll forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
		} else {
			Logs.update("TC_95 Ending Balance is rolled forwarded from Q1 to Q2 of current FY when it is not equal to 0 in Q1",
					"Ending Balance is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
		}
		}else{
			Logs.update("TC_95 verify if ending balance is not equal to zero in previous quarter in same FY", "Ending Balance is qual to zero in previous Quatrter", Status.FAIL, driver);
		}
		//Test id 96: when ending balance is greater than 0 in previous quarter
				if(endBalQ1>0){
				Logs.update("Verify if ending balance is greater than zero", "Ending Balance is greater than zero", Status.PASS, driver);
				Assert.assertEquals(endingBalInQ1, endingBalOfCurrYearQ2);
				if (endingBalInQ1.equals(endingBalOfCurrYearQ2)) {
					Logs.update("TC_96 verify that Ending Balance is rolled forwarded from Q1 to Q2 of current FY when it is greater than 0 in Q1",
							"Ending Balance is roll forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
				} else {
					Logs.update("TC_96 verify that Ending Balance is rolled forwarded from Q1 to Q2 of current FY when it is greater than 0 in Q1",
							"Ending Balance is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
				}
				}else{
					Logs.update("TC_96 verify if ending balance is greater than zero in previous quarter in same FY" , "Ending Balance is not greater than 0", Status.FAIL, driver);
				}	
		}

	
	
	
	
	//Test id# 94
	
	//Test id# 94
		public static void endingBalRollFw_ZeroFromPrvYear(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
				throws Exception {
			// Before test open schedule is not required for this since period is
			// different for each test cases.
			schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
			String PeriodPrevFYQ4 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodPrevFYQ4");
			String PeriodCurFYQ1 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ1");
			//entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
			String bugoID = HubContributor.getBugoID(driver, Logs, TestType, "604D7F93-7239-482B-9A93-ECC4107FC6FA",
					PeriodPrevFYQ4);
			//String bugoID="BU522GOUS";
			// =====
			// Get entity code for above bugo id
			String QueryToGetentityCode = "select  top 1 entitycode from masterdata.entity where " + "bustructure='"
					+ bugoID + "' and entitystatus='A' and entitytype='R'";
			String entityCode = utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode,
					"entitycode");
			System.out.println(entityCode);
			// =====
			//String entityCode="9052";
			// Distribute the schedule for previous year Q4
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodPrevFYQ4);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);
			// Distribute the schedule for current year quarter 1
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ1);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);
			HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, PeriodPrevFYQ4, schedule, Logs);
			//HubContributorFormPage.OpenscheduleAddReserveIfNotPresent(driver, "New/Undiscovered", Logs);// Open general reserve having ending bal=0
			driver.findElement(HubContributorFormObj.btn_Add).click();
			Thread.sleep(5000);
				Form815APage.enterTransactionTaxAllData_endingBal_zero(TestType, driver, Logs);// If no record present then fill the data in form.  
				hubContributorFormObj.saveButton(driver).click();
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
				//driver.findElement(HubContributorFormObj.existingGeneralResFirstRec).click();
				Thread.sleep(2000);		
			base.waitForElementTobeClickable(driver, HubContributorFormObj.edt_BegBalance, 10);
			String endBalInPreYear = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
			Logs.update("Ending balance of Previous year", endBalInPreYear, Status.DONE, driver);
			HubContributor.switchWindow(driver);
			schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
			entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
			Thread.sleep(5000);
			HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ1, schedule, Logs);
			Thread.sleep(2000);
			WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
			boolean schedulePresent = entityXpath.isDisplayed();
			HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
			String reserveType=driver.findElement(By.tagName("body")).getText();
			// Verify if the reserve is rolled forwarded to current year Q1
			Assert.assertFalse(reserveType.contains("New/Undiscovered"));
			Thread.sleep(4000);
			if (!reserveType.contains("New/UnDiscovered")) {
				Logs.update("TC_94 verify that if ending balance is zero for a reserve in previous year Q4 is not rolled forwarded to next FY Q1",
						"Reserve is NOT rolled forwared to current year Q1 as expected", Status.PASS, driver);
			} else {
				Logs.update("TC_94 verify that if ending balance is zero for a reserve in previous year Q4 is not rolled forwarded to next FY Q1",
						"Previous year reserve is rolled forwared to current year Q1 even though ending bal was 0", Status.FAIL, driver);
			}
		}
		//Test id: TC93
			public static void endingBalRollFWCurrFY_Zero(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
					throws Exception {
				// Before test open schedule is not required for this since period is
				// different for each test cases.
				//entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
				schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
				String PeriodCurFYQ1 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ1");
				String PeriodCurFYQ2 = Util.getAllNecessaryData(TestType, "815ADB", "PeriodCurFYQ2");
				//entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
				String bugoID = HubContributor.getBugoID(driver, Logs, TestType, "604D7F93-7239-482B-9A93-ECC4107FC6FA",
						PeriodCurFYQ1);
				System.out.println(bugoID);
				//String bugoID="BU522GOUS";
				// =====
				// Get entity code for above bugo id
				String QueryToGetentityCode = "select  top 1 entitycode from masterdata.entity where " + "bustructure='"
						+ bugoID + "' and entitystatus='A' and entitytype='R'";
				String entityCode = utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode,
						"entitycode");
				// =====
				//String entityCode="9052";
				// Distribute the schedule for current year Q1
				HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ1);
				driver.quit();
				driver = Login.LaunchHub("Setupurl", Logs);
				// Distribute the schedule for current year quarter 2
				HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ2);
				driver.quit();
				driver = Login.LaunchHub("Setupurl", Logs);														 																							
				HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, PeriodCurFYQ1, schedule, Logs);
				//HubContributorFormPage.OpenscheduleAddReserveIfNotPresent(driver, "VAT Tax Reserve", Logs);//Open reserve where end bal is zero for curr FYQ1
				driver.findElement(HubContributorFormObj.btn_Add).click();
				Thread.sleep(5000);
				Form815APage.enterTransactionTaxAllData(TestType, driver, Logs);// If no record present then fill the data in form.  
					hubContributorFormObj.saveButton(driver).click();
					driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
					//driver.findElement(HubContributorFormObj.existingGeneralResFirstRec).click();
					Thread.sleep(2000);	
				
				base.waitForElementTobeClickable(driver, HubContributorFormObj.edt_BegBalance, 10);
				String endingBalInQ1 = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
				Logs.update("Ending of current year Q1=", endingBalInQ1, Status.DONE, driver);
				HubContributor.switchWindow(driver);
				schedule = Util.getAllNecessaryData(TestType, "815ADB", "ScheduleName");
				entityName = Util.getAllNecessaryData(TestType, "815ADB", "EntityDetail");
				HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ2, schedule, Logs);
				Thread.sleep(2000);
				WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
				Thread.sleep(2000);
				boolean schedulePresent = entityXpath.isDisplayed();
				HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
				WebElement existingGenReserveRec = HubHomePageObj.findDynamicXpathTypeOfReserve(driver, "New/Undiscovered");
				Logs.update("Verify the Reserve is carry forwarded from same FY Q1 to Q2 when ending bal is zero", "Reserve is carry forwarded from same FY Q1 to Q2 when ending bal is zero", Status.PASS, driver);
				existingGenReserveRec.click();
				Thread.sleep(4000);
				String endingBalOfCurrYearQ2 = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
				Logs.update("Ending Balance of curreny FY Q2=", endingBalOfCurrYearQ2, Status.DONE, driver);
				Assert.assertEquals(endingBalInQ1, endingBalOfCurrYearQ2);
				if (endingBalInQ1.equals(endingBalOfCurrYearQ2)) {
					Logs.update("TC_93 verify that Ending Balance is rolled forwarded from Q1 to Q2 of current FY when it is equal to 0 in Q1",
							"Ending Balance is roll forwarded from Q1 to Q2 of current FY", Status.PASS, driver);
				} else {
					Logs.update("TC_93 verify that Ending Balance is rolled forwarded from Q1 to Q2 of current FY when it is equal to 0 in Q1",
							"Ending Balance is NOT rolled forwarded from Q1 to Q2 of current FY", Status.FAIL, driver);
				}
			}
			
			

}
