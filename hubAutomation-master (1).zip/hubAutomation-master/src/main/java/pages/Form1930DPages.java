package pages;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.Form_123NC_Obj;
import objectRepository.Form_1930D_Obj;
import objectRepository.Form_1930D_Obj;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class Form1930DPages {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	static Actions actions;
	static WebElement entityXpath;
	static WebElement list;
	static WebDriverWait wait;
	static int i;

	// Test case TC_01 and TC_02

	public static void verifyScheduleDistributed(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs) throws InterruptedException {
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		boolean scheduleDistributed = entityXpath.isDisplayed();
		Assert.assertTrue(scheduleDistributed, "Schedule is not distributed correctly");
		if (scheduleDistributed == true) {
			Thread.sleep(4000);
			Logs.update(
					"R2.1_1930D_TC01_Validate whether the Schedule owner is able to distribute the Financial Disclosures Schedule",
					"Financial Disclosures schedule is distributed successfully", Status.PASS, driver);
		} else {
			Logs.update(
					"R2.1_1930D_TC01_Validate whether the Schedule owner is able to distribute the financial Disclosures Schedule",
					"financial Disclosures schedule is NOT distributed successfully", Status.FAIL, driver);
		}
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String ScheduleNameAct = driver.findElement(HubContributorFormObj.ScheduleNameValue).getText();
		Assert.assertEquals(ScheduleNameAct, schedule);
		if (ScheduleNameAct.equalsIgnoreCase(schedule)) {
			Logs.update("R2.1_1930D_TC02.1_Verify the shchedule Name",
					"Schedule Name is displayed as expected: " + ScheduleNameAct, Status.PASS, driver);
		} else {
			Logs.update("R2.1_1930D_TC02.1_Verify the shchedule Name", "Schedule Name is not displayed as expected",
					Status.FAIL, driver);
		}
		String periodAct = driver.findElement(HubContributorFormObj.PeriodValue).getText();
		Assert.assertEquals(periodAct, period);
		if (periodAct.equalsIgnoreCase(period)) {
			Logs.update(
					"R2.1_1930D_TC02.2_Verify that period is appropriate as to whichever period the schedule is distributed to_ "
							+ periodAct,
					"Period is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update(
					"R2.1_1930D_TC02.2_Verify that period is appropriate as to whichever period the schedule is distributed to",
					"Period is not displayed as expected", Status.FAIL, driver);
		}
		String scheduleGenInfo_HeaderAct = driver.findElement(Form_1930D_Obj.scheduleGeneralInfo_Header).getText();
		if (scheduleGenInfo_HeaderAct.equalsIgnoreCase("Schedule General Information")) {
			Logs.update("R2.1_1930D_TC02.3 verify the general info header",
					"Schedule General Information header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R2.1_1930D_TC02.3 verify the general info header",
					"Schedule General Information header is not displayed as expected", Status.FAIL, driver);
		}

		String reportingUnit_HeaderAct = driver.findElement(Form_1930D_Obj.reportingUnit_Header).getText();
		if (reportingUnit_HeaderAct.equalsIgnoreCase("Reporting Unit :")) {
			Logs.update("R2.1_1930D_TC02.4 verify the reporting Unit header",
					"Reporting Unit header is displayed as expected", Status.PASS, driver);
		} else {
			Logs.update("R2.1_1930D_TC02.4 verify the reporting Unit header",
					"Reporting Unit header is not displayed as expected", Status.FAIL, driver);
		}

		String RuGroupExp = entityName + "-" + scheduleLongDesc;
		String RuGroupAct = driver.findElement(HubContributorFormObj.ReportingUnitValue).getText();
		Assert.assertEquals(RuGroupAct, RuGroupExp);
		if (RuGroupAct.equalsIgnoreCase(RuGroupExp)) {
			Logs.update("R2.1_1930D_TC02.5_Verify that Reporting unit is displayed in the Schedule header",
					"Reporting unit is displayed as expected: " + RuGroupAct, Status.PASS, driver);
		} else {
			Logs.update("R2.1_1930D_TC02.5_Verify that Reporting unit is displayed in the Schedule header",
					"Reporting unit is NOT displayed as expected: " + RuGroupAct, Status.FAIL, driver);

		}

		driver.findElement(HubContributorFormObj.btn_Instructions).click();
		HubContributor.switchWindow_3(driver);
		String pageURLAct = driver.getCurrentUrl();
		String UrlExp = "https://sites.cargill.com/sites/Finance/CFR/Pages/Quick-Learning.aspx";
		System.out.println(pageURLAct);
		if (pageURLAct.equalsIgnoreCase(UrlExp)) {
			Logs.update("R2.1_1930D_TC02.6 verify the user is navigated to QuickLearning page",
					"Clicking on Instructions button user is navigated to page: " + pageURLAct, Status.PASS, driver);
		} else {
			Logs.update("R2.1_1930D_TC02.6 verify the user is navigated to QuickLearning page",
					"Clicking on Instructions button user is NOT navigated to page: " + UrlExp + "But navigated to: "
							+ pageURLAct,
					Status.FAIL, driver);
		}
		//driver.quit();
	}

	// TC_04
	public static void verify_MethodUsedToCalculateFairValue_Field(WebDriver driver, String TestType, String entityName,
			String period, String schedule, DriverScript Logs) throws Exception {
		String commentsToBeEntered = null;
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);

		for (int i = 1; i <= 6; i++) {
			WebElement editingBalEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[3]/div/div/span"));
			int valOfEditingBal = Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
			if (valOfEditingBal == 0) {
				actions.moveToElement(editingBalEle).doubleClick().build().perform();
				Thread.sleep(3000);
				String statusOfField = driver.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea)
						.getAttribute("disabled");
				System.out.println(statusOfField);
				Assert.assertEquals(statusOfField, "true", "Method used to calculate fair value field Not disabled when carrying value for account number is zero");
				if (statusOfField.equals("true")) {
					Logs.update("R2.1_1930D_TC04.1 Verify the status of Method used to calculate field",
							"Method used to calculate fair value field is disabled when carrying value for account number is zero",
							Status.PASS, driver);
				} else {
					Logs.update("R2.1_1930D_TC04.1 Verify the status of Method used to calculate field",
							"Method used to calculate fair value field Not disabled when carrying value for account number is zero",
							Status.FAIL, driver);
				}
				driver.findElement(Form_1930D_Obj.AccountDetails_Cancel_Btn).click();
				Thread.sleep(3000);
			} // When carrying balance is not zero
			else {
				actions.moveToElement(editingBalEle).doubleClick().build().perform();
				Thread.sleep(3000);
				WebElement methodUsedToCalFairValEle = driver
						.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
				methodUsedToCalFairValEle.clear();
				commentsToBeEntered = Util.getAllNecessaryData(TestType, "1930D", "500plus_Chars");
				commentsToBeEntered = commentsToBeEntered.substring(0, 500);

				HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "500plus_Chars",
						methodUsedToCalFairValEle, Logs, "1930D_TC04.2", 500);
				// driver.findElement(Form_1930D_Obj.AccountDetails_Cancel_Btn).click();
				driver.findElement(HubContributorFormObj.btn_Save).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

			}
		}
		String queryToGetComments = "Select Top 1 comments from dbo.schedule1930DAccounts where entityCode=" + "'"
				+ entityName + "'" + "and Comments is not null";
		String commentsFromDB = DataBaseConnection.getData(driver, Logs, TestType, queryToGetComments, "comments");
		Assert.assertEquals(commentsToBeEntered, commentsFromDB, "Comments from DB "+commentsFromDB +"And Commets entered "+commentsToBeEntered+ "does not match");
		if (commentsToBeEntered.equalsIgnoreCase(commentsFromDB)) {
			Logs.update("R2.1_1930D_TC04.3 Verify the comments entered is saved in DB",
					"Comments entered are successfully saved in DB as expected", Status.PASS, driver);
		} else {
			Logs.update("R2.1_1930D_TC04.3 Verify the comments entered is saved in DB",
					"Comments entered is NOT saved in DB as expected", Status.FAIL, driver);
		}
		//driver.quit();
	}

	// Tc_03
	public static void verifyFairValueHeader(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs, String TestType) throws Exception {
		Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		WebElement fairValue = driver.findElement(Form_1930D_Obj.fairValue_TextArea);
		actions.moveToElement(fairValue).doubleClick().build().perform();
		Thread.sleep(3000);
		WebElement fairValue_ele = driver.findElement(Form_1930D_Obj.fairValue);
		driver.findElement(Form_1930D_Obj.fairValue).clear();

		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "MaxLengthOfField",
				fairValue_ele, Logs, "R2_1_1930D_TC03_1", 19);
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1930D", "DecimalVal",
				fairValue_ele, Logs, "R2_1_1930D_TC03_2", "FairValue");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1930D", "InvalidVal",
				fairValue_ele, Logs, "R2_1_1930D_TC03_3", "FairValue");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1930D", "NegVal", fairValue_ele, Logs,
				"R2_1_1930D_TC03_4", 20, "FairValue");

		driver.findElement(Form_1930D_Obj.AccountDetails_Cancel_Btn).click();
		Thread.sleep(7000);
		// Verify BS line as per mockup

		String bslineMockupValues[] = { "0", "047", "260", "300", "360", "520", "212800" };
		for (int i = 1; i <= bslineMockupValues.length - 1; i++) {
			WebElement bslineEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[1]/div/div/span"));
			String bslinetext = bslineEle.getText();
			Assert.assertEquals(bslinetext, bslineMockupValues[i]);
			if (bslinetext.equalsIgnoreCase(bslineMockupValues[i])) {
				Logs.update("R2.1_1930D_TC03_BS line Verification", "Got expected value "+bslinetext, Status.PASS, driver);

			}

			else {
				Logs.update("R2.1_1930D_TC03_BS line Verification", bslineMockupValues[i], Status.FAIL, driver);
			}
		}
		// Verify Asset and Liability as per mockup

		String assetLiability[] = { "0", "Short-Term Investments", "Notes & Accts Receivable, Long-Term",
				"Miscellaneous Investments", "LT Notes/Accts Rec-Nonconsol Cos", "Short-Term Debt",
				"ST Debt-Non-Recourse" };
		for (int i = 1; i <= assetLiability.length - 1; i++) {
			WebElement assetliabilityEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[2]/div/div/span"));
			String assetliabilityEletext = assetliabilityEle.getText();
			Assert.assertEquals(assetliabilityEletext, assetLiability[i]);
			if (assetliabilityEletext.equalsIgnoreCase(assetLiability[i])) {
				Logs.update("R2.1_1930D_TC03_Asset Liability Verification", assetLiability[i], Status.PASS, driver);

			}

			else {
				Logs.update("R2.1_1930D_TC03_Asset Liability Verification", assetLiability[i], Status.FAIL, driver);
			}
		}
	}

	// TC_06

	public static void verifyLongTermDebtHeader(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs, String TestType) throws Exception {
		Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		driver.findElement(Form_1930D_Obj.longTermNo).click();

		try {
			driver.findElement(Form_1930D_Obj.inputQuestion2a).sendKeys(Keys.TAB);
			Logs.update("TC-06-Long term debt Verification", "Question is enabled  even after selecting NO",
					Status.FAIL, driver);
		} catch (Exception e) {
			Logs.update("TC-06-Long term debt Verification", "As Expected Question is Not enabled after selecting NO",
					Status.PASS, driver);
		}

		// TC_05

		Thread.sleep(3000);
		String statictextMockup = "2. Is any long-term debt shown on Balance Sheet Lines 540, 542, 665 or 667 secured?";
		driver.findElement(Form_1930D_Obj.longTermYes).click();
		String actualText = driver.findElement(Form_1930D_Obj.statictextTC05).getAttribute("title");
		Assert.assertEquals(actualText, statictextMockup, "Static Text is as Not  expected");
		if (actualText.equals(statictextMockup)) {
			Logs.update("TC-05-Static text Verification", "Static Text is as expected", Status.PASS, driver);
		} else {
			Logs.update("TC-05-Static text Verification", "Static Text is as Not  expected", Status.FAIL, driver);
		}

		WebElement Question2a_ele1 = driver.findElement(Form_1930D_Obj.inputQuestion2a);
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "MaxLengthOfField",
				Question2a_ele1, Logs, "1930D_TC05", 19);
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1930D", "DecimalVal",
				Question2a_ele1, Logs, "1930D_TC05", "amount of secured debt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1930D", "InvalidVal",
				Question2a_ele1, Logs, "1930D_TC05", "amount of secured debt");
		/*HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1930D", "NegVal",
				Question2a_ele1, Logs, "1930D_TC05", 20, "amount of secured debt");*/
HubContributor.verifyFieldIsTakingOnlyPositiveValue(driver, TestType, Question2a_ele1, "1930D", "PosNegValue", Logs, "TC_05");
	}

	// Tc_07 , Tc_08
	public static void verifyIncomeStatementHeader(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs, String TestType) throws Exception {
		Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		driver.findElement(Form_1930D_Obj.incomeStatementNo).click();

		try {
			driver.findElement(Form_1930D_Obj.inputQuestion3a).sendKeys(Keys.TAB);
			Logs.update(" TC-08-Income Statement Verification", "Question is enabled  even after selecting NO",
					Status.FAIL, driver);
		} catch (Exception e) {
			Logs.update(" TC-08-Income Statement Verification", "As Expected Question is Not enabled after selecting NO",
					Status.PASS, driver);
		}

		Thread.sleep(3000);
		driver.findElement(Form_1930D_Obj.incomeStatementYes).click();
		WebElement Question3a_ele1 = driver.findElement(Form_1930D_Obj.inputQuestion3a);
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "MaxLengthOfField",
				Question3a_ele1, Logs, "1930D_TC07", 19);

		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1930D", "DecimalVal",
				Question3a_ele1, Logs, "1930D_TC07", "amount of foreign exchange gain/loss");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "1930D", "InvalidVal",
				Question3a_ele1, Logs, "1930D_TC07", "amount of foreign exchange gain/loss");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber(driver, TestType, "1930D", "NegVal",
				Question3a_ele1, Logs, "1930D_TC07", 20, "amount of foreign exchange gain/loss");

		// Enter Comments
		String comments2a = "2aText";
		String comments3a = "3aText";
		WebElement Question3aText_ele1 = driver.findElement(Form_1930D_Obj.inputQuestion3aText);
		WebElement longdebtQuestion2aText_ele1 = driver.findElement(Form_1930D_Obj.inputQuestion2aText);
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "500plus_Chars",
				Question3aText_ele1, Logs, "1930D_TC07", 500);
		Thread.sleep(3000);
		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "500plus_Chars",
				longdebtQuestion2aText_ele1, Logs, "1930D_TC05", 500);
		driver.findElement(Form_1930D_Obj.inputQuestion2aText).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion3aText).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion2aText).sendKeys(comments2a);
		driver.findElement(Form_1930D_Obj.inputQuestion3aText).sendKeys(comments3a);
		driver.findElement(HubContributorFormObj.btn_Save).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

		// Database Validation
		String querytoGetDBComments = "select * from dbo.Schedule1930DAnswers where EntityCode='" + entityName + "'";
		String DBcommentsLongTerm = utils.DataBaseConnection.getData(driver, Logs, TestType, querytoGetDBComments,
				"LongTermDebtComments");
		String DBGainOrLossComments = utils.DataBaseConnection.getData(driver, Logs, TestType, querytoGetDBComments,
				"GainOrLossComments");
		System.out.println(DBcommentsLongTerm);
		System.out.println(DBGainOrLossComments);
		Assert.assertEquals(DBcommentsLongTerm, comments2a);
		if (DBcommentsLongTerm.equals(comments2a)) {
			Logs.update(" TC-05-Long term debt comments verification DB", "Comments matches in DB", Status.PASS,
					driver);
		}

		else {
			Logs.update(" TC-05-Long term debt comments verification DB", "Comments does not match DB", Status.FAIL,
					driver);
		}
		Assert.assertEquals(DBGainOrLossComments, comments3a);
		if (DBGainOrLossComments.equals(comments3a)) {
			Logs.update(" TC-08-Gain or Loss comments verification DB", "Comments matches in DB", Status.PASS, driver);
		}

		else {
			Logs.update(" TC-08-Gain or Loss comments verification DB", "Comments does not match DB", Status.PASS,
					driver);
		}

		driver.findElement(Form_1930D_Obj.inputQuestion2aText).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion3aText).clear();
		driver.quit();
	}

	// TC_12
	public static void verify_FairValue_fieldValidation(WebDriver driver, String TestType, String entityName,
			String period, String schedule, DriverScript Logs) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);

		for (int i = 1; i <= 6; i++) {
			WebElement editingBalEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[3]/div/div/span"));
			int valOfEditingBal = Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
			if (valOfEditingBal != 0) {// When account balance is not equal to
				// zero
				actions.moveToElement(editingBalEle).doubleClick().build().perform();
				Thread.sleep(3000);
				WebElement FairValueEle = driver.findElement(Form_1930D_Obj.fairValue);
				FairValueEle.clear();
				Logs.update("Make sure fair value field is cleared", "fair value field is cleared out", Status.PASS,
						driver);
				WebElement methodUsedToCalFairValEle = driver
						.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
				methodUsedToCalFairValEle.clear();
				methodUsedToCalFairValEle.sendKeys("Fair value field check");
				// Try to submit after clearing fair value
				driver.findElement(HubContributorFormObj.btn_Submit).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				String PopupWhenFairValIsNull_Act = driver.findElement(HubContributorFormObj.messagePopUpText)
						.getText();
				String expPopUpMsg="Please enter a �Fair Value� and/or �Method used to calculate Fair Value� under Question 1";
				boolean expPopUpMsgStatus= PopupWhenFairValIsNull_Act.contains(expPopUpMsg);
				Assert.assertTrue(expPopUpMsgStatus);
				if (PopupWhenFairValIsNull_Act.contains(
						expPopUpMsg)) {
					Logs.update("R2.1__1930D_TC12 verify if user is able to submit if Fair value field is blank",
							"Not able to submit the schedule when Fair value field is left blank as expected. Warning message displayed: "
									+ PopupWhenFairValIsNull_Act,
							Status.PASS, driver);
				} else {
					Logs.update("R2.1__1930D_TC12 verify if user is able to submit if Fair value field is blank",
							"Able to submit the schedule even when Fair value field is left blank. Warning message displayed: "
									+ PopupWhenFairValIsNull_Act,
							Status.FAIL, driver);
				}
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

			}
		}
		//driver.quit();
	}

	// TC_13
	public static void verify_MethodUsedToCalcFairValue_fieldValidation(WebDriver driver, String TestType,
			String entityName, String period, String schedule, DriverScript Logs) throws Exception {
		Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);

		for (int i = 1; i <= 6; i++) {
			WebElement editingBalEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[3]/div/div/span"));
			int valOfEditingBal = Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
			if (valOfEditingBal != 0) {// When account balance is not equal to
				// zero
				actions.moveToElement(editingBalEle).doubleClick().build().perform();
				Thread.sleep(3000);
				WebElement FairValueEle = driver.findElement(Form_1930D_Obj.fairValue);
				FairValueEle.clear();
				FairValueEle.sendKeys("12");
				WebElement methodUsedToCalFairValEle = driver
						.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
				methodUsedToCalFairValEle.clear();
				Logs.update("Make sure method used to calculate fair value field is cleared",
						"Method used to calculate fair value field is cleared out", Status.PASS, driver);

				// Try to submit after clearing method used to calculate fair
				// value field
				driver.findElement(HubContributorFormObj.btn_Submit).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				String PopupWhenFairValIsNull_Act = driver.findElement(HubContributorFormObj.messagePopUpText)
						.getText();
				String expPopUpMsg="Please enter a �Fair Value� and/or �Method used to calculate Fair Value� under Question 1";
				boolean expPopUpMsgStatus=PopupWhenFairValIsNull_Act.contains(expPopUpMsg);
				Assert.assertTrue(expPopUpMsgStatus);
				if (PopupWhenFairValIsNull_Act.contains(
						expPopUpMsg)) {
					Logs.update(
							"R2.1__1930D_TC13 verify if user is able to submit if method used to calculate fair value field is blank",
							"Not able to submit the schedule when method used to calculate Fair value field is left blank as expected. Warning message displayed: "
									+ PopupWhenFairValIsNull_Act,
							Status.PASS, driver);
				} else {
					Logs.update(
							"R2.1__1930D_TC13 verify if user is able to submit if method used to calculate Fair value field is blank",
							"Able to submit the schedule even when method used to calculate Fair value field is left blank. Warning message displayed: "
									+ PopupWhenFairValIsNull_Act,
							Status.FAIL, driver);
				}
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

			}

		}
		driver.quit();
	}

	// TC_15
	public static void verify_Yes_No_Question2_3(WebDriver driver, String TestType, DriverScript Logs)
			throws Exception {
		
		String accountCode;
		// Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		driver = Login.LaunchHub("Setupurl", Logs);
		String schedule = Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		String period = Util.getAllNecessaryData(TestType, "1930D", "Period");
		accountCode = Util.getAllNecessaryData(TestType, "1930D", "AccountCode");

		String QueryTobugoID = "Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' and EntityStatus='A' and "
				+ "entityID not IN (select entityId from scheduleinstance where scheduleID='B0C61D4A-78C6-4AFA-9B76-1DE1502CFDC6' "
				+ "and periodid IN ('" + period + "'))";

		String bugoID = HubContributor.getBugoID_WithQuery(driver, Logs, TestType, QueryTobugoID, "BUStructure");
		System.out.println("BugoId for TC13"+bugoID);
		String QueryToGetentityCode = "select  top 1 entitycode from masterdata.entity where " + "bustructure='"
				+ bugoID + "' and entitystatus='A' and entitytype='R'";
		String entityName = utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode,
				"entitycode");
		System.out.println("EntityCode for TC13"+bugoID);
		HubContributor.distributeScheduleYearly_Fiscal(driver, Logs, TestType, bugoID, schedule, period);
		Thread.sleep(6000);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);

		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);

		for (int i = 1; i <= 6; i++) {
			WebElement editingBalEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[3]/div/div/span"));
			int valOfEditingBal = Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
			if (valOfEditingBal != 0) {// When account balance is not equal to
				// zero
				actions.moveToElement(editingBalEle).doubleClick().build().perform();
				Thread.sleep(3000);
				WebElement FairValueEle = driver.findElement(Form_1930D_Obj.fairValue);
				FairValueEle.clear();
				FairValueEle.sendKeys("12");
				WebElement methodUsedToCalFairValEle = driver
						.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
				methodUsedToCalFairValEle.clear();
				methodUsedToCalFairValEle.sendKeys("Yes No question 3 and 4 validation");
			} else {
				// Try to submit after clearing method used to calculate fair
				// value field
				driver.findElement(HubContributorFormObj.btn_Submit).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				String PopupWhenFairValIsNull_Act = driver.findElement(HubContributorFormObj.messagePopUpText)
						.getText();
				String expPopUpMsg="Please select a response for question number 2 and 3";
				boolean expPopUpMsgStatus=PopupWhenFairValIsNull_Act.contains(expPopUpMsg);
				Assert.assertTrue(expPopUpMsgStatus);
				if (PopupWhenFairValIsNull_Act.contains(expPopUpMsg)) {
					Logs.update("R2.1__1930D_TC15 verify if user is able to submit when yes_no option is not selected",
							"Not able to submit the schedule when yes/No option is not selected for question 2 and 3 as expected. Warning message displayed: "
									+ PopupWhenFairValIsNull_Act,
							Status.PASS, driver);
				} else {
					Logs.update("R2.1__1930D_TC15 verify if user is able to submit when yes_no option is not selected",
							"Able to submit the schedule even when yes/No option is not selected for question 2 and 3. Warning message displayed: "
									+ PopupWhenFairValIsNull_Act,
							Status.FAIL, driver);
				}
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

			}
		}
	}

	// TC_09_10_11
	public static void verify_detailsQuestion_TC09_10_11(WebDriver driver, String entityName, String period,
			String schedule, DriverScript Logs, String TestType) throws Exception {
		Util.getAllNecessaryData(TestType, "1930D", "ScheduleName");
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String ParentcurrentHandle = driver.getWindowHandle();
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		
		for (int i = 1; i <= 6; i++) {
			WebElement editingBalEle = driver.findElement(By
					.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["
							+ i + "]/td[3]/div/div/span"));
			int valOfEditingBal = Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
			if (valOfEditingBal != 0) {
				actions.moveToElement(editingBalEle).doubleClick().build().perform();
				Thread.sleep(3000);
				WebElement FairValueEle = driver.findElement(Form_1930D_Obj.fairValue);
				FairValueEle.clear();
				FairValueEle.sendKeys("12");
				WebElement methodUsedToCalFairValEle = driver
						.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
				methodUsedToCalFairValEle.clear();
				methodUsedToCalFairValEle.sendKeys("question 4 validation");
				driver.findElement(HubContributorFormObj.btn_Save).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

			}/*else{
				driver.findElement(HubContributorFormObj.btn_Save).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			}*/
		}
		driver.findElement(Form_1930D_Obj.longTermYes).click();
		driver.findElement(Form_1930D_Obj.inputQuestion2a).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion2a).sendKeys("12");
		driver.findElement(Form_1930D_Obj.inputQuestion2aText).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion2aText).sendKeys("Question 4 validation");
		
		driver.findElement(Form_1930D_Obj.incomeStatementYes).click();
		driver.findElement(Form_1930D_Obj.inputQuestion3a).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion3a).sendKeys("12");
		driver.findElement(Form_1930D_Obj.inputQuestion3aText).clear();
		driver.findElement(Form_1930D_Obj.inputQuestion3aText).sendKeys("Question 4 validation");
		
		
		
		
		driver.findElement(Form_1930D_Obj.addButton).click();
		Thread.sleep(3000);
		WebElement explaination_ele = driver.findElement(Form_1930D_Obj.explaination);

		HubContributor.checkIfUserIsNotAbletoEnterMoreThan500(driver, TestType, "1930D", "500plus_Chars",
				explaination_ele, Logs, "1930D_TC09.2", 500);
		driver.findElement(Form_1930D_Obj.amount).clear();
		driver.findElement(Form_1930D_Obj.amount).sendKeys("5000");
		driver.findElement(HubContributorFormObj.btn_Save).click();
		Thread.sleep(3000);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		Thread.sleep(3000);
		String differenceNo = driver.findElement(Form_1930D_Obj.variance).getText();
		System.out.println(differenceNo);
		int differenceNoint;
		if (differenceNo.contains("(")) {
			differenceNo = differenceNo.replaceAll("[(),]", "");
			differenceNoint = Integer.valueOf(differenceNo) * -1;
		} else {
			differenceNo = differenceNo.replaceAll("[,]", "");
			differenceNoint = Integer.valueOf(differenceNo);
		}
		System.out.println(differenceNoint);
		if (differenceNoint == -5000 || differenceNoint == 5000
				|| (differenceNoint >= 5000 && differenceNoint <= -5000)) {
			// TC_10 - To check Variance
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(3000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

			String popUpMsg1 = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Logs.update("1930D_TC10 Verify the submit is sucessful", "Submit is successful with when varience is within -5000 to +5000 range : " + popUpMsg1,
					Status.PASS, driver);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			// Code to recall the schedule after the submitting the schedule

			driver.switchTo().window(ParentcurrentHandle);
			Thread.sleep(2000);
			driver.findElement(By.name("StatusDashBoardButton")).click();

			WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
			driver.switchTo().frame(Frame);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
			Thread.sleep(5000);
/*			driver.findElement(HubHomePageObj.selectScheduleNew).click();
			Thread.sleep(2000);
			HubHomePageObj.findScheduleName(driver, schedule).click();
			// Thread.sleep(1000);*/
			actions.sendKeys(Keys.TAB).build().perform();
			Thread.sleep(3000);
			driver.findElement(HubHomePageObj.selectSchedule).sendKeys(schedule);
			Thread.sleep(2000);
			actions.sendKeys(Keys.ENTER).build().perform();
			/**Change complete**/
			Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
			driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
			driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
			Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
			driver.findElement(HubHomePageObj.searchButtonDashboard).click();
			Thread.sleep(5000);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);

			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(By.name("btnRecallEdit")).click();
			Logs.update("Verify Recall is successful", "Recall is successful ", Status.PASS, driver);
			Thread.sleep(3000);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(5000);

		}

		else {
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(3000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(3000);
			String ExpectedPopUpMsg="Variance for question 4 is not within the allowed tolerance of +/- 5000.";
			String PopupWhenVarianceGreater = driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			boolean PopupWhenVarianceGreaterStatus= PopupWhenVarianceGreater.contains(ExpectedPopUpMsg);
			Assert.assertTrue(PopupWhenVarianceGreaterStatus, "Expected pop up message does not match. Expected: "+ExpectedPopUpMsg+"Actual "+PopupWhenVarianceGreater);
			if (PopupWhenVarianceGreater
					.contains(ExpectedPopUpMsg)) {
				Logs.update("R2.1__1930D_TC11 verify if user is able to submit when Variance is out of range",
						"Not able to submit the schedule  when Variance is out of range  " + PopupWhenVarianceGreater,
						Status.PASS, driver);
			} else {
				Logs.update("R2.1__1930D_TC11 verify if user is able to submit when Variance is out of range",
						"Able to submit the schedule  when Variance is out of range  " + PopupWhenVarianceGreater,
						Status.FAIL, driver);
			}
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();

		}
		
		//With Data more than 5000
		

	

	}

	//TC_16
			public static void verify_AmountOfSecuredDebt_fieldValidation(WebDriver driver,String TestType, String entityName, String period, String schedule,
					DriverScript Logs) throws Exception {
				actions = new Actions(driver);
				HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
				entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
				actions.moveToElement(entityXpath).doubleClick().build().perform();
				Thread.sleep(4000);
				Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
				driver.findElement(HubHomePageObj.Btn_Open).click();
				Thread.sleep(3000);
				HubContributor.switchWindow(driver);
				driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
				Thread.sleep(7000);

				for(int i=1; i<=6; i++){
					WebElement editingBalEle= driver.findElement(By.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["+i+"]/td[3]/div/div/span"));
					int valOfEditingBal=Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
					if(valOfEditingBal!=0){//When account balance is not equal to zero
						actions.moveToElement(editingBalEle).doubleClick().build().perform();
						Thread.sleep(3000);
						WebElement FairValueEle=driver.findElement(Form_1930D_Obj.fairValue);
						FairValueEle.clear();
						FairValueEle.sendKeys("12");
						WebElement methodUsedToCalFairValEle=driver.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
						methodUsedToCalFairValEle.clear();
						methodUsedToCalFairValEle.sendKeys("question 3 and 4 validation $ field validation");				
						driver.findElement(HubContributorFormObj.btn_Save).click();
						Thread.sleep(3000);
						driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click(); 
					}	
				}//end of for
				driver.findElement(Form_1930D_Obj.longTermYes).click();
				driver.findElement(Form_1930D_Obj.inputQuestion2a).clear();
				Thread.sleep(2000);
				Logs.update("Make sure amount of secured debt field is cleared", "Data is not entered in amount of secured debt field as expected", Status.PASS, driver);
				driver.findElement(Form_1930D_Obj.inputQuestion2aText).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion2aText).sendKeys("$ amount of secured debt");

				driver.findElement(Form_1930D_Obj.incomeStatementYes).click();
				driver.findElement(Form_1930D_Obj.inputQuestion3a).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion3a).sendKeys("12");
				Thread.sleep(2000);

				driver.findElement(Form_1930D_Obj.inputQuestion3aText).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion3aText).sendKeys("$ amount of secured debt");

				//Try to submit after clearing method used to calculate fair value field
				driver.findElement(HubContributorFormObj.btn_Submit).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				String popUpMessageExp="Please enter the $ amount of secured debt under Question 2.a).";
				String PopupWhenAmountOfSecuredIsNull_Act=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
				Assert.assertEquals(PopupWhenAmountOfSecuredIsNull_Act, popUpMessageExp, "Actual and expected pop up message doesnot match");
				if(PopupWhenAmountOfSecuredIsNull_Act.contains(popUpMessageExp)){
					Logs.update("R2.1__1930D_TC16 verify if user is able to submit when amount of secured debt is not entered", "Not able to submit the schedule when amount of secured debt is not entered for question 2 as expected. Warning message displayed: "+PopupWhenAmountOfSecuredIsNull_Act, Status.PASS, driver);
				}else{
					Logs.update("R2.1__1930D_TC16 verify if user is able to submit when amount of secured debt is not entered", "Able to submit the schedule even when amount of secured debt is not entered for question 2. Warning message displayed: "+PopupWhenAmountOfSecuredIsNull_Act, Status.FAIL, driver);
				}
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				Thread.sleep(3000);
				//driver.quit();
			}

			//TC_17
			public static void verify_ListALLitemsThatAreSecurinTheDebt_fieldValidation(WebDriver driver,String TestType, String entityName, String period, String schedule,
					DriverScript Logs) throws Exception {
				actions = new Actions(driver);
				HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
				entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
				actions.moveToElement(entityXpath).doubleClick().build().perform();
				Thread.sleep(4000);
				Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
				driver.findElement(HubHomePageObj.Btn_Open).click();
				Thread.sleep(3000);
				HubContributor.switchWindow(driver);
				driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
				Thread.sleep(7000);

				for(int i=1; i<=6; i++){
					WebElement editingBalEle= driver.findElement(By.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["+i+"]/td[3]/div/div/span"));
					int valOfEditingBal=Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
					if(valOfEditingBal!=0){//When account balance is not equal to zero
						actions.moveToElement(editingBalEle).doubleClick().build().perform();
						Thread.sleep(3000);
						WebElement FairValueEle=driver.findElement(Form_1930D_Obj.fairValue);
						FairValueEle.clear();
						FairValueEle.sendKeys("12");
						WebElement methodUsedToCalFairValEle=driver.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
						methodUsedToCalFairValEle.clear();
						methodUsedToCalFairValEle.sendKeys("question 3 and 4 validation $ field validation");				
						driver.findElement(HubContributorFormObj.btn_Save).click();
						Thread.sleep(3000);
						driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click(); 
					}	
				}//end of for
				driver.findElement(Form_1930D_Obj.longTermYes).click();
				driver.findElement(Form_1930D_Obj.inputQuestion2a).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion2a).sendKeys("12");
				Thread.sleep(2000);
				driver.findElement(Form_1930D_Obj.inputQuestion2aText).clear();
				Logs.update("Make sure List ALL items that are securing the debt field is cleared", "Data is not entered in List ALL items that are securing the debt field as expected", Status.PASS, driver);
				driver.findElement(Form_1930D_Obj.incomeStatementYes).click();
				driver.findElement(Form_1930D_Obj.inputQuestion3a).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion3a).sendKeys("12");
				Thread.sleep(2000);
				//Logs.update("Make sure amount of secured debt field is cleared", "Data is not entered in amount of secured debt field as expected", Status.PASS, driver);
				driver.findElement(Form_1930D_Obj.inputQuestion3aText).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion3aText).sendKeys("$ amount of secured debt");

				//Try to submit after clearing method used to calculate fair value field
				driver.findElement(HubContributorFormObj.btn_Submit).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				String PopupWhenAllItemSecuring_IsNull_Act=driver.findElement(HubContributorFormObj.messagePopUpText).getText();

				String expMessage="Please enter the $ amount of secured debt and/or items that are securing the debt under Question 2.a).";
				Assert.assertEquals(PopupWhenAllItemSecuring_IsNull_Act, expMessage, "Actual and expected message does not match");
				if(PopupWhenAllItemSecuring_IsNull_Act.contains(expMessage)){
					Logs.update("R2.1__1930D_TC17 verify if user is able to submit when List ALL items that are securing the debt is not entered", "Not able to submit the schedule when 'List ALL items that are securing the debt' is not entered for question 2 as expected. Warning message displayed: "+PopupWhenAllItemSecuring_IsNull_Act, Status.PASS, driver);
				}else{
					Logs.update("R2.1__1930D_TC17 verify if user is able to submit when List ALL items that are securing the debt is not entered", "Able to submit the schedule even when'List ALL items that are securing the debt' is not entered for question 2. Warning message displayed: "+PopupWhenAllItemSecuring_IsNull_Act, Status.FAIL, driver);
				}
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				Thread.sleep(3000);
				//driver.quit();
			}

			//TC_18
			public static void verify_AmountOFForExch_ReasonForNotReporting_fieldValidation(WebDriver driver,String TestType, String entityName, String period, String schedule,
					DriverScript Logs) throws Exception {
				actions = new Actions(driver);
				HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
				entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
				actions.moveToElement(entityXpath).doubleClick().build().perform();
				Thread.sleep(4000);
				Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
				driver.findElement(HubHomePageObj.Btn_Open).click();
				Thread.sleep(3000);
				HubContributor.switchWindow(driver);
				driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
				Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
				Thread.sleep(7000);

				for(int i=1; i<=6; i++){
					WebElement editingBalEle= driver.findElement(By.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr["+i+"]/td[3]/div/div/span"));
					int valOfEditingBal=Integer.parseInt(editingBalEle.getText().replaceAll("[,]", ""));
					if(valOfEditingBal!=0){//When account balance is not equal to zero
						actions.moveToElement(editingBalEle).doubleClick().build().perform();
						Thread.sleep(3000);
						WebElement FairValueEle=driver.findElement(Form_1930D_Obj.fairValue);
						FairValueEle.clear();
						FairValueEle.sendKeys("12");
						WebElement methodUsedToCalFairValEle=driver.findElement(Form_1930D_Obj.MethodUsedToCalculateFairValue_TextArea);
						methodUsedToCalFairValEle.clear();
						methodUsedToCalFairValEle.sendKeys("question 3 and 4 validation $ field validation");				
						driver.findElement(HubContributorFormObj.btn_Save).click();
						Thread.sleep(3000);
						driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click(); 
					}	
				}//end of for
				driver.findElement(Form_1930D_Obj.longTermYes).click();
				driver.findElement(Form_1930D_Obj.inputQuestion2a).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion2a).sendKeys("12");
				Thread.sleep(2000);
				driver.findElement(Form_1930D_Obj.inputQuestion2aText).clear();
				driver.findElement(Form_1930D_Obj.inputQuestion2aText).sendKeys("$ amount of foreign exchange gain/loss");

				driver.findElement(Form_1930D_Obj.incomeStatementYes).click();
				driver.findElement(Form_1930D_Obj.inputQuestion3a).clear();
				Logs.update("Make sure dollar amount of foreign exchange gain/loss field is cleared", "Data is not entered in '$ amount of foreign exchange gain/loss' field as expected", Status.PASS, driver);

				Thread.sleep(2000);
				//Logs.update("Make sure amount of secured debt field is cleared", "Data is not entered in amount of secured debt field as expected", Status.PASS, driver);
				driver.findElement(Form_1930D_Obj.inputQuestion3aText).clear();
				Logs.update("Make sure Reason for NOT reporting in the above mentioned accounts field is cleared", "Data is not entered in 'Reason for NOT reporting in the above mentioned accounts' field as expected", Status.PASS, driver);

				//Try to submit after clearing method used to calculate fair value field
				driver.findElement(HubContributorFormObj.btn_Submit).click();
				Thread.sleep(3000);
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				String PopupWhenAllItemSecuring_IsNull_Act=driver.findElement(HubContributorFormObj.messagePopUpText).getText();

				String expMessage="Please enter the $ amount of foreign exchange gain/loss and/or Reason for NOT reporting in the accounts under Question 3.";
				Assert.assertEquals(PopupWhenAllItemSecuring_IsNull_Act, expMessage, "Actual and expected message does not match");
				if(PopupWhenAllItemSecuring_IsNull_Act.contains(expMessage)){
					Logs.update("R2.1__1930D_TC18 verify if user is able to submit without entring data for question 3", "Not able to submit the schedule without entring data under question 3 as expected. Warning message displayed: "+PopupWhenAllItemSecuring_IsNull_Act, Status.PASS, driver);
				}else{
					Logs.update("R2.1__1930D_TC18 verify if user is able to submit without entring data for question 3", "Able to submit the schedule even without entering dataunder  question 3. Warning message displayed: "+PopupWhenAllItemSecuring_IsNull_Act, Status.FAIL, driver);
				}
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				Thread.sleep(3000);
				//driver.quit();
			}
}
