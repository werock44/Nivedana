package pages;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.formula.functions.T;
import org.apache.tools.ant.taskdefs.WaitFor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import objectRepository.R11798Dobj;
import utils.Base_class;
import utils.HubContributor;
import utils.Login;
import utils.ReadXML;
import utils.Util;

public class Form1798DPage {
	//Tc_01
	public static void verifyscheduleDistribution(WebDriver driver, DriverScript Logs, String TestType,
			String entityCode, String schedule, String period, String TestCaseName) throws Exception {
		//driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
	/*	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		System.out.println(entityXpath);
		try {
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Logs.update("TC01- Verify Distribution", "Distribution is successfull and verified  ", Status.PASS, driver);

		}

		catch (Exception e) {
			Logs.update("TC01-Verify Distribution", "Distrbuted schedule not found", Status.FAIL, driver);
		}

	}
	//Test case_TC02_TC03_TC40
	public static void verifyReportingUnit(WebDriver driver, DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName, String expectedRU) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
		/*WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/

		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);

		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		String actualRU = HubHomePageObj.findEntityCode(driver, entityCode).getAttribute("title");
		System.out.println(actualRU);
		System.out.println(expectedRU);
		boolean RuStatus=actualRU.contains(expectedRU);
		Assert.assertTrue(RuStatus);
		if (actualRU.contains(expectedRU)) {

			Logs.update("TC02- Verify Reporting Unit", "RU is succesfully verified", Status.PASS, driver);
		} else {
			Logs.update("TC02- Verify Reporting Unit", "RU verification failed", Status.FAIL, driver);
		}
		
		boolean statusOfExport=driver.findElement(R11798Dobj.exportByPDF).isEnabled();
		Assert.assertTrue(statusOfExport);
		if (driver.findElement(R11798Dobj.exportByPDF).isEnabled())
		{
			Logs.update("TC40- Verify PDF", " PDF button is working fine ", Status.PASS, driver);
		}
		
		else 
		{
			Logs.update("TC40- Verify PDF", " PDF button is NOT working fine ", Status.FAIL, driver);
		}

		// TC-03

		try {
			HubHomePageObj.findEntityCode(driver, entityCode).sendKeys("value");
			Logs.update("TC03- Verify Reporting Unit is not editable", "RU is editable", Status.FAIL, driver);

		} catch (Exception e) {
			Logs.update("TC03- Verify Reporting Unit is not editable", "RU is not editable", Status.PASS, driver);

		}

	}

	//Test case_ TC06,TC07,TC08
	public static void verifySectionB(WebDriver driver, DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName) throws Exception {

		//driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
		/*WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		// Base_class.waitForElementToVisible(driver,
		// HubHomePageObj.selectSchedule, 10);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		// Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBox, 10);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		// TC-06
		Thread.sleep(5000);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1nobutton).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2nobutton).click();
		boolean statusOfSectionHeader=driver.findElement(R11798Dobj.sectionCHeader).isDisplayed();
		Assert.assertFalse(statusOfSectionHeader);

		if (driver.findElement(R11798Dobj.sectionCHeader).isDisplayed()) {
			Logs.update("TC-06-Verify Section C", "Section C is enabled ", Status.FAIL, driver);
		}

		else {
			Logs.update("TC-06-Verify Section C", "Section C is not enabled as section B answers are NO- as expected ",
					Status.PASS, driver);
		}

		// TC-07

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1nobutton).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2yesbutton).click();
		boolean statusOfsectionCHeader=driver.findElement(R11798Dobj.sectionCHeader).isDisplayed();
		Assert.assertFalse(statusOfsectionCHeader);
		if (driver.findElement(R11798Dobj.sectionCHeader).isDisplayed()) {
			Logs.update("TC-07-Verify Section C", "Section C is enabled ", Status.FAIL, driver);
		}

		else {
			Logs.update("TC-07-Verify Section C",
					"Section C is not enabled as  either of section B answers are NO- as expected ", Status.PASS,
					driver);
		}

		// TC-08

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1yesbutton).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2nobutton).click();
		boolean statusOfsectionCHeader1=driver.findElement(R11798Dobj.sectionCHeader).isDisplayed();
		Assert.assertFalse(statusOfsectionCHeader1);
		if (driver.findElement(R11798Dobj.sectionCHeader).isDisplayed()) {
			Logs.update("TC-08-Verify Section C", "Section C is enabled ", Status.FAIL, driver);
		}

		else {
			Logs.update("TC-08-Verify Section C",
					"Section C is not enabled as  either of section B answers are NO- as expected ", Status.PASS,
					driver);
		}
	}

	//Test case_TC09,TC10,TC12,TC13
	public static void verifySectionC(WebDriver driver, DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName) throws Exception {
		//driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
		/*WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		// Base_class.waitForElementToVisible(driver,
		// HubHomePageObj.selectSchedule, 10);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		// Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBox, 10);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}

		// TC-09
		Thread.sleep(5000);
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1yesbutton).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2yesbutton).click();
		boolean statusOfsectionCHeader=driver.findElement(R11798Dobj.sectionCHeader).isDisplayed();
		Assert.assertTrue(statusOfsectionCHeader);
		if (driver.findElement(R11798Dobj.sectionCHeader).isDisplayed()) {
			Logs.update("TC-09-Verify Section C", "Section C is enabled when both section B answers are yes ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-09-Verify Section C", "Section C is not enabled  ", Status.FAIL, driver);
		}

		// TC-10
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.interestOnlyStripsdropdown, 10);
		driver.findElement(R11798Dobj.interestOnlyStripsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.interestOnlyStripsYesbutton, 10);
		driver.findElement(R11798Dobj.interestOnlyStripsYesbutton).click();
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea).clear();
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "Interestonlystrips"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.serviceLiabilitiesdropdown, 10);
		driver.findElement(R11798Dobj.serviceLiabilitiesdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.serviceLiabilitiesYesbutton, 10);
		driver.findElement(R11798Dobj.serviceLiabilitiesYesbutton).click();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).clear();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "ServicingLiabilities"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.reCourseObligationsdropdown, 10);
		driver.findElement(R11798Dobj.reCourseObligationsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.reCourseObligationsYesbutton, 10);
		driver.findElement(R11798Dobj.reCourseObligationsYesbutton).click();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea).clear();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "RecourseORObligation"));

		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.otherAssetsdropdown, 10);
		driver.findElement(R11798Dobj.otherAssetsdropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.otherAssetsYesbutton, 10);
		driver.findElement(R11798Dobj.otherAssetsYesbutton).click();
		driver.findElement(R11798Dobj.otherAssetsTextArea).clear();
		driver.findElement(R11798Dobj.otherAssetsTextArea).sendKeys(ReadXML.readData("TC_798D", "OtherAssets"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.quotedPricedropdown, 10);
		driver.findElement(R11798Dobj.quotedPricedropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.quotedPricedropdownYesbutton, 10);
		driver.findElement(R11798Dobj.quotedPricedropdownYesbutton).click();
		driver.findElement(R11798Dobj.quotedPricedTextArea).clear();
		driver.findElement(R11798Dobj.quotedPricedTextArea).sendKeys(ReadXML.readData("TC_798D", "QuotedPrice"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.salesOfARdropdown, 10);
		driver.findElement(R11798Dobj.salesOfARdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.salesOfARdropdownYesbutton, 10);
		driver.findElement(R11798Dobj.salesOfARdropdownYesbutton).click();
		driver.findElement(R11798Dobj.salesOfARTextArea).clear();
		driver.findElement(R11798Dobj.salesOfARTextArea).sendKeys(ReadXML.readData("TC_798D", "salesOfAR"));

		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.eventsOrCircumdtancesdropdown, 10);
		driver.findElement(R11798Dobj.eventsOrCircumdtancesdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.eventsOrCircumdtancesYesbutton, 10);
		driver.findElement(R11798Dobj.eventsOrCircumdtancesYesbutton).click();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).clear();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "eventsOrCircumdtances"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.previousfinancialassetsdropdown, 10);
		driver.findElement(R11798Dobj.previousfinancialassetsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.previousfinancialassetsYesbutton, 10);
		driver.findElement(R11798Dobj.previousfinancialassetsYesbutton).click();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea).clear();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "previousfinancialassets"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.externalPartydropdown, 10);
		driver.findElement(R11798Dobj.externalPartydropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.externalPartyYesbutton, 10);
		driver.findElement(R11798Dobj.externalPartyYesbutton).click();
		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.externalPartyTextArea).sendKeys(ReadXML.readData("TC_798D", "externalParty"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.revieweByTCMdropdown, 10);
		driver.findElement(R11798Dobj.revieweByTCMdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.revieweByTCMYesbutton, 10);
		driver.findElement(R11798Dobj.revieweByTCMYesbutton).click();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).sendKeys(ReadXML.readData("TC_798D", "revieweByTCM"));

		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

		// Database validation
		// Interest Only Strips
		String expectedValue = driver.findElement(R11798Dobj.interestOnlyStripsTextArea).getAttribute("value");
		String Query = "select * from [dbo].[Schedule1798D] where EntityCode='" + entityCode + "'";
		String actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStripsComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- Interest Only Strips comments matched with DB after save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-Interest Only Strips comments Not matched with DB after save ", Status.FAIL, driver);
		}

		// Servicing Liabilities
		expectedValue = driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilitiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- Service Liabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-Service Liabilities comments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// RecourseObligationComments
		expectedValue = driver.findElement(R11798Dobj.reCourseObligationsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligationComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- Recourse ObligationComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-Recourse ObligationComments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// OtherAssetsLiabilitiesComments
		expectedValue = driver.findElement(R11798Dobj.otherAssetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilitiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- OtherAssetsLiabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// PriceQuotedComments
		expectedValue = driver.findElement(R11798Dobj.quotedPricedTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuotedComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB", "Section C- PriceQuoted Comments matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-PriceQuoted Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// FullCredittoAccountsComments
		expectedValue = driver.findElement(R11798Dobj.salesOfARTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccountsComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- FullCredittoAccounts Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-FullCredittoAccounts Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TransferAssetsExcludeCreditComments
		expectedValue = driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"TransferAssetsExcludeCreditComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- TransferAssetsExcludeCredit Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCredit Comments  Not matched with DB after Save ", Status.FAIL,
					driver);
		}

		// PreviousAssetsPurchasedComments
		expectedValue = driver.findElement(R11798Dobj.previousfinancialassetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"PreviousAssetsPurchasedComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- PreviousAssetsPurchased Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-PreviousAssetsPurchased Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SupportExternalPartiesComments
		expectedValue = driver.findElement(R11798Dobj.externalPartyTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-SupportExternalParties Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-SupportExternalParties Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SaleReviewByTCMComments
		expectedValue = driver.findElement(R11798Dobj.revieweByTCMTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// Verify dropdown option with Database.

		// Interest Only Strip
		expectedValue = driver.findElement(R11798Dobj.interestOnlyStripsdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStrips");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- InterestStrips dropdown  value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-InterestStrips dropdown  value matched DB did Not match with DB after Save ",
					Status.FAIL, driver);
		}

		// serviceLiabilitiesdropdown
		expectedValue = driver.findElement(R11798Dobj.serviceLiabilitiesdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilities");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- ServiceLiabilities dropdown  value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-ServiceLiabilities dropdown  value matched DB did Not match with DB after Save ",
					Status.FAIL, driver);
		}

		// reCourseObligationsdropdown
		expectedValue = driver.findElement(R11798Dobj.reCourseObligationsdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligation");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- RecourseObligation dropdown  value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-RecourseObligation dropdown  value matched DB did Not match with DB after Save ",
					Status.FAIL, driver);
		}

		// OtherAssetsLiabilities
		expectedValue = driver.findElement(R11798Dobj.otherAssetsdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilities");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- OtherAssetsLiabilities dropdown  value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities dropdown  value matched DB did Not match with DB after Save ",
					Status.FAIL, driver);
		}

		// quotedPricedropdown
		expectedValue = driver.findElement(R11798Dobj.quotedPricedropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuoted");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- quotedPricedropdown   value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-quotedPricedropdown   value matched DB did Not match with DB after Save ", Status.FAIL,
					driver);
		}

		// salesOfARdropdown
		expectedValue = driver.findElement(R11798Dobj.salesOfARdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccounts");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB", "Section C- salesOfARdropdown   value matched DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-salesOfARdropdown   value matched DB did Not match with DB after Save ", Status.FAIL,
					driver);
		}

		// eventsOrCircumdtancesdropdown
		expectedValue = driver.findElement(R11798Dobj.eventsOrCircumdtancesdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "TransferAssetsExcludeCredit");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- eventsOrCircumdtancesdropdown   value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-eventsOrCircumdtancesdropdown   value matched DB did Not match with DB after Save ",
					Status.FAIL, driver);
		}

		// previousfinancialassetsdropdown
		expectedValue = driver.findElement(R11798Dobj.previousfinancialassetsdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PreviousAssetsPurchased");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- previousfinancialassetsdropdown   value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-previousfinancialassetsdropdown   value matched DB did Not match with DB after Save ",
					Status.FAIL, driver);
		}

		// externalPartydropdown
		expectedValue = driver.findElement(R11798Dobj.externalPartydropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalParties");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- externalPartydropdown   value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-externalPartydropdown   value matched DB did Not match with DB after Save ", Status.FAIL,
					driver);
		}

		// revieweByTCMdropdown
		expectedValue = driver.findElement(R11798Dobj.revieweByTCMdropdown).getAttribute("title");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCM");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C- revieweByTCMdropdown   value matched DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-10-Verify Section C with DB",
					"Section C-revieweByTCMdropdown value matched DB did Not match with DB after Save ", Status.FAIL,
					driver);
		}

		// TC-12
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea).clear();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).clear();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea).clear();
		driver.findElement(R11798Dobj.otherAssetsTextArea).clear();
		driver.findElement(R11798Dobj.quotedPricedTextArea).clear();
		driver.findElement(R11798Dobj.salesOfARTextArea).clear();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).clear();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea).clear();
		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();

		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

		// Database validation
		// Interest Only Strips
		expectedValue = driver.findElement(R11798Dobj.interestOnlyStripsTextArea).getAttribute("value");
		Query = "select * from [dbo].[Schedule1798D] where EntityCode='" + entityCode + "'";
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStripsComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- Interest Only Strips comments matched with DB after save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-Interest Only Strips comments Not matched with DB after save ", Status.FAIL, driver);
		}

		// Servicing Liabilities
		expectedValue = driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilitiesComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- Service Liabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-Service Liabilities comments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// RecourseObligationComments
		expectedValue = driver.findElement(R11798Dobj.reCourseObligationsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligationComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- Recourse ObligationComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-Recourse ObligationComments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// OtherAssetsLiabilitiesComments
		expectedValue = driver.findElement(R11798Dobj.otherAssetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilitiesComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- OtherAssetsLiabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// PriceQuotedComments
		expectedValue = driver.findElement(R11798Dobj.quotedPricedTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuotedComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB", "Section C- PriceQuoted Comments matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-PriceQuoted Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// FullCredittoAccountsComments
		expectedValue = driver.findElement(R11798Dobj.salesOfARTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccountsComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- FullCredittoAccounts Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-FullCredittoAccounts Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TransferAssetsExcludeCreditComments
		expectedValue = driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"TransferAssetsExcludeCreditComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- TransferAssetsExcludeCredit Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCredit Comments  Not matched with DB after Save ", Status.FAIL,
					driver);
		}

		// PreviousAssetsPurchasedComments
		expectedValue = driver.findElement(R11798Dobj.previousfinancialassetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"PreviousAssetsPurchasedComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C- PreviousAssetsPurchased Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-PreviousAssetsPurchased Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SupportExternalPartiesComments
		expectedValue = driver.findElement(R11798Dobj.externalPartyTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-SupportExternalParties Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-SupportExternalParties Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SaleReviewByTCMComments
		expectedValue = driver.findElement(R11798Dobj.revieweByTCMTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		Assert.assertNull(actualValue);
		if (actualValue==null) {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-12-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TC-13 - verify Mandatory fields on submit .
		Thread.sleep(5000);
		// Click No
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2nobutton).click();

		// Click yes again
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2yesbutton).click();
		// CLick submit button
		driver.findElement(R11798Dobj.submitButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform(); // Click confirm submit
		Thread.sleep(3000);
		actions.sendKeys(Keys.ENTER).build().perform(); // Click on warning ok
		boolean statusOfinterestOnlyStrips=driver.findElement(R11798Dobj.interestOnlyStrips).getAttribute("class").contains("invalid");												// button
		Assert.assertTrue(statusOfinterestOnlyStrips);
		if (driver.findElement(R11798Dobj.interestOnlyStrips).getAttribute("class").contains("invalid")) {
			Logs.update("TC-13-Verify Invalid message", " Displayed Invalid message of Interest only strips ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-13-Verify Invalid message", " NOT  Displayed Invalid message of Interest only strips ",
					Status.FAIL, driver);
		}

	}

	// TC -14,15,16,17,18,19

	public static void verifySectionEditSectionC(WebDriver driver, DriverScript Logs, String TestType,
			String entityCode, String schedule, String period, String TestCaseName) throws Exception {
		//driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
		/*WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		// Base_class.waitForElementToVisible(driver,
		// HubHomePageObj.selectSchedule, 10);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		// Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBox, 10);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}

		Thread.sleep(5000);
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1dropdown, 10);
		Thread.sleep(3000);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1yesbutton).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2yesbutton).click();

		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.interestOnlyStripsdropdown, 10);
		driver.findElement(R11798Dobj.interestOnlyStripsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.interestOnlyStripsYesbutton, 10);
		driver.findElement(R11798Dobj.interestOnlyStripsYesbutton).click();
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea).clear();
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "Interestonlystrips"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.serviceLiabilitiesdropdown, 10);
		driver.findElement(R11798Dobj.serviceLiabilitiesdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.serviceLiabilitiesYesbutton, 10);
		driver.findElement(R11798Dobj.serviceLiabilitiesYesbutton).click();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).clear();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "ServicingLiabilities"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.reCourseObligationsdropdown, 10);
		driver.findElement(R11798Dobj.reCourseObligationsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.reCourseObligationsYesbutton, 10);
		driver.findElement(R11798Dobj.reCourseObligationsYesbutton).click();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea).clear();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "RecourseORObligation"));

		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.otherAssetsdropdown, 10);
		driver.findElement(R11798Dobj.otherAssetsdropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.otherAssetsYesbutton, 10);
		driver.findElement(R11798Dobj.otherAssetsYesbutton).click();
		driver.findElement(R11798Dobj.otherAssetsTextArea).clear();
		driver.findElement(R11798Dobj.otherAssetsTextArea).sendKeys(ReadXML.readData("TC_798D", "OtherAssets"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.quotedPricedropdown, 10);
		driver.findElement(R11798Dobj.quotedPricedropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.quotedPricedropdownYesbutton, 10);
		driver.findElement(R11798Dobj.quotedPricedropdownYesbutton).click();
		driver.findElement(R11798Dobj.quotedPricedTextArea).clear();
		driver.findElement(R11798Dobj.quotedPricedTextArea).sendKeys(ReadXML.readData("TC_798D", "QuotedPrice"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.salesOfARdropdown, 10);
		driver.findElement(R11798Dobj.salesOfARdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.salesOfARdropdownYesbutton, 10);
		driver.findElement(R11798Dobj.salesOfARdropdownYesbutton).click();
		driver.findElement(R11798Dobj.salesOfARTextArea).clear();
		driver.findElement(R11798Dobj.salesOfARTextArea).sendKeys(ReadXML.readData("TC_798D", "salesOfAR"));

		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.eventsOrCircumdtancesdropdown, 10);
		driver.findElement(R11798Dobj.eventsOrCircumdtancesdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.eventsOrCircumdtancesYesbutton, 10);
		driver.findElement(R11798Dobj.eventsOrCircumdtancesYesbutton).click();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).clear();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "eventsOrCircumdtances"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.previousfinancialassetsdropdown, 10);
		driver.findElement(R11798Dobj.previousfinancialassetsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.previousfinancialassetsYesbutton, 10);
		driver.findElement(R11798Dobj.previousfinancialassetsYesbutton).click();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea).clear();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "previousfinancialassets"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.externalPartydropdown, 10);
		driver.findElement(R11798Dobj.externalPartydropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.externalPartyYesbutton, 10);
		driver.findElement(R11798Dobj.externalPartyYesbutton).click();
		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.externalPartyTextArea).sendKeys(ReadXML.readData("TC_798D", "externalParty"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.revieweByTCMdropdown, 10);
		driver.findElement(R11798Dobj.revieweByTCMdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.revieweByTCMYesbutton, 10);
		driver.findElement(R11798Dobj.revieweByTCMYesbutton).click();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).sendKeys(ReadXML.readData("TC_798D", "revieweByTCM"));

		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();
		driver.close();

		// Reopen the form
		driver.switchTo().window(currentHandle);
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		allHandles = driver.getWindowHandles();
		// String[] abc =(String[]) allHandles.toArray();
		String[] array = allHandles.toArray(new String[0]);
		System.out.println(array);
		driver.switchTo().window(array[1]);
		// Edit
		Thread.sleep(8000);
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea).clear();
		Thread.sleep(2000);
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea).clear();
		Thread.sleep(1000);
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "InterestonlystripsEdit"));
		Thread.sleep(2000);
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).clear();
		Thread.sleep(2000);
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "ServicingLiabilitiesEdit"));
		Thread.sleep(2000);
		driver.findElement(R11798Dobj.reCourseObligationsTextArea).clear();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "RecourseORObligationEdit"));

		jse.executeScript("window.scrollBy(0,250)");
		driver.findElement(R11798Dobj.otherAssetsTextArea).clear();
		driver.findElement(R11798Dobj.otherAssetsTextArea).sendKeys(ReadXML.readData("TC_798D", "OtherAssetsEdit"));

		driver.findElement(R11798Dobj.quotedPricedTextArea).clear();
		driver.findElement(R11798Dobj.quotedPricedTextArea).sendKeys(ReadXML.readData("TC_798D", "QuotedPriceEdit"));

		driver.findElement(R11798Dobj.salesOfARTextArea).clear();
		driver.findElement(R11798Dobj.salesOfARTextArea).sendKeys(ReadXML.readData("TC_798D", "salesOfAREdit"));

		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).clear();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "eventsOrCircumdtancesEdit"));

		driver.findElement(R11798Dobj.previousfinancialassetsTextArea).clear();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "previousfinancialassetsEdit"));

		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.externalPartyTextArea).sendKeys(ReadXML.readData("TC_798D", "externalPartyEdit"));

		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).sendKeys(ReadXML.readData("TC_798D", "revieweByTCMEdit"));

		// Save after Edit
		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

		// Database Validation
		String expectedValue = driver.findElement(R11798Dobj.interestOnlyStripsTextArea).getAttribute("value");
		String Query = "select * from [dbo].[Schedule1798D] where EntityCode='" + entityCode + "'";
		String actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStripsComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- Interest Only Strips comments matched with DB after save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-Interest Only Strips comments Not matched with DB after save ", Status.FAIL, driver);
		}

		// Servicing Liabilities
		expectedValue = driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilitiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- Service Liabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-Service Liabilities comments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// RecourseObligationComments
		expectedValue = driver.findElement(R11798Dobj.reCourseObligationsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligationComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- Recourse ObligationComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-Recourse ObligationComments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// OtherAssetsLiabilitiesComments
		expectedValue = driver.findElement(R11798Dobj.otherAssetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilitiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- OtherAssetsLiabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// PriceQuotedComments
		expectedValue = driver.findElement(R11798Dobj.quotedPricedTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuotedComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB", "Section C- PriceQuoted Comments matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-PriceQuoted Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// FullCredittoAccountsComments
		expectedValue = driver.findElement(R11798Dobj.salesOfARTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccountsComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- FullCredittoAccounts Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-FullCredittoAccounts Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TransferAssetsExcludeCreditComments
		expectedValue = driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"TransferAssetsExcludeCreditComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- TransferAssetsExcludeCredit Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCredit Comments  Not matched with DB after Save ", Status.FAIL,
					driver);
		}

		// PreviousAssetsPurchasedComments
		expectedValue = driver.findElement(R11798Dobj.previousfinancialassetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"PreviousAssetsPurchasedComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C- PreviousAssetsPurchased Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-PreviousAssetsPurchased Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SupportExternalPartiesComments
		expectedValue = driver.findElement(R11798Dobj.externalPartyTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-SupportExternalParties Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-SupportExternalParties Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SaleReviewByTCMComments
		expectedValue = driver.findElement(R11798Dobj.revieweByTCMTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-14-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TC -15 - clearing two fields and validating in DB
		Thread.sleep(2000);
		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();
		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-15-Verify Section C with DB",
					"Section C-SupportExternalParties Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-15-Verify Section C with DB",
					"Section C-SupportExternalParties Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-15-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-15-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TC -16,17,18,19 - Select no for section B questions
		Thread.sleep(5000);
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1dropdown, 10);
		Thread.sleep(3000);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1nobutton).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2nobutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2nobutton).click();

		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStrips");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB", "Section C-InterestStrips matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB", "Section C-InterestStrips  Not matched with DB after Save ",
					Status.FAIL, driver);
		}

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStripsComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-InterestStripsComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-InterestStripsComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilities");
		System.out.println(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB", "Section C-ServiceLiabilities matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-ServiceLiabilities  Not matched with DB after Save ", Status.FAIL, driver);
		}

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilitiesComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-ServiceLiabilitiesComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-ServiceLiabilitiesComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligation");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB", "Section C-RecourseObligation matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-RecourseObligation  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligationComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-RecourseObligationComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-RecourseObligationComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilities");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilitiesComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-OtherAssetsLiabilitiesComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-OtherAssetsLiabilitiesComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuoted");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB", "Section C-PriceQuoted matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB", "Section C-PriceQuoted  Not matched with DB after Save ",
					Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuotedComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB", "Section C-PriceQuotedComments matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-PriceQuotedComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccounts");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB", "Section C-FullCredittoAccounts matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-FullCredittoAccounts  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccountsComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-FullCredittoAccountsComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-FullCredittoAccountsComments Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "TransferAssetsExcludeCredit");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCredit matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCredit  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"TransferAssetsExcludeCreditComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCreditComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCreditComments  Not matched with DB after Save ", Status.FAIL,
					driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PreviousAssetsPurchased");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-PreviousAssetsPurchased matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-PreviousAssetsPurchased  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"PreviousAssetsPurchasedComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-PreviousAssetsPurchasedComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-PreviousAssetsPurchasedComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalParties");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-SupportExternalParties matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-16-Verify Section C with DB",
					"Section C-SupportExternalParties  Not matched with DB after Save ", Status.FAIL, driver);
		}

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-17-Verify Section C with DB",
					"Section C-SupportExternalPartiesComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-17-Verify Section C with DB",
					"Section C-SupportExternalPartiesComments  Not matched with DB after Save ", Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCM");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-18-Verify Section C with DB", "Section C-SaleReviewByTCM matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-18-Verify Section C with DB", "Section C-SaleReviewByTCM  Not matched with DB after Save ",
					Status.FAIL, driver);
		}
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		System.out.println(actualValue);
		Assert.assertNull(actualValue);
		if (actualValue == null) {
			Logs.update("TC-19-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-19-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

	}

	//Test case_TC20,TC21,TC22_TC23
	public static void verifySubmitAndRecall(WebDriver driver, DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName) throws Exception {

		//driver = Login.LaunchHub("Setupurl", Logs);
		Actions actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityCode, period, schedule, Logs);
		/*WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(4000);
		// Base_class.waitForElementToVisible(driver,
		// HubHomePageObj.selectSchedule, 10);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		// Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBox, 10);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}

		Thread.sleep(5000);
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1dropdown, 10);
		Thread.sleep(3000);
		driver.findElement(R11798Dobj.ruQuestionare1dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare1yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare1yesbutton).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2dropdown, 10);
		driver.findElement(R11798Dobj.ruQuestionare2dropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.ruQuestionare2yesbutton, 10);
		driver.findElement(R11798Dobj.ruQuestionare2yesbutton).click();

		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.interestOnlyStripsdropdown, 10);
		driver.findElement(R11798Dobj.interestOnlyStripsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.interestOnlyStripsYesbutton, 10);
		driver.findElement(R11798Dobj.interestOnlyStripsYesbutton).click();
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea).clear();
		driver.findElement(R11798Dobj.interestOnlyStripsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "Interestonlystrips"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.serviceLiabilitiesdropdown, 10);
		driver.findElement(R11798Dobj.serviceLiabilitiesdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.serviceLiabilitiesYesbutton, 10);
		driver.findElement(R11798Dobj.serviceLiabilitiesYesbutton).click();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).clear();
		driver.findElement(R11798Dobj.serviceLiabilitiesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "ServicingLiabilities"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.reCourseObligationsdropdown, 10);
		driver.findElement(R11798Dobj.reCourseObligationsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.reCourseObligationsYesbutton, 10);
		driver.findElement(R11798Dobj.reCourseObligationsYesbutton).click();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea).clear();
		driver.findElement(R11798Dobj.reCourseObligationsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "RecourseORObligation"));

		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.otherAssetsdropdown, 10);
		driver.findElement(R11798Dobj.otherAssetsdropdown).click();

		Base_class.waitForElementToVisible(driver, R11798Dobj.otherAssetsYesbutton, 10);
		driver.findElement(R11798Dobj.otherAssetsYesbutton).click();
		driver.findElement(R11798Dobj.otherAssetsTextArea).clear();
		driver.findElement(R11798Dobj.otherAssetsTextArea).sendKeys(ReadXML.readData("TC_798D", "OtherAssets"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.quotedPricedropdown, 10);
		driver.findElement(R11798Dobj.quotedPricedropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.quotedPricedropdownYesbutton, 10);
		driver.findElement(R11798Dobj.quotedPricedropdownYesbutton).click();
		driver.findElement(R11798Dobj.quotedPricedTextArea).clear();
		driver.findElement(R11798Dobj.quotedPricedTextArea).sendKeys(ReadXML.readData("TC_798D", "QuotedPrice"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.salesOfARdropdown, 10);
		driver.findElement(R11798Dobj.salesOfARdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.salesOfARdropdownYesbutton, 10);
		driver.findElement(R11798Dobj.salesOfARdropdownYesbutton).click();
		driver.findElement(R11798Dobj.salesOfARTextArea).clear();
		driver.findElement(R11798Dobj.salesOfARTextArea).sendKeys(ReadXML.readData("TC_798D", "salesOfAR"));

		jse.executeScript("window.scrollBy(0,250)");
		Base_class.waitForElementToVisible(driver, R11798Dobj.eventsOrCircumdtancesdropdown, 10);
		driver.findElement(R11798Dobj.eventsOrCircumdtancesdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.eventsOrCircumdtancesYesbutton, 10);
		driver.findElement(R11798Dobj.eventsOrCircumdtancesYesbutton).click();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).clear();
		driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "eventsOrCircumdtances"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.previousfinancialassetsdropdown, 10);
		driver.findElement(R11798Dobj.previousfinancialassetsdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.previousfinancialassetsYesbutton, 10);
		driver.findElement(R11798Dobj.previousfinancialassetsYesbutton).click();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea).clear();
		driver.findElement(R11798Dobj.previousfinancialassetsTextArea)
				.sendKeys(ReadXML.readData("TC_798D", "previousfinancialassets"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.externalPartydropdown, 10);
		driver.findElement(R11798Dobj.externalPartydropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.externalPartyYesbutton, 10);
		driver.findElement(R11798Dobj.externalPartyYesbutton).click();
		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.externalPartyTextArea).sendKeys(ReadXML.readData("TC_798D", "externalParty"));

		Base_class.waitForElementToVisible(driver, R11798Dobj.revieweByTCMdropdown, 10);
		driver.findElement(R11798Dobj.revieweByTCMdropdown).click();
		Base_class.waitForElementToVisible(driver, R11798Dobj.revieweByTCMYesbutton, 10);
		driver.findElement(R11798Dobj.revieweByTCMYesbutton).click();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).sendKeys(ReadXML.readData("TC_798D", "revieweByTCM"));

		driver.findElement(R11798Dobj.submitButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		actions.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();

		driver.switchTo().window(currentHandle);
		Thread.sleep(2000);
		HubContributorFormPage.openScheduleFromStatusDashBoard(driver, entityCode, period, schedule, Logs);
		/*	driver.findElement(By.name("StatusDashBoardButton")).click();

		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(5000);
		// Base_class.waitForElementTobeClickable(driver,
		// HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityCode);
		Thread.sleep(5000);
		// Base_class.waitForElementToVisible(driver,
		// HubHomePageObj.selectSchedule, 10);
		driver.findElement(HubHomePageObj.selectScheduleNew).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		// Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
		driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
		driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
		Thread.sleep(1000);
		Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);*/
		entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(4000);
		driver.findElement(By.name("btnRecallEdit")).click();

		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

		// Verify DB Data after recall - It should be same .

		// Enter data
		Thread.sleep(3000);

		currentHandle = driver.getWindowHandle();
		wait = new WebDriverWait(driver, 10);
		Thread.sleep(3000);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}

		// DataBase Verification .
		// Database Validation
		Thread.sleep(6000);
		String expectedValue = driver.findElement(R11798Dobj.interestOnlyStripsTextArea).getAttribute("value");
		String Query = "select * from [dbo].[Schedule1798D] where EntityCode='" + entityCode + "'";
		String actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "InterestStripsComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-20-Verify Section C with DB",
					"Section C- Interest Only Strips comments matched with DB after save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-20-Verify Section C with DB",
					"Section C-Interest Only Strips comments Not matched with DB after save ", Status.FAIL, driver);
		}

		// Servicing Liabilities
		expectedValue = driver.findElement(R11798Dobj.serviceLiabilitiesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "ServiceLiabilitiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-20-Verify Section C with DB",
					"Section C- Service Liabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-20-Verify Section C with DB",
					"Section C-Service Liabilities comments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// RecourseObligationComments
		expectedValue = driver.findElement(R11798Dobj.reCourseObligationsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "RecourseObligationComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-20-Verify Section C with DB",
					"Section C- Recourse ObligationComments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-20-Verify Section C with DB",
					"Section C-Recourse ObligationComments Not matched with DB after Save ", Status.FAIL, driver);
		}

		// OtherAssetsLiabilitiesComments
		expectedValue = driver.findElement(R11798Dobj.otherAssetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "OtherAssetsLiabilitiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C- OtherAssetsLiabilities comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-OtherAssetsLiabilities Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// PriceQuotedComments
		expectedValue = driver.findElement(R11798Dobj.quotedPricedTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "PriceQuotedComments");
		Assert.assertEquals(actualValue, expectedValue);		
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB", "Section C- PriceQuoted Comments matched with DB after Save ",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-PriceQuoted Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// FullCredittoAccountsComments
		expectedValue = driver.findElement(R11798Dobj.salesOfARTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "FullCredittoAccountsComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C- FullCredittoAccounts Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-FullCredittoAccounts Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TransferAssetsExcludeCreditComments
		expectedValue = driver.findElement(R11798Dobj.eventsOrCircumdtancesTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"TransferAssetsExcludeCreditComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C- TransferAssetsExcludeCredit Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-TransferAssetsExcludeCredit Comments  Not matched with DB after Save ", Status.FAIL,
					driver);
		}

		// PreviousAssetsPurchasedComments
		expectedValue = driver.findElement(R11798Dobj.previousfinancialassetsTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query,
				"PreviousAssetsPurchasedComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C- PreviousAssetsPurchased Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-PreviousAssetsPurchased Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SupportExternalPartiesComments
		expectedValue = driver.findElement(R11798Dobj.externalPartyTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-SupportExternalParties Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-SupportExternalParties Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// SaleReviewByTCMComments
		expectedValue = driver.findElement(R11798Dobj.revieweByTCMTextArea).getAttribute("value");
		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		Assert.assertEquals(actualValue, expectedValue);
		if (expectedValue.equals(actualValue)) {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-21-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		// TC -15 - clearing two fields and validating in DB
		Thread.sleep(2000);
		driver.findElement(R11798Dobj.externalPartyTextArea).clear();
		driver.findElement(R11798Dobj.revieweByTCMTextArea).clear();
		driver.findElement(R11798Dobj.saveButton1798D).click();
		Thread.sleep(5000);
		actions.sendKeys(Keys.ENTER).build().perform();

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SupportExternalPartiesComments");
		System.out.println(actualValue);
		if (actualValue == null) {
			Logs.update("TC-22-Verify Section C with DB",
					"Section C-SupportExternalParties Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-22-Verify Section C with DB",
					"Section C-SupportExternalParties Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

		actualValue = utils.DataBaseConnection.getData(driver, Logs, TestType, Query, "SaleReviewByTCMComments");
		System.out.println(actualValue);
		if (actualValue == null) {
			Logs.update("TC-23-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments matched with DB after Save ", Status.PASS, driver);
		}

		else {
			Logs.update("TC-23-Verify Section C with DB",
					"Section C-SaleReviewByTCM Comments  Not matched with DB after Save ", Status.FAIL, driver);
		}

	}
	
	//Test case_TC34
	public static void verifyEditAfterSubmit(WebDriver driver, DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName) throws Exception {

		//driver = Login.launchAppURL("Setupurl", Logs);

		//HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		Thread.sleep(3000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.switchWindow(driver);
		Thread.sleep(7000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminDashboardButton, Logs,
				"Admin-Dashboard Button");

		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;

		driver.findElement(HubAdminScreen.entityDetail).sendKeys(entityCode);
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).clear();
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).sendKeys(period);
		Thread.sleep(5000);
		driver.findElement(HubAdminScreen.searchButtom).click();
		Thread.sleep(4000);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		Actions actions = new Actions(driver);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(3000);
		WebElement editbutton = driver.findElement(By.name("btnAdminOpenEdit"));
		if (editbutton.isEnabled()) {
			Logs.update("TC-34-Verify edit post schedule  due date", "Edit is enabled post to schedule  due date",
					Status.PASS, driver);
		}

		else {
			Logs.update("TC-34-Verify edit post schedule  due date", "Edit is disabled post to schedule  due date",
					Status.FAIL, driver);
		}
		
		

	}

	//Test case_TC35
	public static void verifyEditAfterSubmitBeforeduedate(WebDriver driver, DriverScript Logs, String TestType,
			String entityCode, String schedule, String period, String TestCaseName) throws Exception {

		//driver = Login.launchAppURL("Setupurl", Logs);

		//HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		Thread.sleep(3000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.switchWindow(driver);
		Thread.sleep(7000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminDashboardButton, Logs,
				"Admin-Dashboard Button");

		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;

		driver.findElement(HubAdminScreen.entityDetail).sendKeys(entityCode);
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).clear();
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).sendKeys(period);
		Thread.sleep(5000);
		driver.findElement(HubAdminScreen.searchButtom).click();
		Thread.sleep(4000);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		Actions actions = new Actions(driver);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(3000);
		WebElement editbutton = driver.findElement(By.name("btnAdminOpenEdit"));
		if (editbutton.isEnabled()) {
			Logs.update("TC-35-Verify edit prior schedule  due date", "Edit is enabled Prior to schedule  due date",
					Status.FAIL, driver);
		}

		else {
			Logs.update("TC-35-Verify edit prior schedule  due date", "Edit is disabled prior to schedule  due date",
					Status.PASS, driver);
		}

	}

	//Test case_TC38
	public static void verifyInstructions(WebDriver driver, DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName) throws Exception {

		//driver = Login.launchAppURL("Setupurl", Logs);

		//HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.hub2Button, Logs, "Hub 2.0 Button");
		Thread.sleep(3000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubHomePageObj.adminLink, Logs, "Admin Link Button");
		HubContributor.switchWindow(driver);
		Thread.sleep(7000);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.adminDashboardButton, Logs,
				"Admin-Dashboard Button");

		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		Thread.sleep(5000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;

		driver.findElement(HubAdminScreen.entityDetail).sendKeys(entityCode);
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).clear();
		Thread.sleep(2000);
		driver.findElement(HubAdminScreen.edt_Period).sendKeys(period);
		Thread.sleep(5000);
		driver.findElement(HubAdminScreen.searchButtom).click();
		Thread.sleep(4000);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		Actions actions = new Actions(driver);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(3000);

		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		driver.findElement(By.name("btnViewInstanceEdit")).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		Thread.sleep(5000);
		// wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		Thread.sleep(5000);
		currentHandle = driver.getWindowHandle();
		driver.findElement(By.name("BtnInstruction")).click();

		wait = new WebDriverWait(driver, 10);
		Thread.sleep(5000);
		// wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		Thread.sleep(10000);
		if (driver.findElement(By.xpath("//*[@id='ctl00_ctl45_ctl03_ShellNewsfeed']/span")).isEnabled()) {
			Logs.update("TC-38-Verify Instructions button", "Instructions button is working as expected", Status.PASS,
					driver);

		} else {
			Logs.update("TC-38-Verify Instructions button", "Instructions button is NOT  working as Expected",
					Status.FAIL, driver);
		}
			}
	
	//Test case_TC33
	public static void verifyRedirect(WebDriver driver, String scheduleName,DriverScript Logs, String TestType, String entityCode,
			String schedule, String period, String TestCaseName) throws Exception {
			Actions actions = new Actions(driver);
	//driver = Login.LaunchHub("Setupurl", Logs);
	schedule = Util.getAllNecessaryData(TestType, "1798D", "ScheduleName");
	String postduedate = Util.getAllNecessaryData(TestType, "1798D", "FuruteDueDate");
	String priorduedate = Util.getAllNecessaryData(TestType, "1798D", "PastDueDate");
	
	Thread.sleep(3000);
	driver.findElement(HubHomePageObj.adminLink).click();
	Thread.sleep(3000);
	HubContributor.switchWindow(driver);
	Thread.sleep(4000);
	
	HubContributor.setValidDueDateVal(driver, scheduleName, HubAdminScreen.scheduleAttributeDueDateInput_3rdRow, Logs, postduedate, TestCaseName, TestType);
	Thread.sleep(2000);
	driver.switchTo().defaultContent();
	Thread.sleep(2000);
	
	HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityCode, period, schedule, Logs);
	actions = new Actions(driver);
	WebElement	entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);	
	actions.moveToElement(entityXpath).doubleClick().build().perform();
	Thread.sleep(2000);
	try {
		driver.findElement(HubHomePageObj.admintable_redirect).click();
		Logs.update("TC-33-1798D verify the Redirect post due date", "Redirect is working as expected", Status.PASS, driver);
	}
	catch(Exception e)
	{
		Logs.update("TC-33-1798D verify the Redirect post due date", "Redirect is Not working as expected", Status.FAIL, driver);
	}
	
	Thread.sleep(3000);
	actions.sendKeys(Keys.ENTER).build().perform();
	Thread.sleep(3000);
	driver = Login.LaunchHub("Setupurl", Logs);
	Thread.sleep(3000);
	driver.findElement(HubHomePageObj.adminLink).click();
	Thread.sleep(3000);
	HubContributor.switchWindow(driver);
	Thread.sleep(4000);
	HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityCode, period, schedule, Logs);
	actions = new Actions(driver);
	entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);	
	actions.moveToElement(entityXpath).doubleClick().build().perform();
	
		}

}
