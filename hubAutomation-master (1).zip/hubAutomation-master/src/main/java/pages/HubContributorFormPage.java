package pages;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.HubContributor;
import utils.ReadXML;
import utils.Util;

public class HubContributorFormPage {

	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();

	public static void openSchedule(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs) throws InterruptedException {
		Actions actions = new Actions(driver);
		//driver.findElement(HubHomePageObj.myDashBoardButton).click();
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		base.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		//String[] arrSplit = entityName.split(" ");
		//String entityDigits = arrSplit[0];
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
		Thread.sleep(4000);
		//driver.findElement(HubHomePageObj.selectSchedule).click();
		
		/**New change for schedule autosuggest**/
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(3000);
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='123';", scheduleFld);
		driver.findElement(HubHomePageObj.selectSchedule).sendKeys(schedule);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		/**Change complete**/
		
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(5000);
		//try{
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		/*}
		catch(Exception e){
			Logs.update("The entity is no longer present- Either Submitted or Expired, please update a new entity in the data-sheet", "Please open the datasheet under src->main->java->Utils->Datasheet.xls", Status.FAIL, driver);
		}*/
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		base.waitForElementTobeClickable(driver, HubContributorFormObj.btn_Add, 10);
		Thread.sleep(7000);
		Logs.update("Form should open", "Form is open ", Status.PASS, driver);
		driver.findElement(HubContributorFormObj.btn_Add).click();
		Thread.sleep(5000);

		try {
			boolean normalId = driver.findElement(HubContributorFormObj.lbl_IdNo).isDisplayed();
			Logs.update("The schedule should be distributed and be editable",
					"The schedule is distributed and be editable ", Status.PASS, driver);
		} catch (Exception e) {
			try {
				boolean resId = driver.findElement(HubContributorFormObj.lbl_Reserve_Id).isDisplayed();
				Logs.update("The schedule should be distributed and be editable",
						"The schedule is distributed and be editable ", Status.PASS, driver);
			} catch (Exception f) {
				Logs.update("The schedule should be distributed and be editable",
						"The schedule is not distributed and be editable ", Status.FAIL, driver);
			}
		}

	}
	
	public static void openScheduleRollFwDB(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs) throws InterruptedException {
		Actions actions = new Actions(driver);
		driver.findElement(HubHomePageObj.myDashBoardButton).click();
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(2000);
		base.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 10);
		//String[] arrSplit = entityName.split(" ");
		//String entityDigits = arrSplit[0];
		driver.findElement(HubHomePageObj.edt_EntityDeatils).clear();
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
		Thread.sleep(5000);
		//driver.findElement(HubHomePageObj.selectSchedule).click();
		/**New change for schedule autosuggest**/
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(3000);
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='123';", scheduleFld);
		driver.findElement(HubHomePageObj.selectSchedule).sendKeys(schedule);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		/**Change complete**/
		
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(3000);
		try{
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		}
		catch(Exception e){
			Logs.update("The entity is no longer present- Either Submitted or Expired, please update a new entity in the data-sheet", "Please open the datasheet under src->main->java->Utils->Datasheet.xls", Status.FAIL, driver);
		}
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		Thread.sleep(3000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		base.waitForElementTobeClickable(driver, HubContributorFormObj.btn_Add, 10);
		Thread.sleep(7000);
		Logs.update("Form should open", "Form is open ", Status.PASS, driver);
		
	}
	
	public static void openScheduleWithDataFromDB(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs) throws InterruptedException {
		Actions actions = new Actions(driver);
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		base.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).clear();
		Thread.sleep(2000);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
		Thread.sleep(4000);
		
		/**New change for schedule autosuggest**/
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(3000);
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='123';", scheduleFld);
		driver.findElement(HubHomePageObj.selectSchedule).sendKeys(schedule);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		/**Change complete**/
		//Thread.sleep(2000);
		//HubHomePageObj.findScheduleName(driver, schedule).click();
		
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();// only search
		Thread.sleep(3000);
		}
	
	//Created By Arindam
	public static void openScheduleFromStatusDashBoard(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs) throws InterruptedException {
		driver.findElement(HubHomePageObj.statusDashBoard).click();
		Thread.sleep(3000);
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		base.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).clear();
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
		Thread.sleep(4000);
		//driver.findElement(HubHomePageObj.scheduleButton).click();
		//Thread.sleep(2000);
		//HubHomePageObj.findScheduleName(driver, schedule).click();
		Actions actions=new Actions(driver);
		/**New change action
		 * for schedule autosuggest**/
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(3000);
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='123';", scheduleFld);
		driver.findElement(HubHomePageObj.selectSchedule).sendKeys(schedule);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		/**Change complete**/
		
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBoxStatusDB).clear();
		driver.findElement(HubHomePageObj.periodTextBoxStatusDB).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();// only search
		Thread.sleep(3000);
		}


		//String reserveNotExist=driver.findElement(HubContributorFormObj.existingGeneralReserves).getText();
	public static void OpenscheduleAddReserveIfNotPresent(WebDriver driver, String typeOfReserve, DriverScript Logs) throws InterruptedException {
		//WebElement TypeOfReserveXpath = HubHomePageObj.findDynamicXpathTypeOfReserve(driver, typeOfReserve);
		//boolean reserveExist=TypeOfReserveXpath.isDisplayed();
		//if(reserveExist==false){
			
		driver.findElement(HubContributorFormObj.btn_Add).click();
		Thread.sleep(5000);
		try {
			Thread.sleep(2000);
			boolean normalId = driver.findElement(HubContributorFormObj.lbl_Reserve_Id).isDisplayed();
			Logs.update("The schedule should be distributed and be editable",
					"The schedule is distributed and be editable ", Status.PASS, driver);
		} catch (Exception e) {

			Logs.update("Shedule is not open and not editable", "Shedule is not open and not editable", Status.FAIL, driver);
		}
		Form816ARollForwardDBPage.fillForm816A(driver);// If no record present then fill the data in form.  
			hubContributorFormObj.saveButton(driver).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			driver.findElement(HubContributorFormObj.existingGeneralResFirstRec).click();
			Thread.sleep(2000);

		/*}else{
			TypeOfReserveXpath.click();//click on the record data needs to be verified
			Thread.sleep(2000);
			}*/

	}
	
	public static void OpenscheduleAddReserveIfNotPresent815(WebDriver driver, String typeOfReserve, DriverScript Logs) throws Exception {
		//WebElement TypeOfReserveXpath = HubHomePageObj.findDynamicXpathTypeOfReserve(driver, typeOfReserve);
		//boolean reserveExist=TypeOfReserveXpath.isDisplayed();
		//if(reserveExist==false){
			
		driver.findElement(HubContributorFormObj.btn_Add).click();
		Thread.sleep(5000);
		try {
			Thread.sleep(2000);
			boolean normalId = driver.findElement(HubContributorFormObj.lbl_IdNo).isDisplayed();
			Logs.update("The schedule should be distributed and be editable",
					"The schedule is distributed and be editable ", Status.PASS, driver);
		} catch (Exception e) {

			Logs.update("Shedule is not open and not editable", "Shedule is not open and not editable", Status.FAIL, driver);
		}
		Form815APage.enterTransactionTaxAllData("testtype", driver, Logs);
		//Form815ARollForwardDBPage.fillForm815A(driver);// If no record present then fill the data in form.  
			hubContributorFormObj.saveButton(driver).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			//driver.findElement(HubContributorFormObj.existingGeneralResFirstRec).click();
			Thread.sleep(2000);

		/*}else{
			TypeOfReserveXpath.click();//click on the record data needs to be verified
			Thread.sleep(2000);
			}*/

	}
	
	//Created By Arindam
	public static String getDueDateValue(WebDriver driver, WebElement dueDateValue,DriverScript Logs) throws InterruptedException {
		Actions action=new Actions(driver);
		/*driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.findElement(HubAdminScreen.adminScreenButton).click();
		driver.findElement(HubAdminScreen.scheduleAttributeMaintenance).click();		
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);*/
		base.waitForElementTobeClickable(driver, HubAdminScreen.btn_Edit, 20);	
		String dueDateValAct=dueDateValue.getText();
		return dueDateValAct;
	}
	
	public static void searchScheduleFromAdminDashboard(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs) throws InterruptedException {
		
		driver.findElement(HubAdminScreen.adminDashboardButton).click();
		Thread.sleep(3000);
		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		base.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 20);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).clear();
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
		Thread.sleep(4000);
		//driver.findElement(HubHomePageObj.adminscheduleButton).click();
		Thread.sleep(2000);
		Actions actions=new Actions(driver);
		//HubHomePageObj.findScheduleName(driver, schedule).click();
		/**New change for schedule autosuggest**/
		actions.sendKeys(Keys.TAB).build().perform();
		Thread.sleep(3000);
		//JavascriptExecutor js = (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].value='123';", scheduleFld);
		driver.findElement(HubHomePageObj.selectSchedule).sendKeys(schedule);
		Thread.sleep(2000);
		actions.sendKeys(Keys.ENTER).build().perform();
		/**Change complete**/
		
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBoxStatusDB).clear();
		driver.findElement(HubHomePageObj.periodTextBoxStatusDB).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();// only search
		Thread.sleep(3000);
		}
	
	public static void openScheduleAttributeManitenancePage(WebDriver driver,DriverScript Logs) throws InterruptedException {
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(3000);
		driver.findElement(HubAdminScreen.adminScreenButton).click();
		driver.findElement(HubAdminScreen.scheduleAttributeMaintenance).click();			
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
	}
	
	public static void setDueDateForSchedule(WebDriver driver, WebElement dueDateField,WebElement dueDateValue, String dateToSet,DriverScript Logs) throws InterruptedException {
		Actions action=new Actions(driver);
			/*driver.findElement(HubHomePageObj.adminLink).click();
			Thread.sleep(3000);
			HubContributor.switchWindow(driver);
			driver.findElement(HubAdminScreen.adminScreenButton).click();
			driver.findElement(HubAdminScreen.scheduleAttributeMaintenance).click();			
			WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
			driver.switchTo().frame(Frame);*/
			base.waitForElementTobeClickable(driver, HubAdminScreen.btn_Edit, 20);
			action.moveToElement(dueDateField).doubleClick().build().perform();
			Thread.sleep(4000);
			dueDateValue.clear();
			Thread.sleep(2000);
			dueDateValue.sendKeys(dateToSet);
			Thread.sleep(2000);
			driver.findElement(HubAdminScreen.btn_Save).click();
			Thread.sleep(2000);
			driver.findElement(HubAdminScreen.btn_RefreshView).click();
			
		}	
	
	
	public static void taxYearFieldValidation(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		String fromTaxyear = Util.getAllNecessaryData(TestType, TestCaseName, "FromTaxYear");
		String toTaxyear = Util.getAllNecessaryData(TestType, TestCaseName, "ToTaxYear");

		// relating to Tax year field
		Thread.sleep(2000);
		hubContributorFormObj.fromTaxYearName(driver).sendKeys(fromTaxyear);
		Thread.sleep(2000);
		hubContributorFormObj.toTaxYearName(driver).sendKeys(toTaxyear);
		Thread.sleep(2000);
		hubContributorFormObj.saveButton(driver).click();
		Thread.sleep(3000);
		// validate success
		if ((hubContributorFormObj.successMessage(driver).getText()).equalsIgnoreCase("Success")) {
			Logs.update("We should get a success messgae when from Tax year is lesser than to Tax year",
					"Success Message appears", Status.PASS, driver);
		} else {
			Logs.update("We should get a success messgae when from Tax year is lesser than to Tax year",
					"Success Message does not appear", Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(3000);
		// relating to Tax year field negative scenario
		hubContributorFormObj.fromTaxYearName(driver).clear();
		Thread.sleep(1000);
		hubContributorFormObj.toTaxYearName(driver).clear();
		Thread.sleep(2000);
		hubContributorFormObj.fromTaxYearName(driver).sendKeys(toTaxyear);
		hubContributorFormObj.toTaxYearName(driver).sendKeys(fromTaxyear);
		hubContributorFormObj.saveButton(driver).click();
		// validate success
		if ((hubContributorFormObj.invalidMessage(driver).getText())
				.equalsIgnoreCase("To Tax Year should be greater than From Tax Year")) {
			Logs.update("We should get a Warning messgae when To Tax year is lesser than From Tax year",
					"Warning Message appears", Status.PASS, driver);
		} else {
			Logs.update("We should get a Warning messgae when To Tax year is lesser than From Tax year",
					"Warning Message does not appear", Status.FAIL, driver);
		}

		// equal
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(3000);
		hubContributorFormObj.fromTaxYearName(driver).clear();
		Thread.sleep(1000);
		hubContributorFormObj.toTaxYearName(driver).clear();
		Thread.sleep(2000);
		hubContributorFormObj.fromTaxYearName(driver).sendKeys(toTaxyear);
		hubContributorFormObj.toTaxYearName(driver).sendKeys(toTaxyear);
		hubContributorFormObj.saveButton(driver).click();
		// validate success
		if ((hubContributorFormObj.successMessage(driver).getText()).equalsIgnoreCase("Success")) {
			Logs.update("We should get a success messgae when From Tax year is same as To Tax year",
					"Success Message appears", Status.PASS, driver);
		} else {
			Logs.update("We should get a success messgae when From Tax year is same as To Tax year",
					"Success Message does not appear", Status.FAIL, driver);
		}

	}
	
	public static void openAdminLink(WebDriver driver, DriverScript Logs) throws InterruptedException {
		driver.findElement(HubHomePageObj.hub2Button).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(2500);
		HubContributor.switchWindow(driver);// to switch to newly open window
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubAdminScreen.adminDashboardButton, 10);
		Logs.update("Admin window should get opened", "Admin window opened succesfully", Status.PASS, driver);
		}	
	
}
