package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubContributorFormObj;
import utils.Base_class;
import utils.HubContributor;

public class Form816APage_WithoutAllData {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();

	public static void begBalanceDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.edt_BegBalance, 10);
		WebElement begBal=driver.findElement(HubContributorFormObj.begBalance);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_44 Beg Balance", begBal, Logs);
	}

	public static void charge_to_PL_FieldDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.edt_ChargeToPLField, 10);
		WebElement ChargePL=driver.findElement(HubContributorFormObj.chargeToPL);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_51 Charge to PL", ChargePL, Logs);
	}

	public static void return_to_PL_FieldDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.returnedToPL, 10);
		WebElement returnToPL=driver.findElement(HubContributorFormObj.returnedToPL);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_59 Return to PL", returnToPL, Logs);
	}

	public static void use_for_intended_FieldDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.useForIntended_816, 10);
		WebElement useForInt=driver.findElement(HubContributorFormObj.returnedToPL);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_67 Use for Intended", useForInt, Logs);
	}

	public static void translationDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.translation_816, 10);
		WebElement transl=driver.findElement(HubContributorFormObj.translation_816);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_75 Translation", transl, Logs);
	}
	
	public static void reClassDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName ){
		
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.reClass_816, 10);
		WebElement reClas=driver.findElement(HubContributorFormObj.reClass_816);
		HubContributor.verifyDefaultValueIsZero(driver, TestType, "TC_82 Reclass", reClas, Logs);
	}
	
	public static void endingBalanceDefaultVal(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName ){
		
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.endingBalance, 10);
		
		/*
		 * Test Case TC92 816A Verify Ending Balance: The default value should be 0 and field should be non editable
		 */
		String DefaultValue = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("value");
		String endBalEditable = driver.findElement(HubContributorFormObj.endingBalance).getAttribute("class");
		int toIntDefaultValue = Integer.parseInt(DefaultValue);
		Assert.assertEquals(toIntDefaultValue, 0);
		if (toIntDefaultValue == 0 && endBalEditable.contains("readonly")) {
			Logs.update("TC92 816A Verify ending Balance ", "The default value is 0 and field is not editable", Status.PASS, driver);	
		}else{
			Logs.update("TC92:Default value should be 0", "Default value is not 0 and field is editable"  , Status.FAIL, driver);
		}
	}
	public static void explanationOfReclassifications_Default(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName ) throws Exception{
	WebElement ele = driver.findElement(HubContributorFormObj.explanationofReclassifications_816);
	HubContributor.checkIfUserIsAbleToEnter(driver, TestType, TestCaseName, ele, Logs, "TC104 816A Verify Explanation of Reclassifications", "ScheduleName");
//	ele.sendKeys(ReadXML.readData("TC_816A", "explainationOfReclassification"));
}

}
