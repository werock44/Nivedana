package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.ReadXML;
import utils.Util;

public class Form814ARollForwardDBPage {
	public static String schedule;
	public static String entityName;
	public static String period;
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	
	public static void fillForm814A(WebDriver driver) throws InterruptedException{
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.lbl_IdNo, 10);
		hubContributorFormObj.fromTaxYearName(driver).clear();
		hubContributorFormObj.fromTaxYearName(driver).sendKeys(ReadXML.readData("TC_814A", "fromTaxYear"));
		hubContributorFormObj.toTaxYearName(driver).clear();
		hubContributorFormObj.toTaxYearName(driver).sendKeys(ReadXML.readData("TC_814A", "toTaxYear"));
		hubContributorFormObj.currentTaxRate(driver).clear();
		hubContributorFormObj.currentTaxRate(driver).sendKeys(ReadXML.readData("TC_814A", "currTaxRate"));
		driver.findElement(HubContributorFormObj.drpDown_Status).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.statusValue_Undiscovered).click();
		driver.findElement(HubContributorFormObj.edt_ShortDescription).clear();
		driver.findElement(HubContributorFormObj.edt_ShortDescription).sendKeys(ReadXML.readData("TC_814A", "shortDescription"));
		driver.findElement(HubContributorFormObj.edt_LongDescription).clear();
		driver.findElement(HubContributorFormObj.edt_LongDescription).sendKeys(ReadXML.readData("TC_814A", "longDescription"));
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).clear();
		driver.findElement(HubContributorFormObj.edt_StatusOfReserve).sendKeys(ReadXML.readData("TC_814A", "statusOfReserve"));
		driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).clear();
		driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled).sendKeys(ReadXML.readData("TC_814A", "TaxBenifitFiled"));
		driver.findElement(HubContributorFormObj.potentialInterestLocal).clear();
		driver.findElement(HubContributorFormObj.potentialInterestLocal).sendKeys(ReadXML.readData("TC_814A", "PotentialInterestAndPenalities"));
		driver.findElement(HubContributorFormObj.potentialInterestLocal).sendKeys(Keys.TAB);
		driver.findElement(HubContributorFormObj.drpDown_ReognitionThreshold).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.ReognitionThreshold_MoreThan50).click();;
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).clear();
		driver.findElement(HubContributorFormObj.edt_ExpectedBenifit).sendKeys(ReadXML.readData("TC_814A", "ExpectedBenifit"));
		driver.findElement(HubContributorFormObj.drpDown_GLAccountReserve).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.GLAccountReserve_147350).click();
		driver.findElement(HubContributorFormObj.drpDown_GLAccountInterestPenalities).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.val_GLAccountInterestPenalities268200).click();
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).clear();
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).sendKeys(ReadXML.readData("TC_814A", "AccuredInterest"));		
		driver.findElement(HubContributorFormObj.edt_AccuredInterestPenalities).sendKeys(Keys.TAB);
	}

	// Test Id# TC68
	public static void statusOfResPrevFY(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
			throws Exception {
		// Before test open schedule is not required for this since period is
		// different for each test cases.
		schedule = Util.getAllNecessaryData(TestType, "814ADB", "ScheduleName");
		//entityName = Util.getAllNecessaryData(TestType, "814ADB", "EntityDetail");
		String PeriodPrevFYQ4 = Util.getAllNecessaryData(TestType, "814ADB", "PeriodPrevFYQ4");//Search for a schedule of Q4 for prev FY.
		String PeriodCurFYQ1 = Util.getAllNecessaryData(TestType, "814ADB", "PeriodCurFYQ1");
		String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", PeriodPrevFYQ4);
		//String bugoID="BU515GOHN";
		System.out.println(bugoID);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		//Get entity code for above bugo id
		String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		//String entityCode="5511";
		System.out.println(entityCode);
	     //Distribute the schedule for Q4 previous year
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodPrevFYQ4);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		//Distribute the schedule for current year quarter
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ1);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);		
		HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, PeriodPrevFYQ4, schedule, Logs);
		//WebElement existingReserveRec=HubHomePageObj.findDynamicXpathReserveGLAcc(driver, "147350-LTNotes/AcctsRec-IncomeTax-Other");
		//existingReserveRec.click();
		driver.findElement(HubContributorFormObj.btn_Add).click();
		Thread.sleep(5000);
		Form814ARollForwardDBPage.fillForm814A(driver);
		Thread.sleep(2000);
		driver.findElement(HubContributorFormObj.drpDown_Status).click();
		Thread.sleep(1000);
		driver.findElement(HubContributorFormObj.statusValue_Resolved).click();
		hubContributorFormObj.saveButton(driver).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		//driver.findElement(HubContributorFormObj.existingGeneralResFirstRec).click();
		Thread.sleep(2000);	
		//to capture status=resolved
		driver.findElement(HubContributorFormObj.drpDown_Status).click();
		Thread.sleep(1000);
		String valueSelected=driver.findElement(HubContributorFormObj.statusDropDown).getAttribute("class");
		if(valueSelected.contains("selected")){
			Logs.update("Verify that exsting reserve status is resolved in Previous FY", "exsting reserve status is resolved in Previous FY", Status.PASS, driver);
		}else{
			Logs.update("Verify that exsting reserve status is resolved in Previous FY", "exsting reserve status is Not resolved in Previous FY", Status.FAIL, driver);
		}
		
		HubContributor.switchWindow(driver);
		
		HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ1, schedule, Logs);
		Thread.sleep(2000);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
		boolean schedulePresent = entityXpath.isDisplayed();
		HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
		String allReservesinThePage=driver.findElement(By.tagName("body")).getText();
		boolean isReservePresent=allReservesinThePage.contains("147350-LTNotes/AcctsRec-IncomeTax-Other");
		Assert.assertFalse(isReservePresent);
		if(isReservePresent==false){
			Logs.update("TC_68 Reserve with status resolved should not get rolled forwarded to next FY", " Reserve with status resolved is not rolled forwarded to next FY", Status.PASS, driver);	
		}else{
			Logs.update("TC_68 Reserve with status resolved should not get rolled forwarded to next FY", " Reserve with status resolved has got rolled forwarded to next FY", Status.FAIL, driver);
		}
		

	}

	// Test Id# TC69
		public static void statusOfResCurrentFYQ1ToQ2(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
				throws Exception {
			// Before test open schedule is not required for this since period is
			// different for each test cases.
			schedule = Util.getAllNecessaryData(TestType, "814ADB", "ScheduleName");
			//entityName = Util.getAllNecessaryData(TestType, "814ADB", "EntityDetail");
			String PeriodCurFYQ1 = Util.getAllNecessaryData(TestType, "814ADB", "PeriodCurFYQ1");//Search for a schedule of Q1 for current FY.
			String PeriodCurFYQ2 = Util.getAllNecessaryData(TestType, "814ADB", "PeriodCurFYQ2");
			String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", PeriodCurFYQ1);
			//String bugoID="BU515GOHN";
			System.out.println(bugoID);
			String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
					+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
			//Get entity code for above bugo id
			String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
			//String entityCode="5511";
			System.out.println(entityCode);
		     //Distribute the schedule for Q4 previous year
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ1);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);
			//Distribute the schedule for current year quarter
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ2);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);					
			HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, PeriodCurFYQ1, schedule, Logs);
			//WebElement existingReserveRec=HubHomePageObj.findDynamicXpathReserveGLAcc(driver, "229670-APAccrExp-IncomeTax-Other");// for Q1 of current year
			//existingReserveRec.click();
			driver.findElement(HubContributorFormObj.btn_Add).click();
			Thread.sleep(5000);
			Form814ARollForwardDBPage.fillForm814A(driver);
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.drpDown_Status).click();
			Thread.sleep(1000);
			driver.findElement(HubContributorFormObj.statusValue_Resolved).click();
			hubContributorFormObj.saveButton(driver).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Thread.sleep(2000);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.lbl_IdNo, 10);
			//to capture status=resolved
			driver.findElement(HubContributorFormObj.drpDown_Status).click();
			Thread.sleep(1000);
			String valueSelected=driver.findElement(HubContributorFormObj.statusDropDown).getAttribute("class");
			if(valueSelected.contains("selected")){
				Logs.update("Verify that exsting reserve status is resolved in Previous FY", "exsting reserve status is resolved in Previous FY", Status.PASS, driver);
			}else{
				Logs.update("Verify that exsting reserve status is resolved in Previous FY", "exsting reserve status is Not resolved in Previous FY", Status.FAIL, driver);
			}
			
			HubContributor.switchWindow(driver);
			HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ2, schedule, Logs);
			Thread.sleep(2000);
			WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
			boolean schedulePresent = entityXpath.isDisplayed();
			HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
			Thread.sleep(2000);
			WebElement existingReserveRecInQ2=HubHomePageObj.findDynamicXpathReserveGLAcc(driver, "147350-LTNotes/AcctsRec-IncomeTax-Other");
			boolean isReservePresent=existingReserveRecInQ2.isDisplayed();
			Assert.assertTrue(isReservePresent);
			if(isReservePresent==true){
				Logs.update("TC_69 Reserve with status resolved should get rolled forwarded to Q2 from Q1 of current FY", "Reserve with status resolved is getting rolled forwarded to Q2 from Q1 of current FY", Status.PASS, driver);	
			}else{
				Logs.update("TC_69 Reserve with status resolved should get rolled forwarded to Q2 from Q1 of current FY", " Reserve with status resolved is not getting rolled forwarded to Q2 from Q1 of current FY", Status.FAIL, driver);
			}
			

		}
		
		//Test Id: TC70: This test case will be executed the Q3 and Q4 is available in the system current year.
		public static void statusOfResCurrentFYQ3ToQ4(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
				throws Exception {
			// Before test open schedule is not required for this since period is
			// different for each test cases.
			schedule = Util.getAllNecessaryData(TestType, "814ADB", "ScheduleName");
			//entityName = Util.getAllNecessaryData(TestType, "814ADB", "EntityDetail");
			String PeriodCurFYQ3 = Util.getAllNecessaryData(TestType, "814ADB", "PeriodCurFYQ3");//Search for a schedule of Q3 for current FY.
			String PeriodCurFYQ4 = Util.getAllNecessaryData(TestType, "814ADB", "PeriodCurFYQ4");
			String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", PeriodCurFYQ3);
			//String bugoID="BU515GOHN";
			System.out.println(bugoID);
			String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
					+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
			//Get entity code for above bugo id
			String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
			//String entityCode="5511";
			System.out.println(entityCode);
		     //Distribute the schedule for Q4 previous year
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ3);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);
			//Distribute the schedule for current year quarter
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, PeriodCurFYQ4);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);	
			HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, PeriodCurFYQ3, schedule, Logs);
			//WebElement existingReserveRec=HubHomePageObj.findDynamicXpathReserveGLAcc(driver, "229670-APAccrExp-IncomeTax-Other");// for Q1 of current year
			//existingReserveRec.click();
			driver.findElement(HubContributorFormObj.btn_Add).click();
			Thread.sleep(5000);
			Form814ARollForwardDBPage.fillForm814A(driver);
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.drpDown_Status).click();
			Thread.sleep(1000);
			driver.findElement(HubContributorFormObj.statusValue_Resolved).click();
			hubContributorFormObj.saveButton(driver).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Thread.sleep(2000);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.lbl_IdNo, 10);
			//to capture status=resolved
			driver.findElement(HubContributorFormObj.drpDown_Status).click();
			Thread.sleep(1000);
			String valueSelected=driver.findElement(HubContributorFormObj.statusDropDown).getAttribute("class");
			if(valueSelected.contains("selected")){
				Logs.update("Verify that exsting reserve status is resolved in Previous FY", "exsting reserve status is resolved in Previous FY", Status.PASS, driver);
			}else{
				Logs.update("Verify that exsting reserve status is resolved in Previous FY", "exsting reserve status is Not resolved in Previous FY", Status.FAIL, driver);
			}
			
			HubContributor.switchWindow(driver);
			HubContributor.searchSchedule(driver, entityCode, PeriodCurFYQ4, schedule, Logs);
			Thread.sleep(2000);
			WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityCode);
			boolean schedulePresent = entityXpath.isDisplayed();
			HubContributor.addOrOpenExistingSchedule(driver, schedulePresent, entityXpath);
			WebElement existingReserveRecInQ2=HubHomePageObj.findDynamicXpathReserveGLAcc(driver, "147350-LTNotes/AcctsRec-IncomeTax-Other");
			boolean isReservePresent=existingReserveRecInQ2.isDisplayed();
			//String allReservesinThePage=driver.findElement(By.tagName("body")).getText();
			//boolean isReservePresent=allReservesinThePage.contains("147350-LTNotes/AcctsRec-IncomeTax-Other");
			Assert.assertTrue(isReservePresent);
			if(isReservePresent==true){
				Logs.update("TC_70 Reserve with status resolved should get rolled forwarded from Q3 to Q4 of current FY", "Reserve with status resolved is getting rolled forwarded from Q3 to Q4 of current FY", Status.PASS, driver);	
			}else{
				Logs.update("TC_70 Reserve with status resolved should get rolled forwarded  from Q3 to Q4 of current FY", " Reserve with status resolved is not getting rolled forwarded from Q3 to Q4 of current FY", Status.FAIL, driver);
			}
			

		}
		//R0 CR_TC003
		public static void verifyExpectedPercBenifit(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
				throws Exception {
			schedule = Util.getAllNecessaryData(TestType, "814ADB", "ScheduleName");
			String Period = Util.getAllNecessaryData(TestType, "814ADB", "Period");//Search for a schedule of Q1 for current FY.
			String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", Period);
			//String bugoID="BU522GOPK";
			System.out.println(bugoID);
			String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
			//Get entity code for above bugo id
			String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
			//String entityCode="7903";
			System.out.println(entityCode);
		     //Distribute the schedule 
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, Period);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);					
			HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, Period, schedule, Logs);
			driver.findElement(HubContributorFormObj.btn_Add).click();
			Thread.sleep(5000);
			Form814ARollForwardDBPage.fillForm814A(driver);
			Thread.sleep(2000);
			WebElement taxBenifitField=driver.findElement(HubContributorFormObj.edt_TaxBenifitFiled);
			WebElement expBenifitField=driver.findElement(HubContributorFormObj.edt_ExpectedBenifit);
			//Enter negative value in expected percentage field
			Actions actions = new Actions(driver);
			expBenifitField.clear();
			expBenifitField.sendKeys("-12.12");
			expBenifitField.sendKeys(Keys.TAB);
			actions.moveToElement(expBenifitField).perform();
			String errMsg = expBenifitField.getAttribute("class");
			if(errMsg.contains("invalid validationMouseOver")){
				Logs.update("R0 CR_TC003.1 verify only positive numbers are accepted in expected percentage benifit field", "Error is displayed when negative numbers are enterd", Status.PASS, driver);
			}else{
				Logs.update("R0 CR_TC003.1 verify only positive numbers are accepted in expected percentage benifit field", "Error is not displayed when negative numbers are enterd", Status.FAIL, driver);
			}
			Thread.sleep(3000);
			expBenifitField.clear();
			expBenifitField.sendKeys("9");
			taxBenifitField.clear();
			taxBenifitField.sendKeys("199");
			hubContributorFormObj.saveButton(driver).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			String valInUnrecognizedTaxBenifitField = driver.findElement(HubContributorFormObj.edt_UnrecognizedTaxBenifit).getAttribute("value");
			Logs.update("Verify that Unrecognized tax benefit field is rounded off to nearest whole number", "Unrecognized tax benefit field is rounded off to nearest whole number: "+valInUnrecognizedTaxBenifitField, Status.PASS, driver);
			
			String queryToGetExpBenTax="Select top 1 [ExpectedBenefit%Loc] from dbo.schedule814A where entitycode='"+ entityCode+ "'";
			String expectedBenefitVal=DataBaseConnection.getData(driver, Logs, TestType, queryToGetExpBenTax, "ExpectedBenefit%Loc");
			String[] decVal=expectedBenefitVal.split("[.]");	
			int sizeAfterDecimal=decVal[1].length();
			System.out.println(sizeAfterDecimal);
			//Verify that up to 2 decimal value is saved in DB
			if(sizeAfterDecimal==2){
				Logs.update("R0 CR_TC003.2 Verify that Data is saved in DB with 2 decimal place", "Data is saved in DB upto 2 decimal place: "+expectedBenefitVal, Status.PASS, driver);
			}else{
				Logs.update("R0 CR_TC003.2 Verify that Data is saved in DB with 2 decimal place", "Data is not saved in DB upto 2 decimal place: "+expectedBenefitVal, Status.FAIL, driver);
			}
			

		}
		
		//CR_TC004_Check the variance fields
		public static void verifyVariancefield(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
				throws Exception {
			schedule = Util.getAllNecessaryData(TestType, "814ADB", "ScheduleName");
			String Period = Util.getAllNecessaryData(TestType, "814ADB", "Period");//Search for a schedule of Q1 for current FY.
			String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", Period);
			//String bugoID="BU522GOPK";
			System.out.println(bugoID);
			String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
					+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
			//Get entity code for above bugo id
			String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
			//String entityCode="7903";
			System.out.println(entityCode);
		     //Distribute the schedule 
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, Period);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);					
			HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, Period, schedule, Logs);
			driver.findElement(HubContributorFormObj.btn_Add).click();
			Thread.sleep(5000);
			Form814ARollForwardDBPage.fillForm814A(driver);
			Thread.sleep(2000);
			// Code to verify
			driver.findElement(By.xpath("//a[text()='Summary Report']")).click();
			Thread.sleep(3000);
			String winHandle2= driver.getWindowHandle();
			HubContributor.switchWindow_3(driver);// to switch to newly open window
		Thread.sleep(3000);
			String reserveTotal = driver.findElement(By.xpath("//*[@name='tbReserveTotals268200']")).getAttribute("value");
			System.out.println(reserveTotal);
			reserveTotal = driver.findElement(By.xpath("//*[@name='tbReserveTotals147350']")).getAttribute("value");
			System.out.println(reserveTotal);
			
			List<WebElement> ele=driver.findElements(By.xpath("//*[starts-with(@name,'tbVariance1')]"));
			if (ele.size() == 0)
			{
				Logs.update("CR_TC004_Check the variance fields ", "Variance field Not displayed for account starting with 1", Status.PASS, driver);
			}
			
			else 
			{
				Logs.update("CR_TC004_Check the variance fields ", "Variance field displayed for account starting with 1", Status.FAIL, driver);
			}
			
			
	// CR - CR_TC005
			Thread.sleep(3000);
			String variance = driver.findElement(By.xpath("//*[@name='tbVariance268200']")).getAttribute("value");
			driver.switchTo().window(winHandle2);
			Thread.sleep(2000);

			//driver.findElement(By.name("btnSubmit")).click();
			
			
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			String expSubmitMsg = Util.getAllNecessaryData(TestType, "814ADB", "Submit_popUp_Msg");
			String actPopUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Assert.assertEquals(actPopUpMsg, expSubmitMsg);
			if(actPopUpMsg.equalsIgnoreCase(expSubmitMsg))
				{
					Logs.update("R0 CR_TC005 Verify the pop up message on Submit",
							"Expected and Actual pop up message are same: Expected_ " + expSubmitMsg + " Actual_" +actPopUpMsg, Status.PASS, driver);
				} else {
					Logs.update("R0 CR_TC005 Verify the pop up message on Submit",
							"Expected and Actual pop up message are NOT same: Expected_ " + expSubmitMsg + " But found_ "+actPopUpMsg, Status.FAIL, driver);
				}
			
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			String submitSuccess=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Assert.assertEquals(submitSuccess, "Your form has been submitted successfully!!");
			if(submitSuccess.equalsIgnoreCase("Your form has been submitted successfully!!")){
				Logs.update("R0 CR_TC005 verify user is able to submit when variance is  zero", "Able to submit as expected", Status.PASS, driver);
			}else{
				Logs.update("R0 CR_TC005 verify user is able to submit when variance is  zero", "Not Able to submit when variance is zero", Status.FAIL, driver);
			}
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(4000);
			driver.switchTo().alert().accept();				
		}
		
			
		
		//R0_CR_TC006, TC007
		public static void verifyAbleToSubmitWithVarianceNonZero(WebDriver driver, DriverScript Logs, String TestType, String TestCaseName)
				throws Exception {
			
			schedule = Util.getAllNecessaryData(TestType, "814ADB", "ScheduleName");
			String Period = Util.getAllNecessaryData(TestType, "814ADB", "Period");//Search for a schedule of Q1 for current FY.
			String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "A3C4AA2A-9178-40DB-972C-BAF2A2A0BDB9", Period);
			//String bugoID="BU522GOPK";
			System.out.println(bugoID);
			String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
					+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
			//Get entity code for above bugo id
			String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
			//String entityCode="7903";
			System.out.println(entityCode);
		     //Distribute the schedule 
			HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, Period);
			driver.quit();
			driver = Login.LaunchHub("Setupurl", Logs);					
			HubContributorFormPage.openScheduleRollFwDB(driver, entityCode, Period, schedule, Logs);
			driver.findElement(HubContributorFormObj.btn_Add).click();
			Thread.sleep(5000);
			Form814ARollForwardDBPage.fillForm814A(driver);
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.drpDown_GLAccountReserve).click();
			Thread.sleep(1000);
			driver.findElement(HubContributorFormObj.GLAccountReserve_229670).click();
			hubContributorFormObj.saveButton(driver).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			// Click on Summary Report
			driver.findElement(By.xpath("//a[text()='Summary Report']")).click();
			Thread.sleep(3000);
			String currwindow=driver.getWindowHandle();
			HubContributor.switchWindow_3(driver);// to switch to newly open window
		Thread.sleep(3000);
		String varianceSum=driver.findElement(By.xpath("//*[@name='tbVariance229670']")).getAttribute("value");
			if(!varianceSum.equalsIgnoreCase("0")){
			Logs.update("R0 CR_TC006 verify that variance field is not zero" , "Veriance field is not zero", Status.PASS, driver);
			driver.close();
			driver.switchTo().window(currwindow);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			String expSubmitMsg = Util.getAllNecessaryData(TestType, "814ADB", "Submit_popUp_Msg");
			String actPopUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Assert.assertEquals(actPopUpMsg, expSubmitMsg);
			if(actPopUpMsg.equalsIgnoreCase(expSubmitMsg))
				{
					Logs.update("R0 CR_TC007 Verify the pop up message on Submit",
							"Expected and Actual pop up message are same: Expected_ " + expSubmitMsg + " Actual_" +actPopUpMsg, Status.PASS, driver);
				} else {
					Logs.update("R0 CR_TC007 Verify the pop up message on Submit",
							"Expected and Actual pop up message are NOT same: Expected_ " + expSubmitMsg + " But found_ "+actPopUpMsg, Status.FAIL, driver);
				}
			
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(2000);
			String submitSuccess=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Assert.assertEquals(submitSuccess, "Your form has been submitted successfully!!");
			if(submitSuccess.equalsIgnoreCase("Your form has been submitted successfully!!")){
				Logs.update("R0 CR_TC006 verify user is able to submit when variance is not zero", "Able to submit as expected", Status.PASS, driver);
			}else{
				Logs.update("R0 CR_TC006 verify user is able to submit when variance is not zero", "Not Able to submit when variance is not zero", Status.PASS, driver);
			}
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(4000);
			driver.switchTo().alert().accept();				
		}else{
			Logs.update("R0 CR_TC006 verify that varience is not zero", "Variance field zero please try with another account", Status.FAIL, driver);
		}	
				
		}
}

	

	

