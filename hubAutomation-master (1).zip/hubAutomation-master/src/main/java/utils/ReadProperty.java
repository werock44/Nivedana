/**
 * 
 */
package utils;
//import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
/**
 * @author s627207
 *
 */
public class ReadProperty {
	protected Properties prop=null;
	protected InputStream inputFile;
	
	public ReadProperty(String FileName) //throws IOException
	{	

		inputFile=ReadProperty.class.getClassLoader().getResourceAsStream(FileName);
		prop=new Properties();

		try
		{
			if(inputFile!=null)
				prop.load(inputFile);
			else {
				System.out.println("prop input stream null");
				
			}
		}
		catch(Exception ex){System.out.println("IO,err .Property file went wrong\n"+ex.toString());
		System.out.println(inputFile.toString());}
	}
	
	public String getProp(String str)
	{
		String ss;
		ss=prop.getProperty(str);
		System.out.println(str+":"+ss);
		return 	ss;
	}
}
