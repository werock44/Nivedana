/**
 * 
 */
package utils;
import java.time.Duration;
import static java.util.concurrent.TimeUnit.*;

import java.sql.Driver;

import org.openqa.selenium.support.ui.FluentWait;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Predicate;

import Reports.DriverScript;
import Reports.Status;


import org.openqa.selenium.NoSuchElementException;
import java.util.function.Function;






/**
 * @author s627207
 *
 */
public class Base_class {
	protected static int count =3;
	static Base_class base = new Base_class();
	public static String AccountName = null;
	public static int staticwait = 10;

	public static String formatString(String Value){
		Value= Value.trim();
		if (!Value.equals("Slaughterhouse -  Geese") )
		{
			Value = Value.replaceAll("( )+", " ");
		}
		else
		{
			Value= 	Value.trim();
		}
		return Value;

	}
	public void change_frame(WebDriver driver,String title) throws InterruptedException {
		WebElement element = driver.findElement(By.xpath("//iframe[@title='"+title+"']"));
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOf(element));
		Thread.sleep(10000);
		driver.switchTo().frame(element);
	}

	public static void implicitewait(WebDriver driver) {

		driver.manage().timeouts().implicitlyWait(staticwait, TimeUnit.SECONDS);
	}

	public static void PageLoad(WebDriver driver) {

		//Boolean wait = new WebDriverWait(driver, staticwait).until(
		//       webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
		//return wait;
	}

	public static void selectElementselectByVisibleText(WebDriver driver,By arg0,String DropDownValue) {
		Select dropdown= new Select(driver.findElement(arg0));
		dropdown.selectByVisibleText(DropDownValue);
	}

	public static void ScrollPage(int x,int y,WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy("+x+","+y+")");
	}

	public static WebElement waitForElementToVisible(WebDriver driver,By arg0,int seconds) {
		WebDriverWait wait = new WebDriverWait(driver,seconds);
		WebElement element1 = wait.until(ExpectedConditions.visibilityOf(driver.findElement(arg0)));
		return element1;
	}

	public static WebElement waitForElementTobeClickable(WebDriver driver,By arg0,int seconds) {
		WebElement e=driver.findElement(arg0);
		WebDriverWait wait = new WebDriverWait(driver,seconds);
		WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(e));
		return element1;
	}


	public static ArrayList<String> getDropDownValues(String accountType, String FieldName, String DataSheet) throws Exception
	{
		ArrayList<String> Options = new ArrayList<String>();
		short lastcolumn = SpreadSheetOperation.getLastCellNumofHeader(DataSheet);
		for (int m=1;m<=lastcolumn-1;m++)
		{
			String Value = SpreadSheetOperation.getDatadynamic(DataSheet,accountType,FieldName,"Option"+m);
			Value= formatString(Value);


			if (Value.equals(""))
			{
				break;
			}
			else
			{
				Options.add(Value);
			}
		}
		return Options;



	}
	
	
	public static ArrayList<String> getTabValues(String Buisness, String DataSheet) throws Exception
	{
		ArrayList<String> Options = new ArrayList<String>();
		short lastcolumn = SpreadSheetOperation.getLastCellNumofHeader(DataSheet);
		for (int m=1;m<=lastcolumn-1;m++)
		{
			String Value = SpreadSheetOperation.getData(Buisness,DataSheet,"Tab"+m);
			Value= formatString(Value);


			if (Value.equals(""))
			{
				break;
			}
			else
			{
				Options.add(Value);
			}
		}
		return Options;
	}
	public static ArrayList<String> getRecordTypeValues(String Buisness, String DataSheet) throws Exception
	{
		ArrayList<String> Options = new ArrayList<String>();
		short lastcolumn = SpreadSheetOperation.getLastCellNumofHeader(DataSheet);
		for (int m=1;m<=lastcolumn-1;m++)
		{
			String Value = SpreadSheetOperation.getData(Buisness,DataSheet,"RecordType"+m);
			Value= formatString(Value);


			if (Value.equals(""))
			{
				break;
			}
			else
			{
				Options.add(Value);
			}
		}
		return Options;
	}

	
	
	
	
	
	
	public static void SalesforcecomboBoxoptionMatch(WebDriver driver, By arg0, ArrayList<String> Options, String txt, DriverScript Logs) throws InterruptedException 
	{		
	
		driver.findElement(arg0).click();
		Boolean present=false;
		//	int count= Options.size() ;

		int i;

		Thread.sleep(1000);

		waitpolling(driver, By.xpath("//body/div[last()]/div/ul/li/a[text()='--None--']"), 5);

		
		
		for (String opt:Options)  
		{  

			List<WebElement> e=driver.findElements(By.xpath("//body/div[last()]//ul/li/a[text()='" + opt +"']"));

			if (e.size()<=0)
			{
				System.out.println(opt +" is not present");
				Logs.update(txt, opt +" is not present", Status.FAIL,driver);
			}


		}


	}


	public static void SalesforceComboboxNewMatch(WebDriver driver, By arg0, ArrayList<String> Options, String txt, DriverScript Logs) throws InterruptedException 
	{		
		driver.findElement(arg0).click();
		 
	//	Boolean present=false;
		//	int count= Options.size() ;

	//	int i;

		Thread.sleep(1000);

		waitpolling(driver, By.xpath("//lightning-base-combobox-item//span[2]/lightning-base-combobox-formatted-text[text()='--None--']"), 5);


		for (String opt:Options)  
		{  

			List<WebElement> e=driver.findElements(By.xpath("//lightning-base-combobox-item//span[2]/lightning-base-combobox-formatted-text[text()='" + opt +"']"));

			if (e.size()<=0)
			{
				System.out.println(opt +" is not present");
				Logs.update(txt, opt +" is not present", Status.FAIL,driver);
			}


		}


	}

	public static void isPresentAndDisplayed(String name, WebElement e, DriverScript Logs, WebDriver driver)
	{
		try {


			Boolean b = e.isDisplayed();
			if (b==true)
			{

				//Logs.update("name", name + " is present", Status.PASS, driver );
			}
			else
			{

				Logs.update("Page Layout Validation", name + " is not present", Status.FAIL,driver);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}


	}

	public static void waitpolling (WebDriver driver,By arg0, int seconds)
	{

		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.withTimeout(seconds, TimeUnit.SECONDS);
		wait.pollingEvery(3, TimeUnit.SECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.until(new ExpectedCondition<Boolean>(){
			@Override
			public Boolean apply(WebDriver driver) {
				WebElement ele=driver.findElement(arg0);
				if(ele==null)
					return false;

				else
				{

					return true;
				}     
			}
		});

	}

}


