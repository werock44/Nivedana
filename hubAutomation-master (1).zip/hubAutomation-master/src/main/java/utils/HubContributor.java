package utils;

import static org.testng.Assert.assertEquals;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.base.Function;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.Form_123NC_Obj;
import objectRepository.Form_1580G_Obj;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import pages.HubContributorFormPage;

public class HubContributor {
	static int fCount = 0;
	static int i = 0;

	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	static Base_class base = new Base_class();

	/*
	 * Created by Prasannajit To Mouse Hover and capture the tool tip message.
	 */

	public static String mouseHoverTocaptureInvalidMessage(WebDriver driver, DriverScript Logs, WebElement element,
			String InvalidData) {

		Actions actions = new Actions(driver);
		element.clear();
		element.sendKeys(InvalidData);
		element.sendKeys(Keys.TAB);
		actions.moveToElement(element).perform();
		String classValuenew = element.getAttribute("class");
		element.clear();
		return classValuenew;

	}
	
	public static String mouseHoverTocaptureInvalidMessage(WebDriver driver, DriverScript Logs, WebElement element
	) {

		Actions actions = new Actions(driver);
		actions.moveToElement(element).perform();
		String classValuenew = element.getAttribute("class");
		return classValuenew;

	}

	public static String invalidMessageAfterSubmit(WebDriver driver, DriverScript Logs, WebElement element)
			throws InterruptedException {
		Actions actions = new Actions(driver);
		// element.clear();
		actions.moveToElement(element).perform();
		// Thread.sleep(1000);
		Logs.update("screenshot", "Mouse Hover", Status.DONE, driver);
		String classValuenew = element.getAttribute("class");
		Thread.sleep(1000);
		element.clear();
		return classValuenew;
	}

	public static String invalidMessageAfterDistribute(WebDriver driver, DriverScript Logs, By elementToBeVerified)
			throws InterruptedException {
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(elementToBeVerified)).perform();
		// Thread.sleep(1000);
		Logs.update("screenshot", "Mouse Hover", Status.DONE, driver);
		String classValuenew = driver.findElement(elementToBeVerified).getAttribute("class");
		Thread.sleep(1000);
		return classValuenew;
	}

	// Created by Vivek Keshav(v265130)
	public static String getClassValue(WebDriver driver, DriverScript Logs, WebElement element)
			throws InterruptedException {
		String classValuenew = element.getAttribute("class");
		Thread.sleep(1000);
		// element.clear();
		return classValuenew;

	}

	// Created by Vivek Keshav(v265130)
	public static void onSubmitWithInvalidDataLocal(WebDriver driver, String TestType, String TestCaseName,
			WebElement Element, DriverScript Logs, String TC_ID, String ColumnNameInExcelSheet) throws Exception {
		int fCount = 0;
		Element.clear();
		Thread.sleep(1000);

		String testDataInvalidVals = Util.getAllNecessaryData(TestType, TestCaseName, ColumnNameInExcelSheet);

		String[] eachtestDataInvalidVals = testDataInvalidVals.split(",");
		for (int i = 0; i < eachtestDataInvalidVals.length; i++) {
			Element.clear();
			Thread.sleep(1000);
			Element.sendKeys(eachtestDataInvalidVals[i].trim());
			Thread.sleep(1000);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(3000);
			base.waitForElementTobeClickable(driver, HubContributorFormObj.btn_OkSuccessPopUp, 10);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Thread.sleep(2000);
			String classVal1 = HubContributor.invalidMessageAfterSubmit(driver, Logs, Element);
			if (classVal1.contains("invalid validationMouseOver")) {
				fCount = fCount + 1;
				Logs.update("Screenshot", "To check the error after clicking on Submit button", Status.PASS, driver);
			}
		}
		Assert.assertEquals(fCount, eachtestDataInvalidVals.length);
		System.out.println(fCount + "and" + eachtestDataInvalidVals.length);
		if (fCount == eachtestDataInvalidVals.length) {
			Logs.update("Test Case Id " + TC_ID, " Throws error for abcd, ab12, !@#$ on clicking save button",
					Status.PASS, driver);
		} else {
			Logs.update("Test Case Id " + TC_ID, "Throws error for abcd, ab12, !@#$ on clicking save button",
					Status.FAIL, driver);
		}
		eachtestDataInvalidVals = null;
	}

	// Created by Vivek Keshav(v265130)
	public static void onSubmitWithInvalidDataUSD(WebDriver driver, String TestType, String TestCaseName,
			WebElement ElementLocal, WebElement ElementUSD, DriverScript Logs, String TC_ID) throws Exception {
		int fCount = 0;
		ElementLocal.clear();
		// Thread.sleep(1000);
		String testDataInvalidVals = Util.getAllNecessaryData(TestType, TestCaseName, "InvalidVal");
		String[] eachtestDataInvalidVals = testDataInvalidVals.split(",");
		for (int i = 0; i < eachtestDataInvalidVals.length; i++) {
			ElementLocal.clear();
			// Thread.sleep(1000);
			ElementLocal.sendKeys(eachtestDataInvalidVals[i].trim());
			Thread.sleep(1000);
			String valInUSDField = ElementUSD.getAttribute("value");
			if (valInUSDField.equals("")) {
				fCount = fCount + 1;
			}
		}

		Assert.assertEquals(fCount, eachtestDataInvalidVals.length);
		if (fCount == eachtestDataInvalidVals.length) {
			Logs.update("Test Case Id " + TC_ID,
					"The USD field " + ElementUSD + " is empty when Local field has abcd, ab12 and !@#$", Status.PASS,
					driver);
		} else {
			Logs.update("Test Case Id " + TC_ID,
					"The USD field " + ElementUSD + " is not empty when Local field has abcd, ab12 and !@#$",
					Status.FAIL, driver);
		}
		eachtestDataInvalidVals = null;
	}

	// Created by Vivek Keshav(v265130)

	public static void onPositiveAndNegativeValues(WebDriver driver, String TestType, String TestCaseName,
			WebElement Element, DriverScript Logs, String TC_ID, String ColumnNameInExcelSheet) throws Exception {

		int fCount = 0;
		String testData = Util.getAllNecessaryData(TestType, TestCaseName, ColumnNameInExcelSheet);
		String[] splittedVals = testData.split(",");
		for (int i = 0; i < splittedVals.length; i++) {
			Element.clear();
			Element.sendKeys(splittedVals[i]);
			Element.sendKeys(Keys.TAB);
			Thread.sleep(3000);
			hubContributorFormObj.saveButton(driver).click();
			Thread.sleep(5000);
			Logs.update("Screenshot", "To check if error is there or not", Status.PASS, driver);
			if ((hubContributorFormObj.successMessage(driver).getText()).equalsIgnoreCase("Success")) {
				fCount = fCount + 1;
				driver.findElement(hubContributorFormObj.btn_OkSuccessPopUp).click();
				Thread.sleep(2000);
			}
		}
		Assert.assertEquals(fCount, splittedVals.length);
		if (fCount == splittedVals.length) {
			Logs.update("Test Case Id " + TC_ID, "User is able to enter numeric values (+ve and -ve) in the text box",
					Status.PASS, driver);
		} else {
			Logs.update("Test Case Id " + TC_ID,
					"User is not able to enter numeric values (+ve and -ve) in the text box", Status.FAIL, driver);
		}
	}

	// Created by Vivek Keshav(v265130)
	public static void calculateAmountInUSD(WebDriver driver, String TestType, String TestCaseName,
			WebElement ElementLocal, WebElement ElementUSD, DriverScript Logs, String TC_ID) throws Exception {
		String numericVal = Util.getAllNecessaryData(TestType, TestCaseName, "CurrencyVal");

		String conversionRate = Util.getAllNecessaryData(TestType, TestCaseName, "FXRate");
		Double amountLocal = Double.parseDouble(numericVal);
		Double intConversionRate = Double.parseDouble(conversionRate);
		ElementLocal.clear();
		ElementLocal.sendKeys(numericVal);
		ElementLocal.sendKeys(Keys.TAB);

		String amountInUSD = ElementUSD.getAttribute("value");
		Double usdAmount = Double.parseDouble(amountInUSD);
		Double res = amountLocal / intConversionRate;
		String string_temp = new Double(res).toString();
		String string_form = string_temp.substring(0, string_temp.indexOf('.'));
		double valBeforeDecimal = Double.valueOf(string_form);
		if (Double.compare(valBeforeDecimal, usdAmount) == 0) {
			Logs.update("Test Case Id " + TC_ID, "The conversion from Local to USD is correct", Status.PASS, driver);
		}
		ElementLocal.clear();
		ElementLocal.sendKeys(Keys.TAB);
	}

	// Created by Vivek Keshav(v265130)
	public static void checkIfUserIsAbleToEnter(WebDriver driver, String TestType, String TestCaseName,
			WebElement Element, DriverScript Logs, String TC_ID, String ColumnNameWhereDataIsPresent) throws Exception {
		String numericVal = Util.getAllNecessaryData(TestType, TestCaseName, ColumnNameWhereDataIsPresent);
		try {
			Element.clear();
			Element.sendKeys(numericVal);

			Logs.update("Test Case Id " + TC_ID, "User is able to enter the value in the text box", Status.PASS,
					driver);
			Element.clear();
		} catch (Exception e) {
			Logs.update("Test Case Id " + TC_ID, "User is not able to enter the value in the text box", Status.FAIL,
					driver);

		}
	}

	// Created by Vivek Keshav(v265130)
	public static void checkTheDropDownValues(WebDriver driver, String TestType, String TestCaseName, List oList,
			DriverScript Logs, String TC_ID, String ColumnNameWhereDataIsPresent) throws Exception {
		int fCount = 0;
		String dropDownData = Util.getAllNecessaryData(TestType, TestCaseName, ColumnNameWhereDataIsPresent);
		String[] valFRomExcel = dropDownData.split(",");
		int valFromExcelLength = valFRomExcel.length;
		// List<WebElement> oList = (List<WebElement>) Element;
		int sizeOfList = oList.size();
		if (valFromExcelLength == sizeOfList - 1) {
			for (String XLValue : valFRomExcel) {
				for (int i = 1; i < sizeOfList; i++) {
					String appVal = ((WebElement) oList.get(i)).getAttribute("title");
					if (appVal.replace("/n", "").trim().equalsIgnoreCase(XLValue.trim())) {
						fCount = fCount + 1;
					}
				}
			}
			Assert.assertEquals(fCount, valFRomExcel.length);
			if (fCount == valFRomExcel.length) {
				Logs.update("Test Case " + TC_ID, "The values in dropdown are same as given in the datasheet",
						Status.PASS, driver);
			} else {
				Logs.update("Test Case " + TC_ID, "The values in dropdown are not the same as given in the datasheet",
						Status.FAIL, driver);
			}
		} else {
			Logs.update("Test Case " + TC_ID, "Number of values in dropdown are different", Status.FAIL, driver);
		}
	}

	// Created by Vivek Keshav(v265130)
	public static void checkUSDFieldWithInvalidData(WebDriver driver, String TestType, String TestCaseName,
			WebElement FieldLocal, WebElement FieldUSD, DriverScript Logs, String TC_ID, String ColumnNameInExcel)
					throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String testDataInvalidVals = Util.getAllNecessaryData(TestType, TestCaseName, ColumnNameInExcel);
		String[] eachtestDataInvalidVals = testDataInvalidVals.split(",");
		for (int i = 0; i < eachtestDataInvalidVals.length; i++) {
			FieldLocal.sendKeys(Keys.chord(Keys.CONTROL, "a"), eachtestDataInvalidVals[i].trim());

			String valInUSDField = FieldUSD.getAttribute("value");

			if (valInUSDField.equals("")) {
				fCount = fCount + 1;
			}
		}
		Assert.assertEquals(fCount, eachtestDataInvalidVals.length);
		if (fCount == eachtestDataInvalidVals.length) {
			Logs.update("Test Case Id " + TC_ID,
					"USD field does not have anything when abcd, ab12 and !@# is entered in Local field", Status.PASS,
					driver);
		} else {
			Logs.update("Test Case Id " + TC_ID,
					"USD field has some value when abcd, ab12 and !@# is entered in Local field", Status.PASS, driver);
		}
		fCount = 0;
		// FieldLocal.clear();
	}

	// Created by Vivek Keshav(v265130)
	public static void checkIfUserIsAbleToEnterUSD(WebDriver driver, String TestType, String TestCaseName,
			WebElement FieldLocal, WebElement FieldUSD, DriverScript Logs, String TC_ID, String ColumnNameInExcel)
					throws Exception {
		String valInFieldUSD = FieldUSD.getAttribute("value");
		String numericVal = Util.getAllNecessaryData(TestType, TestCaseName, ColumnNameInExcel);
		if (valInFieldUSD.equals("")) {
			try {
				FieldLocal.sendKeys(numericVal);
				Logs.update("Test Case " + TC_ID,
						"User is able to enter in the Local field and no value is present in US field by default",
						Status.PASS, driver);
			} catch (Exception e) {
				Logs.update("Test Case " + TC_ID,
						"User is not able to enter in the Local field and no value is not present in US field by default",
						Status.FAIL, driver);
			}

		} else {
			Logs.update("Test Case " + TC_ID, "No value is not present in US field by default", Status.FAIL, driver);
		}
	}

	/*
	 * Created by Prasannajit To Verify the default value of field is Zero.
	 */
	public static void verifyDefaultValueIsZero(WebDriver driver, String TestType, String FieldName, WebElement Element,
			DriverScript Logs) {
		String defaultValue = Element.getAttribute("value");
		int toIntDefaultValue = Integer.parseInt(defaultValue);
		Assert.assertEquals(toIntDefaultValue, 0);
		if (toIntDefaultValue == 0) {
			Logs.update(FieldName, FieldName + " default value is 0 as expected", Status.PASS, driver);
		}

		else {
			Logs.update(FieldName, FieldName + " default value is Not 0", Status.FAIL, driver);
		}
	}

	/*
	 * Created by Prasannajit To Verify Field is accepting only negative values
	 */
	public static void verifyFieldIsTakingOnlyNegativeValues(WebDriver driver, String TestType, String FieldName,
			WebElement Element, String TestcaseName, String ColumnName, DriverScript Logs) throws Exception {
		String excelValNegative = Util.getAllNecessaryData(TestType, TestcaseName, ColumnName);
		String[] splittedVals = excelValNegative.split(",");
		// Enter negative and verify
		Element.clear();
		try {
			Element.sendKeys(splittedVals[1]);
			Logs.update(FieldName, "Able to enter negative value", Status.PASS, driver);

		} catch (Exception e)

		{
			Logs.update(FieldName, "Not Able to enter negative value", Status.FAIL, driver);
		}
		Element.clear();
		// Enter positive value and verify
		Element.sendKeys(splittedVals[1]);
		String invalidvalue = HubContributor.mouseHoverTocaptureInvalidMessage(driver, Logs, Element, splittedVals[0]);

		if (invalidvalue.contains("invalid validationMouseOver")) {
			Logs.update(FieldName, "Positive value not accepted", Status.PASS, driver);
		}

		else {
			Logs.update(FieldName, "Positive value accepted", Status.FAIL, driver);
		}

	}

	public static void verifyFieldIsTakingOnlyPositiveValue(WebDriver driver, String TestType, WebElement Element,
			String TestCaseName, String ColumnName, DriverScript Logs, String TC_ID) throws Exception {
		String excelValNegative = Util.getAllNecessaryData(TestType, TestCaseName, ColumnName);
		String[] splittedVals = excelValNegative.split(",");
		// Enter positive value and verify
		Element.clear();
		try {
			Element.sendKeys(splittedVals[0]);
			Logs.update(TC_ID, "Able to enter positive value", Status.PASS, driver);

		} catch (Exception e)

		{
			Logs.update(TC_ID, "Not Able to enter postitive value", Status.FAIL, driver);
		}
		Element.clear();
		// Enter negative value and verify
		Element.sendKeys(splittedVals[1]);
		String invalidvalue = HubContributor.mouseHoverTocaptureInvalidMessage(driver, Logs, Element, splittedVals[1]);
		boolean invalidStatus=invalidvalue.contains("invalid");
		Assert.assertTrue(invalidStatus);
		if (invalidvalue.contains("invalid")) {
			Logs.update(TC_ID, "Negative value not accepted", Status.PASS, driver);
		}

		else {
			Logs.update(TC_ID, "Negative value accepted", Status.FAIL, driver);
		}

	}

	// public static void checkTheDropDownValues(WebDriver driver, String
	// TestType, String TestCaseName,
	// WebElement Element, DriverScript Logs, String TC_ID) throws Exception {
	// int fCount = 0;
	// String dropDownData = Util.getAllNecessaryData(TestType, TestCaseName,
	// "GLAccountData");
	// driver.findElement(HubContributorFormObj.drpDown_GLAccountReserve).click();
	// Thread.sleep(1000);
	// try {
	// driver.findElement(HubContributorFormObj.GLAccountReserve_147350).click();
	// Thread.sleep(1000);
	// String valInGLDropDown =
	// driver.findElement(HubContributorFormObj.selectedValInGLAccountReverseDropDwn)
	// .getAttribute("title");
	// Logs.update("DropDown is enabled", "Value has been selected",
	// Status.PASS, driver);
	// } catch (Exception e) {
	//
	// }
	// }

	public static void saveWithFieldAsBlank(WebDriver driver, String TestType, WebElement Element, DriverScript Logs,
			String TC_ID) throws Exception {
		if (!Element.getTagName().equalsIgnoreCase("a")) {
			Element.clear();// clearing the field
		}
		
		Thread.sleep(5000);
		hubContributorFormObj.saveButton(driver).click();
		if ((hubContributorFormObj.successMessage(driver).getText()).equalsIgnoreCase("Success")) {
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();

			Logs.update("Test Case: " + TC_ID, "Able to Save with field as Blank", Status.PASS, driver);
			Thread.sleep(2000);

		} else {
			Logs.update("Test Case: " + TC_ID, "Not Able to Save with as blank", Status.FAIL, driver);
		}
	}

	// Created by Arindam Nath
	public static void verifySaveAndSubmitWithInvalidData(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID) throws Exception {
		String InvalidvaluesForField = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		String[] splittedValsForField = InvalidvaluesForField.split(",");
		int runCount = 0;
		int expectedRunCount = splittedValsForField.length;

		for (int i = 0; i < expectedRunCount; i++) {
			Element.sendKeys(splittedValsForField[i]);
			Element.sendKeys(Keys.TAB);
			Thread.sleep(1000);
			hubContributorFormObj.saveButton(driver).click();
			Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
			String errorMsg = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
			Logs.update("To check the error message", "Error" + " " + errorMsg, Status.PASS, driver);
			if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

				Logs.update("verify that not able to save with invalid values",
						"Error is displayed when tried to save with" + " " + splittedValsForField[i], Status.PASS,
						driver);
			} else {
				Logs.update("verify that not able to save with invalid values",
						"Error is not displayed when tried to save with" + " " + splittedValsForField[i], Status.FAIL,
						driver);
			}
			Base_class.waitForElementToVisible(driver, HubContributorFormObj.popUp_NotSaved, 10);
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			String fieldValidationMsg = HubContributor.invalidMessageAfterSubmit(driver, Logs, Element);
			if (fieldValidationMsg.contains("invalid validationMouseOver")) {

				runCount = runCount + 1;
				Logs.update("To verify field validation is displayed",
						"Field validation message is displayed as expected", Status.PASS, driver);

				driver.findElement(HubContributorFormObj.btn_Submit).click();// Click
				// on
				// submit
				// button
				base.waitForElementTobeClickable(driver, HubContributorFormObj.btn_OkSuccessPopUp, 15);
				String NotSubmitted = driver.findElement(HubContributorFormObj.submitUnsuccessMessage).getText();
				if (NotSubmitted.contains("Submit Unsuccessful")) {
					Logs.update("To verify sumit not succesful", "Not submitted as expected.", Status.PASS, driver);
				}

				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();

			}
			Element.clear();
		}
		if (runCount == expectedRunCount) {

			Logs.update("Test case " + TC_ID,
					"Error is displayed for" + InvalidvaluesForField + "when user tries to save", Status.PASS, driver);

		} else {
			Logs.update("Test case id " + TC_ID,
					"Error is not displayed for" + " " + InvalidvaluesForField + "when user tries to save", Status.FAIL,
					driver);
		}
	}

	// Created by Arindam Nath
	public static void submitWithFieldAsBlank(WebDriver driver, String TestType, WebElement Element, DriverScript Logs,
			String TC_ID) throws Exception {

		if (!Element.getTagName().equalsIgnoreCase("a")) {

			Element.clear();
		}
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		String classval1 = HubContributor.invalidMessageAfterSubmit(driver, Logs, Element);
		// Logs.update(classval1, classval1,Status.PASS, driver);
		if (classval1.contains("validationMouseOver")) {

			Logs.update("Test case " + TC_ID, "Not Able to Submit with field with blank as expected", Status.PASS,
					driver);
		} else {

			Logs.update("Test case " + TC_ID,
					"Actual:Able to Submit with field as blank.Expected: Should not be able to submit", Status.FAIL,
					driver);
		}

	}

	// Created by Arindam Nath
	public static void verifySaveAndSubmitWithDecimal(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID) throws Exception {
		String InvalidvaluesForField = Util.getAllNecessaryData(TestType, TestCaseName, ColName);

		Element.sendKeys(InvalidvaluesForField);
		Element.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		hubContributorFormObj.saveButton(driver).click();
		Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
		String errorMsg = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
		Logs.update("To check the error message", "Error displayed: " + " " + errorMsg, Status.PASS, driver);
		if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

			Logs.update("verify that not able to save with decimal values",
					"Error is displayed when tried to save with" + " " + InvalidvaluesForField, Status.PASS, driver);
		} else {
			Logs.update("verify that not able to save with decimal values",
					"Error is not displayed when tried to save with" + " " + InvalidvaluesForField, Status.FAIL,
					driver);
		}
		Base_class.waitForElementToVisible(driver, HubContributorFormObj.popUp_NotSaved, 10);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		String mouseOverMsg = driver.findElement(HubContributorFormObj.invalidMessageForDecimalVal).getText();

		if (mouseOverMsg.contains("Please report with no decimals.")) {

			Logs.update("Test case: " + TC_ID, "'Please report with no decimals.' message is displayed as expected",
					Status.PASS, driver);
		}
		Element.clear();
	}

	/*
	 * Created by Prasannajit Verify decimal invalid message for positive and
	 * negative fields
	 */

	public static void verifySaveAndSubmitWithDecimalforpositivefields(WebDriver driver, String TestType,
			String TestCaseName, String ColName, WebElement Element, DriverScript Logs, String TC_ID) throws Exception {
		String InvalidvaluesForField = Util.getAllNecessaryData(TestType, TestCaseName, ColName);

		Element.sendKeys(InvalidvaluesForField);
		Element.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		hubContributorFormObj.saveButton(driver).click();
		Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
		String errorMsg = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
		Logs.update("To check the error message", "Error displayed: " + " " + errorMsg, Status.PASS, driver);
		if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

			Logs.update("verify that not able to save with decimal values",
					"Error is displayed when tried to save with" + " " + InvalidvaluesForField, Status.PASS, driver);
		} else {
			Logs.update("verify that not able to save with decimal values",
					"Error is not displayed when tried to save with" + " " + InvalidvaluesForField, Status.FAIL,
					driver);
		}
		Base_class.waitForElementToVisible(driver, HubContributorFormObj.popUp_NotSaved, 10);
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		String mouseOverMsg = driver.findElement(HubContributorFormObj.invalidMessagePositiveval).getText();

		if (mouseOverMsg.contains("Invalid Entry! Positive numbers are not allowed")) {

			Logs.update("Test case: " + TC_ID, "Invalid Entry! Positive numbers are not allowed", Status.PASS, driver);
		}
		Element.clear();
	}

	// Created by Vivek Keshav
	public static void validatePopUpErrorMsgOnSubmit(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID) throws Exception {
		String expectedMessage = Util.getAllNecessaryData(TestType, TestCaseName, ColName);

		if (!(Element.getTagName().equalsIgnoreCase("a")) && !(Element.getAttribute("class").contains("readonly"))) {
			Element.clear();
		}
		driver.findElement(hubContributorFormObj.btn_Submit).click();
		Thread.sleep(2000);
		if (driver.findElement(HubContributorFormObj.popUpErrorMsgOnSumitWithFieldBlank).getText()
				.equalsIgnoreCase(expectedMessage)) {
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Logs.update("Test Case: " + TC_ID,
					"The expected and the actual error message matches when the user tries to submit without entering into a mandatory field",
					Status.PASS, driver);
			Thread.sleep(2000);
		} else {
			Logs.update("Test Case: " + TC_ID, "The error message does not exist", Status.FAIL, driver);
		}
		if (!Element.getTagName().equalsIgnoreCase("a") && !Element.getAttribute("class").contains("readonly")) {
			Element.clear();
		}
	}

	// Created by Vivek Keshav
	public static void verifyIfUserIsAbleToSubmitWithBlank(WebDriver driver, String TestType, DriverScript Logs,
			String TC_ID) throws InterruptedException {
		driver.findElement(HubContributorFormObj.btn_Submit).click();
		Thread.sleep(2000);
		if ((hubContributorFormObj.successMessage(driver).getText()).equalsIgnoreCase("Success")) {
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Thread.sleep(1000);
			if(driver.findElement(HubContributorFormObj.btn_Cancel).isDisplayed()){
				driver.findElement(HubContributorFormObj.btn_Cancel).click();	
			}		 
			Logs.update("Test Case: " + TC_ID, "Able to Submit", Status.PASS, driver);
			// Thread.sleep(2000);
		} else {
			Logs.update("Test Case: " + TC_ID, "Not Able to Submit", Status.PASS, driver);
		}
	}

	public static void verifyEnteringDataInField(WebDriver driver, String TestType, String Field, WebElement Element,
			DriverScript Logs, String TC_ID) {
		Element.clear();
		try {
			Element.sendKeys("Able to enter in" + Field);
			Thread.sleep(1000);
			Logs.update(TC_ID, "Able to enter data in " + Field + "field", Status.PASS, driver);
		} catch (Exception e) {
			Logs.update(TC_ID, "Not able to enter data in " + Field + "field", Status.FAIL, driver);
		}
	}

	// Created by Vivek Keshav

	public static void checkIfUserIsNotAbletoEnterMoreThan500(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID, int ExpectedLength) throws Exception {
		String valOfStatusOfReserve = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		int lengthOfInput = valOfStatusOfReserve.length();
		Element.clear();
		Element.sendKeys(valOfStatusOfReserve);
		Element.sendKeys(Keys.TAB);
		Thread.sleep(3000);
		int enteredValueLength = Element.getAttribute("value").length();
		System.out.println(enteredValueLength);
		Assert.assertEquals(enteredValueLength, ExpectedLength, "More than "+ExpectedLength+ " can be entered");
		if (enteredValueLength == ExpectedLength) {
			Logs.update("Test Case " + TC_ID, "More than " + ExpectedLength + " can not be entered in text box",
					Status.PASS, driver);
		} else if (enteredValueLength > ExpectedLength) {
			Logs.update("Test Case " + TC_ID, "More than " + ExpectedLength + " can be entered in text box",
					Status.FAIL, driver);
		} else {
			Logs.update("Test Case " + TC_ID, "Please check the input", Status.FAIL, driver);

		}
		
	}
	
	//Created By Arindam
	public static void VerifyUserIsAbletoEnter_PositiveNumber_specDigit(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID, int ExpectedLength, String textBoxName) throws Exception {
		String valToEnter = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		Element.clear();
		Element.sendKeys(valToEnter);
		Thread.sleep(3000);
		int enteredValueLength = Element.getAttribute("value").length();
		Assert.assertEquals(enteredValueLength, ExpectedLength);
		if (enteredValueLength == ExpectedLength) {
			Logs.update(TC_ID, "Maximum " + ExpectedLength + " positive numbers can be entered in text box: "+textBoxName,
					Status.PASS, driver);
		} else if (enteredValueLength > ExpectedLength) {
			Logs.update("Test Case " + TC_ID, "More than " + ExpectedLength + " positive numbers can be entered in text box: "+textBoxName,
					Status.FAIL, driver);
		} else {
			Logs.update("Test Case " + TC_ID, "Please check the input", Status.FAIL, driver);

		}
		
	}
	
	public static void Enter_PositiveNumber_in_Field(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, String FieldName) throws Exception {
		String valToEnter = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		Element.clear();
		Element.sendKeys(valToEnter);
	}
	
	public static void clear_Field(WebDriver driver, String TestType,
			WebElement Element) throws Exception {
		Element.clear();


	}
	
	public static void VerifyUserIsAbletoEnter_NegativeNumber_specDigit(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID, int ExpectedLength, String textBoxName) throws Exception {
		String valToEnter = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		Element.clear();
		Element.sendKeys(valToEnter);
		Thread.sleep(3000);
		int enteredValueLength = Element.getAttribute("value").length()-1;
		//Assert.assertEquals(enteredValueLength, ExpectedLength);
		if (enteredValueLength == ExpectedLength) {
			Logs.update(TC_ID, "Maximum " + ExpectedLength + " digit negative numbers can be entered along with negative sign in text box: "+textBoxName,
					Status.PASS, driver);
		} else if (enteredValueLength > ExpectedLength) {
			Logs.update("Test Case " + TC_ID, "More than " + ExpectedLength + " negative numbers can be entered in text box: "+textBoxName,
					Status.FAIL, driver);
		} else {
			Logs.update("Test Case " + TC_ID, "Please check the input", Status.FAIL, driver);

		}
		
	}
	
	
	public static void VerifyUserIsAbletoEnter_NegativeNumber(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID, int ExpectedLength, String textBoxName) throws Exception {
		String valToEnter = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		Element.clear();
		Element.sendKeys(valToEnter);
		Element.sendKeys(Keys.TAB);
		Thread.sleep(3000);
		int enteredValueLength = Element.getAttribute("value").length();
		System.out.println(enteredValueLength);
		//Assert.assertEquals(enteredValueLength, ExpectedLength);
		Assert.assertEquals(enteredValueLength, ExpectedLength, "More than " + ExpectedLength + " negative numbers can be entered in text box");
		if (enteredValueLength == ExpectedLength) {
			Logs.update(TC_ID, "Maximum " + ExpectedLength + " digit negative numbers can be entered along with negative sign in text box: "+textBoxName,
					Status.PASS, driver);
		} else if (enteredValueLength > ExpectedLength) {
			Logs.update("Test Case " + TC_ID, "More than " + ExpectedLength + " negative numbers can be entered in text box: "+textBoxName,
					Status.FAIL, driver);
		} else {
			Logs.update("Test Case " + TC_ID, "Please check the input", Status.FAIL, driver);

		}
		
	}
	
	public static void VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID, String textBoxName) throws Exception {
		Actions act=new Actions(driver);
		String valToEnter = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		Element.clear();
		Element.sendKeys(valToEnter);
		Thread.sleep(2000);
		Element.sendKeys(Keys.TAB);
		Thread.sleep(3000);
		act.moveToElement(Element).build().perform();
		Thread.sleep(8000);
		String invalidvalue = Element.getAttribute("class");
		System.out.println(invalidvalue);
		boolean invalidValPresent=invalidvalue.contains("invalid");
		Assert.assertTrue(invalidValPresent, "Error message is not displayed when alphabetical/decimal data is entered");
		Thread.sleep(2000);
		//WebElement toolTipEle=driver.findElement(By.xpath("//div[contains(@class,'tooltip validation pointer-')]"));
		//String PopupMsg=toolTipEle.getText();
		if (invalidvalue.contains("invalid")) {	
			Logs.update(TC_ID, "Error message is displayed when alphabetical/decimal value is entered in "+textBoxName, Status.PASS, driver);
		
		}
		
		else {
			Logs.update(TC_ID, "Error message is not displayed when alphabetical data is entered", Status.FAIL, driver);
		}
		Element.clear();
		
	}	
	public static void checkIfUserIsAbletoEnterLessThanExpData(WebDriver driver, String TestType, String TestCaseName,
			String ColName, WebElement Element, DriverScript Logs, String TC_ID, int ExpectedLength) throws Exception {
		String valOfStatusOfReserve = Util.getAllNecessaryData(TestType, TestCaseName, ColName);
		int lengthOfInput = valOfStatusOfReserve.length();
		Element.sendKeys(valOfStatusOfReserve);
		Thread.sleep(3000);
		int enteredValueLength = Element.getAttribute("value").length();
		if (enteredValueLength < ExpectedLength) {
			Logs.update("Test Case_ " + TC_ID, "Less than " + ExpectedLength + " can be entered in text box",
					Status.PASS, driver);
		} else {
			Logs.update("Test Case_ " + TC_ID, "Less than " + ExpectedLength + " can not be entered in text box", Status.FAIL, driver);

		}
	}

	// public static void validateIfElementIsPresent(WebDriver driver, By
	// Element, DriverScript Logs, String elementName){
	// Wait waitExplicit = new WebDriverWait(driver, 10);
	// FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	// .pollingEvery(250, TimeUnit.MILLISECONDS)
	// .withTimeout(5, TimeUnit.SECONDS)
	// .ignoring(NoSuchElementException.class);
	//
	// Function<WebDriver, Boolean> function = new Function<WebDriver,
	// Boolean>() {
	// public Boolean apply(WebDriver arg0) {
	// try{
	// waitExplicit.until(ExpectedConditions.elementToBeClickable(driver.findElement((By)
	// Element)));
	// Logs.update("The specified Element "+elementName+" should be present",
	// "The specified Element "+elementName+" is present", Status.PASS, driver);
	// return true;
	// }
	// catch(Exception e){
	// Logs.update("The specified Element "+elementName+" should be present",
	// "The specified Element "+elementName+" is not present", Status.FAIL,
	// driver);
	// return false;
	// }
	// }
	// };
	//
	// wait.until(function);
	// }
	// Create by v265130-Vivek Keshav-
	public static void checkIfUserIsAbleToClick(WebDriver driver, By ElementTOBeClicked, DriverScript Logs,
			String ElementName) {
		int fCounter = 0;
		Wait waitExplicitly = new WebDriverWait(driver, 20);
		waitExplicitly.until(ExpectedConditions.elementToBeClickable(driver.findElement(ElementTOBeClicked)));
		try {
			driver.findElement(ElementTOBeClicked).click();
			fCounter = fCounter + 1;
			Logs.update("The user should be able to click the element " + ElementName,
					"The user is able to click the element " + ElementName, Status.PASS, driver);
		} catch (Exception e) {
			Logs.update("The user should be able to click the element " + ElementName,
					"The user is not able to click the element, the exception is " + e, Status.PASS, driver);
			// Assert.fail();
		}
		Assert.assertEquals(fCounter, 1);
	}

	// Create by v265130-Vivek Keshav-
	public static void validateIfElementIsPresent(WebDriver driver, By Element, DriverScript Logs, String elementName) {

		try {
			Thread.sleep(1000);
			base.waitForElementToVisible(driver, Element, 10);
			boolean check = driver.findElement(Element).isDisplayed();
			Logs.update("The Element " + elementName + " should be present",
					"The Element " + elementName + " is present", Status.PASS, driver);
			Assert.assertTrue(check);
		} catch (Exception e) {
			Logs.update("The Element " + elementName + " should be present",
					"The Element " + elementName + " is NOT present", Status.FAIL, driver);
			Assert.fail();
		}
	}

	// Create by v265130-Vivek Keshav- Switching to newly opened window
	public static void switchWindow(WebDriver driver) {
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(2));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
	}

	public static void switchWindow_3(WebDriver driver) {
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.numberOfWindowsToBe(3));

		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
	}

	/*
	 * Created By Prasannajit To check if Element is editable or not
	 */

	public static void checkifElementisNotEditable(WebDriver driver, By ElementTOBeVerified, DriverScript Logs,
			String ElementName, String TCname) throws InterruptedException {
		Thread.sleep(2000);
		try {
			driver.findElement(ElementTOBeVerified).sendKeys("value");
			Logs.update(TCname, "" + ElementName + " is displayed  and editable", Status.FAIL, driver);

		} catch (Exception e) {
			Logs.update(TCname, "" + ElementName + " is displayed and not editable", Status.PASS, driver);

		}
	}

	/*
	 * Created By Arindam Nath To check if Element is editable or not
	 */

	public static void checkIfElementIsEditable(WebDriver driver, By ElementTOBeVerified, DriverScript Logs,
			String ElementName, String TC_ID) throws InterruptedException {
		Thread.sleep(2000);
		try {
			driver.findElement(ElementTOBeVerified).sendKeys("value");
			Logs.update(TC_ID, "" + ElementName + " is displayed  and editable", Status.PASS, driver);

		} catch (Exception e) {
			Logs.update(TC_ID, "" + ElementName + " is displayed and not editable", Status.FAIL, driver);

		}
	}

	/*
	 * Created By Prasannajit To Validate date format
	 */
	public static void validateDateFormat(WebDriver driver, DriverScript Logs, String dateToValdate,
			String ExpectedDateformat) {

		SimpleDateFormat formatter = new SimpleDateFormat(ExpectedDateformat);
		// To make strict date format validation
		formatter.setLenient(false);
		Date parsedDate = null;
		try {
			parsedDate = formatter.parse(dateToValdate);
			System.out.println("++validated DATE TIME ++" + formatter.format(parsedDate));
			Logs.update("date format validation", "Date format is as expected", Status.PASS, driver);

		} catch (ParseException e) {
			Logs.update("date format validation", "Date format is not as expected", Status.FAIL, driver);
			System.out.println(parsedDate);
		}

	}

	// Created by Arindam Nath
	public static void verifyPopUpMessage(WebDriver driver, By ElementTOBeVerified, DriverScript Logs, String expHeader)
			throws InterruptedException {
		String actHeader = driver.findElement(ElementTOBeVerified).getText();
		Assert.assertEquals(actHeader, expHeader);
		if (actHeader.equalsIgnoreCase(expHeader)) {
			Logs.update("Verify the pop up message",
					"Expected and Actual pop up message are same: Expected_ " + expHeader + " Actual_"+ actHeader, Status.PASS, driver);
		} else {
			Logs.update("Verify the pop up message" ,
					"Expected and Actual pop up message are NOT same: Expected_ " + expHeader + " But found_ "+ actHeader, Status.FAIL, driver);
		}
	}

	/* Created by Prasannajit */
	public static void verifyTextBoxIsEditable(WebDriver driver, By textBoxToBeVerified, DriverScript Logs,
			String TextBoxName, String textvalue) throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(textBoxToBeVerified).clear();
		try {
			driver.findElement(textBoxToBeVerified).sendKeys(textvalue);
			Logs.update(TextBoxName, " is displayed  and editable", Status.PASS, driver);

		} catch (Exception e) {
			Logs.update(TextBoxName, " is displayed and not editable", Status.FAIL, driver);

		}

	}

	/*
	 * Created by Vivek KEshav Specific to the table on My Dashboard Screen-
	 * Cannot be used for any other table
	 */
	public static void checkEntityTableValueMyDashboard(WebDriver driver, DriverScript Logs, int ColumnNumber,
			String ExpectedValueToBEPresentInTable) throws InterruptedException {
		List<WebElement> totalRows = driver.findElements(
				By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr"));
		int totalNumOfRows = totalRows.size();
		// System.out.println("---------------------till here");
		for (int i = 1; i <= totalNumOfRows; i++) {
			String val = driver.findElement(
					By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr[" + i
							+ "]/td[" + ColumnNumber + "]/div/div/span"))
					.getText();
			// System.out.println(val+" "+ExpectedValueToBEPresentInTable);
			if (!val.equalsIgnoreCase(ExpectedValueToBEPresentInTable)) {
				fCount = fCount + 1;
			}
		}
		// System.out.println("---------------------till here");
		Assert.assertEquals(fCount, 0);
		if (fCount == 0) {
			Logs.update("All the rows of the table contains the expected value",
					"Expected value " + ExpectedValueToBEPresentInTable, Status.PASS, driver);
		} else {
			Logs.update("All the rows of the table does not the expected value",
					"Expected value " + ExpectedValueToBEPresentInTable, Status.FAIL, driver);
		}
	}

	public static void searchSchedule(WebDriver driver, String entityName, String period, String schedule,
			DriverScript Logs) throws InterruptedException {
		Actions actions = new Actions(driver);
		driver.findElement(HubHomePageObj.myDashBoardButton).click();
		Thread.sleep(2000);
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Base_class.waitForElementTobeClickable(driver, HubHomePageObj.edt_EntityDeatils, 10);
		//String[] arrSplit = entityName.split(" ");
		//String entityDigits = arrSplit[0];
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.edt_EntityDeatils).clear();
		driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.selectSchedule).click();
		Thread.sleep(2000);
		HubHomePageObj.findScheduleName(driver, schedule).click();
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.periodTextBox).sendKeys(period);
		Thread.sleep(1000);
		driver.findElement(HubHomePageObj.searchButtonDashboard).click();
		Thread.sleep(3000);
		try {
			WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			entityXpath.isDisplayed();
			Thread.sleep(4000);
		} catch (Exception e) {
			Logs.update(
					"The entity is no longer present- Either Submitted or Expired, please update a new entity in the data-sheet",
					"Please open the datasheet under src->main->java->Utils->Datasheet.xls", Status.FAIL, driver);
		}

	}

	public static void setValidDueDateVal(WebDriver driver, String scheduleName,By ElementTOBeUpdated, DriverScript Logs,
			String DueDateTOBeSet, String TestCaseNAme, String TestType) throws Exception {
		//ScheduleName
		//span[text()='Reserve 816 General Reserves']/../../../following-sibling::td[5]
		String s1 = "//span[text()='";
		String s2 = "']/../../../following-sibling::td[5]";
		String duedatexpath=s1+scheduleName+s2;
		
		driver.findElement(HubAdminScreen.adminScreenButton).click();
		driver.findElement(HubAdminScreen.scheduleAttributeMaintenance).click();
		driver.switchTo().frame(driver.findElement(HubAdminScreen.frameAdminScreen));
		Actions action = new Actions(driver);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@title='Schedule Name']")).click();
		WebElement duedate=driver.findElement(By.xpath(duedatexpath));
		Thread.sleep(2000);
		action.moveToElement(duedate).doubleClick().build().perform();
		Thread.sleep(4000);
		driver.findElement(ElementTOBeUpdated).clear();
		driver.findElement(ElementTOBeUpdated).sendKeys(DueDateTOBeSet);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_Save, Logs, "Save Button");
		Base_class.waitForElementTobeClickable(driver, HubAdminScreen.btn_RefreshView, 10);
		HubContributor.checkIfUserIsAbleToClick(driver, HubAdminScreen.btn_RefreshView, Logs, "Refresh View Button");
		Logs.update("Verify Required due date is set", "Due is set correctly to: "+DueDateTOBeSet,Status.PASS, driver);
	}

	public static void addOrOpenExistingSchedule(WebDriver driver, boolean schedulePresent, WebElement entityXpath)
			throws InterruptedException {
		if (schedulePresent == false) {
			driver.switchTo().defaultContent();
			driver.findElement(HubHomePageObj.adminLink).click();
			Thread.sleep(2500);
			HubContributor.switchWindow(driver);// to switch to newly open
			// window
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubAdminScreen.adminDashboardButton, 10);
			driver.findElement(HubAdminScreen.distributeBtn).click();
			driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
			driver.findElement(HubAdminScreen.scheduleDistFrequency_Quaterly).click();
			Thread.sleep(3000);
			driver.findElement(HubAdminScreen.periodField).click();
			driver.findElement(HubAdminScreen.period_QuaterlyCurrent).click();
			Thread.sleep(3000);
			driver.findElement(HubAdminScreen.scheduleField).click();
			driver.findElement(HubAdminScreen.schedule_GenReserve).click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
			Thread.sleep(1000);

			// find the BUGO id and distribute

		} else {
			Actions actions = new Actions(driver);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(HubContributorFormObj.Btn_scheduleOpen).click();
			Thread.sleep(2000);
			HubContributor.switchWindow_3(driver);
		}
	}

	public static void distributeSchedule(WebDriver driver, DriverScript Logs, String TestType,
			String bugoID,String scheduleName, String period) throws Exception {

		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(2500);
		HubContributor.switchWindow(driver);// to switch to newly open window
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubAdminScreen.adminDashboardButton, 10);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[text()='Schedule Distribution']")).click();
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(5000);
		driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
		driver.findElement(HubAdminScreen.scheduleDistFrequency_Quaterly).click();
		Thread.sleep(3000);

		driver.findElement(HubAdminScreen.periodField).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='" + period + "']")).click();
		driver.findElement(HubAdminScreen.scheduleField).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//li[@title='" + scheduleName + "']")).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(10000);

		// distribute

		driver.findElement(By.xpath("(//div[contains(text()," + "'" + bugoID + "')])[1]")).click();
		driver.findElement(By.xpath("//a[@title='Add Selection']")).click();
		driver.findElement(HubContributorFormObj.distributebutton).click();

		Thread.sleep(5000);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build()
		.perform();

		Thread.sleep(2000);
		HubContributor.switchWindow_3(driver);
		// Base_class.waitForElementToVisible(driver,
		// HubContributorFormObj.distributionSuccessmessage, 60);
		Thread.sleep(5000);
		/*String progBarVal = driver.findElement(HubAdminScreen.distributionProgressBar).getAttribute("title");
		if (progBarVal.contains("100%")) {
			Logs.update("Distribution Verification", "Progress bar is showing 100% as expected", Status.PASS, driver);
		} else {
			Logs.update("Distribution Verification", "Distribution is Not successful", Status.FAIL, driver);
		}*/
		

	}
	
	public static void distributeScheduleMonthly(WebDriver driver, DriverScript Logs, String TestType,
			String bugoID,String scheduleName, String period) throws Exception {

		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(2500);
		HubContributor.switchWindow(driver);// to switch to newly open window
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubAdminScreen.adminDashboardButton, 10);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[text()='Schedule Distribution']")).click();
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(7000);
		driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
		driver.findElement(HubAdminScreen.scheduleDistFrequency_Monthly).click();
		Thread.sleep(3000);

		driver.findElement(HubAdminScreen.periodField).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='" + period + "']")).click();
		driver.findElement(HubAdminScreen.scheduleField).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//li[@title='" + scheduleName + "']")).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(10000);

		// distribute

		driver.findElement(By.xpath("(//div[contains(text()," + "'" + bugoID + "')])[1]")).click();
		driver.findElement(By.xpath("//a[@title='Add Selection']")).click();
		driver.findElement(HubContributorFormObj.distributebutton).click();

		Thread.sleep(5000);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build()
		.perform();

		Thread.sleep(2000);
		HubContributor.switchWindow_3(driver);
		// Base_class.waitForElementToVisible(driver,
		// HubContributorFormObj.distributionSuccessmessage, 60);
		Thread.sleep(120);
		/*String progBarVal = driver.findElement(HubAdminScreen.distributionProgressBar).getAttribute("title");
		if (progBarVal.contains("100%")) {
			Logs.update("Distribution Verification", "Progress bar is showing 100% as expected", Status.PASS, driver);
		} else {
			Logs.update("Distribution Verification", "Distribution is Not successful", Status.FAIL, driver);
		}*/
		

	}
	
	public static void distributeScheduleYearly_Fiscal(WebDriver driver, DriverScript Logs, String TestType,
			String bugoID,String scheduleName, String period) throws Exception {

		Thread.sleep(5000);
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(2500);
		HubContributor.switchWindow(driver);// to switch to newly open window
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubAdminScreen.adminDashboardButton, 10);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[text()='Schedule Distribution']")).click();
		WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
		driver.switchTo().frame(Frame);
		Thread.sleep(7000);
		driver.findElement(HubAdminScreen.scheduleDistFrequencyField).click();
		driver.findElement(HubAdminScreen.scheduleDistFrequency_Yearly_Fiscal).click();
		Thread.sleep(3000);

		driver.findElement(HubAdminScreen.periodField).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='" + period + "']")).click();
		driver.findElement(HubAdminScreen.scheduleField).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//li[@title='" + scheduleName + "']")).click();
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp).click();
		Thread.sleep(10000);

		// distribute

		driver.findElement(By.xpath("(//div[contains(text()," + "'" + bugoID + "')])[1]")).click();
		driver.findElement(By.xpath("//a[@title='Add Selection']")).click();
		driver.findElement(HubContributorFormObj.distributebutton).click();

		Thread.sleep(5000);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(HubContributorFormObj.btn_OkSuccessPopUp)).sendKeys(Keys.ENTER).build()
		.perform();

		Thread.sleep(2000);
		HubContributor.switchWindow_3(driver);
		// Base_class.waitForElementToVisible(driver,
		// HubContributorFormObj.distributionSuccessmessage, 60);
		Thread.sleep(120);
		/*String progBarVal = driver.findElement(HubAdminScreen.distributionProgressBar).getAttribute("title");
		if (progBarVal.contains("100%")) {
			Logs.update("Distribution Verification", "Progress bar is showing 100% as expected", Status.PASS, driver);
		} else {
			Logs.update("Distribution Verification", "Distribution is Not successful", Status.FAIL, driver);
		}*/
		

	}
	
	
	public static String getBugoID(WebDriver driver,DriverScript Logs,String TestType,String scheduleID,String period) throws Exception, SQLException, Exception{
	
	String QueryTobugoID ="Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' "
			+ "and EntityStatus='A' and entityID not IN (select entityId from scheduleinstance where "
			+ "scheduleID="+"'"+scheduleID+"'"+" and periodid IN ('"+period+"'))";
	System.out.println(QueryTobugoID);
	String dbColumnName = "BUStructure";
    String bugoID=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryTobugoID, dbColumnName);
    return bugoID;
}
	
	public static String getBugoID_WithQuery(WebDriver driver,DriverScript Logs,String TestType,String QueryTobugoID, String ColName) throws Exception, SQLException, Exception{
		System.out.println(QueryTobugoID);
		String dbColumnName = ColName;
	    String bugoID=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryTobugoID, dbColumnName);
	    return bugoID;
	}

	//For 1590 schedule non us BUGO id needs to be considered.
	public static String getBugoID_NON_US(WebDriver driver,DriverScript Logs,String TestType,String scheduleID,String period) throws Exception, SQLException, Exception{
		
	String QueryTobugoID ="Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' "
			+ "and EntityStatus='A' and entityID not IN (select entityId from scheduleinstance where "
			+ "scheduleID="+"'"+scheduleID+"'"+" and periodid IN ('"+period+"')) and Country!='US'";
	System.out.println(QueryTobugoID);
	String dbColumnName = "BUStructure";
    String bugoID=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryTobugoID, dbColumnName);
    return bugoID;
}
	
	public static String getBUID(WebDriver driver,DriverScript Logs,String TestType,String scheduleID,String period) throws Exception, SQLException, Exception{
		
		String QueryToGetBUID ="Select DISTINCT TOP 1 EntityCode from masterdata.entity where EntityType='BU' "
				+ "and EntityStatus='A' and entityID"
				+ " not IN (select entityId from scheduleinstance where scheduleID="+"'"+scheduleID+"'"
				+ " and periodid in('"+period+"'))";
		System.out.println(QueryToGetBUID);
		String dbColumnName = "EntityCode";
	    String buID=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetBUID, dbColumnName);
	    return buID;
	}
	
	public static void verifyFieldName(WebDriver driver, String expFieldName, String testcaseName, WebElement element,
			DriverScript Logs){
		String fieldLbl_Exp=expFieldName;
		String fieldLbl_Act=element.getText();
		if(fieldLbl_Act.equalsIgnoreCase(fieldLbl_Exp)){
			Logs.update(testcaseName+" verify field should be displayed", "\""+fieldLbl_Act+"\""+" Field is displayed as expected", Status.PASS, driver);
		}
		else{
			Logs.update(testcaseName +" verify field should be displayed", fieldLbl_Exp+" Field is not displayed", Status.FAIL, driver);
		}		
	}

	public static void deleteTxnCodeRecord(WebDriver driver,WebElement recordToBeDeletedEle, WebElement deleteBtnEle) throws InterruptedException{
		boolean ifFirstRecPresent = false;
		do 
		{
		try{			
		 ifFirstRecPresent=recordToBeDeletedEle.isDisplayed();
		}catch(org.openqa.selenium.NoSuchElementException e)
		{
			System.out.println("All the elements are deleted");
			ifFirstRecPresent=false;
		}
		if(ifFirstRecPresent==true){
			recordToBeDeletedEle.click();
			Thread.sleep(2000);
			deleteBtnEle.click();
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		}
	}
		while(ifFirstRecPresent==true);

	}

	
}
