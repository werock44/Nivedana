package utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import io.appium.java_client.functions.ExpectedCondition;

public class BrowserFactory {
	static WebDriver driver;
	private static String path = System.getProperty("user.dir");
	private static String doubleslashpath = path.replaceAll("\\\\", "\\\\\\\\");
	//ReadProperty prop = new ReadProperty("ReadProperty");
	//String browser = prop.getProp("browser");
	public static WebDriver openbrowser(String browser ,String url) {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
	//	options.addArguments("--headless");
		options.setHeadless(false);
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver",doubleslashpath+"\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);	
		      ExpectedCondition<Boolean> expectation = new
		                ExpectedCondition<Boolean>() {
		                    public Boolean apply(WebDriver driver) {
		                        return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
		                    }
		                };
		                WebDriverWait wait = new WebDriverWait(driver, 30);
		                wait.until(expectation);
		                System.out.println("Headless browser");
		}
		
		else if(browser.equalsIgnoreCase("Edge"))
		{
			driver = new EdgeDriver();
		}
		
		/*else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\s627207\\eclipse-workspace\\SFDC_Selenium\\Drivers\\chromedriver.exe");
			driver = new FirefoxDriver(options);
		}
		
		else if(browser.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver","C:\\Users\\s627207\\eclipse-workspace\\SFDC_Selenium\\Drivers\\chromedriver.exe");
			driver = new InternetExplorerDriver(options);
		}
		*/
		driver.get(url);
		Reporter.log("URL: "+url+" is opened.");
		driver.manage().window().maximize();	
		return driver;
	}
}
