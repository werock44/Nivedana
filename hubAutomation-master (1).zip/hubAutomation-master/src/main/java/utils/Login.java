/**
 * 
 */
package utils;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubHomePageObj;

public class Login {
	static DriverScript Logs;
	static Base_class baseClass = new Base_class();
	/*To launch the application by clicking on Hub2.0 link*/
	public static WebDriver LaunchHub(String urlProperty, DriverScript Logs) throws Exception {
		  ConfigDataProvider configuration = new ConfigDataProvider();
		  String Browser = configuration.getBrowser();
		  String url = configuration.getURL(urlProperty);
		  WebDriver driver = BrowserFactory.openbrowser(Browser,url);
		  driver.manage().window().maximize();
		  baseClass.waitForElementTobeClickable(driver, HubHomePageObj.hub2Button, 10);
		  driver.findElement(HubHomePageObj.hub2Button).click();
		  Logs.update("Launching of Hub App " ,"The Hub Application has been launched" , Status.PASS,driver);  
		  try{
		  baseClass.waitForElementTobeClickable(driver, HubHomePageObj.myDashBoardButton, 10);
		  }
		  catch(Exception e){
			  Logs.update("Launching of Hub App " , e.getMessage() , Status.FAIL,driver);
			  Assert.fail(e.getMessage());
		  }
		  return driver;
	  }
	
	//*Just to launch the application. Not clicking on Hub2.0 link.*/
	public static WebDriver launchAppURL(String urlProperty, DriverScript Logs) throws Exception {
		  ConfigDataProvider configuration = new ConfigDataProvider();
		  String Browser = configuration.getBrowser();
		  String url = configuration.getURL(urlProperty);
		  WebDriver driver = BrowserFactory.openbrowser(Browser,url);
		  driver.manage().window().maximize();
		  try{
		  Base_class.waitForElementTobeClickable(driver, HubHomePageObj.hub2Button, 10);
		  Logs.update("Launching of Hub App URL " ,"The Hub Application URL has been launched" , Status.PASS,driver);
		  }catch(Exception e){
			  Logs.update("Launching of Hub App URL " , e.getMessage() , Status.FAIL,driver);
			  Assert.fail(e.getMessage());
		  }
		  return driver;
	}
}
