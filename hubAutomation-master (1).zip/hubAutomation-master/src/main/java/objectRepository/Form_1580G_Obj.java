package objectRepository;

import org.openqa.selenium.By;

public class Form_1580G_Obj {
	
	public static final By btn_Add_Schedule_A = By.xpath("(//span[text() = 'Add'])[1]");
	public static final By btn_Add_Schedule_B = By.xpath("(//span[text() = 'Add'])[2]");
	
	public static final By btn_Delete_Schedule_A = By.xpath("(//span[text() = 'Delete'])[1]");
	public static final By btn_Delete_Schedule_B = By.xpath("(//span[text() = 'Delete'])[2]");
	
	public static final By btn_Cancel = By.xpath("//span[text() = 'Cancel']");
	public static final By btn_Delete = By.xpath("//span[text() = 'Delete']");
	public static final By reportingUnit_Header = By.xpath("//span[@name='lblReportingUnit']");
	
	public static final By schedule_A_Header=By.xpath("(//div[@class='grid-header-text'])[1]");
	public static final By schedule_A_Header_SummaryReport=By.xpath("(//div[@class='grid-header-text'])[2]");
	

	public static final By schedule_B_Header=By.xpath("(//div[@class='grid-header-text'])[3]");
	public static final By schedule_B_Header_SummaryReport=By.xpath("(//div[@class='grid-header-text'])[4]");

	public static final By chooseTransactionCode_Schedule_A_AutoSuggest=By.xpath("(//input[@class='input-control ui-autocomplete-input'])[1]");
	public static final By countryName_Schedule_A_AutoSuggest=By.xpath("(//input[@class='input-control ui-autocomplete-input'])[2]");
	public static final By ForeignAffiliates_Schedule_A=By.xpath("//input[@id='a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_8c793961-f3a8-8f9d-c1b1-8f9b6457ebac']");
	public static final By UnAffiliatesForeignEntities_Schedule_A=By.xpath("//input[@id='a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_165a733b-6b36-40b4-a872-d92ea9d39f46']");
	
	public static final By chooseTransactionCode_Schedule_B_AutoSuggest=By.xpath("(//input[@class='input-control ui-autocomplete-input'])[3]");
	public static final By countryName_Schedule_B_AutoSuggest=By.xpath("(//input[@class='input-control ui-autocomplete-input'])[4]");
	public static final By ForeignAffiliates_Schedule_B=By.xpath("//input[@id='25b38a82-cecc-e26f-2245-1c218a31b10a_4e860cb3-c12d-8a22-725a-05b2edbab37f']");
	public static final By UnAffiliatesForeignEntities_Schedule_B=By.xpath("//input[@id='25b38a82-cecc-e26f-2245-1c218a31b10a_a79d9265-d776-4c64-ad03-1239a34de385']");

	
	public static final By AddedFisrtRow_Schedule_A=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_c4111f8e-1a43-45a4-a382-63574b996e63']/div[3]/div[2]/div/div/table/tbody/tr/td[2]/div/div/span");
	public static final By AddedFisrtRow_Schedule_B=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_25b38a82-cecc-e26f-2245-1c218a31b10a_ffda02e8-2017-4b6f-9db7-098110eb2c8d']/div[3]/div[2]/div/div/table/tbody/tr/td[2]/div/div/span");

public static final By transactionCodeText=By.xpath("//*[@id='a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_cec8909a-1521-bba4-27b7-6baaf874195e']/div/div/div[2]/div[2]/div/div");


	//public static final By invalidCountryCodePopUpMessage=By.xpath("//*[@id='PopupWin_67a944ff-6045-f2ad-6bc0-92dd8023acdf']/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div/div/div[2]");
	//public static final By countryCodeText=By.xpath("//*[@id='a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_e07efc84-534c-22b2-8c7d-846532b90b06']/div/div/div[2]/div[2]/div/div");
	public static final By countryCodeText_sch_B=By.xpath("//*[@id='25b38a82-cecc-e26f-2245-1c218a31b10a_98b05e8c-fee0-0ad4-558d-3eee91fc6182']/div/div/div[2]/div[2]/div/div");
	
	//Summary section
	public static final By SummaryExpandIcon_Sch_A=By.xpath("(//a[@class='expand-vertical'])[1]");
	public static final By SummaryExpandIcon_Sch_B=By.xpath("(//a[@class='expand-vertical'])[2]");
	
	public static final By RefreshIcon_Sch_A=By.xpath("(//span[text()='Refresh'])[1]");
	public static final By RefreshIcon_Sch_B=By.xpath("(//span[text()='Refresh'])[2]");
	
	public static final By Summary_TransactionCode_Sch_A_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[1]/div/div/span");
	public static final By Summary_TransactionCode_Sch_B_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[1]/div/div/span");
	
	public static final By Summary_CountryName_Sch_A_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[2]/div/div/span");
	public static final By Summary_CountryName_Sch_B_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[2]/div/div/span");
	
	public static final By Summary_ForeignAffiliates_Sch_A_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[3]/div/div/span");
	public static final By Summary_ForeignAffiliates_Sch_B_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[3]/div/div/span");

	public static final By Summary_ForeignAffiliates_Total_Sch_A_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[3]/div/div/span");
	public static final By Summary_ForeignAffiliates_Total_Sch_A_Row_2=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[3]/div/div/span");
	//update
	public static final By Summary_ForeignAffiliates_Total_Sch_B_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[3]/div/div/span");
	public static final By Summary_ForeignAffiliates_Total_Sch_B_Row_2=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[3]/div/div/span");
	
	public static final By Summary_UnaffiliatedForeign_Sch_A_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[4]/div/div/span");
	public static final By Summary_UnaffiliatedForeign_Sch_B_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[4]/div/div/span");

	public static final By Summary_UnaffiliatedForeign_Total_Sch_A_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[4]/div/div/span");
	public static final By Summary_UnaffiliatedForeign_Total_Sch_A_Row_2=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[4]/div/div/span");
	//update
	
	public static final By Summary_UnaffiliatedForeign_Total_Sch_B_Row_1=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[4]/div/div/span");
	public static final By Summary_UnaffiliatedForeign_Total_Sch_B_Row_2=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[4]/div/div/span");
	
	public static final By Summary_ForeignAffiliates_GrandTotal_Sch_A=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[3]/div/div/span");
	public static final By Summary_UnaffiliatedForeign_GrandTotal_Sch_A=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_84d3db86-2a20-703e-7214-44464a07abfb_2a4538e6-2485-455f-812e-076e3a837c92']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[4]/div/div/span");


 public static final By invalidCountryCodePopUpMessage=By.xpath("//*[@id='PopupWin_67a944ff-6045-f2ad-6bc0-92dd8023acdf']/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div/div/div[2]");
 public static final By countryCodeText=By.xpath("//*[@id='a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_e07efc84-534c-22b2-8c7d-846532b90b06']/div/div/div[2]/div[2]/div/div");
public static final By scheduleAStaticText=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_c4111f8e-1a43-45a4-a382-63574b996e63']/div[1]/div/div[1]/span");
public static final By transactionCodeStatictext=By.xpath("//*[@id='a317a4f5-4780-9fbe-2b8c-6ae0debd5eee_ae804d3f-7616-ac17-0d2c-7813a945b759']");

public static final By transactionCodeTextScheduleB=By.xpath("//*[@id='25b38a82-cecc-e26f-2245-1c218a31b10a_37f03290-8c02-70da-ac0c-ce3d8d4877c9']/div/div/div[2]/div[2]/div/div");
public static final By scheduleBStaticText=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_25b38a82-cecc-e26f-2245-1c218a31b10a_ffda02e8-2017-4b6f-9db7-098110eb2c8d']/div[1]/div/div[1]/span");


	public static final By Summary_ForeignAffiliates_GrandTotal_Sch_B=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[3]/div/div/span");
	public static final By Summary_UnaffiliatedForeign_GrandTotal_Sch_B=By.xpath("//*[@id='10add1f6-01ed-40da-9e71-b0f47a4066c5_01f96be5-f5a5-4334-9f22-39db58e1d5bb_892c76f0-5b23-c547-0fb7-5cacd6444f21_c0bd1ef2-8f83-4b62-b6e0-a2a02a4c52c5']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[4]/div/div/span");
	
	public static final By commentsTextbox=By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_bf5376a9-c4a9-4640-aea4-6cb90a99b625_TextArea']");


}



  
	

