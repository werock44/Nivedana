package objectRepository;


public class PageValidationString {
//All are xpath of account obj

	 /*-------------------------------------Button----------------------------------*/
	
		public static final String convertCustomerBtn = "//div[text()='Convert to Customer']";
		public static final String successMsgBtn = "//button[text()='Close']";
		public static final String opportunityNewBtn = "(//div[@title='New'])";
		public static final String opportunitySaveBtn = "//button[@title='Save']";
		public static final String contactNewBtn = "(//div[@title='New'])";
		public static final String addEventBtn = "//span[text()='Add']";
		public static final String newTaskBtn = "//span[text()='New Task']";
		public static final String potentialNewBtn = "//button[text()='New']";
		public static final String addProdFunBtn = "//button[@class='slds-button slds-button_neutral']";
		public static final String saveBtn = "//button[text()='Save']";
		public static final String deleteProdfunBtn = "(//span[text()='Delete']/..)";
		public static final String deletePotentialBtn = "//button[text()='Delete']";
		public static final String deleteProdfunConBtn = "//Button[text()='Yes']";
		public static final String newEventSaveBtn = "(//span[text()='Save'])[3]";
		public static final String physicalAddressBtn = "//span[text()='Physical Address']/../following-sibling::div//button";
		public static final String correspondenceAddressBtn = "//span[text()='Correspondence Address']/../following-sibling::div//button";
		public static final String cancelBtn = "//div[@class='modal-footer slds-modal__footer']//span[text()='Cancel']";
		public static final String saveNewBtn = "//div[@class='modal-footer slds-modal__footer']//span[text()='Save & New']";
		public static final String saveBtn2 = "//div[@class='modal-footer slds-modal__footer']//span[text()='Save']";
		
		
		 /*-------------------------------------Link----------------------------------*/
		public static final String logoutLink = "//a[starts-with(text(),'Log out')]";
		public static final String opportunityBusinessNameLnk = "//span[text()='Business']/../following-sibling::div/div/div/div/a[@class='select']";
		public static final String stageLnk = "(//span[text()='Stage'])[2]/../following-sibling::div/div/div/div/a[@class='select']";
		public static final String unitOfContributionLnk = "(//span[text()='Unit of contribution'])/../following-sibling::div/div/div/div/a[@class='select']";
		public static final String unitOfVolumeLnk = "(//span[text()='Unit of volume'])/../following-sibling::div/div/div/div/a[@class='select']";
		public static final String stageValueLnk = "(//a[text()='Explore'])[1]";
		public static final String salutationLnk = "(//span[text()='Salutation'])/../following-sibling::div/div/div/div/a";
		public static final String salutationvalueLnk = "(//a[text()='Mr.'])[1]";
		
		 /*-------------------------------------Tab----------------------------------*/
		
		public static final String potentialTab = "//span[text()='Potential']";
		public static final String opportunityTab = "//span[text()='Opportunities']";
		public static final String activityTab = "(//span[text()='Activity'])[2]";
		public static final String contactTab = "//span[text()='Contacts']";
		
		
		
		 /*-------------------------------------Message--------------------------------------*/
		public static final String pervalerrorMsg = "//div[text()='Sum of Percentage of share should not exceed 100 for a product function [All-Complete]']";
		public static final String sameCombErrorMsg = "//div[text()='Duplicate Product Function and Type are not allowed [All-Complete]']";
		public static final String successMsg = "//section[text()='Request is created successfully']";
		
		
		 /*-------------------------------------TextBox-------------------------------------*/
		public static final String firstNameTxtBx = "//span[text()='First Name']/../following-sibling::input";
		public static final String lastNameTxtBx = "//span[text()='Last Name']/../following-sibling::input";
		public static final String valueMTTxtBx = "//td[@data-label='Value/MT']/div/input";
		public static final String annualVolMTTxtBx = "//td[@data-label='Annual Volume(MT)']/div/input";
		public static final String cycleyrTxtBx = "//td[@data-label='Cycles/yr']/div/input";	
		public static final String animalCycleTxtBx = "(//td[@data-label='Cycles/yr']/following-sibling::td/div/input)[1]";
		public static final String kganimalCycleTxtBx = "(//td[@data-label='Cycles/yr']/following-sibling::td/div/input)[2]";
		public static final String animalYrTxtBx = "//td[@data-label='Animals/yr']/div/input";
		public static final String kgHDDayTxtBx = "(//td[@data-label='Animals/yr']/following-sibling::td/div/input)[1]";
		public static final String dayFedYRTxtBx = "(//td[@data-label='Animals/yr']/following-sibling::td/div/input)[2]";
		public static final String totalTxtBx = "//td[@data-label='Total']/div/input";		
		public static final String shareTxtBx = "//td[@data-label='% of share']/div/input";
		public static final String estimatedCloseDateTxtBx = "((//span[text()='Estimated Close Date'])[2])/../following-sibling::div/input";
		public static final String opportunityNameTxtBx = "(//label/following-sibling::input)[1]";
		public static final String opportunityAccountNameTxtBx = "//input[@title='Search Accounts']";
		public static final String valueCEFTxtBx = "(//div[@title='Value/CFE']/../../../following-sibling::tbody/tr/td[3])[1]";
		public static final String cEFINCLPercentTxtBx = "(//div[@title='Value/CFE']/../../../following-sibling::tbody/tr/td[4])[1]"; 
		public static final String newEventSubjectTxtBx = "(//label[text()='Subject'])[1]/following-sibling::div[1]";
		public static final String parentAccountTxtBx = "//span[text()='Parent Account']/../following-sibling::div//div/input[@title='Search Accounts']";
		public static final String buyingGroupTxtBx = "//span[text()='Buying Group']/../following-sibling::div//input[@title='Search Accounts']";
		public static final String emailTxtBx = "//span[text()='Email']/../following-sibling::input[@type='email']";
		public static final String phoneTxtBx = "//span[text()='Phone']/../following-sibling::input[@type='tel']";
		public static final String cityPATxtBx = "//h3/span[text()='Physical Address']/../following-sibling::div//span[text()='City']/../following-sibling::input[contains(@class,'city')]";
		public static final String statePATxtBx = "//h3/span[text()='Physical Address']/../following-sibling::div//span[text()='State/Province']/../following-sibling::input[contains(@class,'state')]";
		public static final String zipCodePATxtBx = "//h3/span[text()='Physical Address']/../following-sibling::div//span[text()='Zip/Postal Code']/../following-sibling::input[contains(@class,'postalCode')]";
		public static final String countryPATxtBx = "//h3/span[text()='Physical Address']/../following-sibling::div//span[text()='Country']/../following-sibling::input[contains(@class,'country')]";
		public static final String websiteAddressTxtBx = "//span[text()='Website Address']/../following-sibling::input";
		public static final String cityCATxtBx = "//h3/span[text()='Correspondence Address']/../following-sibling::div//span[text()='City']/../following-sibling::input[contains(@class,'city')]";
		public static final String stateCATxtBx = "//h3/span[text()='Correspondence Address']/../following-sibling::div//span[text()='State/Province']/../following-sibling::input[contains(@class,'state')]";
		public static final String zipCodeCATxtBx = "//h3/span[text()='Correspondence Address']/../following-sibling::div//span[text()='Zip/Postal Code']/../following-sibling::input[contains(@class,'postalCode')]";
		public static final String countryCATxtBx = "//h3/span[text()='Correspondence Address']/../following-sibling::div//span[text()='Country']/../following-sibling::input[contains(@class,'country')]";
		public static final String dUNSTxtBx = "//span[text()='D-U-N-S #']/../following-sibling::input";
		public static final String vATTxtBx = "//span[text()='VAT #']/../following-sibling::input";
		public static final String taxIDTxtBx = "//span[text()='Tax ID']/../following-sibling::input";
		public static final String paymentTermsTxtBx = "//span[text()='Payment Terms']/../following-sibling::input";
		public static final String marginEstimateTxtBx = "//span[text()='Margin Estimate']/../following-sibling::input";
		public static final String volumeEstimateTxtBx = "//span[text()='Volume Estimate']/../following-sibling::input";
		public static final String amountofQuotaTxtBx = "//span[text()='Amount of Quota']/../following-sibling::input";
		public static final String parentAccountEXTIDTxtBx = "//span[text()='Parent Account External ID']/../following-sibling::input";
		
			/*-------------------------------------ComboBox----------------------------------*/
		
		public static final String calculationTypeComboBx = "//label[text()='CALCULATION TYPE']/following-sibling::div/div/div/select";
		public static final String speciesTypeComboBx = "//label[text()='SPECIES']/following-sibling::div/div/div/select";
		public static final String externalLeadSourceComboBx = "//span[text()='External Lead Source']/../following-sibling::div//div//a[@class='select']";
		public static final String priorityComboBx = "//span[text()='Priority']/../following-sibling::div//a[@class='select']";
		public static final String segmentComboBx = "//span[text()='Segment (Step 1)']/../following-sibling::div//a[@class='select']";
		public static final String nineBoxComboBx = "//span[text()='9-Box (Step 2)']/../following-sibling::div//a[@class='select']";
		public static final String salesStatusComboBx = "//span[text()='Sales Status']/../following-sibling::div//a[@class='select' and text()='Prospect']";
		public static final String defaultCargillPlantComboBx = "//span[text()='Default Cargill Plant']/../following-sibling::div//a[@class='select']";
		public static final String brandComboBx = "//span[text()='Brand']/../following-sibling::div//a[@class='select']";
		public static final String subTypeComboBx = "//span[text()='Sub-Type']/../following-sibling::div//a[@class='select']";
		
		/*-------------------------------------ComboBox Options-------------------------------*/
		public static final String typeOption = "//td[@data-label='Type']/div/div/div/div/select";
		public static final String productFunOption = "//td[@data-label='Product Function']/div/div/div/div/select";
		
		 /*-------------------------------------Label-------------------------------------*/
		public static final String legalNameLbl = "//span[text()='Legal Name']";
		public static final String accountStatusLbl = "//span[text()='AccountStatus']";
		public static final String sourceSystemLbl = "//span[text()='SourceSystem']/../following-sibling::div//span[text()='SFDC']";
		public static final String externalIdLbl = "//span[text()='External Id']";
		public static final String lastActivityDateLbl = "//span[text()='Last Activity Date']";
		public static final String lastActivityTypeLbl = "//span[text()='Last Activity Type']";
		public static final String choosenSpeciesLbl = "//div[text()='Species']/..//span[text()='Chosen']";
		public static final String choosenOtherBuisnessUnitLbl = "//div[text()='Other Business Units']/..//span[text()='Chosen']";
		public static final String choosenProductBrandLbl = "//div[text()='Product Brand']/..//span[text()='Chosen']";
		public static final String choosenSubBrandLbl = "//div[text()='Sub-Brand']/..//span[text()='Chosen']";
		
		
		 /*-------------------------------------Checkbox-------------------------------------*/
		public static final String activeChkBx = "//span[text()='Active?']/../following-sibling::div//span/img";
		public static final String marketInfluencerChkBx = "//span[text()='Market Influencer']/../following-sibling::input[@type='checkbox']";
		public static final String prospectValidatedChkBx = "(//span[text()='Prospect Validated?'])[2]/../following-sibling::div//span/img";
		public static final String autoValidateChkBx = "//span[text()='Auto Validate?']/../following-sibling::div//span/img";
		public static final String isDuplicateChkBx = "//span[text()='Is Duplicate?']/../following-sibling::div//img";
		public static final String vATfarmerChkBx = "//span[text()='VAT farmer']/../following-sibling::input[@type='checkbox']";
		public static final String mobileFirstChkBx = "//span[text()='Mobile First']/../following-sibling::div//span/img";

		 /*-------------------------------------TextArea-------------------------------------*/

		public static final String socialMediaAddressTxtArea = "//span[text()='Social Media Address']/../following-sibling::textarea";
		public static final String streetPATxtArea = "//h3/span[text()='Physical Address']/../following-sibling::div//span[text()='Street']/../following-sibling::textarea";
		public static final String streetCATxtArea = "//h3/span[text()='Correspondence Address']/../following-sibling::div//span[text()='Street']/../following-sibling::textarea";
		public static final String customerServiceNotesTxtArea = "//span[text()='Customer Service Notes']/../following-sibling::textarea";
		public static final String deliveryInstructionsTxtArea = "//span[text()='Delivery Instructions']/../following-sibling::textarea";
		public static final String reasonDescriptionTxtArea = "//span[text()='Reason Description']/../following-sibling::textarea";
		public static final String missionTxtArea = "//span[text()='Mission (M)']/..//following-sibling::textarea";
		public static final String keyGoalsObjectivesTxtArea = "//span[text()='Key Goals/Objectives']/following-sibling::div//div[2]//p";
		public static final String marketIntelTxtArea = "//span[text()='Market Intel']/following-sibling::div//div[2]//p";
		public static final String riskFactorsTxtArea = "//span[text()='Risk Factors']/following-sibling::div//div[2]//p";
		 /*-------------------------------------Header----------------------------------*/
		
		public static final String accountInformationHd = "//h3//span[text()='Account Information']";
		public static final String segmentInformationHd = "//h3//span[text()='Segment Information']";
		public static final String operationalInformationHd = "//h3//span[text()='Operational Information']";
		public static final String cargillInformationHd = "//h3//span[text()='Cargill Information']";
		public static final String physicalAddressHd = "//h3//span[text()='Physical Address']";
		public static final String correspondenceAddressHd = "//h3//span[text()='Correspondence Address']";
		public static final String additionalInformationHd = "//h3//span[text()='Additional Information']";
		public static final String strategicPlanningHd = "//h3//span[text()='Strategic Planning']";
		
		 /*-------------------------------------ChooseOptions----------------------------------*/
	    //Species Option
		public static final String porkSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Pork']";
		public static final String beefSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Beef']";
		public static final String dairySpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Dairy']";
		public static final String smallRuminantsSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Small Ruminants']";
		public static final String sheepSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Sheep']";
		public static final String goatSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Goat']";
		public static final String broilerSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Broiler']";
		public static final String layersSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Layers']";
		public static final String otherPoultrySpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Other Poultry']";
		public static final String turkeySpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Turkey']";
		public static final String ducksSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Ducks']";
		public static final String equineSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Equine']";
		public static final String rabbitSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Rabbit']";
		public static final String petFoodSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Pet Food']";
		public static final String aquacultureSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Aquaculture']";
		public static final String specialtySpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Specialty']";
		public static final String ingredientSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Ingredient']";
		public static final String otherSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Other']";
		public static final String milkReplacersSpeciesOp = "//div[text()='Species']/..//span[text()='Available']/..//ul//li//span[text()='Milk replacers']";
	
		// Other Buisness Unit Option
		
		public static final String gOSCEOtherBusinessUnitsOp = "//div[text()='Other Business Units']/..//span[text()='Available']/..//ul//li//span[text()='GOSCE']";
		public static final String cFNOtherBusinessUnitsOp = "//div[text()='Other Business Units']/..//span[text()='Available']/..//ul//li//span[text()='CFN']";
		public static final String cPNOtherBusinessUnitsOp = "//div[text()='Other Business Units']/..//span[text()='Available']/..//ul//li//span[text()='CPN']";
		public static final String cPNKiszkowoOtherBusinessUnitsOp = "//div[text()='Other Business Units']/..//span[text()='Available']/..//ul//li//span[text()='CPN Kiszkowo']";
		public static final String gOSCEAgriHorOtherBusinessUnitsOp = "//div[text()='Other Business Units']/..//span[text()='Available']/..//ul//li//span[text()='GOSCE/AgriHor']";
		public static final String sSEBielanyOtherBusinessUnitsOp = "//div[text()='Other Business Units']/..//span[text()='Available']/..//ul//li//span[text()='SSE Bielany']";
		
		// Product Brand option
		public static final String aCCOProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='ACCO']";
		public static final String agwayProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Agway']";
		public static final String akeyProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Akey']";
		public static final String cANProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='CAN']";
		public static final String nutrenaProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Nutrena']";
		public static final String pennfieldProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Pennfield']";
		public static final String privateLabelProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Private Label']";
		public static final String progressiveNutritionProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Progressive Nutrition']";
		public static final String promoteProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Promote']";
		public static final String provimiProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Provimi']";
		public static final String purinaProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Purina']";
		public static final String sportsmensChoiceProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()=\"Sportsmen's Choice\"]";
		public static final String sungloProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Sunglo']";
		public static final String tripleCrownProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Triple Crown']";
		public static final String vigortoneProductBrandOp = "//div[text()='Product Brand']/..//span[text()='Available']/..//ul//li//span[text()='Vigortone']";
		
		// Sub Brand option
		
		public static final String proforceSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Proforce']";
		public static final String pennfieldSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Pennfield']";
		public static final String safeChoiceSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='SafeChoice']";
		public static final String empowerSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Empower']";
		public static final String triumphSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Triumph']";
		public static final String respondSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Respond']";
		public static final String natureWiseSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='NatureWise']";
		public static final String natureSmartSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Nature Smart']";
		public static final String countryFeedsSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Country Feeds']";
		public static final String loyallSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Loyall']";
		public static final String loyallLifeSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Loyall Life']";
		public static final String riverRunSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='River Run']";
		public static final String sportsBlendSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Sports Blend']";
		public static final String nutreBeefSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='NutreBeef']";
		public static final String rightNowMineralsSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Right Now minerals']";
		public static final String cattleGrazersSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Cattle Grazers']";
		public static final String recordRackSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Record Rack']";
		public static final String sportsmensChoiceSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()=\"Sportsmen's Choice\"]";
		public static final String natureWiseNaturalsSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='NatureWise Naturals']";
		public static final String stockandStableSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Stock and Stable']";
		public static final String wranglerSweetSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Wrangler Sweet']";
		public static final String purinaSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Purina']";
		public static final String provimiSubBrandOp = "//div[text()='Sub-Brand']/..//span[text()='Available']/..//ul//li//span[text()='Provimi']";
	
	
	
}
