package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class R12001BGobj {

	private static WebElement element = null;

	public static final By scheduleName = By.id("b2fb2545-6033-8108-50fc-1fe7ac311efb_5c6ad483-51ef-8083-ae09-f31a5bd1bcd3");
	public static final By periodValue= By.id("b2fb2545-6033-8108-50fc-1fe7ac311efb_ba37f5b4-3df2-2b02-8a09-d2c5483b8de0");
	public static final By businessGroup=By.id("b2fb2545-6033-8108-50fc-1fe7ac311efb_20696157-f925-cda7-8f4e-67cdc6f38be8");
	
	public static final By currentQuarterActualAOE_target=By.name("tbCQATar");
	
	public static final By currentQuarterActualAOE_priorYear=By.name("tbCQAPri");
	
	public static final By currentQuarterAdjustedAOE_target=By.name("tbCQT");
	
	public static final By currentQuarterAdjustedAOE_priorYear=By.name("tbPriQA");
	
	public static final By varianceTarget$=By.name("tbVarTar$");
	
	public static final By variancePriorYear$=By.name("tbVarPri$");
	
public static final By varianceTargetpercent=By.name("tbVarTarPer");
	
	public static final By variancePriorYearpercent=By.name("tbVarPriPer");
	
	public static final By changeinAOETextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_ab2a00e5-7fa8-8046-106f-b40d3fc65ce9_TextArea");
	
public static final By revenueTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_18ed477a-0b8c-57ee-485e-800468d7f93a_TextArea");


public static final By costOfInventoryTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_393516ee-7ccf-7371-a2ac-c979e161f8f2_TextArea");
public static final By manufacturingCostsTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_9049b66d-e182-ffd7-2bdd-59c3cfa70aee_TextArea");


public static final By marketTomarketImpactTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_5d328c20-984d-77df-8efe-680649a81054_TextArea");

public static final By tradingMarginsTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_b7031f6c-3624-2590-c07a-d33d45c4b012_TextArea");

public static final By SGATextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_1fda8d92-2f90-32d9-0cd1-8832961337da_TextArea");

public static final By otherTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_d0bb9b86-d9ed-84e4-ea62-4e45ad525aa9_TextArea");
public static final By externalEnvironmentTextArea=By.id("7e3c73b2-0412-e917-133f-7ca2c20faa6a_d51f2fcd-0db0-bb11-7b7d-2a57b74cc9d7_TextArea");
public static final By mostRecentlyPublishedTextArea=By.id("d4c45277-e6e6-9db9-7aef-0b8f8b677210_ce56cb6b-522c-b582-1ccf-e43b90f26684_TextArea");
public static final By addbutton= By.xpath("//span[text()='Add']");
public static final By itemTextBox=By.name("Item Text Box");
public static final By countryTextBox=By.name("Country Text Box");
public static final By explainationTextBox=By.xpath("//*[@id='4ddf2b80-9798-6f11-37c1-f22bc0809db8_b944235a-ee2f-4099-9c9c-bbc14e9b9f8d_TextArea']");

}

	
   

  
	

