package objectRepository;

import org.openqa.selenium.By;


public class ProfileSetUpObj {
	
	 /*-------------------------------------Button----------------------------------*/
	
	public static final By ViewUsersBtn = By.xpath("//td[@id='topButtonRow']/input[@value='View Users']");
	public static final By cansalesloginuserBtn = By.xpath("//td[@id='topButtonRow']/input[@name = 'login']");
	public static final By canDataloginuserBtn = By.xpath("//td[@id='topButtonRow']/input[@name = 'login']");
	/*-------------------------------------Link----------------------------------*/
	public static final By CansalesuserLnk = By.xpath("//a[text()='Albert, Mathieu']");
	public static final By CanDatauserLnk = By.xpath("//a[text()='Moore, Brian']");
	
	
}
