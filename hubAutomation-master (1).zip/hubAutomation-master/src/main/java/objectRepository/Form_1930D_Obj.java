package objectRepository;

import org.openqa.selenium.By;

public class Form_1930D_Obj {
	
	public static final By btn_Add = By.xpath("//span[text() = 'Add']");
	public static final By btn_Cancel = By.xpath("//span[text() = 'Cancel']");
	public static final By btn_Delete = By.xpath("//span[text() = 'Delete']");
	public static final By napcs_Header = By.xpath("//div[contains(text(),'NAPCS')]");
	public static final By thirdPartyCust_Header = By.xpath("//div[contains(text(),'Third-party')]");
	public static final By cargillUsBus_Header = By.xpath("//div[contains(text(),'Cargill�s')]");
	public static final By reportingUnit_Header = By.xpath("//span[@name='lblReportingUnit']");
	public static final By scheduleGeneralInfo_Header=By.xpath("//span[contains(text(),'Schedule General Information')]");
	public static final By salesOfNotUsa_Header=By.xpath("(//span[contains(text(),'Sales of non-USA')])[2]");

//Account Details
	public static final By MethodUsedToCalculateFairValue_TextArea=By.xpath("//*[@id='3c340e78-8718-b99f-1571-aaafe69fb0ee_9fb4adcf-f9f1-30c5-3373-fe9f921d953c_TextArea']");
	public static final By AccountDetails_Cancel_Btn=By.xpath("(//span[text()='Cancel'])[1]");
	
	//Fair value
	public static final By fairValue_TextArea=By.xpath("//*[@id='23163629-9f15-4d6e-b3d0-1f334948e276_dda55e61-635e-420c-3dcc-469b10c15c30_3c340e78-8718-b99f-1571-aaafe69fb0ee_32a835ee-e288-4f81-af74-16432692161f']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[4]/div/div");
	public static final By fairValue=By.xpath("//input[@name='tbFairValue ']");
	
	//Long term -Yes / No
	//Question 2a Input 
	public static final By longTermNo= By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_9957274f-5f0a-1652-f12d-ada2362f6200']/label/span[1]");
	public static final By longTermYes= By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_aabd6f43-326c-7fcb-1446-47eba6f75a76']/label/span[1]");
	public static final By inputQuestion2a= By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_63c93c21-9d91-ba84-e28f-26b934151ba4']");
	public static final By inputQuestion2aText= By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_f309fef4-9630-216a-df69-b47e7a6d37c2_TextArea']");

	//Question 3a Input 
	public static final By incomeStatementYes= By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_9f7569b6-0975-a21c-2b23-7073c07aa7df']/label/span[1]");
	public static final By incomeStatementNo= By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_8a47b578-0898-e757-063e-924d6863af5f']/label/span[1]");
   public static final By inputQuestion3a=By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_b460606d-bbeb-669f-ff71-ffd689df107f']");
   public static final By inputQuestion3aText=By.xpath("//*[@id='00000000-0000-0000-0000-000000000000_8b089926-e7b2-d45b-3d1e-12f01a86fb1c_TextArea']");
 //a[text()='Save']
   public static final By saveButton=By.xpath("//a[text()='Save']");
   //Static text TC05
 //span[@title='2. Is any long-term debt shown on Balance Sheet Lines 540, 542, 665 or 667 secured?']
   public static final By statictextTC05=By.xpath("//span[@title='2. Is any long-term debt shown on Balance Sheet Lines 540, 542, 665 or 667 secured?']");
//TC_09
   public static final By addButton=By.xpath("//span[text()='Add']");
    public static final By explaination=By.xpath("//*[@id='069853b4-1280-dba5-d49b-5011d7ac440a_6d3ded5f-1322-4e26-a9ee-fbb7f2949b48_TextArea']");
 public static final By amount= By.xpath("//input[@name='tbAmount']");
 public static final By variance= By.xpath("//*[@id='069853b4-1280-dba5-d49b-5011d7ac440a_ca1fc8a3-b2b7-52e4-f0d3-46b59c884ddb']");
 


}


	
   

  
	

