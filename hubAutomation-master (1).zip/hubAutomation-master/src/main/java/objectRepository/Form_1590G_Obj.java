package objectRepository;

import org.openqa.selenium.By;

public class Form_1590G_Obj {
	
	public static final By btn_Add = By.xpath("//span[text() = 'Add']");
	public static final By btn_Cancel = By.xpath("//span[text() = 'Cancel']");
	public static final By btn_Delete = By.xpath("//span[text() = 'Delete']");
	public static final By napcs_Header = By.xpath("//div[contains(text(),'NAPCS')]");
	public static final By thirdPartyCust_Header = By.xpath("//div[contains(text(),'Third-party')]");
	public static final By cargillUsBus_Header = By.xpath("//div[contains(text(),'Cargill�s')]");
	public static final By reportingUnit_Header = By.xpath("//div[contains(text(),'Reporting unit')]");
	public static final By scheduleGeneralInfo_Header=By.xpath("//span[contains(text(),'Schedule General Information')]");
	public static final By salesOfNotUsa_Header=By.xpath("(//span[contains(text(),'Sales of non-USA')])[2]");
	//public static final By napcsCodeProductDesc_FieldRow1 = By.xpath("(//div[@class='input-control-watermark'])[2]");
	public static final By napcsCodeProductDesc_FieldRow1=By.xpath("(//input[@type='text' and @class='input-control ui-autocomplete-input'])[1]");
	public static final By napcsCodeProductDesc_FieldRow1_invalid =By.xpath("(//input[@type='text' and @class='input-control ui-autocomplete-input invalid'])[1]");
	public static final By thirdPartyCustomer_FieldRow1 = By.xpath("//input[@name='Third Party Revenue Amount Text Box2']");
	public static final By cargillUSBu_FieldRow1 =By.xpath("//input[@name='Cargill Revenue Amount Text Box2']");
	
	public static final By cargill_thirdparty =By.xpath("//input[@name='Third Party Revenue Amount Text Box2']");
	public static final By ReportingUnitCodeName_FieldRow1=By.xpath("(//input[@type='text' and @class='input-control ui-autocomplete-input'])[2]");
			//By.xpath("(//div[@class='input-control-watermark'])[3]");
	public static final By ReportingUnitCodeName_FieldRow1_invalid=By.xpath("(//input[@type='text' and @class='input-control ui-autocomplete-input invalid'])[2]");
	public static final By ReportingUnitCodeName_FieldRow1_invald_Single=By.xpath("(//input[@type='text' and @class='input-control ui-autocomplete-input invalid'])");
	public static final By napcsCodeList=By.xpath("//ul[@id='ui-id-2']/li");
	public static final By ruCodeList=By.xpath("//ul[@id='ui-id-1']/li");
	//Rows
	
	public static final By row_AfterDelete=By.xpath("//table[@class='grid-content-table zebra-stripes']/tbody/tr");
	public static final By row_1_AfterAdd=By.xpath("(//table[@class='grid-content-table zebra-stripes']/tbody/tr/td[3])[1]");
	public static final By row_2_AfterAdd=By.xpath("(//table[@class='grid-content-table zebra-stripes']/tbody/tr/td[3])[2]");
	//tool tip
	public static final By napcsCodeProductDesc_tooltip = By.xpath("(//div[@class='tooltip validation pointer-up']/span)[4]");
	public static final By thirdPartyCustomer_tooltip = By.xpath("(//div[@class='tooltip validation pointer-up']/span)[2]");
	public static final By cargillUSBu_tooltip =By.xpath("(//div[@class='tooltip validation pointer-up']/span)[3]");
	public static final By ReportingUnitCodeName_tooltip=By.xpath("(//div[@class='tooltip validation pointer-up']/span)[1]");
	public static final By cargillUSBu_tooltip_single=By.xpath("//div[@class='tooltip validation pointer-up']/span");
}


	
   

  
	

