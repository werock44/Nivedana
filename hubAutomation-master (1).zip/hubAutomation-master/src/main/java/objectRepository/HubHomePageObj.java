package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;

import utils.Util;

public class HubHomePageObj {
	private static WebElement element = null;
	public static final By hubCRPbutton = By.name("CRPButtonClick");
    public static final By hub2Button = By.name("NonCRPButtonClick");
	public static final By myDashBoardButton = By.name("MyDashBoardButton");
	public static final By statusDashBoard = By.name("StatusDashBoardButton");
	public static final By adminLink = By.name("AdminLinkButton");
	public static final By periodTextBox=By.name("PeriodID");
	public static final By periodTextBoxNew=By.name("tbPeriod");
    public static final By selectSchedule=By.xpath("//input[@class='input-control ui-autocomplete-input']");
	public static final By selectScheduleNew = By.xpath("//*[@id='1484ae42-5bf1-531f-459e-622d02e6357f_4c1b9c0c-201b-4238-9b82-20f43788ab8a']/div/div[2]/a/span/span");
    public static final By searchButtonDashboard=By.xpath("//a[text()='Search']");
    public static final By scheduleName=By.xpath("//div[2]/div[2]/div/ul/li[@title='Transaction Tax Contingencies and Reserves']");
   public static final By edt_EntityDeatils = By.name("txtEntityDetail");
   public static final By Btn_Open = By.name("btnOpenEdit");
   public static final By StatusVal_Row1=By.xpath("(//table[@class='grid-content-table zebra-stripes']/tbody/tr)[22]/td[5]");
   public static final By LockedByVal_Row1=By.xpath("(//table[@class='grid-content-table zebra-stripes']/tbody/tr)[22]/td[6]");
   public static final By Btn_reCall=By.xpath("//*[@name='btnRecallEdit']");
    /* Status Dashboard screen */
    public static final By table_scheduleName = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[1]/td[1]/div");
    public static final By table_entityDetail = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[2]/td[2]/div");
    public static final By table_entityPeriod = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[2]/td[3]/div");
    public static final By table_scheduleDueDate = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[2]/td[4]/div");
    public static final By table_status = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[1]/td[5]/div");
    public static final By table_lastActionBy = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[1]/td[6]/div");
    public static final By table_view = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[2]/td[7]/div");
    public static final By table_recall = By.xpath("(//table[@class='grid-content-table zebra-stripes'])[2]/descendant::tr[2]/td[8]/div");
    public static final By recall_cancel_button=By.xpath("//a[text()='Cancel']");
    public static final By scheduleButton=By.xpath("//*[@id='1484ae42-5bf1-531f-459e-622d02e6357f_4c1b9c0c-201b-4238-9b82-20f43788ab8a']/div/div[1]/div[2]/div[2]/div/a");
    public static final By statusDropdown = By.xpath("//*[@id='1484ae42-5bf1-531f-459e-622d02e6357f_c0997aa7-879e-446d-bf8d-0ee96f0d8c51']/div/div[2]/a/span/span");
    public static final By statusSubmit = By.xpath("//span[text()='Submitted']");
    public static final By actionerDSIDtextbox = By.name("txtActioner");
    public static final By ascendingRadioButton = By.xpath("//span[text()='Ascending']");
    public static final By descendingRadioButton = By.xpath("//span[text()='Descending']");
    public static final By sortColumn= By.xpath("//*[@id='1484ae42-5bf1-531f-459e-622d02e6357f_d12bfca0-72fa-4d6c-8c14-f5c94e3244db']/div/div[2]/a/span/span");
    public static final By sortValue = By.xpath("(//span[text()='Entity Detail'])[2]");
  public static final By clearAllFilters = By.xpath("//span[text()='Clear All Filters Except Period']");
    public static final By refreshView = By.xpath("//span[text()='Refresh View']");
    public static final By periodTextBoxStatusDB=By.name("tbPeriod");
    public static final By statusValueStatusDB=By.xpath("//span[@name='dlStatusEdit']");
    public static final By lastActionByValStatusDB=By.xpath("//span[@name='dlLastActionByEdit']");
    
    /* Admin DashBoard */
    public static final By admintable_view = By.name("btnViewInstanceEdit");
    public static final By admintable_redirect = By.name("btnRedirectEdit");
    public static final By admintable_reject = By.name("btnRejectEdit");
    public static final By admintable_NA = By.name("btnNAEdit");
    public static final By admintable_edit = By.name("btnAdminOpenEdit");
    public static final By adminscheduleButton=By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_c718014f-6e1c-4cfc-a3e9-c5c7bd811a0a']/div/div[2]/a/span/span");
    public static final By adminstatusDropdown = By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_84e906fb-089a-4003-8712-6266adc86958']/div/div[2]/a/span/span");
    public static final By adminsortColumn= By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_e5c23ad5-876f-4bf3-a9a0-a51262d130d9']/div/div[2]/a/span/span");
    public static final By adminstatusValue= By.xpath("//li[3]/a/span[text()='Current']");
    public static final By enterRejectionCommentTxtBox=By.xpath("//div[@class='input-control text-input']/div[2]/div[2]/div/div");
    public static WebElement findScheduleName(WebDriver driver, String ScheduleName){
		 String s= "//div[2]/div[2]/div/ul/li[@title=";
		 String s1 = "]";
		 ScheduleName = "'"+ScheduleName+"'";
//		 System.out.println(s+ScheduleName+s1);
	    element = driver.findElement(By.xpath(s+ScheduleName+s1));
	 
	 return element; 	 
 
   }
    
    public static WebElement frameStatusOfScheduleLocator(WebDriver driver, String statusVal){
    	String a = "//div/div/ul/li[@title=";
    	String b = "]";
    	statusVal = "'"+statusVal+"'";
    	element = driver.findElement(By.xpath(a+statusVal+b));
    	return element;
    }
    
   public static WebElement findEntityName(WebDriver driver, String EntityName){
		 String s= "//span[text()=";
		 String s1 = "]/../../..";
		 EntityName = "'"+EntityName+"'";
//		 System.out.println(s+EntityName+s1);
	    element = driver.findElement(By.xpath(s+EntityName+s1)); 	
	 return element; 

   }
   
   public static WebElement findEntityCode(WebDriver driver, String EntityCode){
		 String s= "//span[contains(text(),";
		 String s1 = ")]";
		 EntityCode = "'"+EntityCode+"'";
//		 System.out.println(s+EntityName+s1);
	    element = driver.findElement(By.xpath(s+EntityCode+s1)); 	
	 return element; 

 }
   
   public static WebElement findDynamicXpathTypeOfReserve(WebDriver driver, String TypeOfReserve){
		 String s= "//div[@title=";
		 String s1 = "]";
		 String TypeOfRes = "'"+TypeOfReserve+"'";
	    element = driver.findElement(By.xpath(s+TypeOfRes+s1)); 	
	 return element;
 }
   public static WebElement findDynamicXpathReserveGLAcc(WebDriver driver, String ReserveGLACC){
		 String s= "//span[text()=";
		 String s1 = "]";
		 String TypeOfRes = "'"+ReserveGLACC+"'";
//		 System.out.println(s2+s+EntityName+s1+s3);
	    element = driver.findElement(By.xpath(s+TypeOfRes+s1)); 	
	 return element;
}
   public static WebElement findEntityCodeNew(WebDriver driver, String EntityCode){
		 String s= "(//span[contains(text(),";
		 String s1 = ")])[2]";
		 EntityCode = "'"+EntityCode+"'";
//		 System.out.println(s+EntityName+s1);
	    element = driver.findElement(By.xpath(s+EntityCode+s1)); 	
	 return element; 

}

   public static WebElement findDueDateXpath(WebDriver driver, String scheduleName){
	
	   String s1 = "//span[text()='";
	   String s2 = "']/../../../following-sibling::td[5]";
	   String duedatexpath=s1+scheduleName+s2;
//		 System.out.println(s+EntityName+s1);
	    element = driver.findElement(By.xpath(s1+scheduleName+s2)); 	
	 return element; 
   } 
   
	 public static WebElement findDueDate_Value_Xpath(WebDriver driver, String scheduleName){
			
		   String s1 = "//span[text()='";
		   String s2 = "']/../../../following-sibling::td[5]/div/div/span";
		   String duedatexpath=s1+scheduleName+s2;
//			 System.out.println(s+EntityName+s1);
		    element = driver.findElement(By.xpath(s1+scheduleName+s2)); 	
		 return element;  

 }
   
}