package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HubContributorFormObj {
	public static final By btn_Add = By.xpath("//span[text() = 'Add']");
	public static final By edt_CountryNAme = By.name("tbCountry");
	public static final By edt_Currency = By.name("tbLocalCurreny");
	public static final By edt_CurrentTaxRate = By.name("tbcurrentTaxRate");
	public static final By drpDown_Status = By.xpath(
			"//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_62e4d9c3-9af3-41fd-8994-998f0b1190c6']/div/div[1]/div[2]/div[2]/div/a");
	public static final By statusValue_Undiscovered = By.xpath("//li[@title='Undiscovered']");
	public static final By statusValue_Audit = By.xpath("//li[@title='Audit']");
	public static final By statusValue_Litigation = By.xpath("//li[@title='Litigation']");
	public static final By statusValue_Resolved = By.xpath("//li[@title='Resolved']");
	public static final By edt_ShortDescription = By
			.id("0f493254-087a-8e88-0edc-80834b5e1262_b14c1b4c-9c15-4f57-af71-10178cc4dabc_TextArea");
	public static final By edt_LongDescription = By
			.id("0f493254-087a-8e88-0edc-80834b5e1262_aff83811-979e-4592-a514-009d4fdba646_TextArea");
	public static final By drpDown_ReognitionThreshold = By.xpath(
			"//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_f706c285-86b8-6877-119e-3d38ea197144']/div/div[1]/div[2]/div[2]/div/a");
	public static final By selectedVal_drpDown_ReognitionThreshold = By.xpath("//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_f706c285-86b8-6877-119e-3d38ea197144']/div/div[1]/div[2]/div[2]/div/a/span");

	public static final By ReognitionThreshold_MoreThan50 = By.xpath("//li[@title='>50%']");
	public static final By ReognitionThreshold_LessThan50 = By.xpath("//li[@title='<50%']");
	public static final By edt_ExpectedBenifit = By.name("tbExpectedBenefitLocal");
	//TO CHECK ALL THE DROPDOWN VALUES
	public static final By drpDown_GLAcountReserveList = By.xpath("//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_0f047a83-f397-6274-b5df-7d334de1aa73_droplist']/div[2]/div[2]/div/ul/li");
	public static final By drpDwn_GeneralAccountRecorded = By.xpath("//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_5cac5b0b-d4ef-aa1d-141c-6310de8fa0df_droplist']/div[2]/div[2]/div/ul/li");
	public static final By drpDwn_GLAccountRecordedAccuredInterestDefault = By.xpath("//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_5cac5b0b-d4ef-aa1d-141c-6310de8fa0df']/div/div[1]/div[2]/div[2]/div/a/span");
	//_____________________________
	
	public static final By drpDown_GLAccountReserve = By.xpath(
			"//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_0f047a83-f397-6274-b5df-7d334de1aa73']/div/div[1]/div[2]/div[2]/div/a");
	public static final By GLAccountReserve_147350 = By.xpath("//li[contains(@title,'147350')]");
	public static final By GLAccountReserve_229670 = By.xpath("//li[contains(@title,'229670')]");
	public static final By GLAccountReserve_268100 = By.xpath("//li[contains(@title,'268100')]");
	public static final By GLAccountReserve_155100 = By.xpath("//li[contains(@title,'155100')]");
	public static final By GLAccountReserve_155140 = By.xpath("//li[contains(@title,'155140')]");
	public static final By GLAccountReserve_129350 = By.xpath("//li[contains(@title,'129350')]");
	public static final By GLAccountReserve_Other = By.xpath("//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_0f047a83-f397-6274-b5df-7d334de1aa73']/div/div[1]/div[2]/div[2]/div/a/span");
	
	
	public static final By edt_UnrecognizedTaxBenifit = By.name("tbUnrecognizedTaxBenefitLocal");
	public static final By edt_UnrecognizedTaxBenifitUSD = By.name("tbUnrecognizedTaxBenefitUSD");
	public static final By drpDown_GLAccountInterestPenalities = By.xpath(
			"//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_5cac5b0b-d4ef-aa1d-141c-6310de8fa0df']/div/div[1]/div[2]/div[2]/div/a");
	public static final By val_GLAccountInterestPenalities268200 = By.xpath("//li[contains(@title,'268200')]");
	public static final By edt_AccuredInterestPenalities = By.name("tbAccruedI&PLocal");
	public static final By edt_AccuredInterestPenalitiesUSD = By.name("tbAccruedI&PUSD");
	public static final By popUp_RequiredFieldWarning = By.xpath("//div[@title='Required Field Warning']");
	public static final By notSavedPopUpMessage= By.xpath("//div[contains(text(), 'Please correct the errors highlighted in red!!')]");
	public static final By selectedValInGLAccountReverseDropDwn = By.xpath("//*[@id='0f493254-087a-8e88-0edc-80834b5e1262_0f047a83-f397-6274-b5df-7d334de1aa73']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By messagePopUpText=By.xpath("//div[@class='message']");
	private static WebElement element = null;

	String countryName = "//*[@name='tbCountry']";
	String fromTaxYear = "//*[@name='tbFromTaxYear']";
	String toTaxYear = "//*[@name='tbToTaxYear']";
	String taxDeductCheckBox = "//label";
	String currentTaxRate = "//input[@name='tbcurrentTaxRate']";
	String saveButton = "//a[@name='btnSave']";
	String successMessage = "//div[@title='Success']";
	String invalidMessage = "//div[contains(text(),'To Tax Year should be greater than From Tax Year')]";
	public static final By btn_OkSuccessPopUp = By.xpath("//a[contains(@id, 'messageBoxButton_OK')]");
	public static final By btn_OkSuccessPopUpNew= By.xpath("//a[contains(text(), 'OK')]");
	public static final By submitPopUpHeader=By.xpath("//div[@class='popup-header-text']");//Are you sure you are ready to submit?
	public static final By btn_Cancel= By.xpath("//a[contains(text(), 'Cancel')]");
	public static final By invalidMessageForDecimalVal=By.xpath("//span[text()='Please report with no decimals.']");
	public static final By invalidMessagePositiveval=By.xpath("(//span[text()='Invalid Entry! Positive numbers are not allowed'])[1]");
	public static final By popUp_WarningClose = By
			.xpath("//*[@id='PopupWin_075e846a-f32a-ddde-c710-738b829c1477']/div[1]/div[2]/div/div/div[2]/div/div/a");
	public static final By popUpWarning = By.xpath("//div[@title='Warning']");
	public static final By popUp_WarningMsg = By.xpath(
			"//*[@id='PopupWin_075e846a-f32a-ddde-c710-738b829c1477']/div[2]/div[2]/div/div/div/div[2]/div[2]/div[2]/div/div/div[2]");
	// Scenario Analysis -Reserves(Local)
	public static final By bestCase = By.xpath("//input[@name='tbBestCaseSARLocal']");
	public static final By mostLikely = By.xpath("//input[@name='tbMostLikelySARLocal']");
	public static final By worstCase = By.xpath("//input[@name='tbWorstCaseSARLocal']");
	public static final By lbl_IdNo = By.name("lblIDNo");
	public static final By lbl_Reserve_Id=By.name("lblReserveID");
	public static final By statusDropDown=By.xpath("(//div[2]/div[2]/div/ul/li[4])[4]");
	//Scenario Analysis - USD
	public static final By bestCaseUSD = By.xpath("//input[@name='tbBestCaseSARUSD']");
	public static final By mostLikelyUSD = By.xpath("//input[@name='tbMostLikelySARUSD']");
	public static final By worstCaseUSD = By.xpath("//input[@name='tbWorstCaseSARUSD']");

	public static final By edt_StatusOfReserve = By
			.id("0f493254-087a-8e88-0edc-80834b5e1262_b12a14e2-78bb-4637-bbb6-8216a1633804_TextArea");
	public static final By edt_StatusOfReserve816 = By
			.id("25d2388f-d4ae-5092-2578-305d672ca944_920f2e37-c929-43f5-a456-580608c17451_TextArea");
	public static final By edt_TaxBenifitFiled = By.name("tbTaxBenefitLocal");
	public static final By edt_TaxBenifitFiledUSD = By.name("tbTaxBenefitUSD");
	public static final By potentialInterestLocal = By.name("tbPotentialI&PLocal");
	public static final By potentialInterestUSD = By.name("tbPotentialI&PUSD");
	public static final By edt_BegBalance = By.name("tbBegBal");
	public static final By edt_ChargeToPLField = By.name("tbChargetoP&L");

	// 815A
	public static final By begBalance = By.name("tbBegBal");
	public static final By chargePL = By.name("tbChargePL");
	public static final By returnPL = By.name("tbReturnedPL");
	public static final By useForIntended = By.name("tbUseForIntended");
	public static final By translation = By.name("tbTranslation");
	public static final By reClass = By.name("tbReclass");
	public static final By endingBalance = By.name("tbEndingBal");
	public static final By descriptionOfTaxContigency = By.xpath("(//*[contains(@id, 'TextArea')])[2]");
	public static final By backgroundOfTaxContigency = By.xpath("(//*[contains(@id, 'TextArea')])[3]");
	
	
	// 816A
	public static final By currentTaxRate_reserve = By.xpath("//input[@name='tbCurrentTaxRate']");
	public static final By dateFirstRecorded=By.xpath("//input[@id='25d2388f-d4ae-5092-2578-305d672ca944_2487e2aa-9b00-20ff-1452-13739390792d_TextBox']");
	public static final By typeOfReserve=By.xpath("//*[@id='25d2388f-d4ae-5092-2578-305d672ca944_97fd9933-6cf0-1d8a-e09a-8cc7c04a4395']/div/div[1]/div[2]/div[2]/div/a");
	public static final By typeOfReserveConractDefault=By.xpath("//*[@id='25d2388f-d4ae-5092-2578-305d672ca944_97fd9933-6cf0-1d8a-e09a-8cc7c04a4395_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By descriptionOfReserve=By.xpath("(//*[contains(@id, 'TextArea')])[2]");
	public static final By technicalAccountingCOE=By.xpath("//*[@id='25d2388f-d4ae-5092-2578-305d672ca944_cba0344d-e749-4350-a633-78b32e4fe053']/div/div[1]/div[2]/div[2]/div/a");
	public static final By technicalAccountingCOE_Unselected = By.xpath("//*[@id='25d2388f-d4ae-5092-2578-305d672ca944_cba0344d-e749-4350-a633-78b32e4fe053_droplist']/div[2]/div[2]/div/ul/li[1]");
	public static final By technicalAccountingCOEDropDownList = By.xpath("//*[@id='25d2388f-d4ae-5092-2578-305d672ca944_cba0344d-e749-4350-a633-78b32e4fe053_droplist']/div[2]/div[2]/div/ul/li");
	public static final By technicalAccountingCOEValMollie=By.xpath("//*[@id='25d2388f-d4ae-5092-2578-305d672ca944_cba0344d-e749-4350-a633-78b32e4fe053_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By backgroundOfContingency=By.xpath("(//*[contains(@id, 'TextArea')])[3]");
	public static final By statusOfReserve_816=By.xpath("(//*[contains(@id, 'TextArea')])[4]");
	public static final By explanationofReclassifications_816=By.xpath("(//*[contains(@id, 'TextArea')])[5]");
	public static final By chargeToPL=By.xpath("//input[@name='tbChargetoP&L']");
	public static final By returnedToPL=By.xpath("//input[@name='tbReturntoP&L']");
	public static final By useForIntended_816=By.xpath("//input[@name='tbUsedforIntented']");
	public static final By translation_816=By.xpath("//input[@name='tbTranslation']");
	public static final By reClass_816 = By.xpath("//input[@name='tbReclass']");
	public static final By popUpErrorMsgOnSumitWithFieldBlank = By.xpath("//div[@class='scroll-wrapper message-box-content warning']/descendant::div[@class='message'] ");
	public static final By statusOfreserve = By.xpath("(//*[contains(@id, 'TextArea')])[4]");
	public static final By explanationofReclassifications = By.xpath("(//*[contains(@id, 'TextArea')])[5]");
	public static final By existingGeneralReserves=By.xpath("//div[contains(text(),'No items to display.')]");
	public static final By existingGeneralResFirstRec=By.xpath("//*[@id='0136693f-140d-4a45-94e3-9d6c9b518d77_b581a664-1197-4ffe-a32b-86e18ea91f55_9673d6cb-85a9-c273-40b0-6f6c53a723ff_d890b65b-0f3a-495d-8cf2-144c0f934ecc']/div[3]/div[2]/div/div/table/tbody/tr/td[1]/div/div/span");
	public static final By existingSchedule=By.xpath("//div[contains(text(),'No items to display')]");
	public static final By existingScheduleFirstRec=By.xpath("//*[@id='1e6a59fd-93e3-4719-bb46-925676e44997_bfd165e8-a1d2-46b5-97df-75117d8e60a6_322336fa-c9b4-0fae-e33f-cf033c8c3e58_5d0e164d-4605-4ca4-ab51-7e0a46a3e110']/div[3]/div[2]/div/div/table/tbody/tr/td[1]/div/div/span");
	public static final By Btn_scheduleOpen=By.xpath("//a[@name='btnOpenEdit']");
	public static final By distributebutton=By.xpath("//a[text()='Distribute']");
	public static final By distributionSuccessmessage=By.xpath("//span[text()='Distribution Completed Successfully !!']");
	
	//Schedule 2000
	//Schedule General Information
	public static final By ScheduleNameLbl=By.xpath("//span[contains(text(),'Schedule Name')]");
	public static final By ScheduleNameValue=By.xpath("//span[@name='dlblScheduleName']");
	public static final By PeriodValue=By.xpath("//span[@name='dlblPeriod']");
	public static final By BusinessGroupValue=By.xpath("//span[@name='dlblBusinessUnit']");
	public static final By ReportingUnitValue=By.xpath("//span[@name='dlblReportingUnit']");
	
	public static final By BGMonthlyCommHeaderLbl=By.xpath("//div[@name='TheHub2.2050AForm Area Item']/div/div/following-sibling::div/div/div/span");
	public static final By RejectionCommentsLbl=By.xpath("//span[@name='lblRejectionComments']");
	public static final By RejectionCommentsValue=By.xpath("//div[@class='input-control text-input read-only']/div[2]/div[2]/div/textarea");
	public static final By BriefSummOfMonthlyResLbl=By.xpath("//span[@name='lblMonSumm']");
	public static final By BGMonthlyCommBriefSummTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[2]");
	public static final By DriversHeaderLbl=By.xpath("//span[@name='LblDrivers']");
	public static final By RevenueTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[3]");
	public static final By CostOfInventoryTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[4]");
	public static final By ManufactoringCostTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[5]");
	public static final By MarkToMarketTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[6]");
	public static final By TradingMarginTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[7]");
	public static final By SG_ATextArea=By.xpath("(//*[contains(@id,'_TextArea')])[8]");
	public static final By OtherFxTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[9]");
	public static final By ExternalEnvTextArea=By.xpath("(//*[contains(@id,'_TextArea')])[10]");
	public static final By AOETextArea=By.xpath("(//*[contains(@id,'_TextArea')])[11]");
	
	// xpath for effect dropdown
	public static final By effectDropdown = By.xpath(
			"//*[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_14be1470-4543-b119-9026-148dff4870f0']/div/div[2]/a/span/span");
	// public static final By effectValue = By.xpath("//span[@title='Credit
	// (i.e. Refund) ']");
	public static final By effectValue = By.xpath("//div[2]/div[2]/div/ul/li[@title='Credit (i.e. Refund) ']");

	// xpath for outcome dropdown
	public static final By outcomeDropdown = By.xpath(
			"//*[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_a79873df-2aaf-d4f0-ca9d-b51a887e5927']/div/div[2]/a/span/span");
	public static final By outcomeValue = By.xpath("(//span[contains(text(),'Unknown')])[1]");
	public static final By totalReserved = By.name("tbTotalReservedLocal");
	public static final By totalAccruedInterest = By.name("tbTAIPLocal");
	
	//xpath for Account Impacted
	public static final By accountImpacted=By.xpath("//*[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_51f97f88-fe66-b6b7-3efd-78a2de1f0d9f']/div/div[2]/a/span/span");
	public static final By accountImpactedValue = By.xpath("//div[2]/div[2]/div/ul/li[@title='229210	Taxes Payable-Sales Tax']");
	// Interest and penalties
	public static final By interestAndPenaltiesBestCase = By.name("tbBestCaseSAIPLocal");
	public static final By interestAndPenaltiesmostLikely = By.name("tbMostLikelySAIPLocal");
	public static final By interestAndPenaltiesworstCase = By.name("tbWorstCaseSAIPLocal");

// Interest and penalties USD
	public static final By interestAndPenaltiesBestCaseUSD = By.name("tbBestCaseSAIPUSD");
	public static final By interestAndPenaltiesmostLikelyUSD = By.name("tbMostLikelySAIPUSD");
	public static final By interestAndPenaltiesworstCaseUSD = By.name("tbWorstCaseSAIPUSD");

	public static final By statusOfReserve815 = By.xpath("//textarea[@id='e4d3c5f7-8439-caea-712f-c9a6954285f1_c8d1b95d-289c-2830-dde1-6df2ca83a448_TextArea']");

	public static final By statusreserve = By
			.id("e4d3c5f7-8439-caea-712f-c9a6954285f1_c8d1b95d-289c-2830-dde1-6df2ca83a448_TextArea");
	public static final By explainationofreclassfications = By
			.id("e4d3c5f7-8439-caea-712f-c9a6954285f1_821097d7-a499-acea-1d93-a25417915289_TextArea");

	 public static final By btn_Submit = By.name("btnSubmit");
	    public static final By btn_SaveAndRelease = By.name("btnSaveandRelease");
	    public static final By btn_Save=By.name("btnSave");
	    public static final By btn_ExportToPDF=By.xpath("//span[text()='Export To PDF']");
	    public static final By popUp_NotSaved = By.xpath("//div[@title='Not Saved']");
	    public static final By saveAndReleasePopUpMsg=By.xpath("//div[@class='message']");
	    public static final By btn_closeExportPopup=By.xpath("//a[@name='btnClose']");
	    public static final By pdfDownloadPopUpHeader=By.xpath("//div[starts-with(@title,'PDF Created_')]");
	    public static final By submitUnsuccessMessage = By.xpath("//div[@title='Submit Unsuccessful']");
	    public static final By btn_Instructions=By.xpath("//a[@name='BtnInstruction']");
	    public static final By submitOK=By.xpath("//a[text()='OK']");
	public WebElement countryName(WebDriver driver) {
		element = driver.findElement(By.xpath(countryName));
		return element;
	}

	public WebElement fromTaxYearName(WebDriver driver) {
		element = driver.findElement(By.xpath(fromTaxYear));
		return element;
	}

	public WebElement toTaxYearName(WebDriver driver) {
		element = driver.findElement(By.xpath(toTaxYear));
		return element;
	}

	public WebElement taxDeduct(WebDriver driver) {
		element = driver.findElement(By.xpath(taxDeductCheckBox));
		return element;
	}

	public WebElement currentTaxRate(WebDriver driver) {
		element = driver.findElement(By.xpath(currentTaxRate));
		return element;
	}

	public WebElement saveButton(WebDriver driver) {
		element = driver.findElement(By.xpath(saveButton));
		return element;
	}

	public WebElement successMessage(WebDriver driver) {
		element = driver.findElement(By.xpath(successMessage));
		return element;
	}

	public WebElement invalidMessage(WebDriver driver) {
		element = driver.findElement(By.xpath(invalidMessage));
		return element;
	}
   
    
    


}
