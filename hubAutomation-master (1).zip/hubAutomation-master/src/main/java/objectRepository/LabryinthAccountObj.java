package objectRepository;

import org.openqa.selenium.By;

public class LabryinthAccountObj {
	
	
	 /*-------------------------------------Header----------------------------------*/
	
	public static final By accountNameHeader = By.xpath("//span[text()='Account']/../../../following-sibling::div//span");
	public static final By relatedListQuickLinksHeader = By.xpath("//h2[text()='Related List Quick Links']");
	public static final By cFRHeader = By.xpath("//span[text()='CFR Information']");
	public static final By customLinksHeader = By.xpath("//h3/span[text()='Custom Links']");
	public static final By wonLostReasonHeader = By.xpath("//div[contains(@class,'inline-edit-record')]//button//span[text()='Won/Lost Reason']");
	
	
	/*-------------------------------------Button----------------------------------*/
	public static final By followBtn = By.xpath("//span[text()='Follow']");
	public static final By editBtn = By.xpath("//div[text()='Edit']");
	public static final By convertToCustomerBtn = By.xpath("//div[text()='Convert to Customer']");
	public static final By cancelBtn = By.xpath("//span[text()='Cancel']");
	public static final By saveBtn = By.xpath("//span[text()='Save']");

	/*-------------------------------------Label ----------------------------------*/
	public static final By physicalAddressLbl = By.xpath("//span[text()='Physical Address']");
	public static final By phoneLbl = By.xpath("//span[text()='Phone']");
	public static final By subTypeLbl = By.xpath("//span[text()='Sub-Type']");
	public static final By shareOfVolumeLbl = By.xpath("//span[text()='Share of Volume']");
	public static final By shareOfWalletLbl = By.xpath("//span[text()='Share of Wallet']");
	public static final By shareOfCFELbl = By.xpath("//span[text()='Share of CFE']");
	public static final By accountNameLbl = By.xpath("//span[text()='Account Name']/../following-sibling::div/span/span");
	public static final By accountOwnerLbl = By.xpath("//span[text()='Account Owner']/../following-sibling::div//div//a");
	public static final By legalNameLbl = By.xpath("//span[text()='Legal Name']");
	public static final By parentAccountLbl = By.xpath("//span[text()='Parent Account']");
	public static final By accountRecordTypeLbl = By.xpath("//span[text()='Account Record Type']/../../div[2]//span/div//span");
	public static final By createdByLbl = By.xpath("//div[contains(@class,'forceModal open active')]//div//span[text()='Created By']");
	public static final By ownerProfileNameandIdLbl = By.xpath("//div//span[text()='Owner Profile Name and Id']");
	public static final By lastModifiedByLbl = By.xpath("//div[contains(@class,'forceModal open active')]//div//span[text()='Last Modified By']");
	public static final By currentUserProfileNameandIdLbl = By.xpath("//div//span[text()='Current User Profile Name and Id']");
	public static final By accountIdLbl = By.xpath("//div[contains(@class,'forceModal open active')]//div//span[text()='Account Id']");
	
	
	/*-------------------------------------Link ----------------------------------*/
	
	public static final By requestLnk = By.xpath("//span[text()='Requests (1)']");
	public static final By accountTeamLnk = By.xpath("//span[text()='Account Team (0)']");
	public static final By contactsLnk = By.xpath("//span[text()='Contacts (0)']");
	public static final By contactRolesLnk = By.xpath("//span[text()='Contact Roles (0)']");
	public static final By relatedAccountsLnk = By.xpath("//span[text()='Related Accounts (0)']");
	public static final By activitiesLnk = By.xpath("//span[text()='Activities (0)']");
	public static final By accountHistoryLnk = By.xpath("//span[text()='Account History (8)']");
	public static final By notesAttachmentsLnk = By.xpath("//span[text()='Notes & Attachments (0)']");
	public static final By notesLnk = By.xpath("//span[text()='Notes (0)']");
	public static final By surveySegmentationsLnk = By.xpath("//span[text()='Survey Segmentations (0)']");
	public static final By applicationMappingsLnk = By.xpath("//span[text()='Application Mappings (0)']");
	public static final By assignedTerritoriesLnk = By.xpath("//span[text()='Assigned Territories (0)']");
	public static final By scorecard12monthsLnk = By.xpath("//div[contains(@class,'forceModal open active')]//a[text()='Scorecard 12 months']");
	public static final By shareOfWalletLnk = By.xpath("//div[contains(@class,'forceModal open active')]//a[text()='Share of Wallet']");
	public static final By opportunitiesThroughHierarchyLnk = By.xpath("//div[contains(@class,'forceModal open active')]//a[text()='Opportunities Through Hierarchy']");
	public static final By sizeOfWalletLnk = By.xpath("//div[contains(@class,'forceModal open active')]//a[text()='Size of Wallet']");
	public static final By viewRelatedAccountsLnk = By.xpath("//div[contains(@class,'forceModal open active')]//a[text()='View Related Accounts']");
	
	
	
	/*-------------------------------------Checkbox ----------------------------------*/
	public static final By prospectValidatededitChkBx = By.xpath("//span[text()='Prospect Validated?']/../../input");
	public static final By isDuplicateeditChkBx = By.xpath("//span[text()='Is Duplicate?']/../../input");
	public static final By autoValidateeditChkBx = By.xpath("//span[text()='Auto Validate?']/../../input");
	public static final By activeChkBx = By.xpath("//span[text()='Active?']/../../div[2]/span//img");
	public static final By cFRContractChkBx = By.xpath("//Label//span[text()='CFR contract']/../../input");
	public static final By cFRCustomerChkBx = By.xpath("//Label//span[text()='CFR customer']/../../input");
	public static final By requestpprovedChkBx = By.xpath("//div//span[text()='Request Approved']/../../input");
	public static final By personalIDFormulaChkBx = By.xpath("//div//span[text()='Personal ID formula']/../../input");
	public static final By isServicedbyCSProChkBx = By.xpath("//Label//span[text()='Is Serviced by CS Pro?']/../..//input");
	public static final By performanceChkBx = By.xpath("//Label//span[text()='Performance']/../..//input");
	public static final By productPortfolioChkBx = By.xpath("//Label//span[text()='Product Portfolio']/../..//input");
	public static final By creditChkBx = By.xpath("//Label//span[text()='Credit']/../..//input");
	public static final By priceChkBx = By.xpath("//Label//span[text()='Price']/../..//input");
	public static final By businessSolutionChkBx = By.xpath("//Label//span[text()='Business Solution']/../..//input");
	public static final By serviceChkBx = By.xpath("//Label//span[text()='Service']/../..//input");
	public static final By qualityChkBx = By.xpath("//Label//span[text()='Quality']/../..//input");
	public static final By otherChkBx = By.xpath("//Label//span[text()='Other']/../..//input");
	public static final By activeEditChkBx = By.xpath("//span[text()='Active?']/../../input");
	public static final By mobileFirstChkBx = By.xpath("//span[text()='Mobile First']/../following-sibling::input");

/*-------------------------------------Text box ----------------------------------*/
	
	public static final By legalNameTxtBx = By.xpath("//span[text()='Legal Name']/../../input");
	public static final By dateOfLastOrderTxtBx = By.xpath("//label/span[text()='Date of Last Order']/../following-sibling::div//input");
	public static final By dateOfLastInvoiceTxtBx = By.xpath("//label/span[text()='Date of Last Invoice']/../following-sibling::div//input");
	public static final By statisticalIDTxtBx = By.xpath("//label//span[text()='Statistical ID']/../following-sibling::input");
	public static final By personalIDTxtBx = By.xpath("//label//span[text()='Personal ID']/../following-sibling::input");
	public static final By requestedCreditLimitTxtBx = By.xpath("//label//span[text()='Requested Credit Limit']/../following-sibling::input");
	public static final By externalIdTxtBx = By.xpath("//label//span[text()='External Id']/../../input");
	public static final By lastAdminUpdateDateTxtBx = By.xpath("//legend//span[text()='Last Admin Update']//../../div//label[text()='Date']/../input");
	public static final By lastAdminUpdateTimeTxtBx = By.xpath("//legend//span[text()='Last Admin Update']//../../div//label[text()='Time']/../input");
	public static final By applicationMappingLastModifiedDateDateTxtBx = By.xpath("//legend//span[text()='Application Mapping Last Modified Date']//../../div//label[text()='Time']/../input");
	public static final By applicationMappingLastModifiedDateTimeTxtBx = By.xpath("//legend//span[text()='Application Mapping Last Modified Date']//../../div//label[text()='Time']/../input");
	public static final By contactLastModifiedDateDateTxtBx = By.xpath("//legend//span[text()='Contact Last Modified Date']//../../div//label[text()='Time']/../input");
	public static final By contactLastModifiedDateTimeTxtBx = By.xpath("//legend//span[text()='Contact Last Modified Date']//../../div//label[text()='Time']/../input");
	public static final By lastActivityDateDateTxtBx = By.xpath("//legend//span[text()='Last Activity Date']//../../div//label[text()='Time']/../input");
	public static final By lastActivityDateTimeTxtBx = By.xpath("//legend//span[text()='Last Activity Date']//../../div//label[text()='Time']/../input");
	public static final By accountTeamLastModifiedDateDateTxtBx = By.xpath("//legend//span[text()='Account Team Last Modified Date']//../../div//label[text()='Time']/../input");
	public static final By accountTeamLastModifiedDateTimeTxtBx = By.xpath("//legend//span[text()='Account Team Last Modified Date']//../../div//label[text()='Time']/../input");
	public static final By lastActivityTypeTxtBx = By.xpath("//label//span[text()='Last Activity Type']/../../input");
	public static final By correspondenceCountyCommunityTxtBx = By.xpath("//span[text()='Correspondence County/Community']/../../input");
	public static final By physicalCountyCommunityTxtBx = By.xpath("//span[text()='Physical County/Community']/../../input");
	public static final By latitudeLatitudeTxtBx = By.xpath("//legend/span[text()='Latitude']/../..//span[text()='Latitude']/../../input");
	public static final By latitudeLongitudeTxtBx = By.xpath("//legend/span[text()='Latitude']/../..//span[text()='Longitude']/../../input");
	public static final By longitudeLatitudeTxtBx = By.xpath("//legend/span[text()='Longitude']/../..//span[text()='Latitude']/../../input");
	public static final By longitudeLongitudeTxtBx = By.xpath("//legend/span[text()='Longitude']/../..//span[text()='Longitude']/../../input");
	
	
	/*-------------------------------------Combobox ----------------------------------*/	
	public static final By availabilityOnMarketCmbBx = By.xpath("//span/span[text()='Availability on Market']/../following-sibling::div//a");
	public static final By limitChangeReasonCmbBx = By.xpath("//span//span[text()='Limit Change Reason']/..//following-sibling::div//a");
	public static final By cFRExperienceGroupCmbBx = By.xpath("//span//span[text()='CFR experience group']/../../div//a");
	public static final By cFRTypeCmbBx = By.xpath("//span//span[text()='CFR type']/../../div//a");
	public static final By approvalStatusCmbBx = By.xpath("//span//span[text()='Approval Status']/../../div//a");
	public static final By businessCmbBx = By.xpath("//span//span[text()='Business']/../../div//a");
	public static final By cANBusinessCmbBx = By.xpath("//span//span[text()='CAN Business']/../../div//a");
	public static final By defaultCustomerServiceCmbBx = By.xpath("//span//span[text()='Default Customer Service']/../..//a");
	public static final By wonLostCmbBx = By.xpath("//span//span[text()='Won/Lost']/../..//a");
	public static final By accountStatusCmbBx = By.xpath("//span//span[text()='AccountStatus']/../..//a");
	public static final By SourceSystemCmbBx = By.xpath("//span//span[text()='SourceSystem']/../..//a");
	
	
	
	/*-------------------------------------Textarea ----------------------------------*/	
	public static final By lastInvoicesInfoTxtArea = By.xpath("//label/span[text()='Last Invoices Info']/../following-sibling::textarea");
	public static final By customerServiceNotesTxtArea = By.xpath("//label/span[text()='Customer Service Notes']/../../textarea");

	public static final By reqProcessingLogTxtArea = By.xpath("//label//span[text()='Req Processing Log']/../../textarea");
	public static final By assetsTxtArea = By.xpath("//span[text()='Assets']/../../textarea");
	public static final By otherActivityProductionTxtArea = By.xpath("//span[text()='Other Activity/Production']/../../textarea");
	public static final By liabilitiesTxtArea = By.xpath("//span[text()='Liabilities']/../../textarea");
	public static final By securitiesTxtArea = By.xpath("//span[text()='Securities']/../../textarea");
	public static final By wonLostReasonCommentTxtArea = By.xpath("//span[text()='Won/Lost Reason Comment']/../../textarea");

	
	

	/*-------------------------------------Header ----------------------------------*/	
	public static final By segmentInformationHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Segment Information']");
	public static final By operationalInformationHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Operational Information']");
	public static final By physicalAddressHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Physical Address']");
	public static final By correspondenceAddressHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Correspondence Address']");
	public static final By additionalInformationHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Additional Information']");
	public static final By systemInformationHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='System Information']");
	public static final By financialOtherInformationHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Financial/Other Information']");
	public static final By cargillInformationHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Cargill Information']");
	public static final By additionalInformation2Hd = By.xpath("(//div[contains(@class,'forceModal open active')]//h3//span[text()='Additional Information'])[2]");
	public static final By strategicPlanningHd = By.xpath("//div[contains(@class,'forceModal open active')]//h3//span[text()='Strategic Planning']");
	
	//LabryinthAccountObj	
}

	