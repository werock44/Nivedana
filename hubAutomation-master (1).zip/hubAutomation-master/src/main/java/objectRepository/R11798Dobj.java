package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class R11798Dobj {

	private static WebElement element = null;

	public static final By reportingUnit = By.xpath("//span[text()='7902-Cgl Pak AgriFds PvtLtdAdm']");
	public static final By ruQuestionare1dropdown = By.xpath("//*[@id='393482ec-6932-49a0-94d7-9cd1e8aeaebb_d1425424-bd57-46f6-a027-928e24b313b3']/div/div[2]/a/span/span");
	public static final By ruQuestionare2dropdown = By.xpath("//*[@id='393482ec-6932-49a0-94d7-9cd1e8aeaebb_9f52a04a-13df-4c73-83f6-526c5b9d754c']/div/div[2]/a/span/span");
	public static final By ruQuestionare1yesbutton = By.xpath("//*[@id='393482ec-6932-49a0-94d7-9cd1e8aeaebb_d1425424-bd57-46f6-a027-928e24b313b3_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By ruQuestionare1nobutton = By.xpath("//*[@id='393482ec-6932-49a0-94d7-9cd1e8aeaebb_d1425424-bd57-46f6-a027-928e24b313b3_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By ruQuestionare2yesbutton =By.xpath("//*[@id='393482ec-6932-49a0-94d7-9cd1e8aeaebb_9f52a04a-13df-4c73-83f6-526c5b9d754c_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By ruQuestionare2nobutton =By.xpath("//*[@id='393482ec-6932-49a0-94d7-9cd1e8aeaebb_9f52a04a-13df-4c73-83f6-526c5b9d754c_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By sectionCHeader =By.xpath("//span[text()='Question / Commentary']");
	
//Section C 
	public static final By interestOnlyStripsdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7c7cc44f-1672-472e-b207-9df64bee9e03']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By interestOnlyStripsYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7c7cc44f-1672-472e-b207-9df64bee9e03_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By interestOnlyStripsNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7c7cc44f-1672-472e-b207-9df64bee9e03_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By interestOnlyStripsTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_50eb235d-a7bc-4f4b-a29c-85d873c5f6a4_TextArea");
	public static final By 	interestOnlyStrips=By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7c7cc44f-1672-472e-b207-9df64bee9e03");
	
	public static final By serviceLiabilitiesdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_ce8052c0-3364-4382-b283-ca51363ef0e4']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By serviceLiabilitiesYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_ce8052c0-3364-4382-b283-ca51363ef0e4_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By serviceLiabilitiesNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_ce8052c0-3364-4382-b283-ca51363ef0e4_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");	
	public static final By serviceLiabilitiesTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_838e90a7-f071-43d9-8777-cfa8144cdef7_TextArea");
	public static final By 	serviceLiabilities=By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_ce8052c0-3364-4382-b283-ca51363ef0e4");
	
	public static final By reCourseObligationsdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6bb73ed6-56e0-4d25-9afa-5424a283c945']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By reCourseObligationsYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6bb73ed6-56e0-4d25-9afa-5424a283c945_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By reCourseObligationsNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6bb73ed6-56e0-4d25-9afa-5424a283c945_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");	
	public static final By reCourseObligationsTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_69f5e0b4-917d-4787-bd82-97b2ab05b317_TextArea");	
	public static final By reCourseObligations = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6bb73ed6-56e0-4d25-9afa-5424a283c945");
	
	public static final By otherAssetsdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_fd0b7eea-40e9-439e-acba-e6b7350b0a07']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By otherAssetsYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_fd0b7eea-40e9-439e-acba-e6b7350b0a07_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By otherAssetsNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6bb73ed6-56e0-4d25-9afa-5424a283c945_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");	
	public static final By otherAssetsTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_cc506ce0-4223-49ec-a728-aa569e14546f_TextArea");
	public static final By otherAssets = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_fd0b7eea-40e9-439e-acba-e6b7350b0a07");
	
	
	public static final By quotedPricedropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_cbf844a2-9e4e-4ec2-bf6f-efaadc4925e0']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By quotedPricedropdownYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_cbf844a2-9e4e-4ec2-bf6f-efaadc4925e0_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By quotedPricedropdownNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_cbf844a2-9e4e-4ec2-bf6f-efaadc4925e0_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By quotedPricedTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_0786bb7e-b30f-4bc3-9246-8172dcd91b3d_TextArea");
	public static final By quotedPrice= By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_cbf844a2-9e4e-4ec2-bf6f-efaadc4925e0");
	
	public static final By salesOfARdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_01ecbd67-902c-4ced-948b-2bd43edd0401']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By salesOfARdropdownYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_01ecbd67-902c-4ced-948b-2bd43edd0401_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By salesOfARdropdownNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_01ecbd67-902c-4ced-948b-2bd43edd0401_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By salesOfARTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_58b0a66b-4fe0-4530-b042-7b45c4f8d1ea_TextArea");
	public static final By salesOfAR= By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_01ecbd67-902c-4ced-948b-2bd43edd0401");
	
	public static final By eventsOrCircumdtancesdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_03406068-bedd-4f6e-ad95-eb9db72927b8']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By eventsOrCircumdtancesYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_03406068-bedd-4f6e-ad95-eb9db72927b8_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By eventsOrCircumdtancesNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_03406068-bedd-4f6e-ad95-eb9db72927b8_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By eventsOrCircumdtancesTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7562e5c3-f21b-4207-88b6-16060f62ee9d_TextArea");
	public static final By eventsOrCircumdtances = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_03406068-bedd-4f6e-ad95-eb9db72927b8");
	
	public static final By previousfinancialassetsdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_2de14ca8-49f5-42aa-b2cb-d10db78a8b2b']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By previousfinancialassetsYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_2de14ca8-49f5-42aa-b2cb-d10db78a8b2b_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By previousfinancialassetsNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_2de14ca8-49f5-42aa-b2cb-d10db78a8b2b_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By previousfinancialassetsTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_49f38914-ede1-44e4-af68-df84335cea26_TextArea");
	public static final By previousfinancialassets = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_2de14ca8-49f5-42aa-b2cb-d10db78a8b2b");
	
	
	public static final By externalPartydropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6505fbe3-9759-4111-9d71-a9d3d825b606']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By externalPartyYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6505fbe3-9759-4111-9d71-a9d3d825b606_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By externalPartyNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6505fbe3-9759-4111-9d71-a9d3d825b606_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By externalPartyTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_919f81e4-0965-45b0-a4ed-4f504d9ed8e7_TextArea");
	public static final By externalParty = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_6505fbe3-9759-4111-9d71-a9d3d825b606");
	
	
	public static final By revieweByTCMdropdown = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7f139edb-2da9-4f40-b209-c22c38556f03']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By revieweByTCMYesbutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7f139edb-2da9-4f40-b209-c22c38556f03_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By revieweByTCMNobutton = By.xpath("//*[@id='42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7f139edb-2da9-4f40-b209-c22c38556f03_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By revieweByTCMTextArea = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_124af0ba-4af2-4380-bdb7-b01f1b31270d_TextArea");
	public static final By revieweByTCM = By.id("42d5aeb6-8e73-4e8f-9a5c-7071b9632b2d_7f139edb-2da9-4f40-b209-c22c38556f03");
	
	public static final By exportByPDF=By.xpath("//*[@id='018882b6-46f0-e0ff-efaa-0bfc566f54aa_59d35cfa-9572-410d-bfa9-9eef4accb618_ToolbarButton']/span[2]/span[2]");
	
	
	//Save button
	public static final By saveButton1798D = By.name("btnSave");
	//Submit button
	
	public static final By submitButton1798D = By.name("btnSubmit");
	public static final By OKButtonAfterSave = By.xpath("//a[contains(@id, 'messageBoxButton_OK')]");
	//public static final By OKButtonAfterSave= By.id("messageBoxButton_OK1572254343319");
	
}

	
   

  
	

