package objectRepository;

import org.openqa.selenium.By;

public class OpportunityObj {

	 /*-------------------------------------Button----------------------------------*/
	public static final By cancelDependenciesBtn = By.xpath("//h2[text()='Edit Dependencies']/../following-sibling::div//button/span[text()='Cancel']");
	public static final By applyDependenciesBtn = By.xpath("//h2[text()='Edit Dependencies']/../following-sibling::div//button/span[text()='Apply']");
	public static final By cancelBtn = By.xpath("//h2[text()='New Opportunity: Opportunity']/../following-sibling::div//button/span[text()='Cancel']");
	
	public static final By saveNewBtn = By.xpath("//h2[text()='New Opportunity: Opportunity']/../following-sibling::div//button/span[text()='Save & New']");
	public static final By saveBtn = By.xpath("//h2[text()='New Opportunity: Opportunity']/../following-sibling::div//button/span[text()='Save']");

	/*-------------------------------------text area----------------------------------*/
	public static final By goalTxtarea = By.xpath("//span[text()='Goal']/..//following-sibling::textarea");
	public static final By descriptionTxtarea = By.xpath("//span[text()='Description']/../following-sibling::textarea");
	public static final By wonLostReasonCommentTxtarea = By.xpath("//span[text()='Won/Lost Reason Comment']/../following-sibling::textarea");
	public static final By otherResourcesNeededTxtarea = By.xpath("//span[text()='Other Resources Needed']/../following-sibling::textarea");
	
	
	 /*-------------------------------------Headers----------------------------------*/
	public static final By newOpportunityMainHd = By.xpath("//h2[text()='New Opportunity: Opportunity']");
	public static final By wonLostReasonHd = By.xpath("//span[text()='Won/Lost Reason']");
	public static final By opportunityValueHd = By.xpath("//span[text()='Opportunity Value']");
	public static final By additionalInformationHd = By.xpath("//span[text()='Additional Information']");
	public static final By systemInformationHd = By.xpath("//span[text()='System Information']");
	public static final By editDependenciesHd = By.xpath("//h2[text()='Edit Dependencies']");
	
	 /*-------------------------------------Label---------------------------------*/
	public static final By opportunityOwnerlbl = By.xpath("//span[text()='Opportunity Owner']/../following-sibling::div//span/span");
	public static final By actualCloseDatelbl = By.xpath("//span[text()='Actual Close Date']/../following-sibling::div//span/span");
	public static final By externalIDlbl = By.xpath("//span[text()='External Id']");
	
	 /*-------------------------------------Combobox---------------------------------*/
	public static final By businessComboBx = By.xpath("//span[text()='Business']/../following-sibling::div//a[@class='select']");
	public static final By stageComboBx = By.xpath("//span[text()='Stage']/../following-sibling::div//a[@class='select']");
	public static final By wonLostComboBx = By.xpath("//span[text()='Won/Lost']/../following-sibling::div//a[@class='select']");
	public static final By unitOfContributionComboBx = By.xpath("//span[text()='Unit of contribution']/../following-sibling::div//a[@class='select']");
	public static final By unitOfVolumeComboBx = By.xpath("//span[text()='Unit of volume']/../following-sibling::div//a[@class='select']");
	public static final By speciesComboBx = By.xpath("//span[text()='Species']/../following-sibling::div//a[@class='select']");
	public static final By externalLeadSourceComboBx = By.xpath("//span[text()='External Lead Source']/../following-sibling::div//a[@class='select']");
	public static final By businessDependenciesComboBx = By.xpath("//label[text()='Business']/following-sibling::div//input");
	public static final By unitOfVolumeDependenciesComboBx = By.xpath("//label[text()='Unit of volume']/following-sibling::div//input");
	public static final By unitOfContributionDependenciesComboBx = By.xpath("//label[text()='Unit of contribution']/following-sibling::div//input");
	
	/*-------------------------------------TextBox---------------------------------*/
	public static final By opportunityNameTxBx = By.xpath("//span[text()='Opportunity Name']/../following-sibling::input");
	public static final By opportunityOwnerTxBx = By.xpath("//span[text()='Opportunity Name']/../following-sibling::input");
	public static final By accountNameTxBx = By.xpath("//span[text()='Account Name']/../following-sibling::div//div/input");
	public static final By estimatedCloseDateTxBx = By.xpath("//span[text()='Estimated Close Date']/../following-sibling::div/input");
	public static final By alertStartDateTxBx = By.xpath("//span[text()='Alert Start Date']/../following-sibling::div/input");
	public static final By daysBetweenEmailAlertsTxBx = By.xpath("//span[text()='Days Between Email Alerts']/..//following-sibling::input");
	public static final By probabilityTxBx = By.xpath("//span[text()='Probability (%)']/../following-sibling::input");
	public static final By contributionTxBx = By.xpath("//span[text()='Contribution']/../following-sibling::input");
	public static final By volumeTxBx = By.xpath("//span[text()='Volume']/../following-sibling::input");
	public static final By numberOfAnimalsTxtBx = By.xpath("//span[text()='Number of Animals']/../following-sibling::input");
	
	
	/*-------------------------------------Checkbox---------------------------------*/
	public static final By performanceChkBx = By.xpath("//span[text()='Performance']/../following-sibling::input[@type='checkbox']");
	public static final By creditChkBx = By.xpath("//span[text()='Credit']/../following-sibling::input[@type='checkbox']");
	public static final By productPortfolioChkBx = By.xpath("//span[text()='Product Portfolio']/../following-sibling::input[@type='checkbox']");
	public static final By priceChkBx = By.xpath("//span[text()='Price']/../following-sibling::input[@type='checkbox']");
	public static final By qualityChkBx = By.xpath("//span[text()='Quality']/../following-sibling::input[@type='checkbox']");
	public static final By serviceChkBx = By.xpath("//span[text()='Service']/../following-sibling::input[@type='checkbox']");
	public static final By businessSolutionChkBx = By.xpath("//span[text()='Business Solution']/../following-sibling::input[@type='checkbox']");
	public static final By OtherChkBx = By.xpath("//span[text()='Other']/../following-sibling::input[@type='checkbox']");
	public static final By mobileFirstChkBx = By.xpath("//span[text()='System Information']/../..//span[text()='Mobile First']/../following-sibling::div/span/span/img");
	
	/*-------------------------------------Link---------------------------------*/
	public static final By buisnessViewAllDependencieslnk = By.xpath("//span[text()='Business']/../..//following-sibling::button[text()='View all dependencies']");
	public static final By unitOfContributionViewAllDependencieslnk = By.xpath("//span[text()='Unit of contribution']/../..//following-sibling::button[text()='View all dependencies']");
	public static final By unitOfVolumeViewAllDependencieslnk = By.xpath("//span[text()='Unit of volume']/../..//following-sibling::button[text()='View all dependencies']");
	
	

}





