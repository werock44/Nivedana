package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HubDistributionScreen {
	public static WebElement element;
	public static final By btn_ScheduleDistribution = By.name("btn_distribute");
	public static final By drp_scheduleDistributionFrequency = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_3f8206d8-383b-4bb5-b5e6-0f1613fcdf8a']/div/div[1]/div[2]/div[2]/div/a");
	public static final By ScheduleDistribution_Quarterly = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_3f8206d8-383b-4bb5-b5e6-0f1613fcdf8a_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By drp_schedulePeriod = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965']/div/div[1]/div[2]/div[2]/div/a");
	public static final By quarter2020_03 = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965_droplist']/div[2]/div[2]/div/ul/li[4]/a/span");
	public static final By drp_ScheduleName = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c']/div/div[1]/div[2]/div[2]/div/a");
	public static final By selectGeneral_ScheduleName = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c_droplist']/div[2]/div[2]/div/ul/li[2]/a/span");
	public static final By selectITContingency = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c_droplist']/div[2]/div[2]/div/ul/li[3]/a/span");
	public static final By selectTransactionContingency = By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c_droplist']/div[2]/div[2]/div/ul/li[5]/a/span");
	public static final By OKButton_WarningMsg = By.xpath("//a[contains(@id, 'messageBoxButton_OK')]");
	public static final By availableEntities = By.xpath("//*[@class='optioninnerwrapper' and @tabindex=-1]/div");
	public static final By btnAddSelection = By.xpath("//a[@title='Add Selection']");
	public static final By btnDistribute = By.name("btnDistribute");
	public static final By secondPeriodValue = By.xpath("/html/body/div[5]/div[2]/div/div/ul/li[3]");
	public static final By btnOkDistributionProcess = By.xpath("//a[contains(@id,'messageBoxButton_OK')]");
	public static final By edt_ScheduleDueDate = By.name("tbScheduleDueDate");
	public static final By allRowsOfMyDashboardTable = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr");
	public static final By scheduleNameRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[1]/div/div/span");
	public static final By entityDetailRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[2]/div/div/span");
	public static final By periodRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[3]/div/div/span");
	public static final By scheduleDueDateRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[4]/div/div/span");
	public static final By statusRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[5]/div/div/span");
	public static final By LockedByRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[6]/div/div/span");
	public static final By firstRow = By.xpath("//*[@name='TheHub2.MyDashBoard Area Item1']/div[3]/div[2]/div/div/table/tbody/tr/td[1]");
	public static final By btn_OpenSchedule = By.name("btnOpenEdit");
	public static final By btn_Release = By.name("btnReleaseEdit");
	
	public static final By edt_ActionerID = By.name("txtActioner");
	public static final By edt_EntityDetails = By.name("txtEntityDetail");
	public static final By scheduleDropDown = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_19b43b4c-70ae-649e-c935-3bee72388c8d']/div/div[1]/div[2]/div[2]/div/a");
	public static final By statusDropDown  = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_f093911d-60a4-214e-721d-1aafad56183a']/div/div[1]/div[2]/div[2]/div/a");
	public static final By edt_Period = By.name("PeriodID");
	public static final By sortDropDown = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_86c6b518-fdd7-6313-296d-aab85f35714d']/div/div[1]/div[2]/div[2]/div/a");
	public static final By checkBox_Ascending = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_0e67a166-e479-8edf-ae58-9b2023bef9cb']/label/span[1]");
	public static final By checkBox_Descending = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_178890eb-d5f8-f99f-4092-a21c2c624d6c']/label/span[1]");
	public static final By refreshWorkList = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_783648f5-45b6-31a1-55a1-722cd4751a42_ToolbarButton']/span[2]");
	public static final By clearALL = By.xpath("//*[@id='322336fa-c9b4-0fae-e33f-cf033c8c3e58_cca3c7a7-f063-8f79-614c-699eaa27f572_ToolbarButton']/span[2]");
	
	public static final By btn_search = By.name("btnSearch");
	public static WebElement dynamicXpathFrequency(WebDriver driver, String FirstCharacterOfList){
		 String s= "//li[starts-with(@title,";
		 String s1 = ")]";
		 FirstCharacterOfList = "'"+FirstCharacterOfList+"'";
	    element = driver.findElement(By.xpath(s+FirstCharacterOfList+s1)); 
		return element;		
	}
//	public static WebElement dynamic(WebDriver driver, String FirstCharacterOfList){
//		switch(FirstCharacterOfList){
//			case "Q":
//				element = driver.findElement(By.xpath("/html/body/div[5]/div[2]/div/div/ul/li[1]"));
//			break;
//			case "M"
			
//		}
//		return element;
		
//	}
	public static WebElement dynamicXpathSchedule(WebDriver driver, String valueOfScheduleName){
		 String s= "//li[@title=";
		 String s1 = "]";
		 valueOfScheduleName = "'"+valueOfScheduleName+"'";
		 System.out.println("---------------------------------------------"+s+valueOfScheduleName+s1);
	    element = driver.findElement(By.xpath(s+valueOfScheduleName+s1)); 
		return element;		
	}
	
}
