package objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class HubAdminScreen {

	private static WebElement element = null;

	

	public static final By entityDetail = By.name("txtEntityDetail");
	public static final By adminDashboardButton = By.name("AdminDashboardButton");
	public static final By adminScreenButton = By.name("ManageSchedulesButton");
	public static final By frameAdminScreen = By.xpath("//*[@class='content-control-iframe']");
	public static final By edt_Period = By.name("tbPeriod");
	public static final By scheduleDrpDwn = By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_c718014f-6e1c-4cfc-a3e9-c5c7bd811a0a']/div/div[1]/div[2]/div[2]/div/a");
	public static final By selectGeneral = By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_c718014f-6e1c-4cfc-a3e9-c5c7bd811a0a_droplist']/div[2]/div[2]/div/ul/li[4]/a/span");
	public static final By selectITContingency = By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_c718014f-6e1c-4cfc-a3e9-c5c7bd811a0a_droplist']/div[2]/div[2]/div/ul/li[5]/a/span");
	public static final By selectTransactionContingency = By.xpath("//*[@id='6970ad96-0534-24e8-f931-5245c4646e0f_c718014f-6e1c-4cfc-a3e9-c5c7bd811a0a_droplist']/div[2]/div[2]/div/ul/li[11]/a/span");
	public static final By searchButtom = By.name("List Button");
	public static final By scheduleDistributionButton = By.name("btn_distribute");
	public static final By scheduleAttributeMaintenance = By.xpath("//div[@title='Schedule Attribute Maintenance']");
	public static final By btn_Edit = By.id("3a2f7cc0-71d1-ab26-8d09-333a5ce293a5_279864cb-c9ba-4e21-be30-9420582c6407_ToolbarButton");
	public static final By btn_Save = By.id("3a2f7cc0-71d1-ab26-8d09-333a5ce293a5_4dab84a6-9142-4711-a556-c4cf1b2b3bed_ToolbarButton");
	public static final By btn_RefreshView = By.id("3a2f7cc0-71d1-ab26-8d09-333a5ce293a5_440e6fb8-0558-4b74-96be-1093b24ec6b7_ToolbarButton");
	public static final By scheduleAttributeTable = By.xpath("//*[@name='TheHub2.ScheduleAttribute Maintenance Area Item']/div[3]/div[2]/div/div/table/tbody/tr");
	
	
	public static final By scheduleDistWarningPopup=By.xpath("//*[contains(@id,'PopupWin_')]/div[2]/div[2]/div/div/div");
			//("//*[@id='PopupWin_86f1e8fd-e0a2-93d4-4a6d-e54bf4e4a695']/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div");
	public static final By allRowsOfScheduleTable = By.xpath("//*[@name='TheHub2.AdminDashBoard Area Item']/div[3]/div[2]/div/div/table/tbody/tr[1]");
	public static final By statusColumnRowOne = By.xpath("//*[@name='TheHub2.AdminDashBoard Area Item']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[5]/div/div");
	//Schedule Distribution page objects:
	public static final By scheduleDistFrequencyLbl=By.xpath("//span[@name='lblSchdDistroFreq']");
	public static final By scheduleDistFrequencyField=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_3f8206d8-383b-4bb5-b5e6-0f1613fcdf8a']/div/div[1]/div[2]/div[2]/div/a");
	public static final By scheduleDistFrequencyList=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_3f8206d8-383b-4bb5-b5e6-0f1613fcdf8a_droplist']/div[2]/div[2]/div/ul/li");
	public static final By scheduleDistFrequency_Unselect=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_3f8206d8-383b-4bb5-b5e6-0f1613fcdf8a_droplist']/div[2]/div[2]/div/ul/li[1]");
	public static final By scheduleDistFrequency_tooltip=By.xpath("//div[@id='e1a04065-1098-44de-a094-6639742795be_3f8206d8-383b-4bb5-b5e6-0f1613fcdf8a_Tooltip']");
	public static final By scheduleDistFrequency_Quaterly=By.xpath("//span[text()='Quarterly']");
	public static final By scheduleDistFrequency_Monthly=By.xpath("//span[text()='Monthly']");
	public static final By scheduleDistFrequency_Yearly_Fiscal=By.xpath("//span[text()='Yearly (Fiscal)']");
	public static final By PeriodLbl=By.xpath("//span[@name='lblPeriodID']");
	public static final By periodField=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965']/div/div[1]/div[2]/div[2]/div/a/span");
	public static final By periodList=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965_droplist']/div[2]/div[2]/div/ul/li");
	public static final By period_unselect=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965_droplist']/div[2]/div[2]/div/ul/li[1]");
	public static final By Period_tooltip=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965_Tooltip']");
	public static final By period_QuaterlyCurrent=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965_droplist']/div[2]/div[2]/div/ul/li[3]");
	public static final By period_QuaterlyPrevious=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8538e1ce-2f2a-4c13-bb0e-c8e1bb6dc965_droplist']/div[2]/div[2]/div/ul/li[2]");
	public static final By scheduleLbl=By.xpath("//span[@name='lblSchedule']");
	public static final By scheduleField=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c']/div/div[1]/div[2]/div[2]/div/a");
	public static final By scheduleList=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c_droplist']/div[2]/div[2]/div/ul/li");
	public static final By schedule_GenReserve=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c_droplist']/div[2]/div[2]/div/ul/li[4]");
	public static final By schedule_tooltip=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_8ec7d377-98ca-4e95-9161-16c20803ce4c_Tooltip']");
	
	public static final By entitiesLbl=By.xpath("//span[@name='lblEntities']");
	public static final By availableEntitiesHeader=By.xpath("//div[text()='Available Entities']");
	public static final By selectedEntitiesHeader=By.xpath("//div[text()='Selected Entities']");
	public static final By entities_2ndOption=By.xpath("//*[@id='e1a04065-1098-44de-a094-6639742795be_bf81715c-9196-4c5f-a41b-634f9f92d59a']/div[1]/div[1]/div/div[2]/div/div[2]");
	
	public static final By addAllicon=By.xpath("//a[@class='buttonAll hoverbtn']");
	public static final By removeAllIcon=By.xpath("//a[@class='buttonAllBack hoverbtn']");
	public static final By selectedAddicon=By.xpath("//a[@class='buttonOne hoverbtn']");
	public static final By selectedRemoveIcon=By.xpath("//a[@class='buttonOneBack hoverbtn']");
	
	public static final By scheduleDueDateLbl=By.xpath("//span[@name='lblScheduleDueDate:']");
	public static final By scheduleDueDateField=By.xpath("//input[@name='tbScheduleDueDate']");
	public static final By distributeBtn=By.xpath("//a[@name='btnDistribute']");
	public static final By distributionPopUp=By.xpath("//*[@id='PopupWin_e2a2ccb2-6008-d3a1-bbd8-08027d05d1be']/div[1]/div[2]/div/div/div[1]");
			//By.xpath("//div[@class='popup-header-text']");
			//By.xpath("//div[text()='Distribution Process Started']");
	public static final By distributionProgressBar=By.xpath("//span[@name='dlProgressBar']");
	
	//Distribution Progress Dashboard page object
	public static final By schDistributionProgDashboard=By.xpath("//span[text()='Schedule Distribution Progress Dashboard']");
	public static final By totalNumOfScheduleToBeDistributed=By.xpath("//span[@name='lblTotalInstances']");
	public static final By totalNumOfScheduleDistributed=By.xpath("//span[@name='lblWFInstances']");
	public static final By DistributionProgress=By.xpath("//span[@name='lblProgressBar']");
	public static final By pageRefreshInfo=By.xpath("//span[@name='lblRefreshInfo']");
	public static final By pageRefreshValue=By.xpath("//span[@name='dlSeconds']");
	public static final By entityDetail_Distrib=By.xpath("//div[@title='Entity Detail']");
	public static final By periodID_Distrib=By.xpath("//div[@title='Period ID']");
	public static final By stateName_Distrib=By.xpath("//div[@title='State Name']");
	public static final By HcadGroup_Distrib=By.xpath("//div[@title='HCAD Group']");
	public static final By scheduleAttributeRowOneDueDate = By.xpath("//*[@name='TheHub2.ScheduleAttribute Maintenance Area Item']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[6]/div/div/span");
	public static final By scheduleAttributeRowOneScheduleName = By.xpath("//*[@name='TheHub2.ScheduleAttribute Maintenance Area Item']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[1]/div/div/span");
	public static final By scheduleAttributeRowOneFrequency = By.xpath("//*[@name='TheHub2.ScheduleAttribute Maintenance Area Item']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[4]/div/div/span");
	public static final By scheduleAttributeRowOneDueDateInput = By.xpath("//*[@id='3a2f7cc0-71d1-ab26-8d09-333a5ce293a5_b466ad65-029c-5d37-594b-99617e97bad9_TextBox']");
	public static final By scheduleAttributeScheduleName_3rdRow=By.xpath("//*[@name='TheHub2.ScheduleAttribute Maintenance Area Item']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[1]/div/div/span");
	public static final By scheduleAttributeFrequency_3rdRow=By.xpath("//*[@name='TheHub2.ScheduleAttribute Maintenance Area Item']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[4]/div/div/span");
	public static final By scheduleAttributeDueDate_3rdRow=By.xpath("//span[text()='Reserve 816 General Reserves']/../../../following-sibling::td[5]");
	public static final By scheduleAttributeDueDate_2000A=By.xpath("//span[text()='FP&A 2000 Monthly Commentary']/../../../following-sibling::td[5]");
	public static final By scheduleAttributeDueDate_2000AValue=By.xpath("//span[text()='FP&A 2000 Monthly Commentary']/../../../following-sibling::td[5]/div/div/span");
	public static final By scheduleAttributeDueDateInput_3rdRow=By.xpath("//*[@id='3a2f7cc0-71d1-ab26-8d09-333a5ce293a5_b466ad65-029c-5d37-594b-99617e97bad9_TextBox']");

	public static final By redirect_btn=By.xpath("(//a[contains(text(),'Redirect')])[1]");
	

	
}

	
   

  
	

