package Wrap;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import utils.SpreadSheetOperation;

/**
 * 
 */

/**
 * @author s627207
 *
 */
public class TransformerAnnotation implements IAnnotationTransformer{

	
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testconstructor, Method testMethod) {
		try {
			String Flag = SpreadSheetOperation.getData("Canada","Sheet1","Flag");
			
			if(Flag=="yes")
			{
				annotation.setEnabled(false);
				System.out.println("|" + testMethod.getName()+"|enabled=false|");
			}
			else
			{
				annotation.setEnabled(true);
				System.out.println("|" + testMethod.getName()+"|enabled=true|");
			}
			
		} catch (Exception e) {
			System.out.println("Ex: in listern Transform~readTestcaseIDs");
			e.printStackTrace();
		}
		
	}

}
