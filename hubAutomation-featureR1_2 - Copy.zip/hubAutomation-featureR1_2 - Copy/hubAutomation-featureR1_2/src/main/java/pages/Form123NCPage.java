package pages;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.Range;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Reports.DriverScript;
import Reports.Status;
import objectRepository.Form_123NC_Obj;
import objectRepository.HubAdminScreen;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import utils.Base_class;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class Form123NCPage {
	static Base_class base = new Base_class();
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
    static Actions actions;
    static String parentWindow;
    static WebElement dueDateValue;
    static WebElement dueDateField;
    static String currentHandle;
    
    public static void enterDataInAssetsFields(WebDriver driver, String TestType) throws Exception{
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.cashField),"Cash");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.certOfField),"Cert of Dep/Other");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.documentIsInProc_Field),"Documents in Process of Collection");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.shortTermInvestment_Field),"Short Term Investments");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.finalcialInstruments_Field),"Financial Instruments Purchased w/Agmt to Resell");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.tradingSecurities_Field),"Trading Securities");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.accountsReceivable_Trade_Field),"Accounts Receivable, Trade");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.accountsReceivable_Others_Field),"Accounts Receivable, Other");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.accuredIncome_Field),"Accrued Income");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.allowanceForDoubtful_Field),"(Allowance for doubtful accounts)");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.marginDeposited_field),"Margins Deposited w/Clrg Assn & Brokers");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.inventories_field),"Inventories");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.prepaidExpenses_field),"Prepaid Expenses");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.ARCashManagement_field),"AR-Cash Management Account");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.ARInterestBearing_consol_field),"AR-Interest Bearing-Consol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_console_field),"AR-Noninterest Bearing-Consol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.ARInterestBearing_Nonconsol_field),"AR-Interest Bearing-Nonconsol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_Nonconsole_field),"AR-Noninterest Bearing-Nonconsol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OtherCurrentAssets_field),"Other Current Assets - Contract costs");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LoansReceivable_field),"Loans Receivable (FMG Only)");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.RealEstate_field),"Real Estate (FMG Only)");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.Notes_Accts_field),"Notes & Accts Receivable, Long-Term");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InvestmentInLoan_field),"Investment in Loan Portfolios");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTNotes_field),"LT Notes/Accts Rec-Employees");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.CashValueOfLife_field),"Cash Value of Life Ins, Net of Borrow");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.DefferedCharges_field),"Deferred Charges");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.DefferedCharges_NonCurr_field),"	Deferred Chgs-Noncurr Def Tax Debit");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.GoodWill_field),"Goodwill-Net");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.IntangibleAssets_field),"Intangible Assets");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.MiscellaneousInvestments_field),"Miscellaneous Investments");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InvestmentsInConsolidatedCompanies_field),"Investments in Consolidated Companies");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Equity_field),"Investments in Nonconsol Cos at Equity");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Cost_field),"nvestments in Nonconsol Cos at Cost");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InvestInAffiliatedPrivate_field),"Invest in Affiliated Private Inv Funds");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_Consol_field),"LT Notes/Accts Rec-Consol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_NonConsol_field),"LT Notes/Accts Rec-Nonconsol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OtherNonCurrentAssets_field),"Other NonCurrent Assets - Contract costs");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OwnedProperty_field),"Owned Property, Plant & Equipment");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.PropertyUnderCapitalLease_field),"Property Under Capital Leases");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.ConstructionsIsInProgress_field),"Construction in Progress");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field),"(Accumulated depreciation & amoritization)");

		driver.findElement(Form_123NC_Obj.AssetSave_btn).click();
	}	

	public static void enterDataInLiabilitiesFields(WebDriver driver, String TestType) throws Exception{
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.shortTermDebt),"shortTermDebt");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.sTDebtNonRecourse),"sTDebtNonRecourse");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.financialInstruments),"financialInstruments");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LtDebtCurrentRecourse),"LtDebtCurrentRecourse");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LtDebtCurrentNonRecourse),"LtDebtCurrentNonRecourse");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesRcs),"currentObligUnderCapitalLeasesRcs");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesNRcs),"currentObligUnderCapitalLeasesNRcs");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.tradingSecuritiesSold),"tradingSecuritiesSold");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.accountsPayable),"accountsPayable");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.accruedIncomeTaxes),"accruedIncomeTaxes");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.dividendsPayable),"dividendsPayable");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.stDebtCashManagement1),"stDebtCashManagement1");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.stDebtCashManagement2),"stDebtCashManagement2");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.apDebtnonInterestBearingConsol),"apDebtnonInterestBearingConsol");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.stDebtnInterestBearingNonConsol),"stDebtnInterestBearingNonConsol");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.apNoninterestBearingNonconsol),"apNoninterestBearingNonconsol");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.longTermDebt),"longTermDebt");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.lTDebtPortionNonRecourse),"lTDebtPortionNonRecourse");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionRcs),"lTDebtCapitalLeaseObligsLessCurPortionRcs");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionNRcs),"lTDebtCapitalLeaseObligsLessCurPortionNRcs");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTDebtGuaranteeofESOPDebt),"LTDebtGuaranteeofESOPDebt");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio),"LTDebtConsolCosLTPortio");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTDebtLtPortionNonRecourse),"LTDebtLtPortionNonRecourse");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio1),"LTDebtConsolCosLTPortio1");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.LTDebtNonconsolCosexclPermOther),"LTDebtNonconsolCosexclPermOther");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.NonCurrentDeferredIncomeTaxes),"NonCurrentDeferredIncomeTaxes");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.preferredStock),"preferredStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.specialPreferredStock),"specialPreferredStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.commonStock),"commonStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.esopCommonStock),"esopCommonStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.managementStock),"managementStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.retireetStock),"retireetStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.specialmanagementStock),"specialmanagementStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.additionalPaidInCapital),"additionalPaidInCapital");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.devisionEquity),"devisionEquity");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.DividendsonCommonCash),"DividendsonCommonCash");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.DividendsonPreferredCash),"DividendsonPreferredCash");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.DividendsonCommonStock),"DividendsonCommonStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.DividendsonPreferredStock),"DividendsonPreferredStock");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.retainedEarningsOther),"retainedEarningsOther");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.PermanentFinancingTransB4Tax),"PermanentFinancingTransB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.PermanentFinancingTransTax),"PermanentFinancingTransTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.NetInvestHdgsB4Tax),"NetInvestHdgsB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.NetInvestHdgsTax),"NetInvestHdgsTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecB4Tax),"UnrealizedMarketSecB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecTax),"UnrealizedMarketSecTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrealCashFlowHedgingB4Tax),"UnrealCashFlowHedgingB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrealCFHedgingTax),"UnrealCFHedgingTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustB4Tax),"AccumulatedTranslationAdjustB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustTax),"AccumulatedTranslationAdjustTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax),"UnrecogTransitionObligPensPostRetB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetTax),"UnrecogTransitionObligPensPostRetTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetB4Tax),"UnrecogPriorServiceCostPensPostRetB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetTax),"UnrecogPriorServiceCostPensPostRetTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetB4Tax),"UnrecogActuarialPensPostRetB4Tax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax),"UnrecogActuarialPensPostRetTax");
	HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.NonControllingInterests),"NonControllingInterests");
	driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
	}

	public static void clear_LiabilitiesFields(WebDriver driver, String TestType) throws Exception{
		driver.findElement(Form_123NC_Obj.shortTermDebt).clear();
		driver.findElement(Form_123NC_Obj.sTDebtNonRecourse).clear();
		driver.findElement(Form_123NC_Obj.financialInstruments).clear();
		driver.findElement(Form_123NC_Obj.LtDebtCurrentRecourse).clear();
		driver.findElement(Form_123NC_Obj.LtDebtCurrentNonRecourse).clear();
		driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesRcs).clear();
		driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesNRcs).clear();
		driver.findElement(Form_123NC_Obj.tradingSecuritiesSold).clear();
		driver.findElement(Form_123NC_Obj.accountsPayable).clear();
		driver.findElement(Form_123NC_Obj.accruedIncomeTaxes).clear();
		driver.findElement(Form_123NC_Obj.dividendsPayable).clear();
		driver.findElement(Form_123NC_Obj.stDebtCashManagement1).clear();
		driver.findElement(Form_123NC_Obj.stDebtCashManagement2).clear();
		driver.findElement(Form_123NC_Obj.apDebtnonInterestBearingConsol).clear();
		driver.findElement(Form_123NC_Obj.stDebtnInterestBearingNonConsol).clear();
		driver.findElement(Form_123NC_Obj.apNoninterestBearingNonconsol).clear();
		driver.findElement(Form_123NC_Obj.longTermDebt).clear();
		driver.findElement(Form_123NC_Obj.lTDebtPortionNonRecourse).clear();
		driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionRcs).clear();
		driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionNRcs).clear();
		driver.findElement(Form_123NC_Obj.LTDebtGuaranteeofESOPDebt).clear();
		driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio).clear();
		driver.findElement(Form_123NC_Obj.LTDebtLtPortionNonRecourse).clear();
		driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio1).clear();
		driver.findElement(Form_123NC_Obj.LTDebtNonconsolCosexclPermOther).clear();
		driver.findElement(Form_123NC_Obj.NonCurrentDeferredIncomeTaxes).clear();
	driver.findElement(Form_123NC_Obj.preferredStock).clear();
	driver.findElement(Form_123NC_Obj.specialPreferredStock).clear();
	driver.findElement(Form_123NC_Obj.commonStock).clear();
	driver.findElement(Form_123NC_Obj.esopCommonStock).clear();
	driver.findElement(Form_123NC_Obj.managementStock).clear();
	driver.findElement(Form_123NC_Obj.retireetStock).clear();
	driver.findElement(Form_123NC_Obj.specialmanagementStock).clear();
	driver.findElement(Form_123NC_Obj.additionalPaidInCapital).clear();
	driver.findElement(Form_123NC_Obj.devisionEquity).clear();
	driver.findElement(Form_123NC_Obj.DividendsonCommonCash).clear();
	driver.findElement(Form_123NC_Obj.DividendsonPreferredCash).clear();
	driver.findElement(Form_123NC_Obj.DividendsonCommonStock).clear();
	driver.findElement(Form_123NC_Obj.DividendsonPreferredStock).clear();
	driver.findElement(Form_123NC_Obj.retainedEarningsOther).clear();
	driver.findElement(Form_123NC_Obj.PermanentFinancingTransB4Tax).clear();
	driver.findElement(Form_123NC_Obj.PermanentFinancingTransTax).clear();
	driver.findElement(Form_123NC_Obj.NetInvestHdgsB4Tax).clear();
	driver.findElement(Form_123NC_Obj.NetInvestHdgsTax).clear();
	driver.findElement(Form_123NC_Obj.UnrealizedMarketSecB4Tax).clear();
	driver.findElement(Form_123NC_Obj.UnrealizedMarketSecTax).clear();
	driver.findElement(Form_123NC_Obj.UnrealCashFlowHedgingB4Tax).clear();
	driver.findElement(Form_123NC_Obj.UnrealCFHedgingTax).clear();
	driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustB4Tax).clear();
	driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustTax).clear();
	driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax).clear();
	driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetTax).clear();
	driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetB4Tax).clear();
	driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetTax).clear();
	driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetB4Tax).clear();
	driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax).clear();
	driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
	driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
	}
	
	
	public static void enterDataInIncomeStatementFields(WebDriver driver, String TestType) throws Exception{
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.GrossSales_Outside_field),"Gross Sales - Outside");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_field),"Gross Sales - Consol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_field),"Gross Sales - Nonconsol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_field),"Other Operating Income-Outside");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_field),"Other Operating Income-Consol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_field),"	Other Operating Income-Nonconsol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_field),"Sales & Other Income Adjustments");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.CostOfGoodSold_field),"Cost of Goods Sold");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.SellingOrTrading_field),"Selling/Trading");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_field),"General/Administrative");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_field),"Interest on Long-Term Debt");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_field),"Interest on Short-Term Debt");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.Depreciation_field),"Depreciation");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_field),"Intangible Asset Amortization");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_field),"Other (Income)/Expense");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_field),"Income Tax Expense/(Credit)");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_field),"Equity in Net Earnings of Consol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_field),"Equity in Net Earnings of Nonconsol Cos");
		HubContributor.Enter_PositiveNumber_in_Field(driver, TestType, "123NC", "PosVal_valid", driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_field),"(Earnings)/Losses of Noncontrolling Int");
		//Save the section:
		driver.findElement(Form_123NC_Obj.IncomeStatementSave_btn).click();
	}
    
	public static void Clear_IncomeStatementFields(WebDriver driver, String TestType) throws Exception{
		driver.findElement(Form_123NC_Obj.GrossSales_Outside_field).clear();
		driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_field).clear();
		driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_field).clear();
		driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_field).clear();
		driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_field).clear();
		driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_field).clear();
		driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_field).clear();
		driver.findElement(Form_123NC_Obj.CostOfGoodSold_field).clear();
		driver.findElement(Form_123NC_Obj.SellingOrTrading_field).clear();
		driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_field).clear();
		driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_field).clear();
		driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_field).clear();
		driver.findElement(Form_123NC_Obj.Depreciation_field).clear();
		driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_field).clear();
		driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_field).clear();
		driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_field).clear();
		driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_field).clear();
		driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_field).clear();
		driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_field).clear();
		//Save the section:
		driver.findElement(Form_123NC_Obj.IncomeStatementSave_btn).click();
	}
	
	// TC 13 and 14 common function to calculate diff calc vs actual cargill share
		
		public static int calculateValue_TC13_TC14(WebDriver driver, int value) throws Exception {
			Thread.sleep(5000);
			String totalParentInvestAmount =driver.findElement(Form_123NC_Obj.totalEquity_pii).getText().replaceAll("[,]", "");
				
			String ownershipPercentage = driver.findElement(Form_123NC_Obj.OwnershipPercent).getText().replaceAll("[,]", "");
				
			String existingBSTotal = driver.findElement(Form_123NC_Obj.totalEquity).getText().replaceAll("[,]", "");
				
			System.out.println(totalParentInvestAmount+' '+ownershipPercentage+' '+existingBSTotal);
			int totalParentInvestAmount_int = Integer.parseInt(totalParentInvestAmount);
			float ownershipPercentage_float = Float.valueOf(ownershipPercentage);
			int existingBSTotal_int = Integer.parseInt(existingBSTotal);
			System.out.println(totalParentInvestAmount_int+' '+ownershipPercentage_float+' '+existingBSTotal_int);
			
			// Formula
			float result_float = ((totalParentInvestAmount_int + value) / ownershipPercentage_float) - existingBSTotal_int;
			int result_int=(int) Math.round(result_float);
			return result_int;

		}
	
    //TC01 and TC02
	public static void verifyScheduleDistributed(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs) throws Exception {

		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.adminLink).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		Thread.sleep(5000);
		HubContributorFormPage.searchScheduleFromAdminDashboard(driver, entityName, period, schedule, Logs);
		WebElement entityXpathAd = HubHomePageObj.findEntityCode(driver, entityName);	
		boolean scheduleDistributedAd=entityXpathAd.isDisplayed();
		if(scheduleDistributedAd==true){
			Thread.sleep(4000);
			Logs.update("R1_123NC_TC01_Validate whether the Schedule owner is able to distribute the 123NC Schedule", "123NC schedule is distributed successfully and the entity is present in Admin dashboard", Status.PASS, driver);
		}
		else{
			Logs.update("R1_123NC_TC01_Validate whether the Schedule owner is able to distribute the 123NC Schedule", "123NC schedule is NOT distributed successfully", Status.FAIL, driver);		
		}
		driver.close();
		driver.switchTo().window(parentWindow);
		
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		boolean scheduleDistributed=entityXpath.isDisplayed();
		
		Assert.assertEquals(scheduleDistributed, true,"As Expected the schedule is distributed");
		if(scheduleDistributed==true){
			
			Thread.sleep(4000);
			Logs.update("R1_123NC_TC01_Validate whether the Schedule owner is able to distribute the 123NC Schedule", "123NC schedule is distributed successfully", Status.PASS, driver);
		}
		else{
			Logs.update("R1_123NC_TC01_Validate whether the Schedule owner is able to distribute the 123NC Schedule", "123NC schedule is NOT distributed successfully", Status.FAIL, driver);		
		}
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(5000);
		Logs.update("Entity search should be successful", "Entity search is successful ", Status.PASS, driver);
		
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String ScheduleNameAct=driver.findElement(HubContributorFormObj.ScheduleNameValue).getText();
		Assert.assertEquals(ScheduleNameAct, schedule);
		if (ScheduleNameAct.equalsIgnoreCase(schedule)){

			//Logs.update(testReportName, stepDescription, stepStatus, driver);

			Logs.update("R1_123NC_TC_02.1_Verify the shchedule Name", "Schedule Name is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.1_Verify the shchedule Name", "Schedule Name is not displayed as expected", Status.FAIL, driver);
		}
		String periodAct=driver.findElement(HubContributorFormObj.PeriodValue).getText();
		Assert.assertEquals(periodAct, period);
		if (periodAct.equalsIgnoreCase(period)){
			Logs.update("R1_123NC_TC_02.2_Verify that period is appropriate as to whichever period the schedule is distributed to", "Period is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.2_Verify that period is appropriate as to whichever period the schedule is distributed to", "Period is not displayed as expected", Status.FAIL, driver);
		}
		String RuGroupExp=entityName+"-"+scheduleLongDesc;
		String RuGroupAct=driver.findElement(HubContributorFormObj.ReportingUnitValue).getText();
		Assert.assertEquals(RuGroupAct, RuGroupExp);
		if (RuGroupAct.equalsIgnoreCase(RuGroupExp)){
			Logs.update("R1_123NC_TC_02.3_Verify that Reporting unit is displayed in the Schedule header", "Reporting unit is displayed as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.3_Verify that Reporting unit is displayed in the Schedule header", "Reporting unit is NOT displayed as expected", Status.FAIL, driver);

		}
		
		Boolean saveBtnPresent=driver.findElement(HubContributorFormObj.btn_Save).isDisplayed();
		if(saveBtnPresent==true){
			Logs.update("R1_123NC_TC_02.4a verify save button is present in footer", "Save button is present in the footer as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.4a verify save button is present in footer", "Save button is not present in the footer", Status.FAIL, driver);
		}
		Boolean saveAndReleasePresent=driver.findElement(HubContributorFormObj.btn_SaveAndRelease).isDisplayed();
		if(saveAndReleasePresent==true){
			Logs.update("R1_123NC_TC_02.4b verify save and release button is present in footer", "Save and release button is present in the footer as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.4b verify save and release button is present in footer", "Save and release button is Not present in the footer", Status.FAIL, driver);
		}
		Boolean submitPresent=driver.findElement(HubContributorFormObj.btn_Submit).isDisplayed();
		if(submitPresent==true){
			Logs.update("R1_123NC_TC_02.4c verify submit button is present in footer", "Submit button is present in the footer as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.4c verify submit button is present in footer", "Submit button is Not present in the footer", Status.FAIL, driver);
		}
		Boolean expToPDFPresent=driver.findElement(HubContributorFormObj.btn_ExportToPDF).isDisplayed();
		if(expToPDFPresent==true){
			Logs.update("R1_123NC_TC_02.4d verify export to pdf button is present in footer", "Export to pdf button is present in the footer as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_02.4d verify export to pdf button is present in footer", "Export to pdf button is Not present in the footer", Status.FAIL, driver);
		}
		driver.findElement(HubContributorFormObj.btn_ExportToPDF).click();
		/*Thread.sleep(45000);*/
		WebDriverWait wait=new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(HubContributorFormObj.pdfDownloadPopUpHeader));
		
		boolean downloadPopup=driver.findElement(HubContributorFormObj.pdfDownloadPopUpHeader).isDisplayed();
				if(downloadPopup==true){
					Logs.update("R1_123NC_TC_02.5 verify that user is able to click on export to PDF button", "Export to pdf button is clickable", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_02.5 verify that user is able to click on export to PDF button", "Export to pdf button is Not present in the footer", Status.FAIL, driver);
				}
			WebElement frame=driver.findElement(By.xpath("//iframe[@class='runtime-popup']"));
			driver.switchTo().frame(frame);
			Thread.sleep(5000);
			driver.findElement(HubContributorFormObj.btn_closeExportPopup).click();
			driver.findElement(HubContributorFormObj.btn_Instructions).click();
			HubContributor.switchWindow_3(driver);
			String pageURLAct=driver.getCurrentUrl();
			String UrlExp="https://sites.cargill.com/sites/Finance/CFR/Pages/Quick-Learning.aspx";
			System.out.println(pageURLAct);
			if(pageURLAct.equalsIgnoreCase(UrlExp)){
				Logs.update("R1_123NC_TC_02.5 verify the user is navigated to QuickLearning page", "Clicking on Instructions button user is navigated to page: "+pageURLAct, Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_02.5 verify the user is navigated to QuickLearning page", "Clicking on Instructions button user is NOT navigated to page: "+UrlExp+"But navigated to: "+pageURLAct, Status.FAIL, driver);
			}
		driver.quit();
		
	}
	
	//TC_04
	public static void verifyAssetTabDetails(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs, String TestType) throws Exception {

		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		/*WebDriverWait wait=new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(HubHomePageObj.Btn_Open));	*/
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String statusOfAssetSection=driver.findElement(Form_123NC_Obj.expandCollapseIcon).getAttribute("class");
		if (statusOfAssetSection.equalsIgnoreCase("expand-vertical")){
			Logs.update("R1_123NC_TC_04.1 verify that Assets tab is collapsed by_default", "Assets tab is collapsed when the schedule is opened for the first time as expected." , Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_04.1 verify that Assets tab is collapsed by_default", "Assets tab is Not collapsed when the schedule is opened at first" , Status.FAIL, driver);
		}
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.expandCollapseIcon).click();
		//WebElement ele1=driver.findElement(Form_123NC_Obj.cashLbl);


		HubContributor.verifyFieldName(driver, "Cash", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.cashLbl), Logs);
		HubContributor.verifyFieldName(driver, "Cert of Dep/Other", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.certOfLbl), Logs);
		HubContributor.verifyFieldName(driver, "Documents in Process of Collection", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.documentIsInProc_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "Total Cash, Cash Equivalents, and Restricted Cash", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.totalCash_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Short Term Investments", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.shortTermInvestment_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Financial Instruments Purchased w/Agmt to Resell", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.finalcialInstruments_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Trading Securities", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.tradingSecurities_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "Accounts & notes receivable & accrued income:", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.AccountsAndNotesReceivable_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Accounts Receivable, Trade", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.accountsReceivable_Trade_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Accounts Receivable, Other", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.accountsReceivable_Others_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Accrued Income", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.accuredIncome_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "(Allowance for doubtful accounts)", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.allowanceForDoubtful_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Accounts/Notes Rec & Accrued Inc, Net", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.accountsOrNotesRec_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "Margins Deposited w/Clrg Assn & Brokers", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.marginDeposited_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Inventories", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.inventories_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Prepaid Expenses", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.prepaidExpenses_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "Intercompany receivables", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.InterCompanyReceivables_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "AR-Cash Management Account", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.ARCashManagement_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "AR-Interest Bearing-Consol Cos", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.ARInterestBearing_Console_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "AR-Noninterest Bearing-Consol Cos", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_console_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "AR-Interest Bearing-Nonconsol Cos", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.ARInterestBearing_NonConsole_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "AR-Noninterest Bearing-Nonconsol Cos", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_Nonconsole_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other Current Assets - Contract costs", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.OtherCurrentAssets_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Total Current Assets", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.TotalCurrentAssets_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Loans Receivable (FMG Only)", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.LoansReceivable_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Real Estate (FMG Only)", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.RealEstate_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "OTHER ASSETS:", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.OtherAssets_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Notes & Accts Receivable, Long-Term", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.Notes_Accts_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Investment in Loan Portfolios", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.InvestmentInLoan_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "LT Notes/Accts Rec-Employees", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.LTNotes_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Cash Value of Life Ins, Net of Borrow", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.CashValueOfLife_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Deferred Charges", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.DefferedCharges_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Deferred Chgs-Noncurr Def Tax Debit", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.DefferedCharges_NonCurr_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Goodwill-Net", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.GoodWill_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Intangible Assets", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.IntangibleAssets_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Miscellaneous Investments", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.MiscellaneousInvestments_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Investments in Consolidated Companies", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.InvestmentsInConsolidatedCompanies_Lbl), Logs);

		HubContributor.verifyFieldName(driver, "Investments in Nonconsol Cos at Equity", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Equity_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Investments in Nonconsol Cos at Cost", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Cost_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Invest in Affiliated Private Inv Funds", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.InvestInAffiliatedPrivate_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LT Notes/Accts Rec-Consol Cos", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_Consol_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LT Notes/Accts Rec-Nonconsol Cos", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_NonConsol_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other NonCurrent Assets - Contract costs", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.OtherNonCurrentAssets_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Total Other Assets", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.TotalOtherAssets_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "PROPERTY:", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.Property_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Owned Property, Plant & Equipment", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.OwnedProperty_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Property Under Capital Leases", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.PropertyUnderCapitalLease_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Construction in Progress", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.ConstructionsIsInProgress_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "Total Gross Property", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.TotalGrossProperty_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "(Accumulated depreciation & amoritization)", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Net Property", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.NetProperty_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "TOTAL ASSETS", "R1_123NC_TC_04", driver.findElement(Form_123NC_Obj.TotalAssets_Lbl), Logs);
		
		//**validation with Negative numbers **//*
		
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.cashField), Logs, "R1_123NC_TC_04.3", 14, "Cash");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.certOfField), Logs, "R1_123NC_TC_04.3", 14, "Cert of Dep/Other");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.documentIsInProc_Field), Logs, "R1_123NC_TC_04.3", 14, "Documents in Process of Collection");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.shortTermInvestment_Field), Logs, "R1_123NC_TC_04.3", 14, "Short Term Investments");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.finalcialInstruments_Field), Logs, "R1_123NC_TC_04.3", 14, "Financial Instruments Purchased w/Agmt to Resell");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.tradingSecurities_Field), Logs, "R1_123NC_TC_04.3", 14, "Trading Securities");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Trade_Field), Logs, "R1_123NC_TC_04.3", 14, "Accounts Receivable, Trade");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Others_Field), Logs, "R1_123NC_TC_04.3", 14, "Accounts Receivable, Other");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.accuredIncome_Field), Logs, "R1_123NC_TC_04.3", 14, "Accrued Income");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.allowanceForDoubtful_Field), Logs, "R1_123NC_TC_04.3", 14, "(Allowance for doubtful accounts)");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.marginDeposited_field), Logs, "R1_123NC_TC_04.3", 14, "Margins Deposited w/Clrg Assn & Brokers");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.inventories_field), Logs, "R1_123NC_TC_04.3", 14, "Inventories");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.prepaidExpenses_field), Logs, "R1_123NC_TC_04.3", 14, "Prepaid Expenses");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.ARCashManagement_field), Logs, "R1_123NC_TC_04.3", 14, "AR-Cash Management Account");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_consol_field), Logs, "R1_123NC_TC_04.3", 14, "AR-Interest Bearing-Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_console_field), Logs, "R1_123NC_TC_04.3", 14, "AR-Noninterest Bearing-Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_Nonconsol_field), Logs, "R1_123NC_TC_04.3", 14, "AR-Interest Bearing-Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_Nonconsole_field), Logs, "R1_123NC_TC_04.3", 14, "AR-Noninterest Bearing-Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OtherCurrentAssets_field), Logs, "R1_123NC_TC_04.3", 14, "Other Current Assets - Contract costs");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LoansReceivable_field), Logs, "R1_123NC_TC_04.3", 14, "Loans Receivable (FMG Only)");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.RealEstate_field), Logs, "R1_123NC_TC_04.3", 14, "Real Estate (FMG Only)");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.Notes_Accts_field), Logs, "R1_123NC_TC_04.3", 14, "Notes & Accts Receivable, Long-Term");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InvestmentInLoan_field), Logs, "R1_123NC_TC_04.3", 14, "Investment in Loan Portfolios");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTNotes_field), Logs, "R1_123NC_TC_04.3", 14, "LT Notes/Accts Rec-Employees");
		
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.CashValueOfLife_field), Logs, "R1_123NC_TC_04.3", 14, "Cash Value of Life Ins, Net of Borrow");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.DefferedCharges_field), Logs, "R1_123NC_TC_04.3", 14, "Deferred Charges");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.DefferedCharges_NonCurr_field), Logs, "R1_123NC_TC_04.3", 14, "	Deferred Chgs-Noncurr Def Tax Debit");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.GoodWill_field), Logs, "R1_123NC_TC_04.3", 14, "Goodwill-Net");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.IntangibleAssets_field), Logs, "R1_123NC_TC_04.3", 14, "Intangible Assets");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.MiscellaneousInvestments_field), Logs, "R1_123NC_TC_04.3", 14, "Miscellaneous Investments");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InvestmentsInConsolidatedCompanies_field), Logs, "R1_123NC_TC_04.3", 14, "Investments in Consolidated Companies");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Equity_field), Logs, "R1_123NC_TC_04.3", 14, "Investments in Nonconsol Cos at Equity");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Cost_field), Logs, "R1_123NC_TC_04.3", 14, "nvestments in Nonconsol Cos at Cost");
		
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InvestInAffiliatedPrivate_field), Logs, "R1_123NC_TC_04.3", 14, "Invest in Affiliated Private Inv Funds");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_Consol_field), Logs, "R1_123NC_TC_04.3", 14, "LT Notes/Accts Rec-Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_NonConsol_field), Logs, "R1_123NC_TC_04.3", 14, "LT Notes/Accts Rec-Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OtherNonCurrentAssets_field), Logs, "R1_123NC_TC_04.3", 14, "Other NonCurrent Assets - Contract costs");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OwnedProperty_field), Logs, "R1_123NC_TC_04.3", 14, "Owned Property, Plant & Equipment");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.PropertyUnderCapitalLease_field), Logs, "R1_123NC_TC_04.3", 14, "Property Under Capital Leases");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.ConstructionsIsInProgress_field), Logs, "R1_123NC_TC_04.3", 14, "Construction in Progress");
		
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field), Logs, "R1_123NC_TC_04.3", 14, "(Accumulated depreciation & amoritization)");
		
		//Validation with alphabets
		
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.cashField), Logs, "R1_123NC_TC_04.3",  "Cash");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.certOfField), Logs, "R1_123NC_TC_04.3",  "Cert of Dep/Other");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.documentIsInProc_Field), Logs, "R1_123NC_TC_04.3",  "Documents in Process of Collection");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.shortTermInvestment_Field), Logs, "R1_123NC_TC_04.3",  "Short Term Investments");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.finalcialInstruments_Field), Logs, "R1_123NC_TC_04.3",  "Financial Instruments Purchased w/Agmt to Resell");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.tradingSecurities_Field), Logs, "R1_123NC_TC_04.3",  "Trading Securities");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Trade_Field), Logs, "R1_123NC_TC_04.3",  "Accounts Receivable, Trade");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Others_Field), Logs, "R1_123NC_TC_04.3",  "Accounts Receivable, Other");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.accuredIncome_Field), Logs, "R1_123NC_TC_04.3",  "Accrued Income");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.allowanceForDoubtful_Field), Logs, "R1_123NC_TC_04.3",  "(Allowance for doubtful accounts)");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.marginDeposited_field), Logs, "R1_123NC_TC_04.3",  "Margins Deposited w/Clrg Assn & Brokers");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.inventories_field), Logs, "R1_123NC_TC_04.3",  "Inventories");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.prepaidExpenses_field), Logs, "R1_123NC_TC_04.3",  "Prepaid Expenses");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.ARCashManagement_field), Logs, "R1_123NC_TC_04.3",  "AR-Cash Management Account");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_consol_field), Logs, "R1_123NC_TC_04.3",  "AR-Interest Bearing-Consol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_console_field), Logs, "R1_123NC_TC_04.3",  "AR-Noninterest Bearing-Consol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_Nonconsol_field), Logs, "R1_123NC_TC_04.3",  "AR-Interest Bearing-Nonconsol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_Nonconsole_field), Logs, "R1_123NC_TC_04.3",  "AR-Noninterest Bearing-Nonconsol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OtherCurrentAssets_field), Logs, "R1_123NC_TC_04.3",  "Other Current Assets - Contract costs");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LoansReceivable_field), Logs, "R1_123NC_TC_04.3",  "Loans Receivable (FMG Only)");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.RealEstate_field), Logs, "R1_123NC_TC_04.3",  "Real Estate (FMG Only)");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.Notes_Accts_field), Logs, "R1_123NC_TC_04.3",  "Notes & Accts Receivable, Long-Term");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InvestmentInLoan_field), Logs, "R1_123NC_TC_04.3",  "Investment in Loan Portfolios");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTNotes_field), Logs, "R1_123NC_TC_04.3",  "LT Notes/Accts Rec-Employees");
				
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.CashValueOfLife_field), Logs, "R1_123NC_TC_04.3",  "Cash Value of Life Ins, Net of Borrow");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.DefferedCharges_field), Logs, "R1_123NC_TC_04.3",  "Deferred Charges");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.DefferedCharges_NonCurr_field), Logs, "R1_123NC_TC_04.3",  "	Deferred Chgs-Noncurr Def Tax Debit");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.GoodWill_field), Logs, "R1_123NC_TC_04.3",  "Goodwill-Net");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.IntangibleAssets_field), Logs, "R1_123NC_TC_04.3",  "Intangible Assets");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.MiscellaneousInvestments_field), Logs, "R1_123NC_TC_04.3",  "Miscellaneous Investments");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InvestmentsInConsolidatedCompanies_field), Logs, "R1_123NC_TC_04.3",  "Investments in Consolidated Companies");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Equity_field), Logs, "R1_123NC_TC_04.3",  "Investments in Nonconsol Cos at Equity");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Cost_field), Logs, "R1_123NC_TC_04.3",  "nvestments in Nonconsol Cos at Cost");
				
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InvestInAffiliatedPrivate_field), Logs, "R1_123NC_TC_04.3",  "Invest in Affiliated Private Inv Funds");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_Consol_field), Logs, "R1_123NC_TC_04.3",  "LT Notes/Accts Rec-Consol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_NonConsol_field), Logs, "R1_123NC_TC_04.3",  "LT Notes/Accts Rec-Nonconsol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OtherNonCurrentAssets_field), Logs, "R1_123NC_TC_04.3",  "Other NonCurrent Assets - Contract costs");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OwnedProperty_field), Logs, "R1_123NC_TC_04.3",  "Owned Property, Plant & Equipment");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.PropertyUnderCapitalLease_field), Logs, "R1_123NC_TC_04.3",  "Property Under Capital Leases");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.ConstructionsIsInProgress_field), Logs, "R1_123NC_TC_04.3",  "Construction in Progress");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field), Logs, "R1_123NC_TC_04.3",  "(Accumulated depreciation & amoritization)");
			
		//Verify save with invalid value
				driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field).sendKeys("abcd");
				driver.findElement(HubContributorFormObj.btn_Save).click();
				Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
				String errorMsg = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
				Logs.update("To check the error message", "Error displayed: " + " " + errorMsg, Status.PASS, driver);
				if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

					Logs.update("R1_123NC_TC_04.3 verify that not able to save with alphabetical values",
							"Error is displayed when tried to save with abcd", Status.PASS, driver);
				} else {
					Logs.update("R1_123NC_TC_04.3 verify that not able to save with alphabetical values",
							"Error is not displayed when tried to save with abcd", Status.FAIL,
							driver);
				}
				
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field).clear();
	
				
				
				//Decimal validation
				
			    HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.cashField), Logs, "R1_123NC_TC_04.3",  "Cash");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.certOfField), Logs, "R1_123NC_TC_04.3",  "Cert of Dep/Other");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.documentIsInProc_Field), Logs, "R1_123NC_TC_04.3",  "Documents in Process of Collection");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.shortTermInvestment_Field), Logs, "R1_123NC_TC_04.3",  "Short Term Investments");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.finalcialInstruments_Field), Logs, "R1_123NC_TC_04.3",  "Financial Instruments Purchased w/Agmt to Resell");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.tradingSecurities_Field), Logs, "R1_123NC_TC_04.3",  "Trading Securities");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Trade_Field), Logs, "R1_123NC_TC_04.3",  "Accounts Receivable, Trade");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Others_Field), Logs, "R1_123NC_TC_04.3",  "Accounts Receivable, Other");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.accuredIncome_Field), Logs, "R1_123NC_TC_04.3",  "Accrued Income");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.allowanceForDoubtful_Field), Logs, "R1_123NC_TC_04.3",  "(Allowance for doubtful accounts)");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.marginDeposited_field), Logs, "R1_123NC_TC_04.3",  "Margins Deposited w/Clrg Assn & Brokers");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.inventories_field), Logs, "R1_123NC_TC_04.3",  "Inventories");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.prepaidExpenses_field), Logs, "R1_123NC_TC_04.3",  "Prepaid Expenses");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.ARCashManagement_field), Logs, "R1_123NC_TC_04.3",  "AR-Cash Management Account");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_consol_field), Logs, "R1_123NC_TC_04.3",  "AR-Interest Bearing-Consol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_console_field), Logs, "R1_123NC_TC_04.3",  "AR-Noninterest Bearing-Consol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_Nonconsol_field), Logs, "R1_123NC_TC_04.3",  "AR-Interest Bearing-Nonconsol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_Nonconsole_field), Logs, "R1_123NC_TC_04.3",  "AR-Noninterest Bearing-Nonconsol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OtherCurrentAssets_field), Logs, "R1_123NC_TC_04.3",  "Other Current Assets - Contract costs");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.LoansReceivable_field), Logs, "R1_123NC_TC_04.3",  "Loans Receivable (FMG Only)");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.RealEstate_field), Logs, "R1_123NC_TC_04.3",  "Real Estate (FMG Only)");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.Notes_Accts_field), Logs, "R1_123NC_TC_04.3",  "Notes & Accts Receivable, Long-Term");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InvestmentInLoan_field), Logs, "R1_123NC_TC_04.3",  "Investment in Loan Portfolios");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.LTNotes_field), Logs, "R1_123NC_TC_04.3",  "LT Notes/Accts Rec-Employees");
				
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.CashValueOfLife_field), Logs, "R1_123NC_TC_04.3",  "Cash Value of Life Ins, Net of Borrow");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.DefferedCharges_field), Logs, "R1_123NC_TC_04.3",  "Deferred Charges");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.DefferedCharges_NonCurr_field), Logs, "R1_123NC_TC_04.3",  "	Deferred Chgs-Noncurr Def Tax Debit");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.GoodWill_field), Logs, "R1_123NC_TC_04.3",  "Goodwill-Net");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.IntangibleAssets_field), Logs, "R1_123NC_TC_04.3",  "Intangible Assets");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.MiscellaneousInvestments_field), Logs, "R1_123NC_TC_04.3",  "Miscellaneous Investments");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InvestmentsInConsolidatedCompanies_field), Logs, "R1_123NC_TC_04.3",  "Investments in Consolidated Companies");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Equity_field), Logs, "R1_123NC_TC_04.3",  "Investments in Nonconsol Cos at Equity");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Cost_field), Logs, "R1_123NC_TC_04.3",  "nvestments in Nonconsol Cos at Cost");
				
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InvestInAffiliatedPrivate_field), Logs, "R1_123NC_TC_04.3",  "Invest in Affiliated Private Inv Funds");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_Consol_field), Logs, "R1_123NC_TC_04.3",  "LT Notes/Accts Rec-Consol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_NonConsol_field), Logs, "R1_123NC_TC_04.3",  "LT Notes/Accts Rec-Nonconsol Cos");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OtherNonCurrentAssets_field), Logs, "R1_123NC_TC_04.3",  "Other NonCurrent Assets - Contract costs");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OwnedProperty_field), Logs, "R1_123NC_TC_04.3",  "Owned Property, Plant & Equipment");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.PropertyUnderCapitalLease_field), Logs, "R1_123NC_TC_04.3",  "Property Under Capital Leases");
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.ConstructionsIsInProgress_field), Logs, "R1_123NC_TC_04.3",  "Construction in Progress");
				
				HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field), Logs, "R1_123NC_TC_04.3",  "(Accumulated depreciation & amoritization)");
				
				//verify save with invalid value
				driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field).sendKeys("123.34");
				driver.findElement(HubContributorFormObj.btn_Save).click();
				Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
				String errorMsg1 = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
				Logs.update("To check the error message", "Error displayed: " + " " + errorMsg1, Status.PASS, driver);
				if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

					Logs.update("R1_123NC_TC_04.3 verify that not able to save with decimal values",
							"Error is displayed when tried to save with 123.34", Status.PASS, driver);
				} else {
					Logs.update("R1_123NC_TC_04.3 verify that not able to save with decimal values",
							"Error is not displayed when tried to save with 123.34", Status.FAIL,
							driver);
				}
				
				driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
				driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field).clear();
				
				/**Validation with Positive number**/
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.cashField), Logs, "R1_123NC_TC_04.2", 15, "Cash");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.certOfField), Logs, "R1_123NC_TC_04.2", 15, "Cert of Dep/Other");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.documentIsInProc_Field), Logs, "R1_123NC_TC_04.2", 15, "Documents in Process of Collection");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.shortTermInvestment_Field), Logs, "R1_123NC_TC_04.2", 15, "Short Term Investments");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.finalcialInstruments_Field), Logs, "R1_123NC_TC_04.2", 15, "Financial Instruments Purchased w/Agmt to Resell");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.tradingSecurities_Field), Logs, "R1_123NC_TC_04.2", 15, "Trading Securities");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Trade_Field), Logs, "R1_123NC_TC_04.2", 15, "Accounts Receivable, Trade");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.accountsReceivable_Others_Field), Logs, "R1_123NC_TC_04.2", 15, "Accounts Receivable, Other");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.accuredIncome_Field), Logs, "R1_123NC_TC_04.2", 15, "Accrued Income");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.allowanceForDoubtful_Field), Logs, "R1_123NC_TC_04.2", 15, "(Allowance for doubtful accounts)");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.marginDeposited_field), Logs, "R1_123NC_TC_04.2", 15, "Margins Deposited w/Clrg Assn & Brokers");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.inventories_field), Logs, "R1_123NC_TC_04.2", 15, "Inventories");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.prepaidExpenses_field), Logs, "R1_123NC_TC_04.2", 15, "Prepaid Expenses");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.ARCashManagement_field), Logs, "R1_123NC_TC_04.2", 15, "AR-Cash Management Account");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_consol_field), Logs, "R1_123NC_TC_04.2", 15, "AR-Interest Bearing-Consol Cos");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_console_field), Logs, "R1_123NC_TC_04.2", 15, "AR-Noninterest Bearing-Consol Cos");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.ARInterestBearing_Nonconsol_field), Logs, "R1_123NC_TC_04.2", 15, "AR-Interest Bearing-Nonconsol Cos");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.ARNonInterestBearing_Nonconsole_field), Logs, "R1_123NC_TC_04.2", 15, "AR-Noninterest Bearing-Nonconsol Cos");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OtherCurrentAssets_field), Logs, "R1_123NC_TC_04.2", 15, "Other Current Assets - Contract costs");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LoansReceivable_field), Logs, "R1_123NC_TC_04.2", 15, "Loans Receivable (FMG Only)");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.RealEstate_field), Logs, "R1_123NC_TC_04.2", 15, "Real Estate (FMG Only)");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.Notes_Accts_field), Logs, "R1_123NC_TC_04.2", 15, "Notes & Accts Receivable, Long-Term");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InvestmentInLoan_field), Logs, "R1_123NC_TC_04.2", 15, "Investment in Loan Portfolios");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTNotes_field), Logs, "R1_123NC_TC_04.2", 15, "LT Notes/Accts Rec-Employees");
				
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.CashValueOfLife_field), Logs, "R1_123NC_TC_04.2", 15, "Cash Value of Life Ins, Net of Borrow");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.DefferedCharges_field), Logs, "R1_123NC_TC_04.2", 15, "Deferred Charges");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.DefferedCharges_NonCurr_field), Logs, "R1_123NC_TC_04.2", 15, "	Deferred Chgs-Noncurr Def Tax Debit");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.GoodWill_field), Logs, "R1_123NC_TC_04.2", 15, "Goodwill-Net");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.IntangibleAssets_field), Logs, "R1_123NC_TC_04.2", 15, "Intangible Assets");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.MiscellaneousInvestments_field), Logs, "R1_123NC_TC_04.2", 15, "Miscellaneous Investments");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InvestmentsInConsolidatedCompanies_field), Logs, "R1_123NC_TC_04.2", 15, "Investments in Consolidated Companies");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Equity_field), Logs, "R1_123NC_TC_04.2", 15, "Investments in Nonconsol Cos at Equity");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InvestmentInNonconsol_Cost_field), Logs, "R1_123NC_TC_04.2", 15, "nvestments in Nonconsol Cos at Cost");
				
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InvestInAffiliatedPrivate_field), Logs, "R1_123NC_TC_04.2", 15, "Invest in Affiliated Private Inv Funds");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_Consol_field), Logs, "R1_123NC_TC_04.2", 15, "LT Notes/Accts Rec-Consol Cos");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTNotesOrAcctsRec_NonConsol_field), Logs, "R1_123NC_TC_04.2", 15, "LT Notes/Accts Rec-Nonconsol Cos");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OtherNonCurrentAssets_field), Logs, "R1_123NC_TC_04.2", 15, "Other NonCurrent Assets - Contract costs");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OwnedProperty_field), Logs, "R1_123NC_TC_04.2", 15, "Owned Property, Plant & Equipment");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.PropertyUnderCapitalLease_field), Logs, "R1_123NC_TC_04.2", 15, "Property Under Capital Leases");
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.ConstructionsIsInProgress_field), Logs, "R1_123NC_TC_04.2", 15, "Construction in Progress");
				
				HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.AccumulatedDepreciation_field), Logs, "R1_123NC_TC_04.2", 15, "(Accumulated depreciation & amoritization)");
		
				driver.findElement(Form_123NC_Obj.AssetSave_btn).click();
				String QuerytoGetSumOf_010_030_040="select FORMAT(sum(Account010+Account030+Account040), '#,#')"
						+ "as sumOf10_30_40 from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf10_30_40=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_010_030_040, "sumOf10_30_40");
				String ActValOf_045Field=driver.findElement(Form_123NC_Obj.totalCash_Field).getAttribute("value");
				if(sumOf10_30_40.equals(ActValOf_045Field)){
					Logs.update("R1_123NC_TC_04.10", "'Total Cash, Cash Equivalents, and Restricted Cash' autoPopulated field is displayed with sum of fields 010,030 and 040 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'Total Cash, Cash Equivalents, and Restricted Cash' autoPopulated field is not sum of fields 010,030 and 040", Status.FAIL, driver);
				}
				//To verify 'Accounts/Notes Rec & Accrued Inc, Net' field
				String QuerytoGetSumOf_60_70_80_90="select FORMAT(sum(Account060+Account070+Account080+Account090), '#,#')"
						+ "as sumOf60_70_80_90 from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf60_70_80_90=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_60_70_80_90, "sumOf60_70_80_90");
				String ActValOf_100_Field=driver.findElement(Form_123NC_Obj.accountsOrNotesRec_field).getAttribute("value");
				if(sumOf60_70_80_90.equals(ActValOf_100_Field)){
					Logs.update("R1_123NC_TC_04.10", "'Accounts/Notes Rec & Accrued Inc, Net' autoPopulated field is displayed with sum of fields 060,070,080and 090 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'Accounts/Notes Rec & Accrued Inc, Net' autoPopulated field is not sum of fields 060,070,080 and 090", Status.FAIL, driver);
				}
				//To Verify Total current assets field
				//Should be sum of fields 045 047 050 055 100 110 130 200 225 230 235 240 245 247	
				
				String QuerytoGetSumOf_Eligible_Fields="select FORMAT(sum(Account045+Account047+Account050+Account055+Account100+Account110+Account130+Account200+Account225+Account230+Account235+Account240+Account245+Account247), '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf_eligible_fields=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_Eligible_Fields, "sumOf_eligible_Fields");
				String ActValOf_TotalCurrentAsset250_Field=driver.findElement(Form_123NC_Obj.TotalCurrentAssets_field).getAttribute("value");
				if(sumOf60_70_80_90.equals(ActValOf_100_Field)){
					Logs.update("R1_123NC_TC_04.10", "'Total Current Assets' autoPopulated field is displayed with sum of fields 045 047 050 055 100 110 130 200 225 230 235 240 245 and 247 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'Total Current Assets' autoPopulated field is not sum of fields 045 047 050 055 100 110 130 200 225 230 235 240 245 and 247", Status.FAIL, driver);
				}
				
				//To Verify Total Other assets field
				//Should be sum of fields 260 262 270 280 290 293 295 297 300 320 330 340 345 350 360 362	
				
				String QuerytoGetSumOf_field_260_To_362="select FORMAT(sum(Account260+Account262+Account270+Account280+Account290+Account293+Account295+Account297+Account300+Account320+Account330+Account340+Account345+Account350+Account360+Account362), '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf_field_260_To_362=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_260_To_362, "sumOf_eligible_Fields");
				String ActValOf_TotalOtherAsset365_Field=driver.findElement(Form_123NC_Obj.TotalOtherAssets_field).getAttribute("value");
				if(sumOf_field_260_To_362.equals(ActValOf_TotalOtherAsset365_Field)){
					Logs.update("R1_123NC_TC_04.10", "'Total Other Assets' autoPopulated field is displayed with sum of fields 260 262 270 280 290 293 295 297 300 320 330 340 345 350 360 and 362 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'Total Other Assets' autoPopulated field is not sum of fields 260 262 270 280 290 293 295 297 300 320 330 340 345 350 360 and 362", Status.FAIL, driver);
				}
				
				//To Verify Total Gross Property field
				//Should be sum of fields 370 375 and 380
	
				String QuerytoGetSumOf_370_375_380="select FORMAT(sum(Account370+Account375+Account380), '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf_field_370_375_380=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_370_375_380, "sumOf_eligible_Fields");
				String ActValOf_Total_Gross_Property_385_Field=driver.findElement(Form_123NC_Obj.TotalGrossProperty_field).getAttribute("value");
				if(sumOf_field_370_375_380.equals(ActValOf_Total_Gross_Property_385_Field)){
					Logs.update("R1_123NC_TC_04.10", "'Total Gross Property' autoPopulated field is displayed with sum of fields 370 375 and 380 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'Total Gross Property' autoPopulated field is not sum of fields 370 375 and 380", Status.FAIL, driver);
				}
				
				//To Verify Net Property field
				//Should be sum of fields 385 and 390

				String QuerytoGetSumOf_385_390="select FORMAT(sum(Account385+Account390), '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf_field_385_390=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_385_390, "sumOf_eligible_Fields");
				String ActValOf_NetProperty_Field=driver.findElement(Form_123NC_Obj.NetProperty_field).getAttribute("value");
				if(sumOf_field_385_390.equals(ActValOf_NetProperty_Field)){
					Logs.update("R1_123NC_TC_04.10", "'Net Property' autoPopulated field is displayed with sum of fields 385 and 390 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'Net Property' autoPopulated field is not sum of fields 385 and 390", Status.FAIL, driver);
				}
				
				//To Verify TOTAL ASSETS field
				//Should be sum of fields 250+Loan Receivable+Real Estate+365+400

				String QuerytoGetSumOf_Fields="select FORMAT(sum(Account250+LoansReceivable+RealEstate+Account365+Account400), '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCAssets where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				String sumOf_fields=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_Fields, "sumOf_eligible_Fields");
				String ActValOf_TOTAL_Assets_Field=driver.findElement(Form_123NC_Obj.TotalAssets_field).getAttribute("value");
				if(sumOf_fields.equals(ActValOf_TOTAL_Assets_Field)){
					
					Logs.update("R1_123NC_TC_04.10", "'TOTAL ASSETS' autoPopulated field is displayed with sum of fields 250+Loan Receivable+Real Estate+365+400 as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_04.10", "'TOTAL ASSETS' autoPopulated field is not sum of fields 250+Loan Receivable+Real Estate+365+400", Status.FAIL, driver);
				}	
				driver.quit();
				
				
	}
	
		
	/*
	 * TC -03 function
	 */
	public static void verifySceduleSpecificHeader(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {

		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		boolean scheduleDistributed=entityXpath.isDisplayed();
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(5000);
		Logs.update("Entity serach should be successful", "Entity search is successful ", Status.PASS, driver);
		parentWindow=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
			
		// get company name from DB
		String checkQuery = "select concat(EntityCode,'-',EntityShortDesc) as legal from masterdata.entity where entitycode=(select NCToUnit from masterdata.entity where entitycode='"
				+ entityName + "')";
		System.out.println(checkQuery);
		String companyNameDB = utils.DataBaseConnection.getData(driver, Logs, TestType, checkQuery, "legal");
		System.out.println(companyNameDB);
		Thread.sleep(3000);
		String currentHandle = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		Set<String> allHandles = driver.getWindowHandles();
		for (String handle : allHandles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
		Thread.sleep(2000);
		String companyName = driver.findElement(Form_123NC_Obj.companyName).getText();
		System.out.println("UI name "+companyName);
		
		if (companyName.equalsIgnoreCase(companyNameDB))
		{	Assert.assertEquals(companyName, companyNameDB);
			Logs.update("R1_123NC_TC_03_", "Scehdule Specific header -CompanyName is as expected", Status.PASS, driver);
		}
		else 
		{
			Logs.update("R1_123NC_TC_03_", "Scehdule Specific header -CompanyName is as NOT expected", Status.FAIL, driver);
		}
		driver.quit();
	}
	
	
	
	/*
	 * TC -05 function
	 */
	public static void verifyLiabilitiesAndEquity(WebDriver driver, String entityName, String period, String schedule,
			String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {

		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		/*WebDriverWait wait=new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(HubHomePageObj.Btn_Open));	*/
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String statusOfAssetSection=driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).getAttribute("class");
		if (statusOfAssetSection.equalsIgnoreCase("expand-vertical")){
			Assert.assertEquals(statusOfAssetSection, "expand-vertical");
			Logs.update("R1_123NC_TC_05.1 verify that Assets tab is collapsed by_default", "Assets tab is collapsed when the schedule is opened for the first time as expected." , Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_05.1 verify that Assets tab is collapsed by_default", "Assets tab is Not collapsed when the schedule is opened at first" , Status.FAIL, driver);
		}
		Thread.sleep(5000);
		driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
		Thread.sleep(5000);
		//Verify Labels
		HubContributor.verifyFieldName(driver, "Short Term Debt", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.shortTerm_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "STDebtNonRecourse_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.sTDebtNonRecourse_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Financial Instruments", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.financialInstruments_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LtDebtCurrentRecourse", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LtDebtCurrentRecourse_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LtDebtCurrentNonRecourse_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LtDebtCurrentNonRecourse_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "currentObligUnderCapitalLeasesRcs_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesRcs_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "currentObligUnderCapitalLeasesNRcs_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesNRcs_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "tradingSecuritiesSold_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.tradingSecuritiesSold_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "accountsPayable_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.accountsPayable_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "notesAndAccountPay_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.notesAndAccountPay_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "accruedIncomeTaxes_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.accruedIncomeTaxes_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "dividendsPayable_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.dividendsPayable_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "stDebtCashManagement1_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.stDebtCashManagement1_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "stDebtCashManagement2_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.stDebtCashManagement2_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "apDebtnonInterestBearingConsol_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.apDebtnonInterestBearingConsol_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "stDebtnInterestBearingNonConsol_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.stDebtnInterestBearingNonConsol_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "apNoninterestBearingNonconsol_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.apNoninterestBearingNonconsol_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "longTermDebt_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.longTermDebt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "lTDebtPortionNonRecourse_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.lTDebtPortionNonRecourse_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "lTDebtCapitalLeaseObligsLessCurPortionRcs_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionRcs_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "lTDebtCapitalLeaseObligsLessCurPortionNRcs_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionNRcs_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtGuaranteeofESOPDebt_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtGuaranteeofESOPDebt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtConsolCosLTPortio_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "LTDebtLtPortionNonRecourse_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtLtPortionNonRecourse_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtCapitalLeaseObligsLessCurPortionRcs_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtCapitalLeaseObligsLessCurPortionRcs_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtCapitalLeaseObligsLessCurPortionNRcs_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtCapitalLeaseObligsLessCurPortionNRcs_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtGuaranteeESOPDebt_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtGuaranteeESOPDebt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtConsolCosLTPortio1_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio1_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "LTDebtNonconsolCosexclPermOther_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.LTDebtNonconsolCosexclPermOther_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "NonCurrentDeferredIncomeTaxes_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.NonCurrentDeferredIncomeTaxes_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "totalLiabilities_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.totalLiabilities_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "preferredStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.preferredStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "specialPreferredStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.specialPreferredStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "commonStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.commonStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "esopCommonStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.esopCommonStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "managementStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.managementStock_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "retireeStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.retireeStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "specialmanagementStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.specialmanagementStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "additionalPaidInCapital_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.additionalPaidInCapital_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "devisionEquity_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.devisionEquity_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "retainedEarnings_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.retainedEarnings_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "netEarnings_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.netEarnings_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "DividendsonCommonCash_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.DividendsonCommonCash_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "DividendsonPreferredCash_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.DividendsonPreferredCash_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "DividendsonCommonStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.DividendsonCommonStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "DividendsonPreferredStock_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.DividendsonPreferredStock_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "retainedEarningsOther_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.retainedEarningsOther_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "TotalretainedEarnings_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.TotalretainedEarnings_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "PermanentFinancingTransB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.PermanentFinancingTransB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "PermanentFinancingTransTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.PermanentFinancingTransTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "NetInvestHdgsB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.NetInvestHdgsB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "NetInvestHdgsTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.NetInvestHdgsTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrealizedMarketSecB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrealizedMarketSecTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrealCashFlowHedgingB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrealCashFlowHedgingB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrealCFHedgingTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrealCFHedgingTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "AccumulatedTranslationAdjustB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "AccumulatedTranslationAdjustTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrecogTransitionObligPensPostRetB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrecogTransitionObligPensPostRetTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetTax_Lbl), Logs);
		
		HubContributor.verifyFieldName(driver, "UnrecogPriorServiceCostPensPostRetB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrecogPriorServiceCostPensPostRetTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrecogActuarialPensPostRetB4Tax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetB4Tax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "UnrecogActuarialPensPostRetTax_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "TotalOtherComprehensiveIncome_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.TotalOtherComprehensiveIncome_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "TotalCargillStockholdersEquity_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.TotalCargillStockholdersEquity_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "NonControllingInterests_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.NonControllingInterests_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "TotalStockholdersEquity_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.TotalStockholdersEquity_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "TotalLiablilitiesstkholdersequity_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.TotalLiablilitiesstkholdersequity_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "WorkingCapital_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.WorkingCapital_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "BSCheck_Lbl", "R1_123NC_TC_05", driver.findElement(Form_123NC_Obj.BSCheck_Lbl), Logs);
		
		//validation with Negative numbers
		
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.shortTermDebt), Logs, "R1_123NC_TC_05.3", 14, "shortTermDebt");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.sTDebtNonRecourse), Logs, "R1_123NC_TC_05.3", 14, "sTDebtNonRecourse");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.financialInstruments), Logs, "R1_123NC_TC_05.3", 14, "financialInstruments");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LtDebtCurrentRecourse), Logs, "R1_123NC_TC_05.3", 14, "LtDebtCurrentRecourse");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LtDebtCurrentNonRecourse), Logs, "R1_123NC_TC_05.3", 14, "LtDebtCurrentNonRecourse");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesRcs), Logs, "R1_123NC_TC_05.3", 14, "currentObligUnderCapitalLeasesRcs");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesNRcs), Logs, "R1_123NC_TC_05.3", 14, "currentObligUnderCapitalLeasesNRcs");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.tradingSecuritiesSold), Logs, "R1_123NC_TC_05.3", 14, "tradingSecuritiesSold");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.accountsPayable), Logs, "R1_123NC_TC_05.3", 14, "accountsPayable");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.accruedIncomeTaxes), Logs, "R1_123NC_TC_05.3", 14, "accruedIncomeTaxes");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.dividendsPayable), Logs, "R1_123NC_TC_05.3", 14, "dividendsPayable");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.stDebtCashManagement1), Logs, "R1_123NC_TC_05.3", 14, "stDebtCashManagement1");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.stDebtCashManagement2), Logs, "R1_123NC_TC_05.3", 14, "stDebtCashManagement2");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.apDebtnonInterestBearingConsol), Logs, "R1_123NC_TC_05.3", 14, "apDebtnonInterestBearingConsol");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.stDebtnInterestBearingNonConsol), Logs, "R1_123NC_TC_05.3", 14, "stDebtnInterestBearingNonConsol");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.apNoninterestBearingNonconsol), Logs, "R1_123NC_TC_05.3", 14, "apNoninterestBearingNonconsol");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.longTermDebt), Logs, "R1_123NC_TC_05.3", 14, "longTermDebt");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.lTDebtPortionNonRecourse), Logs, "R1_123NC_TC_05.3", 14, "lTDebtPortionNonRecourse");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionRcs), Logs, "R1_123NC_TC_05.3", 14, "lTDebtCapitalLeaseObligsLessCurPortionRcs");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionNRcs), Logs, "R1_123NC_TC_05.3", 14, "lTDebtCapitalLeaseObligsLessCurPortionNRcs");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTDebtGuaranteeofESOPDebt), Logs, "R1_123NC_TC_05.3", 14, "LTDebtGuaranteeofESOPDebt");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio), Logs, "R1_123NC_TC_05.3", 14, "LTDebtConsolCosLTPortio");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTDebtLtPortionNonRecourse), Logs, "R1_123NC_TC_05.3", 14, "LTDebtLtPortionNonRecourse");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio1), Logs, "R1_123NC_TC_05.3", 14, "LTDebtConsolCosLTPortio1");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.LTDebtNonconsolCosexclPermOther), Logs, "R1_123NC_TC_05.3", 14, "LTDebtNonconsolCosexclPermOther");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.NonCurrentDeferredIncomeTaxes), Logs, "R1_123NC_TC_05.3", 14, "NonCurrentDeferredIncomeTaxes");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.preferredStock), Logs, "R1_123NC_TC_05.3", 14, "preferredStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.specialPreferredStock), Logs, "R1_123NC_TC_05.3", 14, "specialPreferredStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.commonStock), Logs, "R1_123NC_TC_05.3", 14, "commonStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.esopCommonStock), Logs, "R1_123NC_TC_05.3", 14, "esopCommonStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.managementStock), Logs, "R1_123NC_TC_05.3", 14, "managementStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.retireetStock), Logs, "R1_123NC_TC_05.3", 14, "retireetStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.specialmanagementStock), Logs, "R1_123NC_TC_05.3", 14, "specialmanagementStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.additionalPaidInCapital), Logs, "R1_123NC_TC_05.3", 14, "additionalPaidInCapital");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.devisionEquity), Logs, "R1_123NC_TC_05.3", 14, "devisionEquity");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.DividendsonCommonCash), Logs, "R1_123NC_TC_05.3", 14, "DividendsonCommonCash");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.DividendsonPreferredCash), Logs, "R1_123NC_TC_05.3", 14, "DividendsonPreferredCash");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.DividendsonCommonStock), Logs, "R1_123NC_TC_05.3", 14, "DividendsonCommonStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.DividendsonPreferredStock), Logs, "R1_123NC_TC_05.3", 14, "DividendsonPreferredStock");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.retainedEarningsOther), Logs, "R1_123NC_TC_05.3", 14, "retainedEarningsOther");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.PermanentFinancingTransB4Tax), Logs, "R1_123NC_TC_05.3", 14, "PermanentFinancingTransB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.PermanentFinancingTransTax), Logs, "R1_123NC_TC_05.3", 14, "PermanentFinancingTransTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.NetInvestHdgsB4Tax), Logs, "R1_123NC_TC_05.3", 14, "NetInvestHdgsB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.NetInvestHdgsTax), Logs, "R1_123NC_TC_05.3", 14, "NetInvestHdgsTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecB4Tax), Logs, "R1_123NC_TC_05.3", 14, "UnrealizedMarketSecB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecTax), Logs, "R1_123NC_TC_05.3", 14, "UnrealizedMarketSecTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrealCashFlowHedgingB4Tax), Logs, "R1_123NC_TC_05.3", 14, "UnrealCashFlowHedgingB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrealCFHedgingTax), Logs, "R1_123NC_TC_05.3", 14, "UnrealCFHedgingTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustB4Tax), Logs, "R1_123NC_TC_05.3", 14, "AccumulatedTranslationAdjustB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustTax), Logs, "R1_123NC_TC_05.3", 14, "AccumulatedTranslationAdjustTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3", 14, "UnrecogTransitionObligPensPostRetB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetTax), Logs, "R1_123NC_TC_05.3", 14, "UnrecogTransitionObligPensPostRetTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3", 14, "UnrecogPriorServiceCostPensPostRetB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetTax), Logs, "R1_123NC_TC_05.3", 14, "UnrecogPriorServiceCostPensPostRetTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3", 14, "UnrecogActuarialPensPostRetB4Tax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax), Logs, "R1_123NC_TC_05.3", 14, "UnrecogActuarialPensPostRetTax");
	HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.NonControllingInterests), Logs, "R1_123NC_TC_05.3", 14, "NonControllingInterests");

		
		//Validation with alphabets
		
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.shortTermDebt), Logs, "R1_123NC_TC_05.3",  "shortTermDebt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.sTDebtNonRecourse), Logs, "R1_123NC_TC_05.3",  "sTDebtNonRecourse");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.financialInstruments), Logs, "R1_123NC_TC_05.3",  "financialInstruments");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LtDebtCurrentRecourse), Logs, "R1_123NC_TC_05.3",  "LtDebtCurrentRecourse");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LtDebtCurrentNonRecourse), Logs, "R1_123NC_TC_05.3",  "LtDebtCurrentNonRecourse");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesRcs), Logs, "R1_123NC_TC_05.3",  "currentObligUnderCapitalLeasesRcs");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesNRcs), Logs, "R1_123NC_TC_05.3",  "currentObligUnderCapitalLeasesNRcs");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.tradingSecuritiesSold), Logs, "R1_123NC_TC_05.3",  "tradingSecuritiesSold");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.accountsPayable), Logs, "R1_123NC_TC_05.3",  "accountsPayable");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.accruedIncomeTaxes), Logs, "R1_123NC_TC_05.3",  "accruedIncomeTaxes");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.dividendsPayable), Logs, "R1_123NC_TC_05.3",  "dividendsPayable");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.stDebtCashManagement1), Logs, "R1_123NC_TC_05.3",  "stDebtCashManagement1");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.stDebtCashManagement2), Logs, "R1_123NC_TC_05.3",  "stDebtCashManagement2");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.apDebtnonInterestBearingConsol), Logs, "R1_123NC_TC_05.3",  "apDebtnonInterestBearingConsol");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.stDebtnInterestBearingNonConsol), Logs, "R1_123NC_TC_05.3",  "stDebtnInterestBearingNonConsol");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.apNoninterestBearingNonconsol), Logs, "R1_123NC_TC_05.3",  "apNoninterestBearingNonconsol");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.longTermDebt), Logs, "R1_123NC_TC_05.3",  "longTermDebt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.lTDebtPortionNonRecourse), Logs, "R1_123NC_TC_05.3",  "lTDebtPortionNonRecourse");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionRcs), Logs, "R1_123NC_TC_05.3",  "lTDebtCapitalLeaseObligsLessCurPortionRcs");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionNRcs), Logs, "R1_123NC_TC_05.3",  "lTDebtCapitalLeaseObligsLessCurPortionNRcs");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTDebtGuaranteeofESOPDebt), Logs, "R1_123NC_TC_05.3",  "LTDebtGuaranteeofESOPDebt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio), Logs, "R1_123NC_TC_05.3",  "LTDebtConsolCosLTPortio");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTDebtLtPortionNonRecourse), Logs, "R1_123NC_TC_05.3",  "LTDebtLtPortionNonRecourse");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio1), Logs, "R1_123NC_TC_05.3",  "LTDebtConsolCosLTPortio1");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.LTDebtNonconsolCosexclPermOther), Logs, "R1_123NC_TC_05.3",  "LTDebtNonconsolCosexclPermOther");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.NonCurrentDeferredIncomeTaxes), Logs, "R1_123NC_TC_05.3",  "NonCurrentDeferredIncomeTaxes");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.preferredStock), Logs, "R1_123NC_TC_05.3",  "preferredStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.specialPreferredStock), Logs, "R1_123NC_TC_05.3",  "specialPreferredStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.commonStock), Logs, "R1_123NC_TC_05.3",  "commonStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.esopCommonStock), Logs, "R1_123NC_TC_05.3",  "esopCommonStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.managementStock), Logs, "R1_123NC_TC_05.3",  "managementStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.retireetStock), Logs, "R1_123NC_TC_05.3",  "retireetStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.specialmanagementStock), Logs, "R1_123NC_TC_05.3",  "specialmanagementStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.additionalPaidInCapital), Logs, "R1_123NC_TC_05.3",  "additionalPaidInCapital");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.devisionEquity), Logs, "R1_123NC_TC_05.3",  "devisionEquity");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.DividendsonCommonCash), Logs, "R1_123NC_TC_05.3",  "DividendsonCommonCash");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.DividendsonPreferredCash), Logs, "R1_123NC_TC_05.3",  "DividendsonPreferredCash");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.DividendsonCommonStock), Logs, "R1_123NC_TC_05.3",  "DividendsonCommonStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.DividendsonPreferredStock), Logs, "R1_123NC_TC_05.3",  "DividendsonPreferredStock");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.retainedEarningsOther), Logs, "R1_123NC_TC_05.3",  "retainedEarningsOther");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.PermanentFinancingTransB4Tax), Logs, "R1_123NC_TC_05.3",  "PermanentFinancingTransB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.PermanentFinancingTransTax), Logs, "R1_123NC_TC_05.3",  "PermanentFinancingTransTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.NetInvestHdgsB4Tax), Logs, "R1_123NC_TC_05.3",  "NetInvestHdgsB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.NetInvestHdgsTax), Logs, "R1_123NC_TC_05.3",  "NetInvestHdgsTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecB4Tax), Logs, "R1_123NC_TC_05.3",  "UnrealizedMarketSecB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecTax), Logs, "R1_123NC_TC_05.3",  "UnrealizedMarketSecTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrealCashFlowHedgingB4Tax), Logs, "R1_123NC_TC_05.3",  "UnrealCashFlowHedgingB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrealCFHedgingTax), Logs, "R1_123NC_TC_05.3",  "UnrealCFHedgingTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustB4Tax), Logs, "R1_123NC_TC_05.3",  "AccumulatedTranslationAdjustB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustTax), Logs, "R1_123NC_TC_05.3",  "AccumulatedTranslationAdjustTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3",  "UnrecogTransitionObligPensPostRetB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetTax), Logs, "R1_123NC_TC_05.3",  "UnrecogTransitionObligPensPostRetTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3",  "UnrecogPriorServiceCostPensPostRetB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetTax), Logs, "R1_123NC_TC_05.3",  "UnrecogPriorServiceCostPensPostRetTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3",  "UnrecogActuarialPensPostRetB4Tax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax), Logs, "R1_123NC_TC_05.3",  "UnrecogActuarialPensPostRetTax");
	HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.NonControllingInterests), Logs, "R1_123NC_TC_05.3",  "NonControllingInterests");
		
	//Positive numbers 
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.shortTermDebt), Logs, "R1_123NC_TC_05.3", 15,"shortTermDebt");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.sTDebtNonRecourse), Logs, "R1_123NC_TC_05.3", 15,"sTDebtNonRecourse");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.financialInstruments), Logs, "R1_123NC_TC_05.3", 15,"financialInstruments");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LtDebtCurrentRecourse), Logs, "R1_123NC_TC_05.3", 15,"LtDebtCurrentRecourse");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LtDebtCurrentNonRecourse), Logs, "R1_123NC_TC_05.3", 15,"LtDebtCurrentNonRecourse");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesRcs), Logs, "R1_123NC_TC_05.3", 15,"currentObligUnderCapitalLeasesRcs");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.currentObligUnderCapitalLeasesNRcs), Logs, "R1_123NC_TC_05.3", 15,"currentObligUnderCapitalLeasesNRcs");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.tradingSecuritiesSold), Logs, "R1_123NC_TC_05.3", 15,"tradingSecuritiesSold");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.accountsPayable), Logs, "R1_123NC_TC_05.3", 15,"accountsPayable");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.accruedIncomeTaxes), Logs, "R1_123NC_TC_05.3", 15,"accruedIncomeTaxes");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.dividendsPayable), Logs, "R1_123NC_TC_05.3", 15,"dividendsPayable");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.stDebtCashManagement1), Logs, "R1_123NC_TC_05.3", 15,"stDebtCashManagement1");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.stDebtCashManagement2), Logs, "R1_123NC_TC_05.3", 15,"stDebtCashManagement2");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.apDebtnonInterestBearingConsol), Logs, "R1_123NC_TC_05.3", 15,"apDebtnonInterestBearingConsol");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.stDebtnInterestBearingNonConsol), Logs, "R1_123NC_TC_05.3", 15,"stDebtnInterestBearingNonConsol");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.apNoninterestBearingNonconsol), Logs, "R1_123NC_TC_05.3", 15,"apNoninterestBearingNonconsol");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.longTermDebt), Logs, "R1_123NC_TC_05.3", 15,"longTermDebt");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.lTDebtPortionNonRecourse), Logs, "R1_123NC_TC_05.3", 15,"lTDebtPortionNonRecourse");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionRcs), Logs, "R1_123NC_TC_05.3", 15,"lTDebtCapitalLeaseObligsLessCurPortionRcs");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.lTDebtCapitalLeaseObligsLessCurPortionNRcs), Logs, "R1_123NC_TC_05.3", 15,"lTDebtCapitalLeaseObligsLessCurPortionNRcs");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTDebtGuaranteeofESOPDebt), Logs, "R1_123NC_TC_05.3", 15,"LTDebtGuaranteeofESOPDebt");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio), Logs, "R1_123NC_TC_05.3", 15,"LTDebtConsolCosLTPortio");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTDebtLtPortionNonRecourse), Logs, "R1_123NC_TC_05.3", 15,"LTDebtLtPortionNonRecourse");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTDebtConsolCosLTPortio1), Logs, "R1_123NC_TC_05.3", 15,"LTDebtConsolCosLTPortio1");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.LTDebtNonconsolCosexclPermOther), Logs, "R1_123NC_TC_05.3", 15,"LTDebtNonconsolCosexclPermOther");
	HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.NonCurrentDeferredIncomeTaxes), Logs, "R1_123NC_TC_05.3", 15,"NonCurrentDeferredIncomeTaxes");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.preferredStock), Logs, "R1_123NC_TC_05.3", 15,"preferredStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.specialPreferredStock), Logs, "R1_123NC_TC_05.3", 15,"specialPreferredStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.commonStock), Logs, "R1_123NC_TC_05.3", 15,"commonStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.esopCommonStock), Logs, "R1_123NC_TC_05.3", 15,"esopCommonStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.managementStock), Logs, "R1_123NC_TC_05.3", 15,"managementStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.retireetStock), Logs, "R1_123NC_TC_05.3", 15,"retireetStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.specialmanagementStock), Logs, "R1_123NC_TC_05.3", 15,"specialmanagementStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.additionalPaidInCapital), Logs, "R1_123NC_TC_05.3", 15,"additionalPaidInCapital");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.devisionEquity), Logs, "R1_123NC_TC_05.3", 15,"devisionEquity");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.DividendsonCommonCash), Logs, "R1_123NC_TC_05.3", 15,"DividendsonCommonCash");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.DividendsonPreferredCash), Logs, "R1_123NC_TC_05.3", 15,"DividendsonPreferredCash");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.DividendsonCommonStock), Logs, "R1_123NC_TC_05.3", 15,"DividendsonCommonStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.DividendsonPreferredStock), Logs, "R1_123NC_TC_05.3", 15,"DividendsonPreferredStock");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.retainedEarningsOther), Logs, "R1_123NC_TC_05.3", 15,"retainedEarningsOther");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.PermanentFinancingTransB4Tax), Logs, "R1_123NC_TC_05.3", 15,"PermanentFinancingTransB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.PermanentFinancingTransTax), Logs, "R1_123NC_TC_05.3", 15,"PermanentFinancingTransTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.NetInvestHdgsB4Tax), Logs, "R1_123NC_TC_05.3", 15,"NetInvestHdgsB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.NetInvestHdgsTax), Logs, "R1_123NC_TC_05.3", 15,"NetInvestHdgsTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecB4Tax), Logs, "R1_123NC_TC_05.3", 15,"UnrealizedMarketSecB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrealizedMarketSecTax), Logs, "R1_123NC_TC_05.3", 15,"UnrealizedMarketSecTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrealCashFlowHedgingB4Tax), Logs, "R1_123NC_TC_05.3", 15,"UnrealCashFlowHedgingB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrealCFHedgingTax), Logs, "R1_123NC_TC_05.3", 15,"UnrealCFHedgingTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustB4Tax), Logs, "R1_123NC_TC_05.3", 15,"AccumulatedTranslationAdjustB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.AccumulatedTranslationAdjustTax), Logs, "R1_123NC_TC_05.3", 15,"AccumulatedTranslationAdjustTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3", 15,"UnrecogTransitionObligPensPostRetB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetTax), Logs, "R1_123NC_TC_05.3", 15,"UnrecogTransitionObligPensPostRetTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3", 15,"UnrecogPriorServiceCostPensPostRetB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCostPensPostRetTax), Logs, "R1_123NC_TC_05.3", 15,"UnrecogPriorServiceCostPensPostRetTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetB4Tax), Logs, "R1_123NC_TC_05.3", 15,"UnrecogActuarialPensPostRetB4Tax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax), Logs, "R1_123NC_TC_05.3", 15,"UnrecogActuarialPensPostRetTax");
HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.NonControllingInterests), Logs, "R1_123NC_TC_05.3", 15,"NonControllingInterests");
driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
Thread.sleep(5000);

//To Verify Total Current Liabilities


String QuerytoGetSum="select FORMAT(sum(Account520+Account525+Account535+Account540+Account542+Account545+Account546+Account547+Account550+Account580+Account590+Account600+Account630+Account640+Account645+Account650+Account655), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
String sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");
String ActValOf_Total_Liabilities_695_Field=driver.findElement(Form_123NC_Obj.totalCurrentLiabilities).getAttribute("value");
if(sum.equals(ActValOf_Total_Liabilities_695_Field)){
	Assert.assertEquals(sum, ActValOf_Total_Liabilities_695_Field);
	Logs.update("R1_123NC_TC_05.10", "'Total Current Liabilities' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.10", "'Total Current Liabilities' autoPopulated field is not sum of fields", Status.FAIL, driver);
}
	
// Total Liabilities
QuerytoGetSum="select FORMAT(sum(Account665+Account667+Account670+Account671+Account673+Account675+Account680+Account685+Account690), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");
ActValOf_Total_Liabilities_695_Field=driver.findElement(Form_123NC_Obj.totalLiabilities).getAttribute("value");
if(sum.equals(ActValOf_Total_Liabilities_695_Field)){
	Assert.assertEquals(sum, ActValOf_Total_Liabilities_695_Field);
	Logs.update("R1_123NC_TC_05.10", "'Total Liabilities' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.10", "'Total Liabilities' autoPopulated field is not sum of fields", Status.FAIL, driver);
}
// Beg R/E-Curr Yr Beg Retained Earnings
String period1 = Util.getAllNecessaryData(TestType, "123NC", "PeriodPrevFYQ4");
String QueryTogetExpectedValue="select FORMAT((Account940), '#,#')"+"as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period1+"')";
String expectedValue=DataBaseConnection.getData(driver, Logs, TestType, QueryTogetExpectedValue, "sumOf_eligible_Fields");
String actualValue=driver.findElement(Form_123NC_Obj.retainedEarnings).getAttribute("value");


/*if(expectedValue.equalsIgnoreCase(actualValue)){
	Logs.update("R1_123NC_TC_05.11", "Beg R/E-Curr Yr Beg Retained Earnings autoPopulated field is displayed as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.11", "Beg R/E-Curr Yr Beg Retained Earnings autoPopulated field is displayed NOT as expected", Status.FAIL, driver);
}*/

//Total Retained Earnings

QuerytoGetSum="select FORMAT(sum(Account790+Account899+Account910+Account920+Account924+Account927+Account930), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String Total_RetainedEarnings_940_Field=driver.findElement(Form_123NC_Obj.TotalretainedEarnings).getAttribute("value");
if(sum.equalsIgnoreCase(Total_RetainedEarnings_940_Field)){
	
	Logs.update("R1_123NC_TC_05.12", "Total Retained Earnings' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.12", "Total Retained Earnings' autoPopulated field is not sum of fields", Status.FAIL, driver);
}

//Total Other Comprehensive Income
QuerytoGetSum="select FORMAT(sum(Account949_010+Account949_020+Account949_030+Account949_040+Account949_050+Account949_060+Account949_070+Account949_080+Account949_090+Account949_100+Account949_130+Account949_140+Account949_150+Account949_160+Account949_170+Account949_180), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String Total_TotalOtherComprehensiveIncome=driver.findElement(Form_123NC_Obj.TotalOtherComprehensiveIncome).getAttribute("value");
if(sum.equalsIgnoreCase(Total_TotalOtherComprehensiveIncome)){
	Logs.update("R1_123NC_TC_05.13", "Total_TotalOtherComprehensiveIncome' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.13", "Total_TotalOtherComprehensiveIncome' autoPopulated field is not sum of fields", Status.FAIL, driver);
}

//Total Cargill Stockholders Equity

QuerytoGetSum="select FORMAT(sum(Account715+Account720+Account725+Account727+Account730+Account732+Account734+Account740+Account750+Account940+Account949), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String TotalCargillStockholdersEquity=driver.findElement(Form_123NC_Obj.TotalCargillStockholdersEquity).getAttribute("value");
if(sum.equalsIgnoreCase(TotalCargillStockholdersEquity)){
	Logs.update("R1_123NC_TC_05.14", "TotalCargillStockholdersEquity' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.14", "TotalCargillStockholdersEquity' autoPopulated field is not sum of fields", Status.FAIL, driver);
}
//Total Stockholders Equity
QuerytoGetSum="select FORMAT(sum(Account950+Account953), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String TotalStockHolderEquity=driver.findElement(Form_123NC_Obj.TotalStockholdersEquity).getAttribute("value");
if(sum.equalsIgnoreCase(TotalStockHolderEquity)){
	Logs.update("R1_123NC_TC_05.15", "TotalStockHolderEquity' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.15", "TotalStockHolderEquity' autoPopulated field is not sum of fields", Status.FAIL, driver);
}


//TOTAL LIABILITIES & STKHOLDERS EQUITY

QuerytoGetSum="select FORMAT(sum(Account695+Account955), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String TOTALLIABILITIESANDSTKHOLDERSEQUITY=driver.findElement(Form_123NC_Obj.TotalLiablilitiesstkholdersequity).getAttribute("value");
if(sum.equalsIgnoreCase(TOTALLIABILITIESANDSTKHOLDERSEQUITY)){
	Logs.update("R1_123NC_TC_05.16", "TOTALLIABILITIESANDSTKHOLDERSEQUITY' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.16", "TOTALLIABILITIESANDSTKHOLDERSEQUITY' autoPopulated field is not sum of fields", Status.FAIL, driver);
}

//Working Capital

QuerytoGetSum="select Format(sum(Account250-Account660),'#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu JOIN dbo.Schedule123NCAssets on dbo.schedule123NCLiabEqu.ScheduleInstanceID=dbo.Schedule123NCAssets.ScheduleInstanceID where dbo.schedule123NCLiabEqu.entitycode="+"'"+entityName+"'"+"and dbo.schedule123NCLiabEqu.PeriodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String workingCapital=driver.findElement(Form_123NC_Obj.WorkingCapital).getAttribute("value");
if(sum.equalsIgnoreCase(workingCapital)){
	Logs.update("R1_123NC_TC_05.17", "workingCapital' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.17", "workingCapital' autoPopulated field is not sum of fields", Status.FAIL, driver);
}


// BS Check

QuerytoGetSum="select Format(sum(Account960-Account500),'#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu JOIN dbo.Schedule123NCAssets on dbo.schedule123NCLiabEqu.ScheduleInstanceID=dbo.Schedule123NCAssets.ScheduleInstanceID where dbo.schedule123NCLiabEqu.entitycode="+"'"+entityName+"'"+"and dbo.schedule123NCLiabEqu.PeriodID in ('"+period+"')";
sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

System.out.println(QuerytoGetSum);
System.out.println(period);
System.out.println(expectedValue);
System.out.println(actualValue);

String bsCheck=driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
if(sum.equalsIgnoreCase(bsCheck)){
	Logs.update("R1_123NC_TC_05.18", "bsCheck' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_05.18", "bsCheck' autoPopulated field is not sum of fields", Status.FAIL, driver);
}
driver.quit();
	}

	
	
	
//TC -07 
public static void verifyReconcilation_TC07(WebDriver driver, String entityName, String period, String schedule,
		String scheduleLongDesc, DriverScript Logs, String TestType) throws Exception {

	driver = Login.LaunchHub("Setupurl", Logs);
	actions = new Actions(driver);
	HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
	WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
	actions.moveToElement(entityXpath).doubleClick().build().perform();
	/*WebDriverWait wait=new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.visibilityOfElementLocated(HubHomePageObj.Btn_Open));	*/
	Thread.sleep(4000);
	driver.findElement(HubHomePageObj.Btn_Open).click();
	Thread.sleep(3000);
	HubContributor.switchWindow(driver);
	driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
	Thread.sleep(7000);
	Thread.sleep(7000);
driver.findElement(Form_123NC_Obj.expandCollapseIcon).click();
//enter data in Assets fields
//function call code to enter data in Asset fields
Form123NCPage.enterDataInAssetsFields(driver, TestType);


//Enter data in liability tab

Thread.sleep(7000);
Thread.sleep(7000);
driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
//Function call code to enter data in liability fields
Form123NCPage.enterDataInLiabilitiesFields(driver, TestType);

//Code to make sure BS check is 0
driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
String bsCheckActual=driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
String NonControllingValToEnter="-"+bsCheckActual;
System.out.println(NonControllingValToEnter);

driver.findElement(Form_123NC_Obj.NonControllingInterests).sendKeys(NonControllingValToEnter);
Thread.sleep(3000);
Thread.sleep(3000);
driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();

//Enter data in income statement tab
Thread.sleep(7000);
Thread.sleep(7000);
driver.findElement(Form_123NC_Obj.expandCollapseIcon_incomeStatement).click();
//Function call code to enter data in Income statement fields
Form123NCPage.enterDataInIncomeStatementFields(driver, TestType);

Thread.sleep(7000);
driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
Thread.sleep(3000);
HubContributor.switchWindow_3(driver);

String ReconPageHeader=driver.findElement(Form_123NC_Obj.ReconciliationSection_Header).getText();
if(ReconPageHeader.equalsIgnoreCase("A&F 123 Non-consolidated at Equity Financial Statements - Reconciliation Section")){
	Logs.update("R1_123NC_TC_07.1", "User is navigated to the page: "+ReconPageHeader, Status.PASS, driver);
}else{
	Logs.update("R1_123NC_TC_07.1", "User is Not navigated to the page ''NonCon. at Equity Financial Stmts - Reconciliation Section'", Status.FAIL, driver);
}

//get company name from DB
		String checkQuery = "select concat(EntityCode,'-',EntityLongDesc) as legal from masterdata.entity where entitycode=(select NCToUnit from masterdata.entity where entitycode='"
				+ entityName + "')";
		System.out.println(checkQuery);
		String companyNameDB = utils.DataBaseConnection.getData(driver, Logs, TestType, checkQuery, "legal");
		System.out.println(companyNameDB);
		
		String actualValue=driver.findElement(Form_123NC_Obj.Legal_BGCParentCompanyName).getAttribute("value");
		
	/*	if(actualValue.equalsIgnoreCase(companyNameDB)){
			Logs.update("R1_123NC_TC_07.2", "Company name matches Database ",Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_07.2", "Company  name do not  matche Database", Status.FAIL, driver);
		}*/

		//OwnerShip Percentage
		checkQuery = "select CGLPERCENT from masterdata.entity where entitycode=(select NCToUnit from masterdata.entity where entitycode='"
				+ entityName + "')";
		System.out.println(checkQuery);
		String ownerShipPercent = utils.DataBaseConnection.getData(driver, Logs, TestType, checkQuery, "CGLPERCENT");
		System.out.println(ownerShipPercent);
		
		actualValue=driver.findElement(Form_123NC_Obj.OwnershipPercent).getAttribute("value");
		/*
		if(actualValue.equalsIgnoreCase(ownerShipPercent)){
			Logs.update("R1_123NC_TC_07.3", "OwnerShip Percentage",Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_07.3", "OwnerShip Percentage do not  matche Database", Status.FAIL, driver);
		}
*/
//Total per non-consolidated balance sheet fields 
		//1. stockOrAdditionalPaidInCapital
		String QuerytoGetSum="select FORMAT(sum(Account715+Account720+Account725+Account727+Account730+Account732+Account734+Account740+Account750), '#,#')"
				+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

		System.out.println(QuerytoGetSum);
		System.out.println(period);
		String stockOrAdditionalPaidInCapital=driver.findElement(Form_123NC_Obj.stockOrAdditionalPaidInCapital).getAttribute("value");
		if(sum.equalsIgnoreCase(stockOrAdditionalPaidInCapital)){
			Logs.update("R1_123NC_TC_07.4", "stockOrAdditionalPaidInCapital' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_05.4", "stockOrAdditionalPaidInCapital' autoPopulated field is not sum of fields", Status.FAIL, driver);
		}

		//2. Beginning Retained Earnings
				QuerytoGetSum="select FORMAT(Account790, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				
				String beginniningRetainedEarnings=driver.findElement(Form_123NC_Obj.beginniningRetainedEarnings).getAttribute("value");
				beginniningRetainedEarnings="0";
				/*if(sum.equalsIgnoreCase(beginniningRetainedEarnings)){
					Logs.update("R1_123NC_TC_07.5", "beginniningRetainedEarnings' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_05.5", "beginniningRetainedEarnings' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}*/

				//3. currentYearEarnings
				QuerytoGetSum="select FORMAT(Account899, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String currentYearEarnings=driver.findElement(Form_123NC_Obj.currentYearEarnings).getAttribute("value");
				if(sum.equalsIgnoreCase(currentYearEarnings)){
					Logs.update("R1_123NC_TC_07.6", "currentYearEarnings' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.6", "currentYearEarnings' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//4. dividendsOrDistribution
				QuerytoGetSum="select FORMAT(sum(Account910+Account920+Account924+Account927+Account930), '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String dividendsOrDistribution=driver.findElement(Form_123NC_Obj.dividendsOrDistribution).getAttribute("value");
				if(sum.equalsIgnoreCase(dividendsOrDistribution)){
					Logs.update("R1_123NC_TC_07.7", "dividendsOrDistribution' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.7", "dividendsOrDistribution' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//5. retainedEarningsOther
				QuerytoGetSum="select FORMAT(Account930, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String retainedEarnings_con=driver.findElement(Form_123NC_Obj.retainedEarnings_con).getAttribute("value");
				if(sum.equalsIgnoreCase(retainedEarnings_con)){
					Logs.update("R1_123NC_TC_07.8", "retainedEarnings_con' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.8", "retainedEarnings_con' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				/*//6. totalEquityOtherThanOCI
				int totalSum=Integer.parseInt(stockOrAdditionalPaidInCapital)+Integer.parseInt(beginniningRetainedEarnings)+Integer.parseInt(currentYearEarnings)+Integer.parseInt(dividendsOrDistribution)+Integer.parseInt(retainedEarnings_con);
				String result =Integer.toString(totalSum);
				System.out.println(totalSum);
				System.out.println(period);
				String totalEquityOtherThanOCI=driver.findElement(Form_123NC_Obj.totalEquityOtherThanOCI).getAttribute("value");
				if(result.equalsIgnoreCase(totalEquityOtherThanOCI)){
					Logs.update("R1_123NC_TC_07.9", "totalEquityOtherThanOCI' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.9", "totalEquityOtherThanOCI' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				*/
		//7.permanentfinancingTransB4Tax
				
				QuerytoGetSum="select FORMAT(Account949_010, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String permanentfinancingTransB4Tax=driver.findElement(Form_123NC_Obj.permanentfinancingTransB4Tax).getAttribute("value");
				if(sum.equalsIgnoreCase(permanentfinancingTransB4Tax)){
					Logs.update("R1_123NC_TC_07.10", "permanentfinancingTransB4Tax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.10", "permanentfinancingTransB4Tax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
		
				//8. permanentfinancingTransTax
				QuerytoGetSum="select FORMAT(Account949_020, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String permanentfinancingTransTax=driver.findElement(Form_123NC_Obj.permanentfinancingTransTax).getAttribute("value");
				if(sum.equalsIgnoreCase(permanentfinancingTransTax)){
					Logs.update("R1_123NC_TC_07.11", "permanentfinancingTransTax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.11", "permanentfinancingTransTax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//9. GLNetInvestHdgsB4Tax
				QuerytoGetSum="select FORMAT(Account949_030, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String GLNetInvestHdgsB4Tax=driver.findElement(Form_123NC_Obj.GLNetInvestHdgsB4Tax).getAttribute("value");
				if(sum.equalsIgnoreCase(GLNetInvestHdgsB4Tax)){
					
					Logs.update("R1_123NC_TC_07.12", "GLNetInvestHdgsB4Tax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.12", "GLNetInvestHdgsB4Tax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//10. GLNetInvestHdgsTax
				QuerytoGetSum="select FORMAT(Account949_040, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String GLNetInvestHdgsTax=driver.findElement(Form_123NC_Obj.GLNetInvestHdgsTax).getAttribute("value");
				if(sum.equalsIgnoreCase(GLNetInvestHdgsTax)){
					Logs.update("R1_123NC_TC_07.12", "GLNetInvestHdgsTax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.12", "GLNetInvestHdgsTax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//11. unrealizedMarketSecB4Tax
				QuerytoGetSum="select FORMAT(Account949_050, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String unrealizedMarketSecB4Tax=driver.findElement(Form_123NC_Obj.unrealizedMarketSecB4Tax).getAttribute("value");
				if(sum.equalsIgnoreCase(unrealizedMarketSecB4Tax)){
					Logs.update("R1_123NC_TC_07.13", "unrealizedMarketSecB4Tax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.13", "unrealizedMarketSecB4Tax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//12. unrealizedMarketSecTax
				QuerytoGetSum="select FORMAT(Account949_060, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String unrealizedMarketSecTax=driver.findElement(Form_123NC_Obj.unrealizedMarketSecTax).getAttribute("value");
				if(sum.equalsIgnoreCase(unrealizedMarketSecTax)){
					Logs.update("R1_123NC_TC_07.14", "unrealizedMarketSecTax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.14", "unrealizedMarketSecTax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				
				//13. unrealCashFlowHedgingB4Tax
				QuerytoGetSum="select FORMAT(Account949_070, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String unrealCashFlowHedgingB4Tax=driver.findElement(Form_123NC_Obj.unrealCashFlowHedgingB4Tax).getAttribute("value");
				if(sum.equalsIgnoreCase(unrealCashFlowHedgingB4Tax)){
					Logs.update("R1_123NC_TC_07.15", "unrealCashFlowHedgingB4Tax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.15", "unrealCashFlowHedgingB4Tax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//14. unrealCashFlowHedgingTax
				QuerytoGetSum="select FORMAT(Account949_080, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String unrealCashFlowHedgingTax=driver.findElement(Form_123NC_Obj.unrealCashFlowHedgingTax).getAttribute("value");
				if(sum.equalsIgnoreCase(unrealCashFlowHedgingTax)){
					Logs.update("R1_123NC_TC_07.16", "unrealCashFlowHedgingTax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.16", "unrealCashFlowHedgingTax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//15. accumulatedTranslationAdjustB4Tax
				QuerytoGetSum="select FORMAT(Account949_090, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String accumulatedTranslationAdjustB4Tax=driver.findElement(Form_123NC_Obj.accumulatedTranslationAdjustB4Tax).getAttribute("value");
				if(sum.equalsIgnoreCase(accumulatedTranslationAdjustB4Tax)){
					Logs.update("R1_123NC_TC_07.17", "accumulatedTranslationAdjustB4Tax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.17", "accumulatedTranslationAdjustB4Tax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				
				//16. accumulatedTranslationAdjustTax
				QuerytoGetSum="select FORMAT(Account949_100, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String accumulatedTranslationAdjustTax=driver.findElement(Form_123NC_Obj.accumulatedTranslationAdjustTax).getAttribute("value");
				if(sum.equalsIgnoreCase(accumulatedTranslationAdjustTax)){
					Logs.update("R1_123NC_TC_07.18", "accumulatedTranslationAdjustTax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.18", "accumulatedTranslationAdjustTax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//17. UnrecogTransitionObligPensPostRetB4Tax_con
				QuerytoGetSum="select FORMAT(Account949_130, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String UnrecogTransitionObligPensPostRetB4Tax_con=driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax_con).getAttribute("value");
				if(sum.equalsIgnoreCase(UnrecogTransitionObligPensPostRetB4Tax_con)){
					Logs.update("R1_123NC_TC_07.19", "UnrecogTransitionObligPensPostRetB4Tax_con' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.19", "UnrecogTransitionObligPensPostRetB4Tax_con' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//18. UnrecogTransition1ObligPensPostRetTax_con
				QuerytoGetSum="select FORMAT(Account949_140, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String UnrecogTransition1ObligPensPostRetTax_con=driver.findElement(Form_123NC_Obj.UnrecogTransitionObligPensPostRetB4Tax_con).getAttribute("value");
				if(sum.equalsIgnoreCase(UnrecogTransition1ObligPensPostRetTax_con)){
					Logs.update("R1_123NC_TC_07.20", "UnrecogTransition1ObligPensPostRetTax_con' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.20", "UnrecogTransition1ObligPensPostRetTax_con' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//19. UnrecogPriorServiceCost1PensPostRetB4Tax_con
				QuerytoGetSum="select FORMAT(Account949_150, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String UnrecogPriorServiceCost1PensPostRetB4Tax_con=driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCost1PensPostRetB4Tax_con).getAttribute("value");
				if(sum.equalsIgnoreCase(UnrecogPriorServiceCost1PensPostRetB4Tax_con)){
					Logs.update("R1_123NC_TC_07.21", "UnrecogPriorServiceCost1PensPostRetB4Tax_con' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.21", "UnrecogPriorServiceCost1PensPostRetB4Tax_con' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//20. UnrecogPriorServiceCost1PensPostRetTax_con
				QuerytoGetSum="select FORMAT(Account949_160, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String UnrecogPriorServiceCost1PensPostRetTax_con=driver.findElement(Form_123NC_Obj.UnrecogPriorServiceCost1PensPostRetTax_con).getAttribute("value");
				if(sum.equalsIgnoreCase(UnrecogPriorServiceCost1PensPostRetTax_con)){
					Logs.update("R1_123NC_TC_07.22", "UnrecogPriorServiceCost1PensPostRetTax_con' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.22", "UnrecogPriorServiceCost1PensPostRetTax_con' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				
				//21. UnrecogActuarialGLPensPostRetB4Tax
				QuerytoGetSum="select FORMAT(Account949_170, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String UnrecogActuarialGLPensPostRetB4Tax=driver.findElement(Form_123NC_Obj.UnrecogActuarialGLPensPostRetB4Tax).getAttribute("value");
				if(sum.equalsIgnoreCase(UnrecogActuarialGLPensPostRetB4Tax)){
					Logs.update("R1_123NC_TC_07.24", "UnrecogActuarialGLPensPostRetB4Tax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.24", "UnrecogActuarialGLPensPostRetB4Tax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
				//22. UnrecogActuarialGLPensPostRetTax
				QuerytoGetSum="select FORMAT(Account949_180, '#,#')"
						+ "as sumOf_eligible_Fields from dbo.schedule123NCLiabEqu where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
				sum=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSum, "sumOf_eligible_Fields");

				System.out.println(QuerytoGetSum);
				System.out.println(period);
				String UnrecogActuarialGLPensPostRetTax=driver.findElement(Form_123NC_Obj.UnrecogActuarialGLPensPostRetTax).getAttribute("value");
				if(sum.equalsIgnoreCase(UnrecogActuarialGLPensPostRetTax)){
					Logs.update("R1_123NC_TC_07.25", "UnrecogActuarialGLPensPostRetTax' autoPopulated field is displayed with sum of fields as expected", Status.PASS, driver);
				}else{
					Logs.update("R1_123NC_TC_07.25", "UnrecogActuarialGLPensPostRetTax' autoPopulated field is not sum of fields", Status.FAIL, driver);
				}
				
//Calculated Cargill Share validation 
				
				String res1=driver.findElement(Form_123NC_Obj.stockOrAdditionalPaidInCapital_ccs).getText();
				int res1_int =Integer.parseInt(res1);
				String res2= driver.findElement(Form_123NC_Obj.stockOrAdditionalPaidInCapital).getText();
				int res2_int=Integer.parseInt(res2);
				String res3 = driver.findElement(Form_123NC_Obj.OwnershipPercent).getText();
				//int res3_int=Integer.parseInt(res3);
				float ownershipPercentage_float = Float.valueOf(res3);
				int res3_int=(int) Math.round(ownershipPercentage_float);
				
				
				if ( res1_int==(res2_int*res3_int))
				{
					Logs.update("R1_123NC_TC_07.26", "stockOrAdditionalPaidInCapital_ccs is displayed as expected ", Status.PASS, driver);
				}
				else 
				{
					Logs.update("R1_123NC_TC_07.26", "stockOrAdditionalPaidInCapital_ccs is displayed NOT as expected ", Status.PASS, driver);
				}
				
				/*//2. 
				String res1=driver.findElement(Form_123NC_Obj.beginniningRetainedEarnings_ccs).getText();
				int res1_int =Integer.parseInt(res1);
				String res2= driver.findElement(Form_123NC_Obj.beginniningRetainedEarnings).getText();
				int res2_int=Integer.parseInt(res2);
				String res3 = driver.findElement(Form_123NC_Obj.OwnershipPercent).getText();
				int res3_int=Integer.parseInt(res3);
				if ( res1_int==(res2_int*res3_int))
				{
					Logs.update("R1_123NC_TC_07.27", "beginniningRetainedEarnings_ccs is displayed as expected ", Status.PASS, driver);
				}
				else 
				{
					Logs.update("R1_123NC_TC_07.27", "beginniningRetainedEarnings_ccs is displayed NOT as expected ", Status.PASS, driver);
				}*/
				
				//3. 
				res1=driver.findElement(Form_123NC_Obj.currentYearEarnings_ccs).getText();
				System.out.println(res1);
		//float	res1_float =Float.valueOf(res1);
				res2= driver.findElement(Form_123NC_Obj.currentYearEarnings).getText();
				
				float res2_float=Float.valueOf(res2);
				res3 = driver.findElement(Form_123NC_Obj.OwnershipPercent).getText();
				//res3_int=Integer.parseInt(res3);
				ownershipPercentage_float = Float.valueOf(res3);
				res3_int=(int) Math.round(ownershipPercentage_float);
				
				if ( res1_int==(res2_float*res3_int))
				{
					Logs.update("R1_123NC_TC_07.28", "currentYearEarnings_ccs is displayed as expected ", Status.PASS, driver);
				}
				else 
				{
					Logs.update("R1_123NC_TC_07.28", "currentYearEarnings_ccs is displayed NOT as expected ", Status.PASS, driver);
				}
				
				//4. 
				res1=driver.findElement(Form_123NC_Obj.dividendsOrDistribution_ccs).getText();
				res1_int =Integer.parseInt(res1);
				res2= driver.findElement(Form_123NC_Obj.dividendsOrDistribution).getText();
				res2_int=Integer.parseInt(res2);
				if ( res1_int==(res2_int*res3_int))
				{
					Logs.update("R1_123NC_TC_07.29", "dividendsOrDistribution_ccs is displayed as expected ", Status.PASS, driver);
				}
				else 
				{
					Logs.update("R1_123NC_TC_07.29", "dividendsOrDistribution_ccs is displayed NOT as expected ", Status.PASS, driver);
				}
				
				//5. 
				res1=driver.findElement(Form_123NC_Obj.retainedEarnings_con_ccs).getText();
				res1_int =Integer.parseInt(res1);
				res2= driver.findElement(Form_123NC_Obj.retainedEarnings_con).getText();
				res2_int=Integer.parseInt(res2);
				if ( res1_int==(res2_int*res3_int))
				{
					Logs.update("R1_123NC_TC_07.30", "retainedEarnings_con_ccs is displayed as expected ", Status.PASS, driver);
				}
				else 
				{
					Logs.update("R1_123NC_TC_07.30", "retainedEarnings_con_ccs is displayed NOT as expected ", Status.PASS, driver);
				}
				
				
				
			//FC INVESTMENT ACCTS FROM PARENT BY SHARE OF NONCON
				String actual=driver.findElement(Form_123NC_Obj.currentYearEarnings_FCInvestment).getText();
				String expected ="330-0010 F245";
				if ( actual.equalsIgnoreCase(expected))
				{
					Logs.update("R1_123NC_TC_07.33", "currentYearEarnings_FCInvestment is displayed as expected ", Status.PASS, driver);
				}
				else 
				{
					Logs.update("R1_123NC_TC_07.33", "currentYearEarnings_FCInvestment is  NOT as expected ", Status.PASS, driver);
				}
				driver.quit();
				
				
	}
	
	//TC-06
	public static void verifyIncomeStatementTabDetails(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
			DriverScript Logs, String TestType) throws Exception {

		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		/*WebDriverWait wait=new WebDriverWait(driver, 50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(HubHomePageObj.Btn_Open));	*/
		Thread.sleep(4000);
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		String statusOfAssetSection=driver.findElement(Form_123NC_Obj.expandCollapseIcon_incomeStatement).getAttribute("class");
		if (statusOfAssetSection.equalsIgnoreCase("expand-vertical")){
			Logs.update("R1_123NC_TC_06.1 verify that Income Statement tab is collapsed by_default", "Income statement tab is collapsed when the schedule is opened for the first time as expected." , Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_06.1 verify that Income statement tab is collapsed by_default", "Income statement tab is Not collapsed when the schedule is opened at first" , Status.FAIL, driver);
		}
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.expandCollapseIcon_incomeStatement).click();
		//Verify the fields in Income statement section
		HubContributor.verifyFieldName(driver, "GROSS SALES:", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GrossSales_Header_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Gross Sales - Outside", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GrossSales_Outside_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Gross Sales - Consol Cos", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Gross Sales - Nonconsol Cos", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Gross Sales", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GrossSales_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other operating income:", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Header_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other Operating Income-Outside", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other Operating Income-Consol Cos", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other Operating Income-Nonconsol Cos", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other Operating Income", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Sales & Other Income Adjustments", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Total Net Sales & Other Income", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.TotalNetSalesAndOtherIncome_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Cost of Goods Sold", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.CostOfGoodSold_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Gross Profit", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GrossProfit_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Expenses:", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.Expenses_Header), Logs);
		HubContributor.verifyFieldName(driver, "Selling/Trading", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.SellingOrTrading_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "General/Administrative", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Interest on Long-Term Debt", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Interest on Short-Term Debt", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Depreciation", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.Depreciation_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Intangible Asset Amortization", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Other (Income)/Expense", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Total expenses", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.TotalExpenses_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Earnings Before Tax", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.EarningsBeforeTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Income Tax Expense/(Credit)", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Earnings After Tax", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.EarningsAfterTax_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Equity in Net Earnings of Consol Cos", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Equity in Net Earnings of Nonconsol Cos", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "Net Earnings", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.NetEarnings_IncomeStmt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "(Earnings)/Losses of Noncontrolling Int", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_Lbl), Logs);
		HubContributor.verifyFieldName(driver, "NET EARNINGS ATTRIBUTABLE TO CARGILL", "R1_123NC_TC_06.2", driver.findElement(Form_123NC_Obj.NETEARNINGSATTRIBUTABLETOCARGILL_Lbl), Logs);

		//**validation with Negative numbers **//*
		
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.GrossSales_Outside_field), Logs, "R1_123NC_TC_06.3", 14, "Gross Sales - Outside");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_field), Logs, "R1_123NC_TC_06.3", 14, "Gross Sales - Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_field), Logs, "R1_123NC_TC_06.3", 14, "Gross Sales - Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_field), Logs, "R1_123NC_TC_06.3", 14, "Other Operating Income-Outside");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_field), Logs, "R1_123NC_TC_06.3", 14, "Other Operating Income-Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_field), Logs, "R1_123NC_TC_06.3", 14, "	Other Operating Income-Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_field), Logs, "R1_123NC_TC_06.3", 14, "Sales & Other Income Adjustments");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.CostOfGoodSold_field), Logs, "R1_123NC_TC_06.3", 14, "Cost of Goods Sold");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.SellingOrTrading_field), Logs, "R1_123NC_TC_06.3", 14, "Selling/Trading");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_field), Logs, "R1_123NC_TC_06.3", 14, "General/Administrative");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_field), Logs, "R1_123NC_TC_06.3", 14, "Interest on Long-Term Debt");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_field), Logs, "R1_123NC_TC_06.3", 14, "Interest on Short-Term Debt");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.Depreciation_field), Logs, "R1_123NC_TC_06.3", 14, "Depreciation");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_field), Logs, "R1_123NC_TC_06.3", 14, "Intangible Asset Amortization");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_field), Logs, "R1_123NC_TC_06.3", 14, "Other (Income)/Expense");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_field), Logs, "R1_123NC_TC_06.3", 14, "Income Tax Expense/(Credit)");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_field), Logs, "R1_123NC_TC_06.3", 14, "Equity in Net Earnings of Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_field), Logs, "R1_123NC_TC_06.3", 14, "Equity in Net Earnings of Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_NegativeNumber_specDigit(driver, TestType, "123NC", "NegVal", driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_field), Logs, "R1_123NC_TC_06.3", 14, "(Earnings)/Losses of Noncontrolling Int");

		//Validation with alphabets
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.GrossSales_Outside_field), Logs, "R1_123NC_TC_06.4",  "Gross Sales - Outside");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_field), Logs, "R1_123NC_TC_06.4",  "Gross Sales - Consol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_field), Logs, "R1_123NC_TC_06.4",  "Gross Sales - Nonconsol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_field), Logs, "R1_123NC_TC_06.4",  "Other Operating Income-Outside");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_field), Logs, "R1_123NC_TC_06.4",  "Other Operating Income-Consol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_field), Logs, "R1_123NC_TC_06.4",  "	Other Operating Income-Nonconsol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_field), Logs, "R1_123NC_TC_06.4",  "Sales & Other Income Adjustments");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.CostOfGoodSold_field), Logs, "R1_123NC_TC_06.4",  "Cost of Goods Sold");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.SellingOrTrading_field), Logs, "R1_123NC_TC_06.4",  "Selling/Trading");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_field), Logs, "R1_123NC_TC_06.4",  "General/Administrative");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_field), Logs, "R1_123NC_TC_06.4",  "Interest on Long-Term Debt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_field), Logs, "R1_123NC_TC_06.4",  "Interest on Short-Term Debt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.Depreciation_field), Logs, "R1_123NC_TC_06.4",  "Depreciation");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_field), Logs, "R1_123NC_TC_06.4",  "Intangible Asset Amortization");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_field), Logs, "R1_123NC_TC_06.4",  "Other (Income)/Expense");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_field), Logs, "R1_123NC_TC_06.4",  "Income Tax Expense/(Credit)");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_field), Logs, "R1_123NC_TC_06.4",  "Equity in Net Earnings of Consol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_field), Logs, "R1_123NC_TC_06.4",  "Equity in Net Earnings of Nonconsol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "InvalidVal", driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_field), Logs, "R1_123NC_TC_06.4",  "(Earnings)/Losses of Noncontrolling Int");

		//Verify save with invalid value
						driver.findElement(Form_123NC_Obj.GrossSales_Outside_field).sendKeys("abcd");
						driver.findElement(HubContributorFormObj.btn_Save).click();
						Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
						String errorMsg = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
						Logs.update("To check the error message", "Error displayed: " + " " + errorMsg, Status.PASS, driver);
						if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

							Logs.update("R1_123NC_TC_06.5 verify that not able to save with alphabetical values",
									"Error is displayed when tried to save with abcd", Status.PASS, driver);
						} else {
							Logs.update("R1_123NC_TC_06.5 verify that not able to save with alphabetical values",
									"Error is not displayed when tried to save with abcd", Status.FAIL,
									driver);
						}
						
						driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
						driver.findElement(Form_123NC_Obj.GrossSales_Outside_field).clear();
			
						
						
						//Decimal validation
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.GrossSales_Outside_field), Logs, "R1_123NC_TC_06.6",  "Gross Sales - Outside");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_field), Logs, "R1_123NC_TC_06.6",  "Gross Sales - Consol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_field), Logs, "R1_123NC_TC_06.6",  "Gross Sales - Nonconsol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_field), Logs, "R1_123NC_TC_06.6",  "Other Operating Income-Outside");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_field), Logs, "R1_123NC_TC_06.6",  "Other Operating Income-Consol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_field), Logs, "R1_123NC_TC_06.6",  "	Other Operating Income-Nonconsol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_field), Logs, "R1_123NC_TC_06.6",  "Sales & Other Income Adjustments");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.CostOfGoodSold_field), Logs, "R1_123NC_TC_06.6",  "Cost of Goods Sold");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.SellingOrTrading_field), Logs, "R1_123NC_TC_06.6",  "Selling/Trading");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_field), Logs, "R1_123NC_TC_06.6",  "General/Administrative");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_field), Logs, "R1_123NC_TC_06.6",  "Interest on Long-Term Debt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_field), Logs, "R1_123NC_TC_06.6",  "Interest on Short-Term Debt");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.Depreciation_field), Logs, "R1_123NC_TC_06.6",  "Depreciation");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_field), Logs, "R1_123NC_TC_06.6",  "Intangible Asset Amortization");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_field), Logs, "R1_123NC_TC_06.6",  "Other (Income)/Expense");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_field), Logs, "R1_123NC_TC_06.6",  "Income Tax Expense/(Credit)");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_field), Logs, "R1_123NC_TC_06.6",  "Equity in Net Earnings of Consol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_field), Logs, "R1_123NC_TC_06.6",  "Equity in Net Earnings of Nonconsol Cos");
		HubContributor.VerifyErrorMsgWhen_AlphabetOrDecimal_ValEntered(driver, TestType, "123NC", "DecimalVal", driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_field), Logs, "R1_123NC_TC_06.6",  "(Earnings)/Losses of Noncontrolling Int");
	
		//verify save with invalid value
		driver.findElement(Form_123NC_Obj.GrossSales_Outside_field).sendKeys("123.34");
		driver.findElement(HubContributorFormObj.btn_Save).click();
		Base_class.waitForElementToVisible(driver, HubContributorFormObj.notSavedPopUpMessage, 10);
		String errorMsg1 = driver.findElement(HubContributorFormObj.notSavedPopUpMessage).getText().trim();
		Logs.update("To check the error message", "Error displayed: " + " " + errorMsg1, Status.PASS, driver);
		if (errorMsg.equalsIgnoreCase("Please correct the errors highlighted in red!!")) {

			Logs.update("R1_123NC_TC_06.7 verify that not able to save with decimal values",
					"Error is displayed when tried to save with 123.34", Status.PASS, driver);
		} else {
			Logs.update("R1_123NC_TC_06.7 verify that not able to save with decimal values",
					"Error is not displayed when tried to save with 123.34", Status.FAIL,
					driver);
		}
		
		driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
		driver.findElement(Form_123NC_Obj.GrossSales_Outside_field).clear();
		
		//Validation with positive numbers
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.GrossSales_Outside_field), Logs, "R1_123NC_TC_06.8", 15,  "Gross Sales - Outside");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.GrossSales_ConsolCos_field), Logs, "R1_123NC_TC_06.8", 15,  "Gross Sales - Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.GrossSales_NonConsolCos_field), Logs, "R1_123NC_TC_06.8", 15,  "Gross Sales - Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_Outside_field), Logs, "R1_123NC_TC_06.8", 15,  "Other Operating Income-Outside");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_ConsolCos_field), Logs, "R1_123NC_TC_06.8", 15,  "Other Operating Income-Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OtherOperatingIncome_NonConsolCos_field), Logs, "R1_123NC_TC_06.8", 15,  "	Other Operating Income-Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.SalesAndOtherIncomeAdjustments_field), Logs, "R1_123NC_TC_06.8", 15,  "Sales & Other Income Adjustments");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.CostOfGoodSold_field), Logs, "R1_123NC_TC_06.8", 15,  "Cost of Goods Sold");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.SellingOrTrading_field), Logs, "R1_123NC_TC_06.8", 15,  "Selling/Trading");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.GeneralOrAdministrative_field), Logs, "R1_123NC_TC_06.8", 15,  "General/Administrative");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InterestOnLongTermDebt_field), Logs, "R1_123NC_TC_06.8", 15,  "Interest on Long-Term Debt");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.InterestOnShortTermDebt_field), Logs, "R1_123NC_TC_06.8", 15,  "Interest on Short-Term Debt");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.Depreciation_field), Logs, "R1_123NC_TC_06.8", 15,  "Depreciation");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.IntangibleAssetAmortization_field), Logs, "R1_123NC_TC_06.8", 15,  "Intangible Asset Amortization");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.OtherIncomeOrExpense_field), Logs, "R1_123NC_TC_06.8", 15,  "Other (Income)/Expense");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.IncomeTaxExpenseOrCredit_field), Logs, "R1_123NC_TC_06.8", 15,  "Income Tax Expense/(Credit)");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfConsolCos_field), Logs, "R1_123NC_TC_06.8", 15,  "Equity in Net Earnings of Consol Cos");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.EquityInNetEarningsOfNonconsolCos_field), Logs, "R1_123NC_TC_06.8", 15,  "Equity in Net Earnings of Nonconsol Cos");
		HubContributor.VerifyUserIsAbletoEnter_PositiveNumber_specDigit(driver, TestType, "123NC", "PosVal", driver.findElement(Form_123NC_Obj.EarningsOrLossesOfNoncontrollingInt_field), Logs, "R1_123NC_TC_06.8", 15,  "(Earnings)/Losses of Noncontrolling Int");
		//Save the section:
		driver.findElement(Form_123NC_Obj.IncomeStatementSave_btn).click();
		//To Verify Gross Sales field
		//Should be sum of fields 803,809 and 812
		
		String QuerytoGetSumOf_field_803_809_812="select FORMAT(sum(Account803+Account809+Account812), '#,#')"
				+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SumOf_field_803_809_812=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_803_809_812, "sumOf_eligible_Fields");
		String ActValOf_GrossSales815_Field=driver.findElement(Form_123NC_Obj.GrossSales_field).getAttribute("value");
		if(SumOf_field_803_809_812.equals(ActValOf_GrossSales815_Field)){
			Logs.update("R1_123NC_TC_06.9", "'Gross Sales' autoPopulated field is displayed with sum of fields 803,809 and 812 as expected", Status.PASS, driver);
		}else{
			Logs.update("R1_123NC_TC_06.9", "'Gross Sales' autoPopulated field is not sum of fields 803,809 and 812", Status.FAIL, driver);
		}

		//To Verify Other Operating Income field
		//Should be sum of fields 821,827 and 830
				
		String QuerytoGetSumOf_field_821_827_830="select FORMAT(sum(Account821+Account827+Account830), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SumOf_field_821_827_830=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_821_827_830, "sumOf_eligible_Fields");
		String ActValOf_OtherOperatingIncome833_Field=driver.findElement(Form_123NC_Obj.OtherOperatingIncome_field).getAttribute("value");
		if(SumOf_field_821_827_830.equals(ActValOf_OtherOperatingIncome833_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Other Operating Income' autoPopulated field is displayed with sum of fields 821,827 and 830 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Other Operating Income' autoPopulated field is not sum of fields 821,827 and 830", Status.FAIL, driver);
		}
		
		//To Verify Total Net Sales & Other Income field
		//Should be sum of fields 815,833 and 836
				
		String QuerytoGetSumOf_field_815_833_836="select FORMAT(sum(Account815+Account833+Account836), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SumOf_field_815_833_836=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_815_833_836, "sumOf_eligible_Fields");
		String ActValOf_TotalNetSalesAndOtherIncome839_Field=driver.findElement(Form_123NC_Obj.TotalNetSalesAndOtherIncome_field).getAttribute("value");
		Assert.assertEquals(SumOf_field_815_833_836, ActValOf_TotalNetSalesAndOtherIncome839_Field, "Total Net Sales & Other Income' autoPopulated field is not sum of fields 815,833 and 836");
		if(SumOf_field_815_833_836.equals(ActValOf_TotalNetSalesAndOtherIncome839_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Total Net Sales & Other Income' autoPopulated field is displayed with sum of fields 815,833 and 836 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Total Net Sales & Other Income' autoPopulated field is not sum of fields 815,833 and 836", Status.FAIL, driver);
		}
		
		//To Verify Gross Profit field
		//Should be subtraction of fields 839-845
				
		String QuerytoGetSubtractOf_field_839_845="select FORMAT(sum(Account839-Account845), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SubtractOf_field_839_845=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSubtractOf_field_839_845, "sumOf_eligible_Fields");
		String ActValOf_grossProfil855_Field=driver.findElement(Form_123NC_Obj.GrossProfit_field).getAttribute("value");
		Assert.assertEquals(SubtractOf_field_839_845, ActValOf_grossProfil855_Field, "Gross Profit' autoPopulated field is not subtraction of fields 839 and 845");
		if(SubtractOf_field_839_845.equals(ActValOf_grossProfil855_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Gross Profit' autoPopulated field is displayed with subtraction of fields 839 and 845 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Gross Profit' autoPopulated field is not subtraction of fields 839 and 845", Status.FAIL, driver);
		}
		
		//To Verify Total expenses field
		//Should be sum of fields 860,861,864,865,867,870 and 875		

				
		String QuerytoGetSumOf_field_860_861_864_865_867_870_875="select FORMAT(sum(Account860+Account861+Account864+Account865+Account867+Account870+Account875), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SumOf_field_860_861_864_865_867_870_875=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_860_861_864_865_867_870_875, "sumOf_eligible_Fields");
		String ActValOf_TotalExpenses876_Field=driver.findElement(Form_123NC_Obj.TotalExpenses_field).getAttribute("value");
		if(SumOf_field_860_861_864_865_867_870_875.equals(ActValOf_TotalExpenses876_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Total Expenses' autoPopulated field is displayed with sum of fields 860,861,864,865,867,870 and 875 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Total Expenses' autoPopulated field is not sum of fields 860,861,864,865,867,870 and 875", Status.FAIL, driver);
		}		
		
		//To Verify Earnings Before Tax field
		//Should be subtraction of fields 855-876
				
		String QuerytoGetSubtractOf_field_855_876="select FORMAT(sum(Account855-Account876), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SubtractOf_field_855_876=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSubtractOf_field_855_876, "sumOf_eligible_Fields");
		SubtractOf_field_855_876=SubtractOf_field_855_876.replace("-", "");
		String exSubtractOf_field_855_876="("+SubtractOf_field_855_876+")";
		String ActValOf_EarningBeforeTax880_Field=driver.findElement(Form_123NC_Obj.EarningsBeforeTax_field).getAttribute("value");
		
		
		Assert.assertEquals(exSubtractOf_field_855_876, ActValOf_EarningBeforeTax880_Field, "'Earning before tax' autoPopulated field is not subtraction of fields 855 and 876");
		if(exSubtractOf_field_855_876.equals(ActValOf_EarningBeforeTax880_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Earning before tax' autoPopulated field is displayed with subtraction of fields 855 and 876 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Earning before tax' autoPopulated field is not subtraction of fields 855 and 876", Status.FAIL, driver);
		}
		
		//To Verify Earnings After Tax field
		//Should be subtraction of fields 880-883
				
		String QuerytoGetSubtractOf_field_880_883="select FORMAT(sum(Account880-Account883), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SubtractOf_field_880_883=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSubtractOf_field_880_883, "sumOf_eligible_Fields");
		SubtractOf_field_880_883=SubtractOf_field_880_883.replace("-", "");
		String exSubtractOf_field_880_883="("+SubtractOf_field_880_883+")";
		
		String ActValOf_EarningAfterTax885_Field=driver.findElement(Form_123NC_Obj.EarningsAfterTax_field).getAttribute("value");
		Assert.assertEquals(exSubtractOf_field_880_883, ActValOf_EarningAfterTax885_Field, "Earning After tax' autoPopulated field is not subtraction of fields 880 and 883");
		if(exSubtractOf_field_880_883.equals(ActValOf_EarningAfterTax885_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Earning After tax' autoPopulated field is displayed with subtraction of fields 880 and 883 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Earning After tax' autoPopulated field is not subtraction of fields 880 and 883", Status.FAIL, driver);
		}
		
		
		//To Verify Net Earnings field
		//Should be sum of fields 885,890 and 891
				
		String QuerytoGetSumOf_field_885_890_891="select sum(Account885+Account890+Account891)"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SumOf_field_885_890_891=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_885_890_891, "sumOf_eligible_Fields");
		String ActValOf_NetEarning895_Field=driver.findElement(Form_123NC_Obj.NetEarnings_IncomeStmt_field).getAttribute("value");
		Assert.assertEquals(SumOf_field_885_890_891, ActValOf_NetEarning895_Field, "Net Earnings' autoPopulated field is not sum of fields 885,890 and 891");
		if(SumOf_field_885_890_891.equals(ActValOf_NetEarning895_Field)){
		Logs.update("R1_123NC_TC_06.9", "'Net Earnings' autoPopulated field is displayed with sum of fields 885,890 and 891 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'Net Earnings' autoPopulated field is not sum of fields 885,890 and 891", Status.FAIL, driver);
		}

		//To Verify NET EARNINGS ATTRIBUTABLE TO CARGILLs field
		//Should be sum of fields 895 and 896
				
		String QuerytoGetSumOf_field_895_896="select FORMAT(sum(Account895+Account896), '#,#')"
		+ "as sumOf_eligible_Fields from dbo.schedule123NCIncomeStmts where entitycode="+"'"+entityName+"'"+"and periodID in ('"+period+"')";
		String SumOf_field_895_896=DataBaseConnection.getData(driver, Logs, TestType, QuerytoGetSumOf_field_895_896, "sumOf_eligible_Fields");
		String ActValOf_NetEarningATTRIBUTABLETOCARGILL899_Field=driver.findElement(Form_123NC_Obj.NETEARNINGSATTRIBUTABLETOCARGILL_field).getAttribute("value");
		Assert.assertEquals(SumOf_field_895_896, ActValOf_NetEarningATTRIBUTABLETOCARGILL899_Field, "NET EARNINGS ATTRIBUTABLE TO CARGILLs' autoPopulated field is not sum of fields 895 and 896");
		if(SumOf_field_895_896.equals(ActValOf_NetEarningATTRIBUTABLETOCARGILL899_Field)){
		Logs.update("R1_123NC_TC_06.9", "'NET EARNINGS ATTRIBUTABLE TO CARGILLs' autoPopulated field is displayed with sum of fields 895 and 896 as expected", Status.PASS, driver);
		}else{
		Logs.update("R1_123NC_TC_06.9", "'NET EARNINGS ATTRIBUTABLE TO CARGILLs' autoPopulated field is not sum of fields 895 and 896", Status.FAIL, driver);

		}		
				
		driver.quit();
		}
		

	
	//TC-08
		public static void verify123NCSubmitFunctionality(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
				DriverScript Logs, String TestType) throws Exception {

			driver = Login.LaunchHub("Setupurl", Logs);
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			/*WebDriverWait wait=new WebDriverWait(driver, 50);
			wait.until(ExpectedConditions.visibilityOfElementLocated(HubHomePageObj.Btn_Open));	*/
			Thread.sleep(4000);
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			String ParentcurrentHandle=driver.getWindowHandle();
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(7000);
			Thread.sleep(7000);
			driver.findElement(Form_123NC_Obj.expandCollapseIcon).click();
			//enter data in Assets fields
			//Function call code to enter data in Assets fields
			Form123NCPage.enterDataInAssetsFields(driver, TestType);
			Thread.sleep(5000);
			//Enter data in liability tab
			driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
		//Function call code to enter data in liability tab
		Form123NCPage.enterDataInLiabilitiesFields(driver, TestType);
		
	//Code to clear Retained earnings,Other
	driver.findElement(Form_123NC_Obj.retainedEarningsOther).clear();
	Thread.sleep(3000);
	driver.findElement(Form_123NC_Obj.retainedEarningsOther).sendKeys("0");
	Thread.sleep(3000);
	driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();	
	
	//Code to make sure BS check is 0
	driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
	String bsCheckActual=driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
	String NonControllingValToEnter="-"+bsCheckActual;
	System.out.println(NonControllingValToEnter);
	
	driver.findElement(Form_123NC_Obj.NonControllingInterests).sendKeys(NonControllingValToEnter);
	Thread.sleep(3000);
	driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();

	//Enter data in incomestatement tab
	Thread.sleep(7000);
			driver.findElement(Form_123NC_Obj.expandCollapseIcon_incomeStatement).click();
			//Function call code to enter data in Income statement all fields
			Form123NCPage.enterDataInIncomeStatementFields(driver, TestType);
			Thread.sleep(5000);
			driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
			Thread.sleep(3000);
			currentHandle = driver.getWindowHandle();
			HubContributor.switchWindow_3(driver);
			String ReconPageHeader=driver.findElement(Form_123NC_Obj.ReconciliationSection_Header).getText();
			if(ReconPageHeader.equalsIgnoreCase("A&F 123 Non-consolidated at Equity Financial Statements - Reconciliation Section")){
				Assert.assertEquals(ReconPageHeader,"A&F 123 Non-consolidated at Equity Financial Statements - Reconciliation Section");
				Logs.update("R1_123NC_TC_08.1", "User is navigated to the page: "+ReconPageHeader, Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_08.1", "User is Not navigated to the page ''NonCon. at Equity Financial Stmts - Reconciliation Section'", Status.FAIL, driver);
			}
			
			String equityCheckVal=driver.findElement(Form_123NC_Obj.EquityCheckVal).getAttribute("title");
			String oCICheckVal=driver.findElement(Form_123NC_Obj.OCICheckVal).getAttribute("title");
			if(equityCheckVal.equals("0")){
				Logs.update("R1_123NC_TC_08.1 Verify quity check is equal to 0", "Equity check is equal to zero as expected", Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_08.1 Verify quity check is equal to 0", "Equity check is not equal to zero", Status.FAIL, driver);
			}
			
			if(oCICheckVal.equals("0")){
				Logs.update("R1_123NC_TC_08.2 Verify OCI check is equal to 0", "OCI check is equal to zero as expected", Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_08.2 Verify OCI check is equal to 0", "OCI check is not equal to zero", Status.FAIL, driver);
			}

			int differenceNoint;
			Thread.sleep(3000);
			String differenceNo=driver.findElement(Form_123NC_Obj.DIFFERENCE_CALC_VS_ACTUAL_CARGILL_SHARE_Val).getText();
			System.out.println(differenceNo);
			 if (differenceNo.contains("(")) {
				 differenceNo = differenceNo.replaceAll("[(),]", "");
			        differenceNoint=Integer.valueOf(differenceNo) * -1;
			    } else {
			    	differenceNo = differenceNo.replaceAll("[,]", "");
			        differenceNoint= Integer.valueOf(differenceNo);
			    }
			 System.out.println(differenceNoint);
		if (differenceNoint > 5000 || differenceNoint < -5000){
			// when the difference amount is greater than 5000 then user should
			// not be able to submit the schedule without entering commentary
			// field
			Logs.update("Verify DIFFERENCE CALC VS ACTUAL CARGILL SHARE",
					"Difference Calc vs Actual Cargill Share� is greater than 10,000/-10,000 and enter commentary. ", Status.PASS, driver);
			// Clearing the commentary section
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.commentaryTextArea).clear();
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.commentaryTextArea).sendKeys("Entering commentary because difference is more than 5000");
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.saveCommentary_btn).click();
			Thread.sleep(5000);
			driver.close();
			driver.switchTo().window(currentHandle);
			Thread.sleep(3000);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(2000);
			String expPopMsg = Util.getAllNecessaryData(TestType, "123NC", "SubmitSuccessPopUpMessage");
			String popUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.messagePopUpText, Logs, expPopMsg);
			Assert.assertEquals(expPopMsg, popUpMsg, "Expected and actual popup msg is not same");
			Thread.sleep(4000);
			if(popUpMsg.contains("Once submitted, you will be required to recall the schedule")){
			Logs.update("R1_123NC_TC_08.3 Verify user is able to submit the shchedule", "Able to submit the schedule as expected: "+popUpMsg,Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_08.3 Verify user is able to submit the shchedule ", "Not Able to submit the schedule ",Status.FAIL, driver);
			}
			
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			String popUpMsg1=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Logs.update("Verify the submit is sucessful", "Submit is successful with message: "+popUpMsg1, Status.PASS, driver);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			//Code to recall the schedule after the submitting the schedule
			
			driver.switchTo().window(ParentcurrentHandle);
			Thread.sleep(2000);
			driver.findElement(By.name("StatusDashBoardButton")).click();

			WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
			driver.switchTo().frame(Frame);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.selectScheduleNew).click();
			Thread.sleep(2000);
			HubHomePageObj.findScheduleName(driver, schedule).click();
			// Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
			driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
			driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
			Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
			driver.findElement(HubHomePageObj.searchButtonDashboard).click();
			Thread.sleep(5000);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			String StatusOfSchedule=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
			Logs.update("Verify the status of the schedule after submit", "Status of the schedule after submit is: "+StatusOfSchedule, Status.PASS, driver);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(By.name("btnRecallEdit")).click();
			Logs.update("Verify Recall is successful", "Recall is successful ", Status.PASS, driver);
			Thread.sleep(3000);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(5000);
			driver.quit();
		}else{
			Logs.update("Verify DIFFERENCE CALC VS ACTUAL CARGILL SHARE",
					"Difference Calc vs Actual Cargill Share� is less than 10,000/-10,000 so commentary is not required to submit ", Status.PASS, driver);
			// Clearing the commentary section
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.commentaryTextArea).clear();
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.saveCommentary_btn).click();
			Thread.sleep(5000);
			driver.close();
			driver.switchTo().window(currentHandle);
			Thread.sleep(3000);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(2000);
			String expPopMsg = Util.getAllNecessaryData(TestType, "123NC", "SubmitSuccessPopUpMessage");
			String popUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.messagePopUpText, Logs, expPopMsg);
			Assert.assertEquals(expPopMsg, popUpMsg, "Expected and actual popup msg is not same");
			Thread.sleep(4000);
			if(popUpMsg.contains("Once submitted, you will be required to recall the schedule")){
			Logs.update("R1_123NC_TC_08.3 Verify user is able to submit the shchedule", "Able to submit the schedule as expected: "+popUpMsg,Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_08.3 Verify user is able to submit the shchedule ", "Not Able to submit the schedule ",Status.FAIL, driver);
			}
			
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			String popUpMsg1=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Logs.update("Verify the submit is sucessful", "Submit is successful with message: "+popUpMsg1, Status.PASS, driver);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			//Code to recall the schedule after the submitting the schedule
			
			driver.switchTo().window(ParentcurrentHandle);
			Thread.sleep(2000);
			driver.findElement(By.name("StatusDashBoardButton")).click();

			WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
			driver.switchTo().frame(Frame);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.selectScheduleNew).click();
			Thread.sleep(2000);
			HubHomePageObj.findScheduleName(driver, schedule).click();
			// Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
			driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
			driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
			Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
			driver.findElement(HubHomePageObj.searchButtonDashboard).click();
			Thread.sleep(5000);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			String StatusOfSchedule=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
			Logs.update("Verify the status of the schedule after submit", "Status of the schedule after submit is: "+StatusOfSchedule, Status.PASS, driver);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(By.name("btnRecallEdit")).click();
			Logs.update("Verify Recall is successful", "Recall is successful ", Status.PASS, driver);
			Thread.sleep(3000);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(5000);
			driver.quit();
			
		}
	}
		
			
		
		
		
		//TC11,TC12
		public static void verifyTotalRetainedEarningsFunctionality(WebDriver driver, String entityName, String period, String schedule, String scheduleLongDesc,
				DriverScript Logs, String TestType) throws Exception {

			driver = Login.LaunchHub("Setupurl", Logs);
			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);	
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			String ParentcurrentHandle = driver.getWindowHandle();
			HubContributor.switchWindow(driver);
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
			Thread.sleep(7000);
			Thread.sleep(7000);
			driver.findElement(Form_123NC_Obj.expandCollapseIcon).click();
			//enter data in Assets fields
			//Function call code to enter data all fields in assets section
			Form123NCPage.enterDataInAssetsFields(driver, TestType);
			
			//Enter data in liability tab
			Thread.sleep(5000);
			driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
			//Function call code to enter data in all the field in liability tab.
			Form123NCPage.enterDataInLiabilitiesFields(driver, TestType); 
			
	//Code to make sure BS check is 0
	driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
		String bsCheckActual=driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
		String NonControllingValToEnter="-"+bsCheckActual;
		System.out.println(NonControllingValToEnter);
		
		driver.findElement(Form_123NC_Obj.NonControllingInterests).sendKeys(NonControllingValToEnter);
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
	//To read the value from field
	String RetainedEarningsOtherVal=driver.findElement(Form_123NC_Obj.retainedEarningsOther).getAttribute("value");
	if(!RetainedEarningsOtherVal.equals("0")){
		Logs.update("Verify that value in the Retained Earnings,Other is not equal to 0", "Value in the Retained Earnings,Other is not zero as expected", Status.PASS, driver);
	}else{
		Logs.update("Verify that value in the Retained Earnings,Other is not equal to 0", "Value in the Retained Earnings,Other is zero please correct the inputs", Status.FAIL, driver);
	}
	
	//Code to make sure commentary is added in recon page
	Thread.sleep(7000);
	driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
	
	Thread.sleep(3000);
	currentHandle = driver.getWindowHandle();
	HubContributor.switchWindow_3(driver);
	Thread.sleep(6000);
	driver.findElement(Form_123NC_Obj.commentaryTextArea).clear();
	Thread.sleep(5000);
	driver.findElement(Form_123NC_Obj.commentaryTextArea)
			.sendKeys("Entering commentary to save when difference is greater than 5000");
	Thread.sleep(5000);
	driver.findElement(Form_123NC_Obj.saveCommentary_btn).click();
	Thread.sleep(3000);
	driver.close();
	driver.switchTo().window(currentHandle);
	Thread.sleep(3000);
	driver.findElement(HubContributorFormObj.btn_Submit).click();
	Thread.sleep(4000);
	
	if(driver.findElement(HubContributorFormObj.messagePopUpText).isDisplayed()){
	String popUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
	Logs.update("R1_123NC_TC_11 Verify user is able to submit when value present", "Not able to submit the schedule when total Retained Earnings is not 0 and commentary against the field is not entered with message: "+popUpMsg,Status.PASS, driver);
	}else{
		Logs.update("R1_123NC_TC_11 Verify user is able to submit when value present", "Able to submit the schedule when total Retained Earnings is not 0 and commentary against the field is not entered",Status.FAIL, driver);
	}
	
	driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
	
	//Code to make sure Retained earning, Other is 0
	driver.findElement(Form_123NC_Obj.retainedEarningsOther).clear();
	Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.retainedEarningsOther).sendKeys("0");
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
		String retainedEarningVal=driver.findElement(Form_123NC_Obj.retainedEarningsOther).getAttribute("value");
		if(retainedEarningVal.equals("0")){
		Logs.update("Verify retained earning field is set to 0" , "Retained earning field is set to 0 as expected", Status.PASS, driver);
		}else{
			Logs.update("Verify retained earning field is set to 0" , "Retained earning field is NOT set to 0 ", Status.FAIL, driver);
		}
		Thread.sleep(3000);
	//Code to make sure BS check is 0 after changing  Retained earning,Other is set to 0.
	driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
	String bsCheckActual_1=driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
	String NonControllingValToEnter_1="-"+bsCheckActual_1;
	driver.findElement(Form_123NC_Obj.NonControllingInterests).sendKeys(NonControllingValToEnter_1);
	Thread.sleep(3000);
	driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
	Thread.sleep(3000);
	
	driver.findElement(HubContributorFormObj.btn_Submit).click();
	Thread.sleep(4000);
	String popUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
	
	if(popUpMsg.contains("Once submitted, you will be required to recall the schedule")){
	Logs.update("R1_123NC_TC_12 Verify user is able to submit when Retained Earning is 0", "Able to submit the schedule when Retained Earnings,Other is 0 and commentary against the field is not entered as expected: "+popUpMsg,Status.PASS, driver);
	}else{
		Logs.update("R1_123NC_TC_12 Verify user is able to submit when Retained Earning is 0", "Not Able to submit the schedule when Retained Earnings,Other is 0 and commentary against the field is not entered",Status.FAIL, driver);
	}
	driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
	String popUpMsg1=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
	Logs.update("Verify the submit is sucessful", "Submit is successful with message: "+popUpMsg1, Status.PASS, driver);
	actions.sendKeys(Keys.ENTER).build().perform();
	Thread.sleep(3000);
	driver.switchTo().alert().accept();
	//Code to recall the schedule after the submitting the schedule
	
	driver.switchTo().window(ParentcurrentHandle);
	Thread.sleep(2000);
	driver.findElement(By.name("StatusDashBoardButton")).click();

	WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
	driver.switchTo().frame(Frame);
	Thread.sleep(5000);
	// Base_class.waitForElementTobeClickable(driver,
	// HubHomePageObj.edt_EntityDeatils, 20);
	driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
	Thread.sleep(5000);
	// Base_class.waitForElementToVisible(driver,
	// HubHomePageObj.selectSchedule, 10);
	driver.findElement(HubHomePageObj.selectScheduleNew).click();
	Thread.sleep(2000);
	HubHomePageObj.findScheduleName(driver, schedule).click();
	// Thread.sleep(1000);
	Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
	driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
	driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
	Thread.sleep(1000);
	Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
	driver.findElement(HubHomePageObj.searchButtonDashboard).click();
	Thread.sleep(5000);
	entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
	String StatusOfSchedule=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
	Logs.update("Verify the status of the schedule after submit", "Status of the schedule after submit is: "+StatusOfSchedule, Status.PASS, driver);
	actions.moveToElement(entityXpath).doubleClick().build().perform();
	Thread.sleep(4000);
	driver.findElement(By.name("btnRecallEdit")).click();
	Logs.update("Verify Recall is successful", "Recall is successful ", Status.PASS, driver);
	Thread.sleep(3000);
	actions.sendKeys(Keys.ENTER).build().perform();
	Thread.sleep(5000);
	driver.quit();
}
		
	//TC_13	
	public static void verifySubmitFunctionWhenDiffIsGreaterThanRange(WebDriver driver, String entityName,
			String period, String schedule, String scheduleLongDesc, DriverScript Logs, String TestType)
			throws Exception {
		String bsCheckActual;
		String NonControllingValToEnter;
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String ParentcurrentHandle=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		Thread.sleep(7000);
		Thread.sleep(7000);
		driver.findElement(Form_123NC_Obj.expandCollapseIcon).click();
		Thread.sleep(5000);
		driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
		// Function call code to clear data in liability tab
		Form123NCPage.clear_LiabilitiesFields(driver, TestType);
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.expandCollapseIcon_incomeStatement).click();
		
		int array[]={10001,-10001};
		for(int i=0; i<array.length; i++)
		{ Logs.update("Verify DIFFERENCE CALC VS ACTUAL CARGILL SHARE","For Value "+array[i], Status.PASS, driver);
			Thread.sleep(5000);
			driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
			Thread.sleep(3000);
			currentHandle = driver.getWindowHandle();
			HubContributor.switchWindow_3(driver);
		int res=Form123NCPage.calculateValue_TC13_TC14(driver, array[i]);
		String ResToEnter=String.valueOf(res);
		System.out.println(res);
		//Go Back to previous page to update the field to make difference as 10001.
		driver.close();
		driver.switchTo().window(currentHandle);
		driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax).sendKeys(ResToEnter);
		
		//Code to make BS check=0
		driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
		bsCheckActual = driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
		NonControllingValToEnter = "-" + bsCheckActual;
		System.out.println(NonControllingValToEnter);

		driver.findElement(Form_123NC_Obj.NonControllingInterests).sendKeys(NonControllingValToEnter);
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
		//Again click on reconciliation button
		Thread.sleep(5000);
		driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
		
		Thread.sleep(3000);
		currentHandle = driver.getWindowHandle();
		HubContributor.switchWindow_3(driver);
		
		
	int differenceNoint;
		String differenceNo;
		Thread.sleep(4000);
		differenceNo = driver.findElement(Form_123NC_Obj.DIFFERENCE_CALC_VS_ACTUAL_CARGILL_SHARE_Val).getText();
		System.out.println(differenceNo);
		if (differenceNo.contains("(")) {
			differenceNo = differenceNo.replaceAll("[(),]", "");
			differenceNoint = Integer.valueOf(differenceNo) * -1;
		} else {
			differenceNo = differenceNo.replaceAll("[,]", "");
			differenceNoint = Integer.valueOf(differenceNo);
		}
		System.out.println(differenceNoint);
		
		if (differenceNoint > 5000 || differenceNoint < -5000 ) {
			// when the difference amount is greater than 5000 or less than -5000 then user should
			// not be able to submit the schedule without entering commentary
			// field
			Logs.update("Verify DIFFERENCE CALC VS ACTUAL CARGILL SHARE",
					"Difference Calc vs Actual Cargill Share� is greater than 5000/-5000: "+differenceNoint, Status.PASS, driver);
			// Clearing the commentary section
			Thread.sleep(5000);
			driver.findElement(Form_123NC_Obj.commentaryTextArea).clear();
			Thread.sleep(3000);
			Logs.update("Make sure the commentary section is cleared", "Commentary section is cleared as expected", Status.PASS, driver);
			driver.findElement(Form_123NC_Obj.saveCommentary_btn).click();
			Thread.sleep(5000);
			driver.close();
			driver.switchTo().window(currentHandle);
			Thread.sleep(3000);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(2000);
			String popupMsgOnSubmit=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			String expPopMsg = Util.getAllNecessaryData(TestType, "123NC", "SubmitPopUpHeaderMessage");
			//HubContributor.verifyPopUpMessage(driver, HubContributorFormObj.messagePopUpText, Logs, expPopMsg);*/
			if(popupMsgOnSubmit.contains(expPopMsg)){
			Logs.update("R1_123NC_TC_13 verify user is not able to submit the schedule",
					"User is not able to submit the schedule when difference of the value is >5000 or <-5000: "+popupMsgOnSubmit,
					Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_13 verify user is not able to submit the schedule",
						"Pop Error message is different: "+popupMsgOnSubmit +"Expected Message is: "+expPopMsg,
						Status.FAIL, driver);
			}
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax).clear();
			driver.findElement(Form_123NC_Obj.NonControllingInterests).click();
			Thread.sleep(3000);
			driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
			Thread.sleep(5000);
			
		}}
		driver.quit();
	}

	//TC_14: Should be able to submit the schedule when difference calculated in the reconciliation section 
	//is less than  than 5000 or -5000 and the corresponding commentary box is left blank
	public static void verifySubmitFunctionWhenDiffIsWithinTheRange(WebDriver driver, String entityName,
			String period, String schedule, String scheduleLongDesc, DriverScript Logs, String TestType)
			throws Exception {
		String bsCheckActual;
		String NonControllingValToEnter;
		driver = Login.LaunchHub("Setupurl", Logs);
		actions = new Actions(driver);
		HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
		WebElement entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
		actions.moveToElement(entityXpath).doubleClick().build().perform();
		Thread.sleep(4000);
		String ParentcurrentHandle=driver.getWindowHandle();
		driver.findElement(HubHomePageObj.Btn_Open).click();
		Thread.sleep(3000);
		HubContributor.switchWindow(driver);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		Base_class.waitForElementTobeClickable(driver, HubContributorFormObj.ScheduleNameLbl, 10);
		
		//driver.findElement(Form_123NC_Obj.expandCollapseIcon).click();
		
	//	driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
		// Function call code to clear data in liability tab
	//	Form123NCPage.clear_LiabilitiesFields(driver, TestType);
		//Thread.sleep(3000);
		//driver.findElement(Form_123NC_Obj.expandCollapseIcon_incomeStatement).click();
		
		int array[]={10000,999,-999};
		for(int i=0; i<array.length; i++)
		{Thread.sleep(7000);
		Thread.sleep(7000);
		Logs.update("Verify DIFFERENCE CALC VS ACTUAL CARGILL SHARE","For Value "+array[i],
				 Status.PASS, driver);
		
			driver.findElement(Form_123NC_Obj.expandCollapseIconLiabilities).click();
			// Function call code to clear data in liability tab
			Form123NCPage.clear_LiabilitiesFields(driver, TestType);
			
			Thread.sleep(5000);
			
			driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
			Thread.sleep(3000);
			currentHandle = driver.getWindowHandle();
			HubContributor.switchWindow_3(driver);
		int res=Form123NCPage.calculateValue_TC13_TC14(driver, array[i]);
		String ResToEnter=String.valueOf(res);
		System.out.println(res);
		//Go Back to previous page to update the field to make difference as 10001.
		driver.close();
		driver.switchTo().window(currentHandle);
		driver.findElement(Form_123NC_Obj.UnrecogActuarialPensPostRetTax).sendKeys(ResToEnter);
		
		//Code to make BS check=0
		driver.findElement(Form_123NC_Obj.NonControllingInterests).clear();
		bsCheckActual = driver.findElement(Form_123NC_Obj.BSCheck).getAttribute("value");
		NonControllingValToEnter = "-" + bsCheckActual;
		System.out.println(NonControllingValToEnter);

		driver.findElement(Form_123NC_Obj.NonControllingInterests).sendKeys(NonControllingValToEnter);
		Thread.sleep(3000);
		driver.findElement(Form_123NC_Obj.LiabilitiesSave_btn).click();
		//Again click on reconciliation button
		Thread.sleep(5000);
		driver.findElement(Form_123NC_Obj.ReconciliationSection_Btn).click();
		
		Thread.sleep(3000);
		currentHandle = driver.getWindowHandle();
		HubContributor.switchWindow_3(driver);
		
	int differenceNoint;
		String differenceNo;
		Thread.sleep(4000);
		differenceNo = driver.findElement(Form_123NC_Obj.DIFFERENCE_CALC_VS_ACTUAL_CARGILL_SHARE_Val).getText();
		System.out.println(differenceNo);
		if (differenceNo.contains("(")) {
			differenceNo = differenceNo.replaceAll("[(),]", "");
			differenceNoint = Integer.valueOf(differenceNo) * -1;
		} else {
			differenceNo = differenceNo.replaceAll("[,]", "");
			differenceNoint = Integer.valueOf(differenceNo);
		}
		System.out.println(differenceNoint);
		
		if((differenceNoint > -10000 && differenceNoint<10000)||differenceNoint==10000 )
		{//make it && for actual data 
			// when the difference amount is less than 10000 or greater than -10000 then user should
			// be able to submit the schedule without entering commentary
			// field
			Logs.update("Verify DIFFERENCE CALC VS ACTUAL CARGILL SHARE",
					"Difference Calc vs Actual Cargill Share� is less than 10,000 or greater than -10,000 or equal to 10000: "+differenceNoint, Status.PASS, driver);
			// Clearing the commentary section
			Thread.sleep(5000);
			driver.findElement(Form_123NC_Obj.commentaryTextArea).clear();
			Thread.sleep(5000);
			Logs.update("Make sure that commentary section is cleared", "Commentary section is cleared as expected", Status.PASS, driver);
			driver.findElement(Form_123NC_Obj.saveCommentary_btn).click();
			Thread.sleep(5000);
			driver.close();
			driver.switchTo().window(currentHandle);
			Thread.sleep(3000);
			driver.findElement(HubContributorFormObj.btn_Submit).click();
			Thread.sleep(4000);
			String popUpMsg=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			
			if(popUpMsg.contains("Once submitted, you will be required to recall the schedule")){
			Logs.update("R1_123NC_TC_14 Verify user is able to submit when difference is less than 10000", "Able to submit the schedule when difference is less than 10000 and greater than -10000 as expected: "+popUpMsg,Status.PASS, driver);
			}else{
				Logs.update("R1_123NC_TC_14 Verify user is able to submit when difference is less than 10000", "Not Able to submit the schedule when difference is less than 10000",Status.FAIL, driver);
			}
			
			driver.findElement(HubContributorFormObj.btn_OkSuccessPopUpNew).click();
			String popUpMsg1=driver.findElement(HubContributorFormObj.messagePopUpText).getText();
			Logs.update("Verify the submit is sucessful", "Submit is successful with message: "+popUpMsg1, Status.PASS, driver);
			actions.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			//close the window after submit
			driver.close();
			//Code to recall the schedule after the submitting the schedule
			
			driver.switchTo().window(ParentcurrentHandle);
			Thread.sleep(2000);
			driver.findElement(By.name("StatusDashBoardButton")).click();

			WebElement Frame = driver.findElement(By.xpath("//iframe[@class='content-control-iframe']"));
			driver.switchTo().frame(Frame);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.edt_EntityDeatils).sendKeys(entityName);
			Thread.sleep(5000);
			driver.findElement(HubHomePageObj.selectScheduleNew).click();
			Thread.sleep(2000);
			HubHomePageObj.findScheduleName(driver, schedule).click();
			// Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.periodTextBoxNew, 10);
			driver.findElement(HubHomePageObj.periodTextBoxNew).clear();
			driver.findElement(HubHomePageObj.periodTextBoxNew).sendKeys(period);
			Thread.sleep(1000);
			Base_class.waitForElementToVisible(driver, HubHomePageObj.searchButtonDashboard, 10);
			driver.findElement(HubHomePageObj.searchButtonDashboard).click();
			Thread.sleep(5000);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			Thread.sleep(3000);
			//String StatusOfSchedule=driver.findElement(HubHomePageObj.StatusVal_Row1).getText();
			//Logs.update("Verify the status of the schedule after submit", "Status of the schedule after submit is: "+StatusOfSchedule, Status.PASS, driver);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			driver.findElement(By.name("btnRecallEdit")).click();
			Logs.update("Verify Recall is successful", "Recall is successful ", Status.PASS, driver);
			Thread.sleep(3000);
			actions.sendKeys(Keys.ENTER).build().perform();
				Thread.sleep(5000);
			driver.switchTo().defaultContent();
			currentHandle=driver.getWindowHandle();
			//Switch to the window opened after Recall  and close it 
			HubContributor.switchWindow(driver);
			driver.close();
			driver.switchTo().window(currentHandle);
			//Click on My DashBoard
			driver.findElement(By.name("MyDashBoardButton")).click();

			actions = new Actions(driver);
			HubContributorFormPage.openScheduleWithDataFromDB(driver, entityName, period, schedule, Logs);
			entityXpath = HubHomePageObj.findEntityCode(driver, entityName);
			actions.moveToElement(entityXpath).doubleClick().build().perform();
			Thread.sleep(4000);
			ParentcurrentHandle=driver.getWindowHandle();
			driver.findElement(HubHomePageObj.Btn_Open).click();
			Thread.sleep(3000);
			HubContributor.switchWindow(driver);
			Thread.sleep(3000);
			

			}
		} // end of for
driver.quit();
	}
}
	
	
	

		
		

			
				

			

