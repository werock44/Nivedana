/**
 * 
 */
package pages;

/**
 * @author n098178
 *
 */
public class ApplicationSearchPage {

}
