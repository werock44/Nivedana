package objectRepository;

import org.openqa.selenium.By;

public class Form_123NC_Obj {
	
	//Assets Tab
	public static final By expandCollapseIcon = By.xpath("//span[contains(text(),'ASSETS')]//parent::div//following-sibling::div/a");
	public static final By companyName = By.xpath("//span[@name='dlCompany Name']");
	
	public static final By cashLbl=By.xpath("//span[@name='lblAccount010']");
	public static final By cashField=By.xpath("//input[@name='tbAccount010 ']");
	
	public static final By certOfLbl=By.xpath("//span[@name='lblAccount030']");
	public static final By certOfField=By.xpath("//input[@name='tbAccount030 ']");
	
	public static final By documentIsInProc_Lbl=By.xpath("//span[@name='lblAccount040 ']");
	public static final By documentIsInProc_Field=By.xpath("//input[@name='tbAccount040 ']");
	
	public static final By totalCash_Lbl=By.xpath("//span[@name='lblAccount045 ']");
	public static final By totalCash_Field=By.xpath("//input[@name='tbAccount045 ']");
	
	public static final By shortTermInvestment_Lbl=By.xpath("//span[@name='lblAccount047 ']");
	public static final By shortTermInvestment_Field=By.xpath("//input[@name='tbAccount047 ']");
	
	public static final By finalcialInstruments_Lbl=By.xpath("//span[@name='lblAccount050 ']");
	public static final By finalcialInstruments_Field=By.xpath("//input[@name='tbAccount050 ']");
	
	public static final By tradingSecurities_Lbl=By.xpath("//span[@name='lblAccount055 ']");
	public static final By tradingSecurities_Field=By.xpath("//input[@name='tbAccount055 ']");
	
	public static final By accountsReceivable_Trade_Lbl=By.xpath("//span[@name='lblAccount060 ']");
	public static final By accountsReceivable_Trade_Field=By.xpath("//input[@name='tbAccount060 ']");
	
	public static final By accountsReceivable_Others_Lbl=By.xpath("//span[@name='lblAccount070 ']");
	public static final By accountsReceivable_Others_Field=By.xpath("//input[@name='tbAccount070 ']");
	
	public static final By accuredIncome_Lbl=By.xpath("//span[@name='lblAccount080 ']");
	public static final By accuredIncome_Field=By.xpath("//input[@name='tbAccount080']");
	
	public static final By allowanceForDoubtful_Lbl=By.xpath("//span[@name='lblAccount090']");
	public static final By allowanceForDoubtful_Field=By.xpath("//input[@name='tbAccount090 ']");
	
	public static final By accountsOrNotesRec_Lbl=By.xpath("//span[@name='lblAccount100 ']");
	public static final By accountsOrNotesRec_field=By.xpath("//input[@name='tbAccount100 ']");
	
	public static final By marginDeposited_Lbl=By.xpath("//span[@name='lblAccount110']");
	public static final By marginDeposited_field=By.xpath("//input[@name='tbAccount110 ']");
	
	public static final By inventories_Lbl=By.xpath("//span[@name='lblAccount130 Label']");
	public static final By inventories_field=By.xpath("//input[@name='tbAccount130 ']");
	
	public static final By prepaidExpenses_Lbl=By.xpath("//span[@name='lblAccount200']");
	public static final By prepaidExpenses_field=By.xpath("//input[@name='tbAccount200 ']");
	
	public static final By ARCashManagement_Lbl=By.xpath("//span[@name='lblAccount225 ']");
	public static final By ARCashManagement_field=By.xpath("//input[@name='tbAccount225 ']");

	public static final By ARInterestBearing_Console_Lbl=By.xpath("//span[@name='lblAccount230 ']");
	public static final By ARInterestBearing_consol_field=By.xpath("//input[@name='tbAccount230 ']");
	
	public static final By ARNonInterestBearing_console_Lbl=By.xpath("//span[@name='lblAccount235']");
	public static final By ARNonInterestBearing_console_field=By.xpath("//input[@name='tbAccount235 ']");
	
	public static final By ARInterestBearing_NonConsole_Lbl=By.xpath("//span[@name='lblAccount240']");
	public static final By ARInterestBearing_Nonconsol_field=By.xpath("//input[@name='tbAccount240 ']");
	
	public static final By ARNonInterestBearing_Nonconsole_Lbl=By.xpath("//span[@name='lblAccount245 ']");
	public static final By ARNonInterestBearing_Nonconsole_field=By.xpath("//input[@name='tbAccount245']");

	public static final By OtherCurrentAssets_Lbl=By.xpath("//span[@name='lblAccount247 ']");
	public static final By OtherCurrentAssets_field=By.xpath("//input[@name='tbAccount247 ']");
	
	public static final By TotalCurrentAssets_Lbl=By.xpath("//span[@name='lblAccount250']");
	public static final By TotalCurrentAssets_field=By.xpath("//input[@name='tbAccount250 ']");
	
	public static final By LoansReceivable_Lbl=By.xpath("//span[@name='lblLoans Receivable']");
	public static final By LoansReceivable_field=By.xpath("//input[@name='tbLoansReceivable ']");
	
	public static final By RealEstate_Lbl=By.xpath("//span[@name='lblReal Estate ']");
	public static final By RealEstate_field=By.xpath("//input[@name='tbRealEstate ']");
	
	public static final By Notes_Accts_Lbl=By.xpath("//span[@name='lblAccount260 ']");
	public static final By Notes_Accts_field=By.xpath("//input[@name='tbAccount260 ']");
	
	public static final By InvestmentInLoan_Lbl=By.xpath("//span[@name='lblAccount262 ']");
	public static final By InvestmentInLoan_field=By.xpath("//input[@name='tbAccount262 ']");
	
	public static final By LTNotes_Lbl=By.xpath("//span[@name='lblAccount270 ']");
	public static final By LTNotes_field=By.xpath("//input[@name='tbAccount270']");
	
	public static final By CashValueOfLife_Lbl=By.xpath("//span[@name='lblAccount280 ']");
	public static final By CashValueOfLife_field=By.xpath("//input[@name='tbAccount280 ']");
	
	public static final By DefferedCharges_Lbl=By.xpath("//span[@name='lblAccount290 ']");
	public static final By DefferedCharges_field=By.xpath("//input[@name='tbAccount290']");
	
	public static final By DefferedCharges_NonCurr_Lbl=By.xpath("//span[@name='lblAccount293 ']");
	public static final By DefferedCharges_NonCurr_field=By.xpath("//input[@name='tbAccount293']");
	
	public static final By GoodWill_Lbl=By.xpath("//span[@name='lblAccount295 ']");
	public static final By GoodWill_field=By.xpath("//input[@name='tbAccount295 ']");
	
	public static final By IntangibleAssets_Lbl=By.xpath("//span[@name='lblAccount297 ']");
	public static final By IntangibleAssets_field=By.xpath("//input[@name='tbAccount297 ']");
	
	public static final By MiscellaneousInvestments_Lbl=By.xpath("//span[@name='lblAccount300']");
	public static final By MiscellaneousInvestments_field=By.xpath("//input[@name='tbAccount300 ']");
	
	public static final By InvestmentsInConsolidatedCompanies_Lbl=By.xpath("//span[@name='lblAccount320 ']");
	public static final By InvestmentsInConsolidatedCompanies_field=By.xpath("//input[@name='tbAccount320']");
	
	public static final By InvestmentInNonconsol_Equity_Lbl=By.xpath("//span[@name='lblAccount330 ']");
	public static final By InvestmentInNonconsol_Equity_field=By.xpath("//input[@name='tbAccount330 ']");
	
	public static final By InvestmentInNonconsol_Cost_Lbl=By.xpath("//span[@name='lblAccount340']");
	public static final By InvestmentInNonconsol_Cost_field=By.xpath("//input[@name='tbAccount340 ']");
	
	public static final By InvestInAffiliatedPrivate_Lbl=By.xpath("//span[@name='lblAccount345 ']");
	public static final By InvestInAffiliatedPrivate_field=By.xpath("//input[@name='tbAccount345 ']");
	
	public static final By LTNotesOrAcctsRec_Consol_Lbl=By.xpath("//span[@name='lblAccount350 ']");
	public static final By LTNotesOrAcctsRec_Consol_field=By.xpath("//input[@name='tbAccount350 ']");
	
	public static final By LTNotesOrAcctsRec_NonConsol_Lbl=By.xpath("//span[@name='lblAccount360 ']");
	public static final By LTNotesOrAcctsRec_NonConsol_field=By.xpath("//input[@name='tbAccount360']");
	
	public static final By OtherNonCurrentAssets_Lbl=By.xpath("//span[@name='lblAccount362 ']");
	public static final By OtherNonCurrentAssets_field=By.xpath("//input[@name='tbAccount362']");
	
	public static final By TotalOtherAssets_Lbl=By.xpath("//span[@name='lblAccount365 ']");
	public static final By TotalOtherAssets_field=By.xpath("//input[@name='tbAccount365']");
	
	public static final By OwnedProperty_Lbl=By.xpath("//span[@name='lblAccount370 ']");
	public static final By OwnedProperty_field=By.xpath("//input[@name='tbAccount370 ']");
	
	public static final By PropertyUnderCapitalLease_Lbl=By.xpath("//span[@name='lblAccount375 ']");
	public static final By PropertyUnderCapitalLease_field=By.xpath("//input[@name='tbAccount375 ']");
	
	public static final By ConstructionsIsInProgress_Lbl=By.xpath("//span[@name='lblAccount380 ']");
	public static final By ConstructionsIsInProgress_field=By.xpath("//input[@name='tbAccount380 ']");
	
	public static final By TotalGrossProperty_Lbl=By.xpath("//span[@name='lblAccount385']");
	public static final By TotalGrossProperty_field=By.xpath("//input[@name='tbAccount385']");
	
	public static final By AccumulatedDepreciation_Lbl=By.xpath("//span[@name='lblAccount390']");
	public static final By AccumulatedDepreciation_field=By.xpath("//input[@name='tbAccount390 ']");
	
	public static final By NetProperty_Lbl=By.xpath("//span[@name='lblAccount400 ']");
	public static final By NetProperty_field=By.xpath("//input[@name='tbAccount400 ']");
	
	public static final By TotalAssets_Lbl=By.xpath("//span[@name='lblAccount500 ']");
	public static final By TotalAssets_field=By.xpath("//input[@name='tbAccount500 ']");
	
	public static final By CurrentAssets_Lbl=By.xpath("//span[@name='Label49']");
	public static final By AccountsAndNotesReceivable_Lbl=By.xpath("//span[@name='Label48']");
	public static final By InterCompanyReceivables_Lbl=By.xpath("//span[@name='Label50']");
	public static final By OtherAssets_Lbl=By.xpath("//span[@name='Label51']");
	public static final By Property_Lbl=By.xpath("//span[@name='Label52']");
	public static final By AssetSave_btn=By.xpath("//a[@id='586f6d52-967e-8d98-6721-16bf9d13c14f_059988d2-4616-757b-75f9-85e48e73dd70_ToolbarButton']/span[2]/span[2]");
	public static final By LiabilitiesSave_btn=By.xpath("//*[@id='19356508-8a7b-5df6-5f1f-65fc3c5ea38a_bf178fcd-58de-362e-4050-b9d72e3568d1_ToolbarButton']/span[2]/span[2]");
	
	//Income statement
	public static final By expandCollapseIcon_incomeStatement = By.xpath("//span[contains(text(),'INCOME')]//parent::div//following-sibling::div/a");
	
	public static final By GrossSales_Header_Lbl=By.xpath("//span[@name='Label29']");
	public static final By GrossSales_Outside_Lbl=By.xpath("//span[@name='lblAccount803']");
	public static final By GrossSales_Outside_field=By.xpath("//input[@name='tbAccount803 ']");
	
	public static final By GrossSales_ConsolCos_Lbl=By.xpath("//span[@name='lblAccount809 ']");
	public static final By GrossSales_ConsolCos_field=By.xpath("//input[@name='tbAccount809 ']");
	
	public static final By GrossSales_NonConsolCos_Lbl=By.xpath("//span[@name='lblAccount812 ']");
	public static final By GrossSales_NonConsolCos_field=By.xpath("//input[@name='tbAccount812 ']");
	
	public static final By GrossSales_Lbl=By.xpath("//span[@name='lblAccount815 ']");
	public static final By GrossSales_field=By.xpath("//input[@name='tbAccount815 ']");
	
	public static final By OtherOperatingIncome_Header_Lbl=By.xpath("//span[@name='Label30']");
	public static final By OtherOperatingIncome_Outside_Lbl=By.xpath("//span[@name='lblAccount821']");
	public static final By OtherOperatingIncome_Outside_field=By.xpath("//input[@name='tbAccount821 ']");
	
	public static final By OtherOperatingIncome_ConsolCos_Lbl=By.xpath("//span[@name='lblAccount827 ']");
	public static final By OtherOperatingIncome_ConsolCos_field=By.xpath("//input[@name='tbAccount827']");
	
	public static final By OtherOperatingIncome_NonConsolCos_Lbl=By.xpath("//span[@name='lblAccount830 ']");
	public static final By OtherOperatingIncome_NonConsolCos_field=By.xpath("//input[@name='tbAccount830']");
	
	public static final By OtherOperatingIncome_Lbl=By.xpath("//span[@name='lblAccount833 ']");
	public static final By OtherOperatingIncome_field=By.xpath("//input[@name='tbAccount833 ']");
	
	public static final By SalesAndOtherIncomeAdjustments_Lbl=By.xpath("//span[@name='lblAccount836']");
	public static final By SalesAndOtherIncomeAdjustments_field=By.xpath("//input[@name='tbAccount836 ']");
	
	public static final By TotalNetSalesAndOtherIncome_Lbl=By.xpath("//span[@name='lblAccount839 ']");
	public static final By TotalNetSalesAndOtherIncome_field=By.xpath("//input[@name='tbAccount839 ']");
	
	public static final By CostOfGoodSold_Lbl=By.xpath("//span[@name='lblAccount845 ']");
	public static final By CostOfGoodSold_field=By.xpath("//input[@name='tbAccount845 ']");
	
	public static final By GrossProfit_Lbl=By.xpath("//span[@name='lblAccount855']");
	public static final By GrossProfit_field=By.xpath("//input[@name='tbAccount855 ']");
	
	public static final By Expenses_Header=By.xpath("//span[@name='lblExpenses']");
	public static final By SellingOrTrading_Lbl=By.xpath("//span[@name='lblAccount860']");
	public static final By SellingOrTrading_field=By.xpath("//input[@name='tbAccount860 ']");
	
	public static final By GeneralOrAdministrative_Lbl=By.xpath("//span[@name='lblAccount861']");
	public static final By GeneralOrAdministrative_field=By.xpath("//input[@name='tbAccount861 ']");
	
	public static final By InterestOnLongTermDebt_Lbl=By.xpath("//span[@name='lblAccount864 ']");
	public static final By InterestOnLongTermDebt_field=By.xpath("//input[@name='tbAccount864 ']");
	
	public static final By InterestOnShortTermDebt_Lbl=By.xpath("//span[@name='lblAccount865']");
	public static final By InterestOnShortTermDebt_field=By.xpath("//input[@name='tbAccount865 ']");
	
	public static final By Depreciation_Lbl=By.xpath("//span[@name='lblAccount867 ']");
	public static final By Depreciation_field=By.xpath("//input[@name='tbAccount867']");
	
	public static final By IntangibleAssetAmortization_Lbl=By.xpath("//span[@name='lblAccount870 ']");
	public static final By IntangibleAssetAmortization_field=By.xpath("//input[@name='tbAccount870 ']");
	
	public static final By OtherIncomeOrExpense_Lbl=By.xpath("//span[@name='lblAccount875 ']");
	public static final By OtherIncomeOrExpense_field=By.xpath("//input[@name='tbAccount875']");
	
	public static final By TotalExpenses_Lbl=By.xpath("//span[@name='lblAccount876 ']");
	public static final By TotalExpenses_field=By.xpath("//input[@name='tbAccount876 ']");
	
	public static final By EarningsBeforeTax_Lbl=By.xpath("//span[@name='lblAccount880 ']");
	public static final By EarningsBeforeTax_field=By.xpath("//input[@name='tbAccount880 ']");
	
	public static final By IncomeTaxExpenseOrCredit_Lbl=By.xpath("//span[@name='lblAccount883 ']");
	public static final By IncomeTaxExpenseOrCredit_field=By.xpath("//input[@name='tbAccount883 ']");
	
	public static final By EarningsAfterTax_Lbl=By.xpath("//span[@name='lblAccount885']");
	public static final By EarningsAfterTax_field=By.xpath("//input[@name='tbAccount885 ']");
	
	public static final By EquityInNetEarningsOfConsolCos_Lbl=By.xpath("//span[@name='lblAccount890']");
	public static final By EquityInNetEarningsOfConsolCos_field=By.xpath("//input[@name='tbAccount890']");
	
	public static final By EquityInNetEarningsOfNonconsolCos_Lbl=By.xpath("//span[@name='lblAccount891']");
	public static final By EquityInNetEarningsOfNonconsolCos_field=By.xpath("//input[@name='tbAccount891']");
	
	public static final By NetEarnings_IncomeStmt_Lbl=By.xpath("//span[@name='lblAccount895']");
	public static final By NetEarnings_IncomeStmt_field=By.xpath("//input[@name='tbAccount895 ']");
	
	public static final By EarningsOrLossesOfNoncontrollingInt_Lbl=By.xpath("//span[@name='lblAccount896 ']");
	public static final By EarningsOrLossesOfNoncontrollingInt_field=By.xpath("//input[@name='tbAccount896']");
	
	public static final By NETEARNINGSATTRIBUTABLETOCARGILL_Lbl=By.xpath("//span[@name='lblAccount899 ']");
	public static final By NETEARNINGSATTRIBUTABLETOCARGILL_field=By.xpath("//input[@name='tbAccount899 ']");
	
	public static final By IncomeStatementSave_btn=By.xpath("//a[@id='5188399d-cf6a-cc79-0427-24ed503cf1d2_92c29e62-909c-77c3-5cef-6a0edaf250b1_ToolbarButton']/span[2]/span[2]");
	
	
	
	//Liabilities tab
			public static final By expandCollapseIconLiabilities = By.xpath("//span[contains(text(),'LIABILITIES')]//parent::div//following-sibling::div/a");
			
			public static final By shortTerm_Lbl=By.xpath("//span[@name='lblAccount520']");
			public static final By shortTermDebt=By.xpath("//input[@name='tbAccount520 ']");
			
			public static final By sTDebtNonRecourse_Lbl=By.xpath("//span[@name='lblAccount525 ']");
			public static final By sTDebtNonRecourse=By.xpath("//input[@name='tbAccount525 ']");
			
			public static final By financialInstruments_Lbl=By.xpath("//span[@name='lblAccount535']");
			public static final By financialInstruments=By.xpath("//input[@name='tbAccount535 ']");		
			
			public static final By LtDebtCurrentRecourse_Lbl=By.xpath("//span[@name='lblAccount542']");
			public static final By LtDebtCurrentRecourse=By.xpath("//input[@name='tbAccount540 ']");		

			
			public static final By LtDebtCurrentNonRecourse_Lbl=By.xpath("//span[@name='lblAccount545 ']");
			public static final By LtDebtCurrentNonRecourse=By.xpath("//input[@name='tbAccount542 ']");		

			public static final By currentObligUnderCapitalLeasesRcs_Lbl=By.xpath("//span[@name='lblAccount546 ']");
			public static final By currentObligUnderCapitalLeasesRcs=By.xpath("//input[@name='tbAccount545 ']");
			
			public static final By currentObligUnderCapitalLeasesNRcs_Lbl=By.xpath("//span[@name='lblAccount547 ']");
			public static final By currentObligUnderCapitalLeasesNRcs=By.xpath("//input[@name='tbAccount546 ']");
			
			public static final By 	tradingSecuritiesSold_Lbl=By.xpath("//span[@name='lblAccount550 ']");
			public static final By tradingSecuritiesSold=By.xpath("//input[@name='tbAccount547 ']");

			public static final By 	accountsPayable_Lbl=By.xpath("//span[@name='lblAccount580 ']");
			public static final By accountsPayable=By.xpath("//input[@name='tbAccount550 ']");
			
			public static final By 	notesAndAccountPay_Lbl=By.xpath("//span[@name='lblAccount590']");
			public static final By notesAndAccountPay=By.xpath("//input[@name='tbAccount580 ']");
			
			public static final By 	accruedIncomeTaxes_Lbl=By.xpath("//span[@name='lblAccount600 ']");
			public static final By accruedIncomeTaxes=By.xpath("//input[@name='tbAccount590 ']");
					
			public static final By 	dividendsPayable_Lbl=By.xpath("//span[@name='lblAccount630 ']");
			public static final By dividendsPayable=By.xpath("//input[@name='tbAccount600 ']");

			public static final By 	stDebtCashManagement1_Lbl=By.xpath("//span[@name='lblAccount645 ']");
			public static final By stDebtCashManagement1=By.xpath("//input[@name='tbAccount630 ']");
			
			public static final By 	stDebtCashManagement2_Lbl=By.xpath("//span[@name='lblAccount650 ']");
			public static final By stDebtCashManagement2=By.xpath("//input[@name='tbAccount640 ']");
			
			public static final By 	apDebtnonInterestBearingConsol_Lbl=By.xpath("//span[@name='lblAccount655 ']");
			public static final By apDebtnonInterestBearingConsol=By.xpath("//input[@name='tbAccount645 ']");
			
			public static final By 	stDebtnInterestBearingNonConsol_Lbl=By.xpath("//span[@name='lbllAccount650']");
			public static final By stDebtnInterestBearingNonConsol=By.xpath("//input[@name='tbAccount650 ']");
			
			public static final By 	apNoninterestBearingNonconsol_Lbl=By.xpath("//span[@name='lbllAccount655']");
			public static final By apNoninterestBearingNonconsol=By.xpath("//input[@name='tbAccount655 ']");

			public static final By totalCurrentLiabilities=By.xpath("//input[@name='tbAccount660 ']");

			public static final By 	longTermDebt_Lbl=By.xpath("//span[@name='lblAccount665 ']");
			public static final By longTermDebt=By.xpath("//input[@name='tbAccount665 ']");

			public static final By lTDebtPortionNonRecourse_Lbl=By.xpath("//span[@name='lblAccount667']");
			public static final By lTDebtPortionNonRecourse=By.xpath("//input[@name='tbAccount667 ']");

			public static final By lTDebtCapitalLeaseObligsLessCurPortionRcs_Lbl=By.xpath("//span[@name='lblAccount670']");
			public static final By lTDebtCapitalLeaseObligsLessCurPortionRcs=By.xpath("//input[@name='tbAccount670 ']");

			public static final By lTDebtCapitalLeaseObligsLessCurPortionNRcs_Lbl=By.xpath("//span[@name='lblAccount671 ']");
			public static final By lTDebtCapitalLeaseObligsLessCurPortionNRcs=By.xpath("//input[@name='tbAccount671 ']");

			public static final By 	LTDebtGuaranteeofESOPDebt_Lbl=By.xpath("//span[@name='lblAccount673']");
			public static final By LTDebtGuaranteeofESOPDebt=By.xpath("//input[@name='tbAccount673 ']");
			
			public static final By 	LTDebtConsolCosLTPortio_Lbl=By.xpath("//span[@name='lblAccount675']");
			public static final By LTDebtConsolCosLTPortio=By.xpath("//input[@name='tbAccount675 ']");


			public static final By 	LTDebtLtPortionNonRecourse_Lbl=By.xpath("//span[@name='lblAccount667']");
			public static final By LTDebtLtPortionNonRecourse=By.xpath("//input[@name='tbAccount667 ']");
			
			public static final By 	LTDebtCapitalLeaseObligsLessCurPortionRcs_Lbl=By.xpath("//span[@name='lblAccount670']");
			public static final By LTDebtCapitalLeaseObligsLessCurPortionRcs=By.xpath("//input[@name='tbAccount670 ']");

			public static final By 	LTDebtCapitalLeaseObligsLessCurPortionNRcs_Lbl=By.xpath("//span[@name='lblAccount671 ']");
			public static final By LTDebtCapitalLeaseObligsLessCurPortionNRcs=By.xpath("//input[@name='tbAccount671 ']");

			public static final By 	LTDebtGuaranteeESOPDebt_Lbl=By.xpath("//span[@name='lblAccount673']");
			public static final By LTDebtGuaranteeESOPDebt=By.xpath("//input[@name='tbAccount673 ']");
			
			public static final By LTDebtConsolCosLTPortio1_Lbl=By.xpath("//span[@name='lblAccount675']");
			public static final By LTDebtConsolCosLTPortio1=By.xpath("//input[@name='tbAccount675 ']");
			
			public static final By LTDebtNonconsolCosexclPermOther_Lbl=By.xpath("//span[@name='lblAccount680 ']");
			public static final By LTDebtNonconsolCosexclPermOther=By.xpath("//input[@name='tbAccount680 ']");
			
			public static final By 	NonCurrentDeferredIncomeTaxes_Lbl=By.xpath("//span[@name='lblAccount685 ']");
			public static final By NonCurrentDeferredIncomeTaxes=By.xpath("//input[@name='tbAccount685']");
			
			public static final By 	totalLiabilities_Lbl=By.xpath("//span[@name='lblAccount695 ']");
			public static final By totalLiabilities=By.xpath("//input[@name='tbAccount695 ']");
			
			public static final By 	preferredStock_Lbl=By.xpath("//span[@name='lblAccount715']");
			public static final By preferredStock=By.xpath("//input[@name='tbAccount715 ']");
			
			public static final By 	specialPreferredStock_Lbl=By.xpath("//span[@name='lblAccount720']");
			public static final By specialPreferredStock=By.xpath("//input[@name='tbAccount720 ']");
			
			public static final By 	commonStock_Lbl=By.xpath("//span[@name='lblAccount725 ']");
			public static final By commonStock=By.xpath("//input[@name='tbAccount725 ']");
			
			public static final By 	esopCommonStock_Lbl=By.xpath("//span[@name='lblAccount727 ']");
			public static final By esopCommonStock=By.xpath("//input[@name='tbAccount727 ']");
			
			public static final By 	managementStock_Lbl=By.xpath("//span[@name='lblAccount730 ']");
			public static final By managementStock=By.xpath("//input[@name='tbAccount730 ']");
			
			
			public static final By 	retireeStock_Lbl=By.xpath("//span[@name='lblAccount732 ']");
			public static final By retireetStock=By.xpath("//input[@name='tbAccount732 ']");

			public static final By 	specialmanagementStock_Lbl=By.xpath("//span[@name='lblAccount734 ']");
			public static final By specialmanagementStock=By.xpath("//input[@name='tbAccount734 ']");
			
			public static final By 	additionalPaidInCapital_Lbl=By.xpath("//span[@name='lblAccount740 ']");
			public static final By additionalPaidInCapital=By.xpath("//input[@name='tbAccount740 ']");
			
			public static final By 	devisionEquity_Lbl=By.xpath("//span[@name='lblAccount750 ']");
			public static final By devisionEquity=By.xpath("//input[@name='tbAccount750 ']");
		
			
			public static final By 	retainedEarnings_Lbl=By.xpath("//span[@name='lblAccount790']");
			public static final By retainedEarnings=By.xpath("//input[@name='tbAccount790 ']");
			
			public static final By 	netEarnings_Lbl=By.xpath("//span[@name='lblAccount899']");
			public static final By netEarnings=By.xpath("//input[@name='tbAccount899 ']");
			
			public static final By 	DividendsonCommonCash_Lbl=By.xpath("//span[@name='lblAccount910 ']");
			public static final By DividendsonCommonCash=By.xpath("//input[@name='tbAccount910 ']");
			
			public static final By 	DividendsonPreferredCash_Lbl=By.xpath("//span[@name='lblAccount920 ']");
			public static final By DividendsonPreferredCash=By.xpath("//input[@name='tbAccount920']");
			
			public static final By 	DividendsonCommonStock_Lbl=By.xpath("//span[@name='lblAccount924']");
			public static final By DividendsonCommonStock=By.xpath("//input[@name='tbbbAccount924 ']");
			
			public static final By 	DividendsonPreferredStock_Lbl=By.xpath("//span[@name='lblAccount927 ']");
			public static final By DividendsonPreferredStock=By.xpath("//input[@name='tbAccount927']");
			
			public static final By 	retainedEarningsOther_Lbl=By.xpath("//span[@name='lblAccount930']");
			public static final By retainedEarningsOther=By.xpath("//input[@name='tbAccount930']");
			
			public static final By 	TotalretainedEarnings_Lbl=By.xpath("//span[@name='lblAccount940']");
			public static final By TotalretainedEarnings=By.xpath("//input[@name='tbAccount940']");
			
			public static final By 	PermanentFinancingTransB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_010 ']");
			public static final By PermanentFinancingTransB4Tax=By.xpath("//input[@name='tbAccount949_010']");
			
			public static final By 	PermanentFinancingTransTax_Lbl=By.xpath("//span[@name='lblAccount949_020 ']");
			public static final By PermanentFinancingTransTax=By.xpath("//input[@name='tbAccount949_020 ']");
			
			public static final By 	NetInvestHdgsB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_030 ']");
			public static final By NetInvestHdgsB4Tax=By.xpath("//input[@name='tbAccount949_030 ']");

			public static final By 	NetInvestHdgsTax_Lbl=By.xpath("//span[@name='lblAccount949_040 ']");
			public static final By NetInvestHdgsTax=By.xpath("//input[@name='tbAccount949_040 ']");
			
			public static final By 	UnrealizedMarketSecB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_050 ']");
			public static final By UnrealizedMarketSecB4Tax=By.xpath("//input[@name='tbAccount949_050 ']");
			
			public static final By 	UnrealizedMarketSecTax_Lbl=By.xpath("//span[@name='lblAccount949_060 ']");
			public static final By UnrealizedMarketSecTax=By.xpath("//input[@name='tbAccount949_060']");
			
			public static final By 	UnrealCashFlowHedgingB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_070 ']");
			public static final By UnrealCashFlowHedgingB4Tax=By.xpath("//input[@name='tbAccount949_070']");
			
			public static final By 	UnrealCFHedgingTax_Lbl=By.xpath("//span[@name='lblAccount949_080']");
			public static final By UnrealCFHedgingTax=By.xpath("//input[@name='tbAccount949_080 ']");
			
			public static final By 	AccumulatedTranslationAdjustB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_090 ']");
			public static final By AccumulatedTranslationAdjustB4Tax=By.xpath("//input[@name='tbAccount949_090 ']");
			
			public static final By 	AccumulatedTranslationAdjustTax_Lbl=By.xpath("//span[@name='lblAccount949_100']");
			public static final By AccumulatedTranslationAdjustTax=By.xpath("//input[@name='tbAccount949_100 ']");
			
			public static final By 	UnrecogTransitionObligPensPostRetB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_130']");
			public static final By UnrecogTransitionObligPensPostRetB4Tax=By.xpath("//input[@name='tbAccount949_130']");
			
			public static final By 	UnrecogTransitionObligPensPostRetTax_Lbl=By.xpath("//span[@name='lblAccount949_140 ']");
			public static final By UnrecogTransitionObligPensPostRetTax=By.xpath("//input[@name='tbAccount949_140 ']");
			
			public static final By 	UnrecogPriorServiceCostPensPostRetB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_150 ']");
			public static final By UnrecogPriorServiceCostPensPostRetB4Tax=By.xpath("//input[@name='tbAccount949_150 ']");
		
			public static final By 	UnrecogPriorServiceCostPensPostRetTax_Lbl=By.xpath("//span[@name='lblAccount949_160 ']");
			public static final By UnrecogPriorServiceCostPensPostRetTax=By.xpath("//input[@name='tbAccount949_160 ']");
			
			public static final By 	UnrecogActuarialPensPostRetB4Tax_Lbl=By.xpath("//span[@name='lblAccount949_170 ']");
			public static final By UnrecogActuarialPensPostRetB4Tax=By.xpath("//input[@name='tbAccount949_170 ']");
			
			public static final By 	UnrecogActuarialPensPostRetTax_Lbl=By.xpath("//span[@name='lblAccount949_180 ']");
			public static final By UnrecogActuarialPensPostRetTax=By.xpath("//input[@name='tbAccount949_180 ']");

			
			public static final By 	TotalOtherComprehensiveIncome_Lbl=By.xpath("//span[@name='lblAccount949 ']");
			public static final By TotalOtherComprehensiveIncome=By.xpath("//input[@name='tbAccount949 ']");

			public static final By TotalCargillStockholdersEquity_Lbl=By.xpath("//span[@name='lblAccount950 ']");
			public static final By TotalCargillStockholdersEquity=By.xpath("//input[@name='tbAccount950 ']");

			
			public static final By NonControllingInterests_Lbl=By.xpath("//span[@name='lblAccount953 ']");
			public static final By NonControllingInterests=By.xpath("//input[@name='tbAccount953 ']");
			
			public static final By 	TotalStockholdersEquity_Lbl=By.xpath("//span[@name='lblAccount955 ']");
			public static final By TotalStockholdersEquity=By.xpath("//input[@name='tbAccount955 ']");

			
			public static final By 	TotalLiablilitiesstkholdersequity_Lbl=By.xpath("//span[@name='lblAccount960']");
			public static final By TotalLiablilitiesstkholdersequity=By.xpath("//input[@name='tbAccount960 ']");

			public static final By 	WorkingCapital_Lbl=By.xpath("//span[@name='lblAccount990 ']");
			public static final By WorkingCapital=By.xpath("//input[@name='tbAccount990 ']");

			public static final By 	BSCheck_Lbl=By.xpath("//span[@name='lblBSCheck']");
			public static final By BSCheck=By.xpath("//input[@name='tbBlockingCheck']");

//Common elements
			public static final By ReconciliationSection_Btn=By.xpath("//a[@name='btnSummaryReport']");
			public static final By ReconciliationSection_Header=By.xpath("//div[@class='grid-header']/div/div/span");
			public static final By EquityCheckVal=By.xpath("//span[@name='dlEquityCheck']");
			public static final By OCICheckVal=By.xpath("//span[@name='dlOCICheck']");
			public static final By DIFFERENCE_CALC_VS_ACTUAL_CARGILL_SHARE_Val=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[24]/td[7]/div/div/span");
			public static final By commentaryTextArea=By.xpath("//textarea[@id='69a4821c-a9d9-6819-a426-5bb2cdd91645_0473d755-640b-4b08-feb1-34138a40a3f2_TextArea']");
			public static final By saveCommentary_btn=By.xpath("//span[text()='Save Commentary ']");
				
			//TC-07
			public static final By Legal_BGCParentCompanyName=By.xpath("//*[@id='69a4821c-a9d9-6819-a426-5bb2cdd91645_5ee1d1ea-c8fa-ec9c-8d70-6db951494b35']");
			
			public static final By OwnershipPercent=By.xpath("//*[@id='69a4821c-a9d9-6819-a426-5bb2cdd91645_69d38b5a-e69d-e38c-f344-d56d4356b7b7']");
			
			public static final By stockOrAdditionalPaidInCapital=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[3]/div/div/span");
			public static final By beginniningRetainedEarnings=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[3]/div/div/span");
			public static final By currentYearEarnings=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[3]/div/div/span");
			public static final By dividendsOrDistribution=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[3]/div/div/span");
			public static final By retainedEarnings_con=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[3]/div/div/span");
			public static final By totalEquityOtherThanOCI=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[6]/td[3]/div/div/span");
			public static final By permanentfinancingTransB4Tax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[7]/td[3]/div/div/span");
			public static final By permanentfinancingTransTax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[8]/td[3]/div/div/span");
			public static final By GLNetInvestHdgsB4Tax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[9]/td[3]/div/div/span");
			public static final By GLNetInvestHdgsTax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[10]/td[3]/div/div/span");
			public static final By unrealizedMarketSecB4Tax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[11]/td[3]/div/div/span");
			public static final By unrealizedMarketSecTax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[12]/td[3]/div/div/span");
			public static final By unrealCashFlowHedgingB4Tax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[13]/td[3]/div/div/span");
			public static final By unrealCashFlowHedgingTax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[14]/td[3]/div/div/span");
			public static final By accumulatedTranslationAdjustB4Tax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[15]/td[3]/div/div/span");
			public static final By accumulatedTranslationAdjustTax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[16]/td[3]/div/div/span");
			public static final By UnrecogTransitionObligPensPostRetB4Tax_con=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[17]/td[3]/div/div/span");
			public static final By UnrecogTransition1ObligPensPostRetTax_con=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[18]/td[3]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetB4Tax_con=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[19]/td[3]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetTax_con=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[20]/td[3]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetB4Tax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[21]/td[3]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetTax=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[22]/td[3]/div/div/span");
			public static final By OtherComprehensiveIncomeORLoss=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[23]/td[3]/div/div/span");
			public static final By totalEquity=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[24]/td[3]/div/div/span");

			
			//Calculated Cargill Share
			public static final By stockOrAdditionalPaidInCapital_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[4]/div/div/span");
			public static final By beginniningRetainedEarnings_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[4]/div/div/span");
			public static final By currentYearEarnings_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[4]/div/div/span");
			public static final By dividendsOrDistribution_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[4]/div/div/span");
			public static final By retainedEarnings_con_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[4]/div/div/span");
			public static final By totalEquityOtherThanOCI_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[6]/td[4]/div/div/span");
			public static final By permanentfinancingTransB4Tax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[7]/td[4]/div/div/span");
			public static final By permanentfinancingTransTax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[8]/td[4]/div/div/span");
			public static final By GLNetInvestHdgsB4Tax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[9]/td[4]/div/div/span");
			public static final By GLNetInvestHdgsTax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[10]/td[4]/div/div/span");
			public static final By unrealizedMarketSecB4Tax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[11]/td[4]/div/div/span");
			public static final By unrealizedMarketSecTax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[12]/td[4]/div/div/span");
			
			
			public static final By unrealCashFlowHedgingB4Tax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[13]/td[4]/div/div/span");
			public static final By unrealCashFlowHedgingTax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[14]/td[4]/div/div/span");
			public static final By accumulatedTranslationAdjustB4Tax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[15]/td[4]/div/div/span");
			public static final By accumulatedTranslationAdjustTax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[16]/td[4]/div/div/span");
			public static final By UnrecogTransitionObligPensPostRetB4Tax_con_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[17]/td[4]/div/div/span");
			public static final By UnrecogTransition1ObligPensPostRetTax_con_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[18]/td[4]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetB4Tax_con_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[19]/td[4]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetTax_con_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[20]/td[4]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetB4Tax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[21]/td[4]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetTax_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[22]/td[4]/div/div/span");
			public static final By OtherComprehensiveIncomeORLoss_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[23]/td[4]/div/div/span");
			public static final By totalEquity_ccs=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[24]/td[4]/div/div/span");

			//PARENT INVESTMENT AMOUNT
			public static final By stockOrAdditionalPaidInCapital_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[6]/div/div/span");
			public static final By beginniningRetainedEarnings_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[6]/div/div/span");
			public static final By currentYearEarnings_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[6]/div/div/span");
			public static final By dividendsOrDistribution_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[6]/div/div/span");
			public static final By retainedEarnings_con_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[6]/div/div/span");
			public static final By totalEquityOtherThanOCI_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[6]/td[6]/div/div/span");
			public static final By permanentfinancingTransB4Tax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[7]/td[6]/div/div/span");
			public static final By permanentfinancingTransTax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[8]/td[6]/div/div/span");
			public static final By GLNetInvestHdgsB4Tax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[9]/td[6]/div/div/span");
			public static final By GLNetInvestHdgsTax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[10]/td[6]/div/div/span");
			public static final By unrealizedMarketSecB4Tax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[11]/td[6]/div/div/span");
			public static final By unrealizedMarketSecTax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[12]/td[6]/div/div/span");
			
			
			public static final By unrealCashFlowHedgingB4Tax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[13]/td[6]/div/div/span");
			public static final By unrealCashFlowHedgingTax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[14]/td[6]/div/div/span");
			public static final By accumulatedTranslationAdjustB4Tax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[15]/td[6]/div/div/span");
			public static final By accumulatedTranslationAdjustTax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[16]/td[6]/div/div/span");
			public static final By UnrecogTransitionObligPensPostRetB4Tax_con_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[17]/td[6]/div/div/span");
			public static final By UnrecogTransition1ObligPensPostRetTax_con_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[18]/td[6]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetB4Tax_con_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[19]/td[6]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetTax_con_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[20]/td[6]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetB4Tax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[21]/td[6]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetTax_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[22]/td[6]/div/div/span");
			public static final By OtherComprehensiveIncomeORLoss_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[23]/td[6]/div/div/span");
			public static final By totalEquity_pii=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[24]/td[6]/div/div/span");
			
			//DIFFERENCE CALC VS ACTUAL CARGILL SHARE
			public static final By stockOrAdditionalPaidInCapital_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[1]/td[7]/div/div/span");
			public static final By beginniningRetainedEarnings_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[2]/td[7]/div/div/span");
			public static final By currentYearEarnings_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[7]/div/div/span");
			public static final By dividendsOrDistribution_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[7]/div/div/span");
			public static final By retainedEarnings_con_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[5]/td[7]/div/div/span");
			public static final By totalEquityOtherThanOCI_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[6]/td[7]/div/div/span");
			public static final By permanentfinancingTransB4Tax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[7]/td[7]/div/div/span");
			public static final By permanentfinancingTransTax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[8]/td[7]/div/div/span");
			public static final By GLNetInvestHdgsB4Tax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[9]/td[7]/div/div/span");
			public static final By GLNetInvestHdgsTax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[10]/td[7]/div/div/span");
			public static final By unrealizedMarketSecB4Tax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[11]/td[7]/div/div/span");
			public static final By unrealizedMarketSecTax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[12]/td[7]/div/div/span");
			public static final By unrealCashFlowHedgingB4Tax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[13]/td[7]/div/div/span");
			public static final By unrealCashFlowHedgingTax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[14]/td[7]/div/div/span");
			public static final By accumulatedTranslationAdjustB4Tax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[15]/td[7]/div/div/span");
			public static final By accumulatedTranslationAdjustTax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[16]/td[7]/div/div/span");
			public static final By UnrecogTransitionObligPensPostRetB4Tax_con_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[17]/td[7]/div/div/span");
			public static final By UnrecogTransition1ObligPensPostRetTax_con_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[18]/td[7]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetB4Tax_con_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[19]/td[7]/div/div/span");
			public static final By UnrecogPriorServiceCost1PensPostRetTax_con_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[20]/td[7]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetB4Tax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[21]/td[7]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetTax_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[22]/td[7]/div/div/span");
			public static final By OtherComprehensiveIncomeORLoss_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[23]/td[7]/div/div/span");
			public static final By totalEquity_DCACS=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[24]/td[7]/div/div/span");
			
			// FC Investment accts from parent by share of non con
			public static final By currentYearEarnings_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[3]/td[5]/div/div/span");
			public static final By dividendsOrDistribution_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[4]/td[5]/div/div/span");
			public static final By totalEquityOtherThanOCI_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[6]/td[5]/div/div/span");
			public static final By permanentfinancingTransB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[7]/td[5]/div/div/span");
			public static final By permanentfinancingTransTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[8]/td[5]/div/div/span");
			public static final By GLNetInvestHdgsB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[9]/td[5]/div/div/span");
			public static final By GLNetInvestHdgsTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[10]/td[5]/div/div/span");
			public static final By unrealizedMarketSecB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[11]/td[5]/div/div/span");
			public static final By unrealizedMarketSecTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[12]/td[5]/div/div/span");
			public static final By unrealCashFlowHedgingB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[13]/td[5]/div/div/span");
			public static final By unrealCashFlowHedgingTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[14]/td[5]/div/div/span");
			public static final By accumulatedTranslationAdjustB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[15]/td[5]/div/div/span");
			public static final By accumulatedTranslationAdjustTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[16]/td[5]/div/div/span");
			public static final By UnrecogTransitionObligPensPostRetB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[17]/td[5]/div/div/span");
			public static final By UnrecogTransitionObligPensPostRetTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[18]/td[5]/div/div/span");
			public static final By UnrecogPriorServiceCostPensPostRetB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[19]/td[5]/div/div/span");
			public static final By UnrecogPriorServiceCostPensPostRetTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[20]/td[5]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetB4Tax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[21]/td[5]/div/div/span");
			public static final By UnrecogActuarialGLPensPostRetTax_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[22]/td[5]/div/div/span");
			public static final By totalEquity_FCInvestment=By.xpath("//*[@id='1c220552-134c-4e6f-a050-c5aea1e1edd2_82790b22-701d-1e8a-b914-3a4f0f23bebc_69a4821c-a9d9-6819-a426-5bb2cdd91645_ad28f4ff-798c-4c62-84ea-8721c5a7856f']/div[3]/div[2]/div/div/table/tbody/tr[24]/td[5]/div/div/span");
			
			

			
}


	
   

  
	

