/**
 * 
 */
package objectRepository;

import org.openqa.selenium.By;

/**
 * @author n098178
 *
 */
public class ApplicationPage {
	
	public static final By selectAssessmentStatus = By.xpath("//select[contains(@class,'form-control ng-pristine ng-valid ng-star-inserted ng-touched')]");
	public static final By selectRFactorAssessment = By.xpath("(//select[contains(@class,'form-control ng-untouched ng-pristine ng-valid ng-star-inserted')])[1]");
	
	//Main Tab
	public static final By selectOwningEnterprise = By.xpath("(//select[contains(@class,'form-control ng-pristine ng-valid ng-star-inserted ng-touched')])[3]");
	public static final By selectEnterpriseGroup = By.xpath("//input[contains(@autocomplete,'aa3d6cdc8297')]");
	public static final By selectPortfolio = By.xpath("//input[contains(@autocomplete,'a6cc6a8a7dba')]");
	public static final By selectAssignedRegion = By.xpath("//input[contains(@autocomplete,'a19e5b903cc4')]");
	public static final By clickExpandOfAttributeFromElnsight = By.xpath("//path[contains(@d,'M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z')]");
	
	//Assessment Tab
	public static final By clickAssessment = By.xpath("//a[contains(@id,'assessment')]");
	public static final By enterModernizationAssessmentReasoning = By.xpath("//textarea[contains(@placeholder,'R-Factor Reasoning')]");
	public static final By selectBubbleID = By.xpath("(//select[contains(@class,'form-control ng-untouched ng-pristine ng-valid ng-star-inserted')])[3]");
	public static final By selectSprint = By.xpath("(//select[contains(@class,'form-control ng-untouched ng-pristine ng-valid ng-star-inserted')])[2]");
	public static final By businessValueToModernizeSlider = By.xpath("(//div[@class='ng5-slider-inner-tooltip ng-star-inserted'][contains(.,'2')])[1]");
	public static final By currentApplicationComplexitySlider = By.xpath("(//div[@class='ng5-slider-inner-tooltip ng-star-inserted'][contains(.,'2')])[2]");
	public static final By complexityToModernizeSlider = By.xpath("(//div[@class='ng5-slider-inner-tooltip ng-star-inserted'][contains(.,'2')])[3]");
	
	//Contacts Tab
	public static final By clickContacts = By.xpath("//a[contains(@id,'contacts')]");
	public static final By selectApplicationBRM = By.xpath("//label[text()='Application BRM']//parent::div//parent::div/following-sibling::div/input");
	public static final By selectAssessmentSME = By.xpath("//label[text()='Assessment SME(s)']//parent::div//parent::div/following-sibling::div/input");
	public static final By selectPortfolioArchitect = By.xpath("//label[text()='Portfolio Architect(s)']//parent::div//parent::div/following-sibling::div/input");
	public static final By selectProductOwners = By.xpath("//label[text()='Product Owner(s)']//parent::div//parent::div/following-sibling::div/input");
	public static final By selectApplicationServiceDeliveryAdvisor = By.xpath("//label[text()='Application Service Delivery Advisor(s)']//parent::div//parent::div/following-sibling::div/input");
	public static final By selectTechnicalSMEArchitect = By.xpath("//label[text()='Technical SME/Architect(s)']//parent::div//parent::div/following-sibling::div/input");
	public static final By selectEnterpriseArchitect = By.xpath("//input[contains(@autocomplete,'a59fc4f4e6c3')]");
	public static final By clickSaveApplication = By.xpath("//button[contains(.,'Save Application')]");
	public static final By clickAllAttributeButton = By.xpath("//button[contains(.,'All Attributes')]");
	public static final By clickCloseAllButton = By.xpath("//button[@class='btn btn-secondary'][contains(.,'Close')]");
	
	//Technical Facts Tab
	public static final By clickTechnicalFacts = By.xpath("//a[contains(@id,'facts')]");
	public static final By selectCode = By.xpath("//input[contains(@autocomplete,'addeae9d387d')]");
	public static final By selectOperatingSystem = By.xpath("//input[contains(@autocomplete,'a58ffd94a8aa')]");
	public static final By selectDatabase = By.xpath("//input[contains(@autocomplete,'aa76c06fe22d')]");
	
	//More Section
	public static final By clickMore = By.xpath("//a[contains(@id,'more')]");
	public static final By clickFinancialLink = By.xpath("//a[contains(@id,'financial')]");
	public static final By enterSustainAMSCost = By.xpath("(//input[contains(@class,'form-control ng-untouched ng-pristine ng-valid')])[13]");
	public static final By enterSoftwareLicensing = By.xpath("(//input[contains(@class,'form-control ng-untouched ng-pristine ng-valid')])[16]");
	public static final By enterApplicationDevelopmentOrProjects = By.xpath("(//input[contains(@class,'form-control ng-untouched ng-pristine ng-valid')])[14]");
	public static final By clickSaveApplication1 = By.xpath("//button[@class='btn float-right btn-primary ng-star-inserted'][contains(.,'Save Application')]");
	
	//Notes Tab
	public static final By clickNotes = By.xpath("//a[contains(@id,'notes')]");
	public static final By clickNewNotes = By.xpath("//button[@class='btn btn-secondary btn-xs ng-star-inserted'][contains(.,'New Note')]");
	public static final By enterNoteTitle = By.xpath("//input[contains(@placeholder,'Note Title')]");
	public static final By enterNoteDescription = By.xpath("//html/body/p");
	public static final By clickSaveNote = By.xpath("//button[@class='btn btn-secondary btn-xs ng-star-inserted'][contains(.,'Save Note')]");
	public static final By clickEditNote = By.xpath("//button[@class='btn btn-secondary btn-xs ng-star-inserted'][contains(.,'Edit Note')]");
}
