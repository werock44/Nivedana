/**
 * 
 */
package objectRepository;

import org.openqa.selenium.By;

/**
 * @author n098178
 *
 */
public class ApplicationSearch {
	
	public static final By enterApplicationName = By.xpath("//input[contains(@class,'form-control ng-pristine ng-valid ng-touched')]");
			
	public static final By applicationToBeOpened = By.xpath("//a[contains(text(),'ABA Tracker')]");
	
	public static final By rFactorFilterButton = By.xpath("(//span[contains(@class,'ag-icon ag-icon-filter')])[19]");
	
	public static final By uncheckSelectAllButtonForRF = By.xpath("//label[@class='custom-control-label pt-1'][contains(.,'Select All')]");
	
	public static final By checkRTwoBox = By.xpath("//label[@class='custom-control-label pt-1'][contains(.,'R2 - Retire')]");
	
	public static final By checkRFourBox = By.xpath("//label[@class='custom-control-label pt-1'][contains(.,'R4 - Re-Platform')]");
	
	public static final By checkRSixBox = By.xpath("//label[@class='custom-control-label pt-1'][contains(.,'R6 - Re-Architect')]");
	
	public static final By okButton = By.xpath("//button[@class='btn btn-sm btn-primary'][contains(.,'OK')]");
	
	public static final By owningEnterpriseFilterButton = By.xpath("(//span[contains(@class,'ag-icon ag-icon-filter')])[25]");
	
	public static final By uncheckSelectAllButtonForOE = By.xpath("(//label[contains(@class,'custom-control-label pt-1')])[1]");
	
	public static final By checkCANForOE = By.xpath("//label[@class='custom-control-label pt-1'][contains(.,'CAN')]");
	
	public static final By checkCPSForOE = By.xpath("//label[@class='custom-control-label pt-1'][contains(.,'CPS')]");
	

}
