/**
 * 
 */
package objectRepository;

import org.openqa.selenium.By;

/**
 * @author n098178
 *
 */
public class AppModernizationHomePage {

	public static final By modernizationValueProposition = By.xpath("//div[@class='title'][contains(.,'Modernization Value Proposition')]");

	public static final By applicationSearch = By.xpath("//div[@class='title'][contains(.,'Application Search')]");

	public static final By newApplication = By.xpath("(//fa-icon[contains(@class,'ng-fa-icon')])[5]");

	public static final By applicationChangeHistory = By.xpath("//div[@class='title'][contains(.,'Application Change History')]");

	public static final By administration = By.xpath("//div[@class='title'][contains(.,'Administration')]");
	
	public static final By integrationSearch = By.xpath("//div[contains(@class,'overlay ng-tns-c2-0 ng-trigger ng-trigger-fadeIn ng-star-inserted')]");
	
}
