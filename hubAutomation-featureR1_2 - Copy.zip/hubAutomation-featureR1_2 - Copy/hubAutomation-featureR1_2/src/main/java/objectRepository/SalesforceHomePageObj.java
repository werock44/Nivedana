package objectRepository;

import org.openqa.selenium.By;




public class SalesforceHomePageObj {
	
	 /*-------------------------------------Button----------------------------------*/
	
	public static final By accountsBtn = By.xpath("//a[@href='/lightning/o/Account/home' and @title='Accounts']");
	public static final By accountsNewBtn = By.xpath("//div[@title='New']");
	public static final By nextBtn = By.xpath("//span[text()='Next']");
	public static final By accountSaveBtn = By.xpath("//button[@title='Save']");
	public static final By subtypeComboBx = By.xpath("//a[@class='select']");
	public static final By subtypeOption  = By.xpath("//a[@title='Building']");
	public static final By externalOption1  = By.xpath("//a[@title='Advertisement']");
	public static final By externalOption2  = By.xpath("//a[@title='Partner']");
	public static final By requestsBtn  = By.xpath("//a[@href='/lightning/o/Request__c/home']");
	public static final By homepageBtn  = By.xpath("//a[@href='/lightning/o/Request__c/home']");
	public static final By approveBtn  = By.xpath("//div[text()='Approve']/..");
	public static final By rejectBtn  = By.xpath("//div[@title='Reject']/..");
	public static final By gotoHomeBtn  = By.xpath("//a[text()='Go Home']");
	public static final By accountRecordTypeBtn  = By.xpath("(//span[text()='Account Record Type'])[2]");
	public static final By approveCmtBtn  = By.xpath("//span[text()='Approve']");
	public static final By rejectCmtBtn  = By.xpath("//span[text()='Reject']");
	public static final By settingBtn  = By.xpath("//a[contains(@class,'global-header__button_icon')]/div");
	public static final By cancelBtn = By.xpath("//h2[text()='New Account']/../../..//span[text()='Cancel']");
	 /*-------------------------------------TextBox----------------------------------*/
	public static final By accountNameTxtBx = By.xpath("(//span[text()='Account Name' ]/..)[1]//following::div/div/div/div/input[1]");
	
	public static final By selectRequestsLnk  = By.xpath("//a[starts-with(@title,'R-')]");
	public static final By accountnameCellValueLnk  = By.xpath("//th[@class='slds-cell-edit cellContainer']/span[1]/a");
	public static final By salesforceSearchTxtBx  = By.xpath("(//input[contains(@placeholder,'Search')])[1]");

	/*-------------------------------------Tabs----------------------------------*/
	
	public static final By requestsTab  = By.xpath("//span[contains(@title,'Requests')]");
	public static final By RelatedPageTab  = By.xpath("(//span[text()='Related'])[2]");

	/*-------------------------------------Text----------------------------------*/
	public static final By businessTxt  = By.xpath("//span[text()='Business']/../following-sibling::div/span/span");
	
	public static final By accountsStdCan  = By.xpath("//span[text()='Standard CFN Canada' and @class='slds-form-element__label']");
	public static final By accountsCompeCan  = By.xpath("//span[text()='Competitor CFN Canada'and @class='slds-form-element__label']");
	public static final By accountsThirdPartyCan  = By.xpath("//span[text()='Third Party CFN Canada' and @class='slds-form-element__label']");
	public static final By setupIcon  = By.xpath("//lightning-icon[@class='slds-button__icon slds-global-header__icon slds-icon-utility-setup slds-icon_container']");
	public static final By subSetupIcon  = By.xpath("//*[@class='slds-icon slds-icon-text-default' and @data-key='setup']");
	public static final By accountNameRequest  = By.xpath("//a[starts-with(text(),'TestAccount')]");
	/*-------------------------------------link----------------------------------*/
	public static final By developerConsoleLnk  = By.xpath("//*[contains(text(),'Developer Console')]");
	
	
	
	
	
	
	
	
	
	
	
	
	
}


	
