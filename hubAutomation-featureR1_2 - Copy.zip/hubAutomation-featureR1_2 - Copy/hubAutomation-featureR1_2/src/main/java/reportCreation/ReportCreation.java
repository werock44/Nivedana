/**
 * 
 */
package reportCreation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.FileSystem;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import reportScreenshots.CaptureScreenshots;


/**
 * @author s627207
 *
 */
public class ReportCreation {
	
	public static ArrayList<String> logsTemp = new ArrayList<String>() ;
	public static int stepCounter=0;

	public void writeFile(String TestCase_Name,String logs) {

	  try {
		String stamp = new SimpleDateFormat("-yyyy_MM_dd-HH_mm_ss").format(new Date());
		File template = new File(".\\src\\main\\java\\reporrtCreation\\Template.html");
		String html = FileUtils.readFileToString(template);
		logs="<tr><td>Canada</td><td>yes</td><td>pass</td></tr>\n";
		html = html.replace("$BodyText", logs); // update body text in template
		File fw = new File(".\\CustomeReports\\Report"+stamp+".html");
		FileUtils.writeStringToFile(fw, html); 
	  }
	 catch(Exception e) {
		 System.out.println("Error!"+e.getMessage());
	 }
	}
	
	public ArrayList<String> Accountaddinglogs(String region,String AccountType,String Flag,String Status,String outputData) throws IOException {
		File template = new File(".\\src\\main\\java\\reporrtCreation\\Template.html"); // this will load template
		String html = FileUtils.readFileToString(template);// convert template into String variable
		String stamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
		String logs="<tr><td>"+region+"</td><td>"+AccountType+"</td><td>"+Flag+"</td><td>"+Status+"</td><td>"+outputData+"</td></tr>\n";
		//<td><a href=.\\src\\reportScreenshots.Screenshots\\"+ScreenshotName+"><div>"+ScreenshotName+"</div></a></td>
		//System.out.println(logs);
		logsTemp.add(logs);
		return  logsTemp;
	}
	public void Accountaddinglogsintemplate(ArrayList<String> logs) throws IOException {
		String bodyText = "";
		String stamp = new SimpleDateFormat("-yyyy_MM_dd-HH_mm_ss").format(new Date());
		File template = new File(".\\src\\main\\java\\reporrtCreation\\Template.html");
		String html = FileUtils.readFileToString(template);
		for (String log : logs) {
			bodyText = bodyText + log;
		}
		//System.out.println("Body Text is"+bodyText);
		html = html.replace("$BodyText", bodyText); // update body text in template
		
		File fw = new File(".\\CustomeReports\\Report"+stamp+".html");
		FileUtils.writeStringToFile(fw, html);
	}
	
	public void addScreenShot(WebDriver driver,String screenShotText)
	{
		try {
			Thread.sleep(50);// delay for page load
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		stepCounter++;
		String stamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
		String div="";//CustomReport\Screenshots
		String img;
		try {
			img = CaptureScreenshots.TakeScreenshot(driver, screenShotText);
			div=stamp+"<img class=\"pic\" src=\"Img_s1.jpg\" alt=\"IMG\">\r\n" + 
					"<img class=\"big_pic\" src=\"./Screenshots/"+img+"\" alt=\"IMG1\">";
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		
		screenShotText="<tr><td>"+stepCounter+"</td><td>"+div+"</td><td>"+screenShotText+"</td></tr>\n";
		logsTemp.add(screenShotText);
	}
	
	
	/*public void addScreenShot(String screenShotText)
	{
		try {
			Thread.sleep(50);// delay for page load
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		stepCounter++;
		String stamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
		String div="";//CustomReport\Screenshots
	    String img = takeScreenshot();
				div=stamp+"<img class=\"pic\" src=\"Img_s1.jpg\" alt=\"IMG\">\r\n" + 
						"<img class=\"big_pic\" src=\"./Screenshots/"+img+"\" alt=\"IMG1\">";
		
		screenShotText="<tr><td>"+stepCounter+"</td><td>"+div+"</td><td>"+screenShotText+"</td></tr>\n";
		logsTemp.add(screenShotText);
	}*/
}


