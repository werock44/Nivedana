package Reports;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;



import io.appium.java_client.AppiumDriver;
import Reports.ReportThemeFactory.Theme;


public class DriverScript {
	private static final boolean False = false;
	private static final String True = null;
	private List<String> businessFlowData;
	private int currentIteration, currentSubIteration;
	private Date startTime, endTime;
	private String executionTime;

//	private String StartTime;
	private ReportSettings reportSettings;
	private SeleniumReport report;


	



	private Properties properties;
	private Properties mobileProperties;


	private Boolean linkScreenshotsToTestLog = true;


	private String reportPath;


	private String seeTesResultPath;

	/**
	 * DriverScript constructor
	 * 
	 * @param testParameters
	 *            A {@link SeleniumTestParameters} object
	 */
	
	public void setLinkScreenshotsToTestLog(Boolean linkScreenshotsToTestLog) {
		this.linkScreenshotsToTestLog = linkScreenshotsToTestLog;
	}

	/**
	 * Function to get the name of the test report
	 * 
	 * @return The test report name
	 */
	public String getReportName() {
		return reportSettings.getReportName();
	}

	/**
	 * Function to get the status of the test case executed
	 * 
	 * @return The test status
	 */
	public String getTestStatus() {
		return report.getTestStatus();
	}

	/**
	 * Function to get the decription of any failure that may occur during the
	 * script execution
	 * 
	 * @return The failure description (relevant only if the test fails)
	 */
	public String getFailureDescription() {
		return report.getFailureDescription();
	}

	/**
	 * Function to get the execution time for the test case
	 * 
	 * @return The test execution time
	 */
	public String getExecutionTime() {
		return executionTime;
	}

	/**
	 * Function to execute the given test case
	 */
	public void driveTestExecution() {
		
		initializeTestReport();
		wrapUp();
	}
	
	public void driveTestExecution(String ReportName) {
		
		initializeTestReport(ReportName);
		wrapUp();
	}
	

	
	public void initializeTestReport() 
	{
		initializeReportSettings();
		ReportTheme reportTheme = ReportThemeFactory.getReportsTheme(Theme
				.valueOf("CUSTOM"));

		report = new SeleniumReport(reportSettings, reportTheme);

		report.initialize();
//		report.setDriver(driver);

		report.initializeTestLog();
		createTestLogHeader();
	}
	public void initializeTestReport(String ReportName) 
	{
		initializeReportSettings(ReportName);
		ReportTheme reportTheme = ReportThemeFactory.getReportsTheme(Theme
				.valueOf("CUSTOM"));

		report = new SeleniumReport(reportSettings, reportTheme);

		report.initialize();
//		report.setDriver(driver);

		report.initializeTestLog();
		createTestLogHeader();
	}
	
	

	
	
	
	

	
	

	public void initializeReportSettings() {
		if (System.getProperty("ReportPath") != null) {
			reportPath = System.getProperty("ReportPath");
		} else {
			reportPath = TimeStamp.getInstance();
		}

		reportSettings = new ReportSettings(reportPath,
				"Test");

		reportSettings.setDateFormatString("dd-MMM-yyyy hh:mm:ss a");
		reportSettings.setLogLevel(4);
		reportSettings.setProjectName("Hub Automation");
		reportSettings.setGenerateExcelReports(false);
		reportSettings.setGenerateHtmlReports(true);
		
		reportSettings.setTakeScreenshotFailedStep(true);
		reportSettings.setTakeScreenshotPassedStep(true);
		reportSettings.setConsolidateScreenshotsInWordDoc(false);
		
		reportSettings
					.setLinkScreenshotsToTestLog(true);
		
	}
	
	public void initializeReportSettings(String ProjectName) {
		if (System.getProperty("ReportPath") != null) {
			reportPath = System.getProperty("ReportPath");
		} else {
			reportPath = TimeStamp.getInstance();
		}

		reportSettings = new ReportSettings(reportPath,
				ProjectName);

		reportSettings.setDateFormatString("dd-MMM-yyyy hh:mm:ss a");
		reportSettings.setLogLevel(4);
		reportSettings.setProjectName("Hub Automation : ");
		reportSettings.setGenerateExcelReports(false);
		reportSettings.setGenerateHtmlReports(true);
		
		reportSettings.setTakeScreenshotFailedStep(true);
		reportSettings.setTakeScreenshotPassedStep(true);
		reportSettings.setConsolidateScreenshotsInWordDoc(false);
		
		reportSettings
					.setLinkScreenshotsToTestLog(true);
		
	}
	

	
	
public void update(String testReportName, String stepDescription, Status stepStatus, WebDriver driver) {
	//report.addTestLogSubSection("CHocalte");
	//report.addTestLogSection("Cadbury");
		  report.updateTestLog(testReportName,stepDescription, stepStatus, driver);
	}
	
	
	private void createTestLogHeader() {
		report.addTestLogHeading(reportSettings.getProjectName() + " - "
				+ reportSettings.getReportName()
				+ " Automation Execution Results");
		// startTime= Util.getFormattedTime("yyyy-mm-dd hh:mm:ss");
		report.addTestLogSubHeading(
				"Date & Time",
				": "+Util.getFormattedTime("yyyy-mm-dd hh:mm:ss"),
				"Iteration Mode", ":1" );
	
		String Browser= "Local";
		switch (Browser) {
		case "Local":
			report.addTestLogSubHeading("Browser/Platform", ": "
					+ "Chrome", "Execution on",
					": " + "Local Machine");
			break;

		}

		report.addTestLogTableHeadings();
	}

	
	
	private void wrapUp() {
		endTime = Util.getCurrentTime();
		closeTestReport();
		//downloadAddtionalReport();
	}

	private void closeTestReport() {
		executionTime = Util.getTimeDifference(startTime, endTime);
	//	report.addTestLogFooter(executionTime);

		if (reportSettings.shouldConsolidateScreenshotsInWordDoc()) {
			report.consolidateScreenshotsInWordDoc();
		}

	}
	
	public void endReport( Date startTime ) {
		endTime = Util.getCurrentTime();
		executionTime = Util.getTimeDifferences(startTime, endTime);
		report.addTestLogEnd(executionTime);
		//downloadAddtionalReport();
	}
/*
	private void downloadAddtionalReport() {
		if (testParameters.getExecutionMode().equals(ExecutionMode.PERFECTO)
				&& reportSettings.shouldGeneratePerfectoReports()
				&& testParameters.getMobileToolName().equals(
						MobileToolName.DEFAULT)) {
			try {
				driver.close();
				RemoteWebDriverUtils.downloadReport(
						(RemoteWebDriver) driver.getWebDriver(), "pdf",
						reportPath + Util.getFileSeparator()
								+ "Perfecto Results" + Util.getFileSeparator()
								+ testParameters.getCurrentScenario() + "_"
								+ testParameters.getCurrentTestcase() + "_"
								+ testParameters.getCurrentTestInstance()
								+ ".pdf");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (testParameters.getExecutionMode().equals(ExecutionMode.SEETEST)
				&& reportSettings.shouldGenerateSeeTestReports()) {
			new File(reportPath + Util.getFileSeparator() + "SeeTest Results"
					+ Util.getFileSeparator()
					+ testParameters.getCurrentTestcase() + "_"
					+ testParameters.getCurrentTestInstance()).mkdir();
			File source = new File(seeTesResultPath);
			File dest = new File(reportPath + Util.getFileSeparator()
					+ "SeeTest Results" + Util.getFileSeparator()
					+ testParameters.getCurrentTestcase() + "_"
					+ testParameters.getCurrentTestInstance());

			try {
				FileUtils.copyDirectoryToDirectory(source, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	
*/
	
}