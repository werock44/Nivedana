package Reports;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
//import com.experitest.client.Client;

public class SeleniumReport extends Report {

	
//	private Client client;

	/**
	 * Constructor to initialize the Report object
	 * 
	 * @param reportSettings
	 *            The {@link ReportSettings} object
	 * @param reportTheme
	 *            The {@link ReportTheme} object
	 * @param testParameters
	 */
	public SeleniumReport(ReportSettings reportSettings,
			ReportTheme reportTheme) {
		super(reportSettings, reportTheme);
		
	}

	/**
	 * Function to set the {@link CraftDriver} object
	 * 
	 * @param driver
	 *            The {@link CraftDriver} object
	 */

	

	@Override
	protected void takeScreenshot(String screenshotPath, WebDriver driver) {
		
		File scrFile;
		scrFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		String Local="LOCAL";
		switch (Local) {
		case "LOCAL":
			break;
		}

		try {
			FileUtils.copyFile(scrFile, new File(screenshotPath), true);
		} catch (IOException e) {
			e.printStackTrace();
			
		}
		
	
	
	}}
