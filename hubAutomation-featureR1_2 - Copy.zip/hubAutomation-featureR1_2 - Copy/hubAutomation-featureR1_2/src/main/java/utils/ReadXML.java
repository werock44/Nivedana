package utils;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
public class ReadXML {
	/*author v265130
	Vivek Keshav
	*/
	static String desiredValue = null;
	public static String readData(String Scenario, String valToFind) {
		 
		
		
	      try {
	         File inputFile = new File("src/main/java/Data/Data.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
//	         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         NodeList nList = doc.getElementsByTagName(Scenario);
	         int nodesOfTC = nList.getLength();
	         if(nodesOfTC == 1){
	        	 
	          
	            	Node nNode = nList.item(0);
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               desiredValue = eElement.getElementsByTagName(valToFind).item(0).getTextContent();	  
//	               System.out.println(desiredValue);
	            }
	           
	         }
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
		return desiredValue;
	   }
}
