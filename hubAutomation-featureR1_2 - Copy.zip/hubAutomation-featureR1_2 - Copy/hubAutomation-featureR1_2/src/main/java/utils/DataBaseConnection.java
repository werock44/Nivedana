package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.WebDriver;

import Reports.DriverScript;

public class DataBaseConnection {

	private static String data1;

	/*
	 * public static String[] getData(WebDriver driver, DriverScript Logs,
	 * String TestType, String QueryTOExecute, String dbColumnName) throws
	 * Exception, SQLException, ClassNotFoundException {
	 * 
	 * String dbURL =
	 * "jdbc:sqlserver://10.12.67.5;databasename=FinanceHub2Stage;integratedSecurity=true";
	 * String username = ""; String password = ""; String dbDriver =
	 * "com.microsoft.sqlserver.jdbc.SQLServerDriver"; Class.forName(dbDriver);
	 * Connection con = DriverManager.getConnection(dbURL, username,
	 * password);// Creating connection to the data base Statement st =
	 * con.createStatement(); String selectquery =QueryTOExecute; ResultSet rs =
	 * st.executeQuery(selectquery); //Iterator it= rs.ite String[] res = null;
	 * int i=0 ; while (rs.next()) { String data= (rs.getString(dbColumnName));
	 * res[i] = data; i++; //System.out.println(""); } con.close(); return res;
	 * }
	 */

	public static String getData(WebDriver driver, DriverScript Logs, String TestType, String QueryTOExecute,
			String dbColumnName) throws Exception, SQLException, ClassNotFoundException {
		String val = null;
		String dbURL = "jdbc:sqlserver://10.12.67.5;databasename=FinanceHub2Stage;integratedSecurity=true";
		String username = "";
		String password = "";
		String dbDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		Class.forName(dbDriver);
		try (Connection con = DriverManager.getConnection(dbURL, username, password); // Creating
																						// connection
																						// to
																						// the
																						// data
																						// base
				Statement st = con.createStatement();
				// selectquery = QueryTOExecute;

				ResultSet rs = st.executeQuery(QueryTOExecute);) {
			if (rs.next()) {
				val = rs.getString(dbColumnName);
			}
		} catch (Exception e) {
			System.out.println("Database connection failed " + e);
		}
		return val;

	}

}
