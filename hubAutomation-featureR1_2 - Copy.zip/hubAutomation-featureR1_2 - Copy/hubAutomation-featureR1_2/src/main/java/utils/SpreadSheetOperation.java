package utils;



import java.io.File;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.openqa.selenium.By;


public class SpreadSheetOperation {
	
	
	private static final String datatableName="DataSheet";
	private static String dataReferenceIdentifier = "#";

	private static String currentTestcase="Accounts";
	private static int currentIteration = 1;
	private static int currentSubIteration = 1;
	private static Properties properties;
	private static String path = System.getProperty("user.dir");
	private static String doubleslashpath = path.replaceAll("\\\\", "\\\\\\\\");
	private final static String datatablePath= doubleslashpath +"\\src\\main\\java\\utils";
	/**
	 * Constructor to initialize the {@link SpreadSheetOperation} object
	 * 
	 * @param datatablePath
	 *            The path where the datatable is stored
	 * @param datatableName
	 *            The name of the datatable file
	 */

	/**
	 * Function to set the data reference identifier character
	 * 
	 * @param dataReferenceIdentifier
	 *            The data reference identifier character
	 */
	public void setDataReferenceIdentifier(String dataReferenceIdentifier) {
		if (dataReferenceIdentifier.length() != 1) {
			throw new FrameworkException(
					"The data reference identifier must be a single character!");
		}

		this.dataReferenceIdentifier = dataReferenceIdentifier;
	}

	/**
	 * Function to set the variables required to uniquely identify the exact row
	 * of data under consideration
	 * 
	 * @param currentTestcase
	 *            The ID of the current test case
	 * @param currentIteration
	 *            The Iteration being executed currently
	 * @param currentSubIteration
	 *            The Sub-Iteration being executed currently
	 */
	public void setCurrentRow(String currentTestcase, int currentIteration,
			int currentSubIteration) {
		this.currentTestcase = currentTestcase;
		this.currentIteration = currentIteration;
		this.currentSubIteration = currentSubIteration;
	}

	private static void checkPreRequisites() {
		if (currentTestcase == null) {
			throw new FrameworkException(
					"SpreadSheetOperation.currentTestCase is not set!");
		}
		if (currentIteration == 0) {
			throw new FrameworkException(
					"SpreadSheetOperation.currentIteration is not set!");
		}
		/*if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			if (currentSubIteration == 0) {
				throw new FrameworkException(
						"SpreadSheetOperation.currentSubIteration is not set!");
			}
		}*/
	}

	/**
	 * Function to return the test data value corresponding to the sheet name
	 * and field name passed
	 * 
	 * @param datasheetName
	 *            The name of the sheet in which the data is present
	 * @param fieldName
	 *            The name of the field whose value is required
	 * @return The test data present in the field name specified
	 * @throws Exception 
	 * @see #putData(String, String, String)
	 * @see #getExpectedResult(String)
	 */
	public static String getData(String currentTestcase,String datasheetName, String fieldName) throws Exception {
		//checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
//		rowNum = testDataAccess.getRowNum(Integer.toString(currentIteration),
//				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
	/*if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(
					Integer.toString(currentSubIteration), 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}
*/
		String dataValue = testDataAccess.getValue(rowNum, fieldName);

		if (dataValue.startsWith(dataReferenceIdentifier)) {
			dataValue = getCommonData(fieldName, dataValue);
		}

		return dataValue;
	}
	
	
	
	public static String getDatadynamic(String datasheetName, String currentTestcase, String FieldName, String ColoumnName) throws Exception {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException("The Country \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		
		int totalcountofTestCase = testDataAccess.getTotalRowsOfTestcase(currentTestcase,rowNum);
	
		rowNum=testDataAccess.getparticularRow(FieldName, rowNum, totalcountofTestCase) 	;
						
				
		if (rowNum == -1) {
			throw new FrameworkException("The FieldName \"" + FieldName
					+ "\"" + " for " +currentTestcase + " is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		

		String dataValue = testDataAccess.getValue(rowNum, ColoumnName);

		if (dataValue.startsWith(dataReferenceIdentifier)) {
			dataValue = getCommonData(ColoumnName, dataValue);
		}

		return dataValue;
	}
	
	
	
	public static int getTotalRowsOfTestcase(String datasheetName, String testCaseName, int rowNum) throws Exception {
		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);
		
		int s=1;															
		
		for (int m=rowNum+1;rowNum<=testDataAccess.getLastRowNumOfColumn("Dropdown");m++ )
		{
			int set = testDataAccess.getRowNum(testCaseName, 0, m);
			if(set==-1)
			{
				break;
			}
			s++;
		}
		return s;
	}
	
	

	public static String getData(String currentTestcase,String datasheetName, String fieldName, int currentIteration) throws Exception {
		//checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		
		//System.out.println(rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		rowNum = testDataAccess.getRowNum(Integer.toString(currentIteration),
				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
	/*if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(
					Integer.toString(currentSubIteration), 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}




*/
		
		String dataValue = testDataAccess.getValue(rowNum, fieldName);

		if (dataValue.startsWith(dataReferenceIdentifier)) {
			dataValue = getCommonData(fieldName, dataValue);
		}

		return dataValue;
		
	}
	
	public static short getLastCellNumofHeader(String datasheetName) throws Exception {
		//checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

	//	int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row

		
		short dataValue = testDataAccess.getHeaderLastCellNum();

		

		return dataValue;
		
		
	}
	
	
	
	private static String getCommonData(String fieldName, String dataValue) throws Exception {
		ExcelDataAccess commonDataAccess = new ExcelDataAccess(datatablePath,
				"Common Testdata");
		commonDataAccess.setDatasheetName("Common_Testdata");

		String dataReferenceId = dataValue.split(dataReferenceIdentifier)[1];

		int rowNum = commonDataAccess.getRowNum(dataReferenceId, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException(
					"The common test data row identified by \""
							+ dataReferenceId + "\""
							+ "is not found in the common test data sheet!");
		}

		return commonDataAccess.getValue(rowNum, fieldName);
	}

	/**
	 * Function to output intermediate data (output values) into the specified
	 * sheet
	 * 
	 * @param datasheetName
	 *            The name of the sheet into which the data is to be written
	 * @param fieldName
	 *            The name of the field into which the data is to be written
	 * @param dataValue
	 *            The value to be written into the field specified
	 * @see #getData(String, String)
	 */
	public static void putData(String datasheetName, String fieldName, String dataValue) {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		rowNum = testDataAccess.getRowNum(Integer.toString(currentIteration),
				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
		/*if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(
					Integer.toString(currentSubIteration), 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}*/
		
		

		synchronized (SpreadSheetOperation.class) {
			testDataAccess.setValue(rowNum, fieldName, dataValue);
		}
	}
	
	
	public static int getLastrownumber(String datasheetName) throws Exception {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);
		int i= testDataAccess.getLastrownum();
				return i;

	}
	
	public static void putData(String datasheetName, String fieldName, String dataValue,int x) {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, x); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		rowNum = testDataAccess.getRowNum(Integer.toString(x),
				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
		/*if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(
					Integer.toString(currentSubIteration), 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}*/
		
		

		synchronized (SpreadSheetOperation.class) {
			testDataAccess.setValue(rowNum, fieldName, dataValue);
		}
	}
	/**
	 * Function to get the expected result corresponding to the field name
	 * passed
	 * 
	 * @param fieldName
	 *            The name of the field which contains the expected results
	 * @return The expected result present in the field name specified
	 * @throws Exception 
	 * @see #getData(String, String)
	 */
	public String getExpectedResult(String fieldName) throws Exception {
		checkPreRequisites();

		ExcelDataAccess expectedResultsAccess = new ExcelDataAccess(
				datatablePath, datatableName);
		expectedResultsAccess.setDatasheetName("Parametrized_Checkpoints");

		int rowNum = expectedResultsAccess.getRowNum(currentTestcase, 0, 1); // Start
																				// at
																				// row
																				// 1,
																				// skipping
																				// the
																				// header
																				// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\""
					+ "is not found in the parametrized checkpoints sheet!");
		}
		rowNum = expectedResultsAccess.getRowNum(
				Integer.toString(currentIteration), 1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the parametrized checkpoints sheet!");
		}
		if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = expectedResultsAccess.getRowNum(
					Integer.toString(currentSubIteration), 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the parametrized checkpoints sheet!");
			}
		}

		return expectedResultsAccess.getValue(rowNum, fieldName);
	}

	/**
	 * Function to return the test data value corresponding to the sheet name
	 * and field name passed
	 * 
	 * @param datasheetName
	 *            The name of the sheet in which the data is present
	 * @param fieldName
	 *            The name of the field whose value is required
	 * @param subIteration
	 *            The SubIteration which is required to access the respective
	 *            data
	 * @return The test data present in the field name specified
	 * @throws Exception 
	 * @see #putData(String, String, String)
	 * @see #getExpectedResult(String)
	 */
	public String getDataWithSubIteration(String datasheetName,
			String fieldName, String subIteration) throws Exception {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		rowNum = testDataAccess.getRowNum(Integer.toString(currentIteration),
				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
		if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(subIteration, 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}

		String dataValue = testDataAccess.getValue(rowNum, fieldName);

		if (dataValue.startsWith(dataReferenceIdentifier)) {
			dataValue = getCommonData(fieldName, dataValue);
		}

		return dataValue;
	}

	/**
	 * Function to return the test data value corresponding to the sheet name
	 * and field name passed
	 * 
	 * @param datasheetName
	 *            The name of the sheet in which the data is present
	 * @param Keys
	 *            The name of the fields whose values are required
	 * @return The Map of Column Names with values
	 * @throws Exception 
	 */
	public Map<String, String> getData(String datasheetName, String[] keys) throws Exception {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(currentTestcase, 0, 1); // Start
																		// at
																		// row
																		// 1,
																		// skipping
																		// the
																		// header
																		// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		rowNum = testDataAccess.getRowNum(Integer.toString(currentIteration),
				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
		if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(
					Integer.toString(currentSubIteration), 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}

		Map<String, String> values = testDataAccess.getValuesForSpecificRow(
				keys, rowNum);

		return values;
	}

	/**
	 * Function to return the test data value corresponding to the sheet name
	 * and field name passed
	 * 
	 * @param Test
	 *            Case ID The name of Test Case ID
	 * @param datasheetName
	 *            The name of the sheet in which the data is present
	 * @param fieldName
	 *            The name of the field whose value is required
	 * @param subIteration
	 *            The SubIteration which is required to access the respective
	 *            data
	 * @return The test data present in the field name specified
	 * @throws Exception 
	 * @see #putData(String, String, String)
	 * @see #getExpectedResult(String)
	 */
	public String getDataWithSubIterationTDID(String testcase,
			String datasheetName, String fieldName, String subIteration) throws Exception {
		checkPreRequisites();

		ExcelDataAccess testDataAccess = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess.setDatasheetName(datasheetName);

		int rowNum = testDataAccess.getRowNum(testcase, 0, 1); // Start
																// at
																// row
																// 1,
																// skipping
																// the
																// header
																// row
		if (rowNum == -1) {
			throw new FrameworkException("The test case \"" + currentTestcase
					+ "\"" + "is not found in the test data sheet \""
					+ datasheetName + "\"!");
		}
		rowNum = testDataAccess.getRowNum(Integer.toString(currentIteration),
				1, rowNum);
		if (rowNum == -1) {
			throw new FrameworkException("The iteration number \""
					+ currentIteration + "\"" + "of the test case \""
					+ currentTestcase + "\""
					+ "is not found in the test data sheet \"" + datasheetName
					+ "\"!");
		}
		if (properties.getProperty("Approach")
				.equalsIgnoreCase("KeywordDriven")) {
			rowNum = testDataAccess.getRowNum(subIteration, 2, rowNum);
			if (rowNum == -1) {
				throw new FrameworkException("The sub iteration number \""
						+ currentSubIteration + "\""
						+ "under iteration number \"" + currentIteration + "\""
						+ "of the test case \"" + currentTestcase + "\""
						+ "is not found in the test data sheet \""
						+ datasheetName + "\"!");
			}
		}

		String dataValue = testDataAccess.getValue(rowNum, fieldName);

		if (dataValue.startsWith(dataReferenceIdentifier)) {
			dataValue = getCommonData(fieldName, dataValue);
		}

		return dataValue;
	}
}