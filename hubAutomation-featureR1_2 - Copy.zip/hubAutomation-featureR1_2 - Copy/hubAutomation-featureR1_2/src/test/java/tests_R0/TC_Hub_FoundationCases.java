package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pages.FoundationCasesPage;
import Reports.DriverScript;
import pages.Form814APage;
import pages.HubContributorFormPage;
import utils.Login;
import utils.Util;

public class TC_Hub_FoundationCases {
	static WebDriver driver;
	static DriverScript Logs; 
	public static String schedule;
	public static String entityName;
	public static String period;
	@BeforeClass
	public void LaunchApp() throws Exception {
		Logs =new DriverScript();
		Logs.driveTestExecution("Foundation Cases");		
	}
//	@BeforeTest
//	@Parameters({ "TestType" })
//	public static void initializeVaribales(String TestType) throws Exception{
//		schedule = Util.getAllNecessaryData(TestType, "FoundationCase", "ScheduleName");	
//		entityName = Util.getAllNecessaryData(TestType, "FoundationCase", "EntityDetail");
//		period = Util.getAllNecessaryData(TestType, "FoundationCase", "Period");
//	}
	@BeforeMethod
	@Parameters({ "TestType" })
	public static void Login(String TestType) throws Exception{
		driver  = Login.launchAppURL("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "FoundationCase", "ScheduleName");	
		entityName = Util.getAllNecessaryData(TestType, "FoundationCase", "EntityDetail");
		period = Util.getAllNecessaryData(TestType, "FoundationCase", "Period");
		
	}
	@Test(priority=0) // Passed
	@Parameters({"TestType"})
	public static void foundationCase_Admin(String TestType) throws Exception{
	FoundationCasesPage.AdminScreensFC(driver, Logs, TestType, "FoundationCase814");
	}
	
	@Test(priority=0)//Passed
	@Parameters({"TestType"})
	public static void foundationCase_AdminTC04(String TestType) throws Exception{
	FoundationCasesPage.AdminScreen_TC04(driver, Logs, TestType, "FoundationCase814");
	}
	
	
	@Test(priority=0)//Passed
	@Parameters({"TestType"})
	public static void foundationCase_Distribution_01(String TestType) throws Exception{
		FoundationCasesPage.distributionFC_01_02(driver, Logs, TestType, "FoundationCase");
		}
	
	@Test(priority=0)//passed
	@Parameters({"TestType"})
	public static void foundationCase_Distribution_03_04(String TestType) throws Exception{
		FoundationCasesPage.distributionFC_03_04(driver, Logs, TestType, "FoundationCase");
		}
	

	
	
	@Test(priority=0)//Passed
	@Parameters({"TestType"})
	public static void foundationCase_Distribution_05(String TestType) throws Exception{
		FoundationCasesPage.distributionFC_05(driver, Logs, TestType, "FoundationCase");
		}


	
	@Test(priority=0)
	@Parameters({"TestType"})
		public static void foundationCase_Dashboard(String TestType) throws Exception{

			FoundationCasesPage.dashboardFC(driver, Logs, TestType, "FoundationCase815");
	}
	
	@Test(priority=0)
	@Parameters({"TestType"})
		public static void foundationCase_AdminDashboard(String TestType) throws Exception{
			FoundationCasesPage.dashboardAdminFC(driver, Logs, TestType, "FoundationCase815");
		
}
	

	@Test(enabled=false)
	@Parameters({"TestType"})
		public static void 	domainverificaiton(String TestType) throws Exception{
			FoundationCasesPage.dashboardDomainVerificationFC(driver, Logs, TestType, "FoundationCase815");
}


	@Test(priority=0)
	@Parameters({"TestType"})
		public static void foundationCase_MYDashboardFC(String TestType) throws Exception{
			FoundationCasesPage.dashboardFC(driver, Logs, TestType, "FoundationCase815");	
	}
	
	@Test(priority=0)
	@Parameters({"TestType"})
	public static void foundationCase_MyDashboard(String TestType) throws Exception{

		//FoundationCasesPage.myDashboardFC(driver, Logs, TestType, "FoundationCase");
		FoundationCasesPage.myDashboardF_TC01(driver, Logs, TestType, "FoundationCase814");
	}

	@Test(priority=0)
	@Parameters({"TestType"})
	public static void foundationCase_MyDashboardTC02(String TestType) throws Exception{
		FoundationCasesPage.myDashboardF_TC02(driver, Logs, TestType, "FoundationCase814");

	}
	
		
	@AfterMethod
	public void QuitBrowser(){
		driver.quit();
	}


}
