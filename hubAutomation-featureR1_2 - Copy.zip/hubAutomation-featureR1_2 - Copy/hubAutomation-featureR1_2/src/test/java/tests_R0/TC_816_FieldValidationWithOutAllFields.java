package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import pages.Form816APage;
import pages.Form816APage_WithoutAllData;
import pages.HubContributorFormPage;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_816_FieldValidationWithOutAllFields {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String period;

	/*@BeforeSuite
	public void LaunchApp() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("816A Field Level Validation Without Out All Fields");
		driver = Login.LaunchHub("Setupurl", Logs);
	}*/

	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("816A Field Level Validation Without Out All Fields");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "816A", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "816A", "Period");
		//entityName = Util.getAllNecessaryData(TestType, "816A", "EntityDetail");
		String bugoID=HubContributor.getBugoID(driver, Logs, TestType, "EA8B8BA4-B64E-4023-B952-38BC3880E716", period);
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		String entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");	
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		HubContributorFormPage.openSchedule(driver, entityCode, period, schedule, Logs);

	}

	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void begBalance(String TestType) throws Exception {
		Form816APage_WithoutAllData.begBalanceDefaultVal(driver, Logs, TestType, "816A");
		
	}
	
	@Test(priority=2)
	@Parameters({ "TestType" })
	public static void returnToPLField(String TestType) throws Exception {
		Form816APage_WithoutAllData.return_to_PL_FieldDefaultVal(driver, Logs, TestType, "816A");
		
	}
	
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void useForIntendedField(String TestType) throws Exception {
		Form816APage_WithoutAllData.use_for_intended_FieldDefaultVal(driver, Logs, TestType, "816A");
	}
	
		

	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void chargeToPLField(String TestType) throws Exception {
		Form816APage_WithoutAllData.charge_to_PL_FieldDefaultVal(driver, Logs, TestType, "816A");
	}
	
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void translation(String TestType) throws Exception {
		Form816APage_WithoutAllData.translationDefaultVal(driver, Logs, TestType, "816A");
		
	}
	
	@Test(priority=6)
	@Parameters({ "TestType" })
	public static void reClassTest(String TestType) throws Exception {
		Form816APage_WithoutAllData.reClassDefaultVal(driver, Logs, TestType, "816A");
		
	}
	
	@Test(priority=7)
	@Parameters({ "TestType" })
	public static void endingBalanceTest(String TestType) throws Exception {
		Form816APage_WithoutAllData.endingBalanceDefaultVal(driver, Logs, TestType, "816A");
	}
	@Test(priority=8)
	@Parameters({ "TestType" })
	public static void explanationOfReclassifications_Default(String TestType) throws Exception{
		Form816APage_WithoutAllData.explanationOfReclassifications_Default(driver, Logs, TestType, "816A");
	}
	
	@AfterClass
	public void QuitBrowser(){
		driver.quit();
	}

	
}
