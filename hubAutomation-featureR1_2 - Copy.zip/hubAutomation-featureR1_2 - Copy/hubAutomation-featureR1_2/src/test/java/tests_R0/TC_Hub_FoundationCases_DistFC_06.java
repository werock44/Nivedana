package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pages.FoundationCasesPage;
import pages.FoundationCasesPage_DistFC_TC06;
import Reports.DriverScript;
import pages.Form814APage;
import pages.HubContributorFormPage;
import utils.DataBaseConnection;
import utils.Login;
import utils.Util;

public class TC_Hub_FoundationCases_DistFC_06 {
	static WebDriver driver;
	static DriverScript Logs; 
	public static String schedule;
	public static String entityName;
	public static String period;
	@BeforeSuite
	public void LaunchApp() throws Exception {
		Logs =new DriverScript();
		Logs.driveTestExecution("Foundation Cases");		
	}
//	@BeforeTest
//	@Parameters({ "TestType" })
//	public static void initializeVaribales(String TestType) throws Exception{
//		schedule = Util.getAllNecessaryData(TestType, "FoundationCase", "ScheduleName");	
//		entityName = Util.getAllNecessaryData(TestType, "FoundationCase", "EntityDetail");
//		period = Util.getAllNecessaryData(TestType, "FoundationCase", "Period");
//	}
	@BeforeMethod
	@Parameters({ "TestType" })
	public static void Login(String TestType) throws Exception{
		driver  = Login.LaunchHub("Setupurl", Logs);
		//schedule = Util.getAllNecessaryData(TestType, "FoundationCase", "ScheduleName");	
		//entityName = Util.getAllNecessaryData(TestType, "FoundationCase", "EntityDetail");
		/*String query="select  top 1 entityCode from masterdata.entity where "
				+ "bustructure=(Select distinct top 1 BUStructure from masterdata.entity"
				+ " where EntityType='R' and EntityStatus='A' and entityID not IN (select entityId "
				+ "from scheduleinstance where scheduleID='EA8B8BA4-B64E-4023-B952-38BC3880E716' "
				+ "and periodid='2019.12')) and entitystatus='A' and EntityType='R'";*/
		//String enityCode=DataBaseConnection.getData(driver, Logs, TestType, query,"entityCode");
		//period = Util.getAllNecessaryData(TestType, "FoundationCase", "Period");
		
	}
	
	@Test(priority=0)
	@Parameters({"TestType"})
	public static void foundationCase_DistFC06(String TestType) throws Exception{
	FoundationCasesPage_DistFC_TC06.distributionFC_06(driver, Logs, TestType, "FoundationCase");
	}
	
	
		
	@AfterMethod
	public static void LogOff(){
		//driver.quit();
	}


}
