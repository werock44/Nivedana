package tests_R0;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Reports.DriverScript;
import objectRepository.HubContributorFormObj;
import objectRepository.HubHomePageObj;
import pages.Form814APage;
import pages.Form815APage;
import pages.Form815ARollForwardDBPage;
import pages.Form816ARollForwardDBPage;
import pages.FoundationCasesPage;
import pages.HubContributorFormPage;
import utils.HubContributor;
import utils.Login;
import utils.Util;

//Author - Prasannajit(p674532)

public class TC_815_RollForwardDB {
	static WebDriver driver;
	static DriverScript Logs; 
	public static String schedule;
	public static String entityName;
	public static String period;
	static HubContributorFormObj hubContributorFormObj = new HubContributorFormObj();
	@BeforeClass
	public void LaunchApp() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("815A RollForward DB Validation");
		//driver = Login.LaunchHub("Setupurl", Logs);
	}
	
	@BeforeMethod
		public static void Login() throws Exception{
		driver = Login.LaunchHub("Setupurl", Logs);
	}
		
		@Test(priority=0)//Passed
		@Parameters({ "TestType" })
		public static void begBalanceRollFw815(String TestType) throws Exception {
			Form815ARollForwardDBPage.begBalEndBalRollFwPrevYr(driver, Logs, TestType, "815ADB");
			
		}
		@Test(priority=0)//passed
		@Parameters({ "TestType" })
		public static void rollFWofFieldsForSameFY(String TestType) throws Exception {
			Form815ARollForwardDBPage.rollFWofFieldsForSameFY(driver, Logs, TestType, "815ADB");		
		}
/*
		@Test(priority=0)
	@Parameters({ "TestType" })
	public static void endingBalRollFWCurrYr_Zero(String TestType) throws Exception {
		Form815ARollForwardDBPage.endingBalRollFWCurrFY_Zero(driver, Logs, TestType, "815ADB");	
	}*/

@AfterMethod
public void QuitBrowser(){
	driver.quit();
}

}

