package tests_R1;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import Reports.DriverScript;
import Reports.Status;
import objectRepository.HubHomePageObj;
import pages.Form1798DPage;
import pages.Form2001BG;
import pages.HubContributorFormPage;
import pages.HubHomePage;
import utils.HubContributor;
import utils.Login;
import utils.Util;

public class TC_2001_ScheduleTests {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityCode;
	public static String bugoID;
	public static String period;
	
	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		// LaunchApp
		Logs = new DriverScript();
		Logs.driveTestExecution("2001 TC01- To verify that the distributed schedule is received by the hub contributor");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "2001", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "2001", "Period");
		
		/*bugoID=HubContributor.getBUID(driver, Logs, TestType,
				"1F45CEB3-D705-4788-9BEC-2C3952501A5A", period);
		System.out.println(bugoID);
		
		entityCode=bugoID; // Here Entity Code and bugo id are same .
		System.out.println(entityCode); //Code to distribute schedule and get entity code 
				HubContributor.distributeSchedule(driver, Logs, TestType,bugoID, schedule, period); 
				driver.quit(); */
							
		entityCode="BU345";
		driver.quit();
			}

	@Test(priority = 0)
	@Parameters({ "TestType" })
	public static void tc01_verifyDistributedSchedule(String TestType) throws Exception {
		Form2001BG.verifyscheduleDistribution(driver, Logs, TestType, entityCode, schedule, period, "2001");
			}
	
	@AfterMethod
	public void afterMethod() {
      driver.quit();
	}
	
}