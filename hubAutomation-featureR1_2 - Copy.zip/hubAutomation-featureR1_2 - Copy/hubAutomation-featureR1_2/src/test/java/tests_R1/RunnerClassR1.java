package tests_R1;

import org.testng.TestNG;



public class RunnerClassR1 {
	
		static TestNG testNg;

		public static void main(String[] args) {
			
			testNg= new TestNG();
			
			testNg.setTestClasses(new Class[] {TC_1930D_SheduleTest.class});
			testNg.run();
		
			
		}

	}
