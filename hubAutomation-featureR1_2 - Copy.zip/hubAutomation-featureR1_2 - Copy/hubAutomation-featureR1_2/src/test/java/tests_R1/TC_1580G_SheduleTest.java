package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import Reports.DriverScript;
import pages.Form1580GPages;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;
public class TC_1580G_SheduleTest {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityShortDesc;


	@BeforeClass
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("1580G All field validations");
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "1580G", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "1580G", "Period");
		 //entityCode="5483";
		entityName = Util.getAllNecessaryData(TestType, "1580G", "EntityDetail");	
		//Schedule id for 1580='256226F1-05FF-44E9-955F-C26271F121A6'
		//We need to consider only US bugo ids for 1580
		String QueryTobugoID ="Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' "
				+ "and EntityStatus='A' and entityID not IN (select entityId from scheduleinstance where "
				+ "scheduleID='256226F1-05FF-44E9-955F-C26271F121A6' and periodid IN ('"+period+"')) and Country='US'";
		System.out.println(QueryTobugoID);
	    String bugoID=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryTobugoID, "BUStructure");
	    System.out.println(bugoID);
	    /** Uncomment above bugo id get data code and comment below hard code when final commit**/
	    //String bugoID="BU525GOUS";
	    
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		System.out.println(entityCode);
		
		/** Uncomment above two line and commnet below hard code when final commit**/

		 //entityCode="7932"; // Arindam
		//entityCode="7760"; //Prasanna
	
		String queryToGetShortDesc="select EntityShortDesc from masterdata.entity where entityCode="+"'"+entityCode+"'";
		entityShortDesc =DataBaseConnection.getData(driver, Logs, TestType, queryToGetShortDesc, "EntityShortDesc");
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		
	}
	
	@BeforeMethod
	public static void lauchBrowser() throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);

	}

	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void verifyScheduleDistribute1580G_TC01_TC02(String TestType) throws Exception {
	Form1580GPages.verifyScheduleDistributed(driver, entityCode, period, schedule, entityShortDesc, Logs);
	
	}
	
	@Test(priority=1)
	@Parameters({ "TestType" })
	public static void verify_transactionCode_SmartText_TC04(String TestType) throws Exception {
	Form1580GPages.verify_transactionCodeSmartText(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	/*@Test(priority=2)
	@Parameters({ "TestType" })
	public static void verify_countryCode_SmartText_TC05(String TestType) throws Exception {
	Form1580GPages.verify_CountryCodeSmartText(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	@Test(priority=3)
	@Parameters({ "TestType" })
	public static void verifyForeign_Affiliates_Field_Sch_A_TC06(String TestType) throws Exception {
	Form1580GPages.verify_Foreign_Affiliates_Schedule_A_Field(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	@Test(priority=4)
	@Parameters({ "TestType" })
	public static void verify_UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Field_TC07(String TestType) throws Exception {
	Form1580GPages.verify_UNAFFILIATED_FOREIGN_ENTITIES_Schedule_A_Field(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	
	@Test(priority=5)
	@Parameters({ "TestType" })
	public static void verify_SummaryReport_Schedule_A_TC08(String TestType) throws Exception {
	Form1580GPages.verify_SummaryReport_Schedule_A(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	@Test(priority=6)
	@Parameters({ "TestType" })
	public static void verify_transactionCode_SmartText_TC09(String TestType) throws Exception {
	Form1580GPages.verify_CountryDropDown_Sch_B(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	@Test(priority=7)
	@Parameters({ "TestType" })
	public static void verify_transactionCode_SmartText_TC10(String TestType) throws Exception {
	Form1580GPages.verify_scheduleBtransactionCodeSmartText(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	}
	
	@Test(priority=8)
	@Parameters({ "TestType" })
	public static void verifyForeign_Affiliates_Field_Sch_B_TC11(String TestType) throws Exception {
	Form1580GPages.verify_Foreign_Affiliates_Schedule_B_Field(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	@Test(priority=9)
	@Parameters({ "TestType" })
	public static void verify_UNAFFILIATED_FOREIGN_ENTITIES_Sch_A_Field_TC12(String TestType) throws Exception {
	Form1580GPages.verify_UNAFFILIATED_FOREIGN_ENTITIES_Schedule_B_Field(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	}

	@Test(priority=10)
	@Parameters({ "TestType" })
	public static void verify_SummaryReport_Schedule_B_TC13(String TestType) throws Exception {
	Form1580GPages.verify_SummaryReport_Schedule_B(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	}

	
	
	@Test(priority=11)
	@Parameters({ "TestType" })
	public static void verify_commentsInCommentaryField_TC14(String TestType) throws Exception {
	Form1580GPages.verify_commentsInCommentaryField(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	}
	
	
	@Test(priority=12)
	@Parameters({ "TestType" })
	public static void verify_Submit_WithCountryBlank_Schedule_A_Field_TC15(String TestType) throws Exception {
	Form1580GPages.verify_Submit_WithCountryBlank_Schedule_A_Field(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}
	
	@Test(priority=13)
	@Parameters({ "TestType" })
	public static void verify_Submit_WithCountryBlank_Schedule_B_Field_TC16(String TestType) throws Exception {
	Form1580GPages.verify_Submit_WithCountryBlank_Schedule_B_Field(driver, entityCode, period, schedule, entityShortDesc, Logs, TestType);
	
	}	
*/
	
	@AfterMethod
	public void QuitBrowser(){
//	driver.quit();
	}

	
}
