package tests_R1;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import Reports.DriverScript;
import pages.Form1580GPages;
import utils.DataBaseConnection;
import utils.HubContributor;
import utils.Login;
import utils.Util;
public class TC_1580G_SheduleTest_WithSubmit {
	static WebDriver driver;
	static DriverScript Logs;
	public static String schedule;
	public static String entityName;
	public static String entityCode;
	public static String period;
	public static String entityShortDesc;
	

	@BeforeClass
	public static void initializeLogs() throws Exception {
		Logs = new DriverScript();
		Logs.driveTestExecution("1580G All field validations");
	}
	
	@BeforeMethod
	@Parameters({ "TestType" })
	public static void initializeVaribales(String TestType) throws Exception {
		driver = Login.LaunchHub("Setupurl", Logs);
		schedule = Util.getAllNecessaryData(TestType, "1580G", "ScheduleName");
		period = Util.getAllNecessaryData(TestType, "1580G", "Period");
		 //entityCode="5483";
		entityName = Util.getAllNecessaryData(TestType, "1580G", "EntityDetail");	
		//Schedule id for 1580='256226F1-05FF-44E9-955F-C26271F121A6'
		//We need to consider only US bugo ids for 1580
		String QueryTobugoID ="Select distinct top 1 BUStructure from masterdata.entity where EntityType='R' "
				+ "and EntityStatus='A' and entityID not IN (select entityId from scheduleinstance where "
				+ "scheduleID='256226F1-05FF-44E9-955F-C26271F121A6' and periodid IN ('"+period+"')) and Country='US'";
		System.out.println(QueryTobugoID);
	    String bugoID=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryTobugoID, "BUStructure");
	    System.out.println(bugoID);
	    /** Uncomment above bugo id get data code and comment below hard code when final commit**/
	    //String bugoID="BU525GOUS";
	    
		String QueryToGetentityCode= "select  top 1 entitycode from masterdata.entity where "
				+ "bustructure='"+bugoID+"' and entitystatus='A' and entitytype='R'";
		entityCode=utils.DataBaseConnection.getData(driver, Logs, TestType, QueryToGetentityCode, "entitycode");
		System.out.println(entityCode);
		
		/** Uncomment above two line and comment below hard code when final commit**/
		 //entityCode="2326";//"7932"; // Arindam
		//entityCode="7760"; //Prasanna
		
		String queryToGetShortDesc="select EntityShortDesc from masterdata.entity where entityCode="+"'"+entityCode+"'";
		entityShortDesc =DataBaseConnection.getData(driver, Logs, TestType, queryToGetShortDesc, "EntityShortDesc");
		HubContributor.distributeSchedule(driver, Logs, TestType, bugoID, schedule, period);
		driver.quit();
		driver = Login.LaunchHub("Setupurl", Logs);
		
	}
	

	

	@Test(priority=0)
	@Parameters({ "TestType" })
	public static void verifyScheduleDistribute1580G_TC01_TC02(String TestType) throws Exception {
	Form1580GPages.verifyIfScheduleOwnerIsAbleToEditAfterDueDate(driver,entityCode, period, schedule, entityShortDesc, Logs, TestType,"1580G");

	}

	
	@AfterClass
	public void QuitBrowser(){
		//driver.quit();
	}

	
}
